"""Verify and reproduce the public paper release offline from frozen study inputs."""
import argparse, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def rebuilt_content(path):
    """Ignore only CRLF versus LF in regenerated text, never in frozen inputs."""
    data=path.read_bytes()
    if path.suffix in {'.csv','.tex','.json'}:
        data=data.replace(b'\r\n',b'\n')
    return data

def compare_rebuilt(reference, generated):
    return generated.is_file() and rebuilt_content(reference)==rebuilt_content(generated)

def verify(root=ROOT):
    # Release integrity is deliberately byte-exact, including line endings.
    manifest=json.loads((root/'RELEASE_MANIFEST.json').read_text(encoding='utf-8'))
    for entry in manifest['files']:
        p=root/entry['path']
        if not p.is_file() or p.stat().st_size!=entry['bytes'] or sha(p)!=entry['sha256']:
            raise RuntimeError('Release integrity mismatch: '+entry['path'])
    print(f"Verified {len(manifest['files'])} release files.",flush=True)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--verify-only',action='store_true'); ap.add_argument('--skip-pdf',action='store_true'); ap.add_argument('--build-dir',default='build/revision'); args=ap.parse_args()
    verify()
    if args.verify_only: return
    dest=(ROOT/args.build_dir).resolve()
    if ROOT not in dest.parents or dest.exists(): raise RuntimeError('Choose a new build directory inside the extracted release.')
    dest.mkdir(parents=True)
    for folder in ['code','notes','Paper/revision/latex']:
        shutil.copytree(ROOT/folder,dest/folder)
    # Only immutable source and nondeterministic/manual handoffs seed the rebuild.
    spec=json.loads((ROOT/'replication/frozen_inputs.json').read_text(encoding='utf-8'))
    for entry in spec['required_inputs']:
        src=ROOT/entry['path']; assert sha(src)==entry['sha256'],entry['path']
        target=dest/entry['path']; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,target)
    human='output/human-validation/human_validation_coding_workbook_50_letters_v20260807_completed.xlsx'
    (dest/human).parent.mkdir(parents=True,exist_ok=True); shutil.copy2(ROOT/human,dest/human)
    for folder in ['data/final','output/tables','output/figures','output/replication','notes']:
        (dest/folder).mkdir(parents=True,exist_ok=True)
    env=os.environ.copy(); env.pop('OPENAI_API_KEY',None); env['MPLBACKEND']='Agg'
    # Reuse the caller's ordinary font cache; its contents do not affect data results.
    env.setdefault('MPLCONFIGDIR',str(ROOT/'.mplconfig'))
    commands=[['02_build_panel.py','--pull-date','20260828'],['04_classify_deficiencies.py','--prepare-only'],['04_classify_deficiencies.py'],['05_validate_phase3.py'],['06_exploratory_analysis.py'],['07_phase4_analysis.py'],['08_extract_facility_passages.py'],['09_classify_facility_subcategories.py','--prepare-only'],['09_classify_facility_subcategories.py'],['10_validate_facility_subcategories.py'],['11_checkpoint5_remaining_tasks.py'],['12_checkpoint6_task_a.py'],['13_checkpoint6_remaining_tasks.py'],['14_checkpoint7_ocr_association.py'],['15_revision_analysis.py'],['19_application_summary.py'],['16_revision_validation.py']]
    runlog=[]
    for command in commands:
        log=dest/(command[0]+'.log')
        with log.open('w',encoding='utf-8') as f:
            result=subprocess.run([sys.executable,'code/'+command[0],*command[1:]],cwd=dest,env=env,stdout=f,stderr=subprocess.STDOUT)
        if result.returncode: raise RuntimeError(f'{command[0]} failed; see {log}')
        print('Reproduced '+command[0],flush=True); runlog.append(command[0])
    checks=[]
    references=sorted((ROOT/'data/final').glob('*.csv'))+sorted((ROOT/'output/revision/tables').glob('*.csv'))+sorted((ROOT/'output/revision/application-analysis').glob('*.csv'))+sorted((ROOT/'Paper/revision/latex/generated').glob('*.tex'))
    references += [ROOT/'output/revision/analysis_summary.json',ROOT/'output/revision/validation_report.json']
    for reference in references:
        rel=reference.relative_to(ROOT); generated=dest/rel
        if not compare_rebuilt(reference,generated): raise RuntimeError('Rebuilt data differs: '+str(rel))
        checks.append(rel.as_posix())
    if not args.skip_pdf:
        subprocess.run(['latexmk','-pdf','-interaction=nonstopmode','-halt-on-error','main.tex'],cwd=dest/'Paper/revision/latex',check=True,stdout=subprocess.DEVNULL)
        subprocess.run(['latexmk','-pdf','-interaction=nonstopmode','-halt-on-error','main-with-author.tex'],cwd=dest/'Paper/revision/latex',check=True,stdout=subprocess.DEVNULL)
    report={'status':'passed','network_calls':0,'new_model_calls':0,'comparison':'CRLF/LF-normalized regenerated text; byte-exact release and frozen inputs','stages':runlog,'matching_data_files':checks,'pdf_compiled':not args.skip_pdf}
    (dest/'reproduction_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'Complete: {len(checks)} reconstructed data files match the release.',flush=True)

if __name__=='__main__': main()
