#!/usr/bin/env python3
"""Revised Phase 4 descriptives and fixed-horizon second-CRL analysis."""

from __future__ import annotations

import csv
import json
import math
import os
import re
from pathlib import Path
from datetime import datetime
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".mplconfig"))
(ROOT / ".mplconfig").mkdir(exist_ok=True)

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


CATEGORIES = [
    "clinical_efficacy", "clinical_safety", "trial_design_conduct", "cmc",
    "facility_inspection", "stability_shelf_life", "bioequivalence_bioavailability",
    "nonclinical_toxicology", "labeling_proprietary_name", "administrative_procedural",
]
LABELS = {
    "clinical_efficacy": "Clinical efficacy",
    "clinical_safety": "Clinical safety",
    "trial_design_conduct": "Trial design/conduct",
    "cmc": "CMC",
    "facility_inspection": "Facility inspection",
    "stability_shelf_life": "Stability/shelf life",
    "bioequivalence_bioavailability": "Bioequivalence/availability",
    "nonclinical_toxicology": "Nonclinical/toxicology",
    "labeling_proprietary_name": "Labeling/name",
    "administrative_procedural": "Administrative/procedural",
}
COLORS = {
    "clinical_efficacy": "#2563eb",
    "clinical_safety": "#dc2626",
    "trial_design_conduct": "#7c3aed",
    "cmc": "#ea580c",
    "facility_inspection": "#0f766e",
    "stability_shelf_life": "#ca8a04",
    "bioequivalence_bioavailability": "#0891b2",
    "nonclinical_toxicology": "#65a30d",
    "labeling_proprietary_name": "#db2777",
    "administrative_procedural": "#64748b",
}


def find_vintage() -> str:
    paths = sorted((ROOT / "data" / "final").glob("analysis_panel_classified_v*.csv"))
    if len(paths) != 1:
        raise RuntimeError(f"Expected one classified panel, found {[p.name for p in paths]}")
    return re.search(r"_v(\d{8})\.csv$", paths[0].name).group(1)  # type: ignore[union-attr]


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def latex_escape(value: Any) -> str:
    text = str(value)
    for old, new in {
        "\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
        "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
    }.items():
        text = text.replace(old, new)
    return text


def write_latex(path: Path, headers: list[str], rows: list[list[Any]], alignment: str) -> None:
    lines = [
        f"\\begin{{tabular}}{{{alignment}}}", "\\toprule",
        " & ".join(latex_escape(x) for x in headers) + r" \\", "\\midrule",
    ]
    lines.extend(" & ".join(latex_escape(x) for x in row) + r" \\" for row in rows)
    lines.extend(["\\bottomrule", "\\end{tabular}", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def wilson(successes: int, n: int, z: float = 1.959964) -> tuple[float | None, float | None, float | None]:
    if n == 0:
        return None, None, None
    p = successes / n
    denominator = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denominator
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denominator
    return p, max(0.0, center - half), min(1.0, center + half)


def sponsor_group(value: Any) -> str:
    if pd.isna(value) or str(value).strip() == "":
        return "Unknown/unmatched"
    count = int(float(value))
    if count == 1:
        return "1 application"
    if count <= 9:
        return "2-9 applications"
    return "10+ applications"


def named_division_group(frame: pd.DataFrame, minimum_n: int = 10) -> pd.Series:
    raw = frame["review_division"].fillna("").astype(str).str.strip()
    counts = raw[raw.ne("")].value_counts()
    retained = set(counts[counts >= minimum_n].index)
    return raw.map(lambda x: "Unknown" if not x else (x if x in retained else "Other named divisions"))


def category_rows(frame: pd.DataFrame, group_name: str, group_value: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    category_sets = frame["deficiency_categories"].str.split("|").map(set)
    for category in CATEGORIES:
        primary_n = int(frame["primary_deficiency_category"].eq(category).sum())
        any_n = int(category_sets.map(lambda values: category in values).sum())
        rows.append({
            "group_dimension": group_name,
            "group": group_value,
            "sample_n": len(frame),
            "category": category,
            "primary_n": primary_n,
            "primary_share": round(primary_n / len(frame), 6) if len(frame) else None,
            "any_n": any_n,
            "any_share": round(any_n / len(frame), 6) if len(frame) else None,
        })
    return rows


def collapsed_primary(category: str) -> str:
    return {
        "facility_inspection": "facility",
        "cmc": "cmc",
        "clinical_efficacy": "efficacy",
        "clinical_safety": "safety",
        "nonclinical_toxicology": "nonclinical",
    }.get(category, "other")


def robust_lpm(frame: pd.DataFrame) -> list[dict[str, Any]]:
    work = frame.copy()
    work["primary_group"] = work["primary_deficiency_category"].map(collapsed_primary)
    work["event"] = work["second_crl_within_730d_event"].astype(int)
    work["bla"] = work["application_type"].eq("BLA").astype(int)
    work["year"] = pd.to_datetime(work["letter_date"]).dt.year.astype(float)
    year_mean = float(work["year"].mean())
    work["year_centered"] = work["year"] - year_mean

    columns = ["intercept", "cmc", "efficacy", "safety", "nonclinical", "other", "BLA", "first_crl_year"]
    matrix_columns = [np.ones(len(work))]
    for group in ["cmc", "efficacy", "safety", "nonclinical", "other"]:
        matrix_columns.append(work["primary_group"].eq(group).astype(float).to_numpy())
    matrix_columns.extend([work["bla"].to_numpy(dtype=float), work["year_centered"].to_numpy(dtype=float)])
    x = np.column_stack(matrix_columns)
    y = work["event"].to_numpy(dtype=float)
    xtx_inv = np.linalg.pinv(x.T @ x)
    beta = xtx_inv @ x.T @ y
    residual = y - x @ beta
    meat = x.T @ (x * residual[:, None] ** 2)
    n, k = x.shape
    covariance = (n / (n - k)) * xtx_inv @ meat @ xtx_inv
    se = np.sqrt(np.clip(np.diag(covariance), 0, None))
    rows: list[dict[str, Any]] = []
    labels = {
        "intercept": "Facility reference at mean year, NDA",
        "cmc": "CMC vs facility",
        "efficacy": "Clinical efficacy vs facility",
        "safety": "Clinical safety vs facility",
        "nonclinical": "Nonclinical/toxicology vs facility",
        "other": "Other primary categories vs facility",
        "BLA": "BLA vs NDA",
        "first_crl_year": "One-year increase in first-CRL year",
    }
    for name, estimate, standard_error in zip(columns, beta, se):
        rows.append({
            "term": name,
            "label": labels[name],
            "estimate": float(estimate),
            "robust_se_hc1": float(standard_error),
            "ci_low": float(estimate - 1.959964 * standard_error),
            "ci_high": float(estimate + 1.959964 * standard_error),
            "model_n": n,
            "events": int(y.sum()),
            "reference_primary_group": "facility",
            "year_center": year_mean,
        })
    return rows


def main() -> None:
    vintage = find_vintage()
    panel = pd.read_csv(
        ROOT / "data" / "final" / f"analysis_panel_classified_v{vintage}.csv",
        dtype=str,
        keep_default_na=False,
    )
    classified = panel.loc[panel["deficiency_categories"].ne("")].copy()
    strict = classified.loc[classified["is_strict_crl"].eq("1")].copy()
    first = strict.loc[strict["is_first_strict_crl"].eq("1")].copy()
    first["followup_days"] = pd.to_numeric(first["first_crl_followup_days"], errors="coerce")
    first["days_to_second"] = pd.to_numeric(first["days_first_to_second_crl"], errors="coerce")
    first["letter_year"] = pd.to_datetime(first["letter_date"]).dt.year
    tables = ROOT / "output" / "tables"
    figures = ROOT / "output" / "figures"
    tables.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)

    recent = classified.loc[classified["letter_date"].ge("2024-01-01")]
    comparison: list[dict[str, Any]] = []
    for category in CATEGORIES:
        full_n = int(classified["primary_deficiency_category"].eq(category).sum())
        recent_n = int(recent["primary_deficiency_category"].eq(category).sum())
        full_share = full_n / len(classified)
        recent_share = recent_n / len(recent)
        comparison.append({
            "category": category,
            "full_sample_n": len(classified),
            "full_primary_n": full_n,
            "full_primary_share": round(full_share, 6),
            "2024_forward_sample_n": len(recent),
            "2024_forward_primary_n": recent_n,
            "2024_forward_primary_share": round(recent_share, 6),
            "difference_2024_forward_minus_full": round(recent_share - full_share, 6),
        })
    write_csv(
        tables / f"phase4_primary_category_comparison_v{vintage}.csv",
        comparison,
        [
            "category", "full_sample_n", "full_primary_n", "full_primary_share",
            "2024_forward_sample_n", "2024_forward_primary_n", "2024_forward_primary_share",
            "difference_2024_forward_minus_full",
        ],
    )
    write_latex(
        tables / f"phase4_primary_category_comparison_v{vintage}.tex",
        ["Category", "Full N", "Full share", "2024+ N", "2024+ share", "Difference"],
        [[
            LABELS[row["category"]], row["full_primary_n"], f"{row['full_primary_share']:.1%}",
            row["2024_forward_primary_n"], f"{row['2024_forward_primary_share']:.1%}",
            f"{row['difference_2024_forward_minus_full']:+.1%}",
        ] for row in comparison],
        "lrrrrr",
    )

    classified["calendar_year"] = pd.to_datetime(classified["letter_date"]).dt.year
    time_rows: list[dict[str, Any]] = []
    for year, frame in classified.groupby("calendar_year"):
        for row in category_rows(frame, "calendar_year", str(year)):
            time_rows.append({"calendar_year": year, **{k: v for k, v in row.items() if k != "group_dimension"}})
    write_csv(
        tables / f"phase4_category_by_year_v{vintage}.csv",
        time_rows,
        ["calendar_year", "group", "sample_n", "category", "primary_n", "primary_share", "any_n", "any_share"],
    )

    def era(year: int) -> str:
        if year <= 2014:
            return "2002-2014"
        if year <= 2019:
            return "2015-2019"
        if year <= 2023:
            return "2020-2023"
        return "2024-2026"

    classified["era"] = classified["calendar_year"].map(era)
    era_order = ["2002-2014", "2015-2019", "2020-2023", "2024-2026"]
    era_rows: list[dict[str, Any]] = []
    for era_name in era_order:
        era_rows.extend(category_rows(classified.loc[classified["era"].eq(era_name)], "era", era_name))
    write_csv(
        tables / f"phase4_category_by_era_v{vintage}.csv",
        era_rows,
        ["group_dimension", "group", "sample_n", "category", "primary_n", "primary_share", "any_n", "any_share"],
    )

    app_type_rows: list[dict[str, Any]] = []
    for group_name, frame in classified.groupby("application_type"):
        app_type_rows.extend(category_rows(frame, "application_type", group_name))
    write_csv(
        tables / f"phase4_category_by_application_type_v{vintage}.csv",
        app_type_rows,
        ["group_dimension", "group", "sample_n", "category", "primary_n", "primary_share", "any_n", "any_share"],
    )

    classified["sponsor_size_group"] = classified["sponsor_application_count"].map(sponsor_group)
    sponsor_rows: list[dict[str, Any]] = []
    for group_name, frame in classified.groupby("sponsor_size_group"):
        sponsor_rows.extend(category_rows(frame, "sponsor_size", group_name))
    write_csv(
        tables / f"phase4_category_by_sponsor_size_v{vintage}.csv",
        sponsor_rows,
        ["group_dimension", "group", "sample_n", "category", "primary_n", "primary_share", "any_n", "any_share"],
    )

    classified["division_group"] = named_division_group(classified)
    division_rows: list[dict[str, Any]] = []
    for group_name, frame in classified.groupby("division_group"):
        division_rows.extend(category_rows(frame, "review_division", group_name))
    write_csv(
        tables / f"phase4_category_by_review_division_v{vintage}.csv",
        division_rows,
        ["group_dimension", "group", "sample_n", "category", "primary_n", "primary_share", "any_n", "any_share"],
    )

    horizon_rows: list[dict[str, Any]] = []
    for horizon in [365, 730, 1095]:
        horizon_sample = first.loc[first["followup_days"].ge(horizon)].copy()
        horizon_sample["event"] = horizon_sample["days_to_second"].le(horizon).fillna(False).astype(int)
        for category in CATEGORIES:
            group = horizon_sample.loc[horizon_sample["primary_deficiency_category"].eq(category)]
            event_n = int(group["event"].sum())
            rate, low, high = wilson(event_n, len(group))
            horizon_rows.append({
                "horizon_days": horizon,
                "category": category,
                "eligible_n": len(group),
                "event_n": event_n,
                "event_rate": rate,
                "ci_low_wilson": low,
                "ci_high_wilson": high,
            })
        for composite in ["all", "cmc_or_facility_primary", "other_primary"]:
            if composite == "all":
                group = horizon_sample
            else:
                is_manufacturing = horizon_sample["primary_deficiency_category"].isin(["cmc", "facility_inspection"])
                group = horizon_sample.loc[is_manufacturing if composite == "cmc_or_facility_primary" else ~is_manufacturing]
            event_n = int(group["event"].sum())
            rate, low, high = wilson(event_n, len(group))
            horizon_rows.append({
                "horizon_days": horizon,
                "category": composite,
                "eligible_n": len(group),
                "event_n": event_n,
                "event_rate": rate,
                "ci_low_wilson": low,
                "ci_high_wilson": high,
            })
    write_csv(
        tables / f"phase4_second_crl_rates_by_horizon_v{vintage}.csv",
        horizon_rows,
        ["horizon_days", "category", "eligible_n", "event_n", "event_rate", "ci_low_wilson", "ci_high_wilson"],
    )

    main_rates = [row for row in horizon_rows if row["horizon_days"] == 730 and row["category"] in CATEGORIES]
    write_latex(
        tables / f"phase4_second_crl_rates_730d_v{vintage}.tex",
        ["First-CRL primary category", "Eligible N", "Second CRL", "Rate", "95% CI"],
        [[
            LABELS[row["category"]], row["eligible_n"], row["event_n"],
            "--" if row["event_rate"] is None else f"{row['event_rate']:.1%}",
            "--" if row["ci_low_wilson"] is None else f"[{row['ci_low_wilson']:.1%}, {row['ci_high_wilson']:.1%}]",
        ] for row in main_rates],
        "lrrrr",
    )

    eligible_730 = first.loc[first["followup_days"].ge(730)].copy()
    eligible_730["second_crl_within_730d_event"] = eligible_730["days_to_second"].le(730).fillna(False).astype(int)
    sensitivity_rows: list[dict[str, Any]] = []
    for sample_name, frame in [
        ("all_eligible", eligible_730),
        ("classification_status_ok", eligible_730.loc[eligible_730["classification_status"].eq("ok")]),
        ("zero_redaction_markers", eligible_730.loc[pd.to_numeric(eligible_730["redaction_marker_count"], errors="coerce").fillna(0).eq(0)]),
    ]:
        for category in CATEGORIES:
            group = frame.loc[frame["primary_deficiency_category"].eq(category)]
            events = int(group["second_crl_within_730d_event"].sum())
            rate, low, high = wilson(events, len(group))
            sensitivity_rows.append({
                "sample": sample_name, "category": category, "eligible_n": len(group),
                "event_n": events, "event_rate": rate, "ci_low_wilson": low, "ci_high_wilson": high,
            })
        for composite in ["all", "cmc_or_facility_primary", "other_primary"]:
            if composite == "all":
                group = frame
            else:
                is_manufacturing = frame["primary_deficiency_category"].isin(["cmc", "facility_inspection"])
                group = frame.loc[is_manufacturing if composite == "cmc_or_facility_primary" else ~is_manufacturing]
            events = int(group["second_crl_within_730d_event"].sum())
            rate, low, high = wilson(events, len(group))
            sensitivity_rows.append({
                "sample": sample_name, "category": composite, "eligible_n": len(group),
                "event_n": events, "event_rate": rate, "ci_low_wilson": low, "ci_high_wilson": high,
            })
    write_csv(
        tables / f"phase4_second_crl_classification_sensitivity_v{vintage}.csv",
        sensitivity_rows,
        ["sample", "category", "eligible_n", "event_n", "event_rate", "ci_low_wilson", "ci_high_wilson"],
    )

    lpm_rows = robust_lpm(eligible_730)
    write_csv(
        tables / f"phase4_second_crl_lpm_v{vintage}.csv",
        lpm_rows,
        ["term", "label", "estimate", "robust_se_hc1", "ci_low", "ci_high", "model_n", "events", "reference_primary_group", "year_center"],
    )
    write_latex(
        tables / f"phase4_second_crl_lpm_v{vintage}.tex",
        ["Term", "Estimate", "Robust SE", "95% CI"],
        [[row["label"], f"{row['estimate']:.3f}", f"{row['robust_se_hc1']:.3f}",
          f"[{row['ci_low']:.3f}, {row['ci_high']:.3f}]"] for row in lpm_rows],
        "lrrr",
    )

    plt.rcParams.update({"font.size": 9, "axes.titlesize": 12, "axes.labelsize": 10})
    ordered = sorted(comparison, key=lambda row: row["full_primary_share"])
    y = np.arange(len(ordered))
    fig, ax = plt.subplots(figsize=(9.0, 6.0))
    ax.barh(y - 0.19, [r["full_primary_share"] * 100 for r in ordered], height=0.36,
            color="#64748b", label="Full (N=449)")
    ax.barh(y + 0.19, [r["2024_forward_primary_share"] * 100 for r in ordered], height=0.36,
            color="#2563eb", label="2024-forward (N=158)")
    ax.set_yticks(y, [LABELS[r["category"]] for r in ordered])
    ax.set(title="Primary deficiency categories: full vs 2024-forward", xlabel="Share of deficiency actions (%)")
    ax.legend(frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(figures / f"phase4_primary_category_comparison_v{vintage}.pdf", bbox_inches="tight")
    plt.close(fig)

    era_frame = pd.DataFrame(era_rows)
    fig, ax = plt.subplots(figsize=(9.2, 5.4))
    bottom = np.zeros(len(era_order))
    for category in CATEGORIES:
        values = np.array([
            float(era_frame.loc[(era_frame["group"] == era_name) & (era_frame["category"] == category), "primary_share"].iloc[0]) * 100
            for era_name in era_order
        ])
        ax.bar(era_order, values, bottom=bottom, color=COLORS[category], label=LABELS[category])
        bottom += values
    ax.set(title="Primary deficiency-category mix over time", ylabel="Share of classified actions (%)", xlabel="Letter period")
    ax.set_ylim(0, 100)
    ax.legend(frameon=False, bbox_to_anchor=(1.02, 1), loc="upper left")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(figures / f"phase4_category_mix_over_time_v{vintage}.pdf", bbox_inches="tight")
    plt.close(fig)

    rate_plot = [row for row in main_rates if row["eligible_n"] > 0]
    rate_plot.sort(key=lambda row: row["event_rate"])
    y = np.arange(len(rate_plot))
    estimates = np.array([row["event_rate"] for row in rate_plot]) * 100
    low = np.array([row["ci_low_wilson"] for row in rate_plot]) * 100
    high = np.array([row["ci_high_wilson"] for row in rate_plot]) * 100
    fig, ax = plt.subplots(figsize=(9.0, 5.8))
    ax.errorbar(estimates, y, xerr=np.vstack([estimates - low, high - estimates]), fmt="o",
                color="#0f766e", ecolor="#94a3b8", capsize=3)
    ax.set_yticks(y, [f"{LABELS[r['category']]} (N={r['eligible_n']})" for r in rate_plot])
    ax.set(title="Second CRL within 730 days by first-CRL primary category",
           xlabel="Event rate with Wilson 95% CI (%)", ylabel="")
    ax.axvline(20, color="#cbd5e1", linewidth=1, linestyle="--", label="Overall: 20.0%")
    ax.legend(frameon=False, loc="lower right")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(figures / f"phase4_second_crl_rates_730d_v{vintage}.pdf", bbox_inches="tight")
    plt.close(fig)

    app_frame = pd.DataFrame(app_type_rows)
    fig, ax = plt.subplots(figsize=(9.0, 6.0))
    y = np.arange(len(CATEGORIES))
    nda = [float(app_frame.loc[(app_frame["group"] == "NDA") & (app_frame["category"] == c), "primary_share"].iloc[0]) * 100 for c in CATEGORIES]
    bla = [float(app_frame.loc[(app_frame["group"] == "BLA") & (app_frame["category"] == c), "primary_share"].iloc[0]) * 100 for c in CATEGORIES]
    ax.scatter(nda, y, color="#2563eb", label="NDA", zorder=3)
    ax.scatter(bla, y, color="#ea580c", label="BLA", zorder=3)
    for i in range(len(CATEGORIES)):
        ax.plot([nda[i], bla[i]], [i, i], color="#cbd5e1", zorder=1)
    ax.set_yticks(y, [LABELS[c] for c in CATEGORIES])
    ax.set(title="Primary deficiency categories by application type", xlabel="Share of classified actions (%)", ylabel="")
    ax.legend(frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(figures / f"phase4_category_by_application_type_v{vintage}.pdf", bbox_inches="tight")
    plt.close(fig)

    summary = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "data_vintage": vintage,
        "classified_deficiency_actions_n": len(classified),
        "classified_2024_forward_n": len(recent),
        "first_strict_crl_applications_n": len(first),
        "primary_horizon_days": 730,
        "primary_horizon_eligible_n": len(eligible_730),
        "primary_horizon_event_n": int(eligible_730["second_crl_within_730d_event"].sum()),
        "primary_horizon_event_rate": float(eligible_730["second_crl_within_730d_event"].mean()),
        "horizon_eligible_and_event_counts": {
            str(horizon): {
                "eligible_n": next(row["eligible_n"] for row in horizon_rows if row["horizon_days"] == horizon and row["category"] == "all"),
                "event_n": next(row["event_n"] for row in horizon_rows if row["horizon_days"] == horizon and row["category"] == "all"),
            }
            for horizon in [365, 730, 1095]
        },
        "review_division_missing_first_crl_n": int(first["review_division"].eq("").sum()),
        "sponsor_size_missing_first_crl_n": int(first["sponsor_application_count"].eq("").sum()),
        "duration_models_run": False,
        "duration_models_omission_reason": (
            "Observable approval outcomes are selected on approval, and amendment dates identify failed cycles; "
            "the 2024-forward sample lacks broadly observable outcomes."
        ),
        "lpm_model_n": lpm_rows[0]["model_n"],
        "lpm_events": lpm_rows[0]["events"],
        "lpm_terms": {row["term"]: {"estimate": row["estimate"], "ci_low": row["ci_low"], "ci_high": row["ci_high"]} for row in lpm_rows},
    }
    (ROOT / "data" / "interim" / f"phase4_summary_v{vintage}.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    print(
        f"Phase 4 complete: {len(classified)} classified actions; {len(eligible_730)} "
        f"730-day-eligible first CRLs; {int(eligible_730['second_crl_within_730d_event'].sum())} events."
    )


if __name__ == "__main__":
    main()
