#!/usr/bin/env python3
"""Validate Phase 3 classifications and create checkpoint tables.

This script intentionally refuses to report partial model results.  It runs only after
every segmented deficiency action has one structured classification.
"""

from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import math
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
CATEGORIES = [
    "clinical_efficacy", "clinical_safety", "trial_design_conduct", "cmc",
    "facility_inspection", "stability_shelf_life", "bioequivalence_bioavailability",
    "nonclinical_toxicology", "labeling_proprietary_name", "administrative_procedural",
]


def current_prompt_sha256() -> str:
    path = ROOT / "code" / "04_classify_deficiencies.py"
    spec = importlib.util.spec_from_file_location("crl_primary_classifier", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load classifier prompt from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return hashlib.sha256(module.prompt_text().encode("utf-8")).hexdigest()


def find_vintage() -> str:
    paths = sorted((ROOT / "data" / "interim").glob("deficiency_segments_v*.jsonl"))
    if len(paths) != 1:
        raise RuntimeError(f"Expected one segment file, found {[p.name for p in paths]}")
    return re.search(r"_v(\d{8})\.jsonl$", paths[0].name).group(1)  # type: ignore[union-attr]


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def latex_escape(value: Any) -> str:
    text = str(value)
    replacements = {
        "\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
        "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text


def write_latex_table(
    path: Path,
    headers: list[str],
    rows: list[list[Any]],
    alignment: str,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        f"\\begin{{tabular}}{{{alignment}}}",
        "\\toprule",
        " & ".join(latex_escape(value) for value in headers) + r" \\",
        "\\midrule",
    ]
    lines.extend(" & ".join(latex_escape(value) for value in row) + r" \\" for row in rows)
    lines.extend(["\\bottomrule", "\\end{tabular}", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def cohens_kappa(manual: list[str], model: list[str]) -> tuple[float, float, float]:
    n = len(manual)
    observed = sum(a == b for a, b in zip(manual, model)) / n
    mc = Counter(manual)
    lc = Counter(model)
    expected = sum((mc[c] / n) * (lc[c] / n) for c in CATEGORIES)
    kappa = (observed - expected) / (1 - expected) if expected < 1 else 1.0
    return observed, expected, kappa


def two_prop_pvalue(success_a: int, n_a: int, success_b: int, n_b: int) -> float | None:
    if not n_a or not n_b:
        return None
    pooled = (success_a + success_b) / (n_a + n_b)
    se = math.sqrt(pooled * (1 - pooled) * (1 / n_a + 1 / n_b))
    if se == 0:
        return 1.0
    z = abs(success_a / n_a - success_b / n_b) / se
    return math.erfc(z / math.sqrt(2))


def category_table(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    samples = {
        "full_deficiency_actions": rows,
        "2024_forward_deficiency_actions": [r for r in rows if r["letter_date"] >= "2024-01-01"],
    }
    for sample_name, sample in samples.items():
        for category in CATEGORIES:
            primary_n = sum(r["primary_category"] == category for r in sample)
            any_n = sum(category in r["categories"] for r in sample)
            output.append({
                "sample": sample_name,
                "sample_n": len(sample),
                "category": category,
                "primary_n": primary_n,
                "primary_share": round(primary_n / len(sample), 6) if sample else None,
                "any_n": any_n,
                "any_share": round(any_n / len(sample), 6) if sample else None,
            })
    return output


def redaction_table(rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    positive = sorted(
        [r for r in rows if r["redaction_marker_count"] > 0],
        key=lambda r: (r["redaction_markers_per_1000_chars"], r["letter_id"]),
    )
    light = [r for r in rows if r["redaction_marker_count"] == 0]
    cutoff_index = max(0, math.ceil(0.75 * len(positive)) - 1)
    cutoff = positive[cutoff_index]["redaction_markers_per_1000_chars"] if positive else math.inf
    heavy = [r for r in positive if r["redaction_markers_per_1000_chars"] >= cutoff]
    output: list[dict[str, Any]] = []
    comparison_categories = CATEGORIES + ["cmc_or_facility"]
    for category in comparison_categories:
        def has_category(row: dict[str, Any]) -> bool:
            if category == "cmc_or_facility":
                return "cmc" in row["categories"] or "facility_inspection" in row["categories"]
            return category in row["categories"]

        light_n = sum(has_category(r) for r in light)
        heavy_n = sum(has_category(r) for r in heavy)
        output.append({
            "category": category,
            "light_definition": "zero visible redaction markers",
            "heavy_definition": "top quartile of marker density among marker-positive letters",
            "light_sample_n": len(light),
            "heavy_sample_n": len(heavy),
            "light_any_n": light_n,
            "heavy_any_n": heavy_n,
            "light_any_share": round(light_n / len(light), 6) if light else None,
            "heavy_any_share": round(heavy_n / len(heavy), 6) if heavy else None,
            "heavy_minus_light": round(heavy_n / len(heavy) - light_n / len(light), 6)
            if light and heavy else None,
            "two_sided_two_proportion_p": two_prop_pvalue(heavy_n, len(heavy), light_n, len(light)),
        })
    meta = {
        "marker_positive_n": len(positive),
        "light_n": len(light),
        "heavy_n": len(heavy),
        "heavy_density_cutoff_per_1000_chars": cutoff if positive else None,
    }
    return output, meta


def repeated_application_table(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_application: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        by_application.setdefault(row["application_id"], []).append(row)
    output: list[dict[str, Any]] = []
    for application_id, letters in sorted(by_application.items()):
        if len(letters) < 2:
            continue
        ordered = sorted(letters, key=lambda row: (row["letter_date"], row["letter_id"]))
        primary_sequence = [row["primary_category"] for row in ordered]
        category_sets = [tuple(sorted(set(row["categories"]))) for row in ordered]
        output.append({
            "application_id": application_id,
            "letter_n": len(ordered),
            "first_letter_date": ordered[0]["letter_date"],
            "last_letter_date": ordered[-1]["letter_date"],
            "letter_ids": "|".join(row["letter_id"] for row in ordered),
            "primary_category_sequence": "|".join(primary_sequence),
            "category_sets_sequence": ";".join("+".join(values) for values in category_sets),
            "primary_category_changed": int(len(set(primary_sequence)) > 1),
            "any_category_set_changed": int(len(set(category_sets)) > 1),
        })
    return output


def main() -> None:
    vintage = find_vintage()
    interim = ROOT / "data" / "interim"
    final = ROOT / "data" / "final"
    output_tables = ROOT / "output" / "tables"
    segments = read_jsonl(interim / f"deficiency_segments_v{vintage}.jsonl")
    classifications = read_jsonl(interim / f"llm_deficiency_classifications_v{vintage}.jsonl")
    by_id = {row["letter_id"]: row for row in classifications}
    missing = [row for row in segments if row["letter_id"] not in by_id]
    if missing:
        raise SystemExit(
            f"Phase 3 classification is incomplete: {len(classifications)}/{len(segments)} present; "
            f"{len(missing)} missing. First missing: {missing[0]['letter_id']}"
        )
    if len(by_id) != len(classifications):
        raise RuntimeError("Duplicate letter_id values in classification JSONL")
    expected_prompt_hash = current_prompt_sha256()
    observed_prompt_hashes = {row.get("prompt_sha256", "") for row in classifications}
    if observed_prompt_hashes != {expected_prompt_hash}:
        raise RuntimeError(
            "Frozen classifications do not match the current classifier prompt: "
            f"expected={expected_prompt_hash}, observed={sorted(observed_prompt_hashes)}"
        )
    response_ids = [row.get("response_id", "") for row in classifications]
    if any(not value for value in response_ids) or len(response_ids) != len(set(response_ids)):
        raise RuntimeError("Classification response IDs must be present and unique")

    merged: list[dict[str, Any]] = []
    for segment in segments:
        model = by_id[segment["letter_id"]]
        if model.get("segment_sha256") != segment.get("segment_sha256"):
            raise RuntimeError(f"Stale classification for {segment['letter_id']}: segment hash changed")
        merged.append({**segment, **model})

    validation_path = ROOT / "data" / "manual" / f"classification_validation_sample_v{vintage}.csv"
    with validation_path.open(encoding="utf-8-sig", newline="") as handle:
        validation = list(csv.DictReader(handle))
    manual_primary = [row["manual_primary_category"] for row in validation]
    model_primary = [by_id[row["letter_id"]]["primary_category"] for row in validation]
    observed, expected, kappa = cohens_kappa(manual_primary, model_primary)
    disagreements: list[dict[str, Any]] = []
    for row in validation:
        model = by_id[row["letter_id"]]
        if row["manual_primary_category"] != model["primary_category"]:
            disagreements.append({
                "letter_id": row["letter_id"],
                "application_id": row["application_id"],
                "letter_date": row["letter_date"],
                "manual_primary_category": row["manual_primary_category"],
                "model_primary_category": model["primary_category"],
                "manual_categories": row["manual_categories"],
                "model_categories": "|".join(model["categories"]),
                "manual_notes": row["manual_notes"],
                "model_rationale": model["rationale"],
            })

    categories = category_table(merged)
    redaction, redaction_meta = redaction_table(merged)
    repeated_applications_all = repeated_application_table(merged)
    repeated_applications_strict = repeated_application_table(
        [row for row in merged if row.get("letter_type") == "COMPLETE RESPONSE"]
    )
    write_csv(
        output_tables / f"phase3_category_distribution_v{vintage}.csv",
        categories,
        ["sample", "sample_n", "category", "primary_n", "primary_share", "any_n", "any_share"],
    )
    write_csv(
        output_tables / f"phase3_redaction_comparison_v{vintage}.csv",
        redaction,
        [
            "category", "light_definition", "heavy_definition", "light_sample_n", "heavy_sample_n",
            "light_any_n", "heavy_any_n", "light_any_share", "heavy_any_share",
            "heavy_minus_light", "two_sided_two_proportion_p",
        ],
    )
    write_csv(
        output_tables / f"phase3_validation_disagreements_v{vintage}.csv",
        disagreements,
        [
            "letter_id", "application_id", "letter_date", "manual_primary_category",
            "model_primary_category", "manual_categories", "model_categories", "manual_notes",
            "model_rationale",
        ],
    )
    write_csv(
        output_tables / f"phase3_repeated_application_changes_v{vintage}.csv",
        repeated_applications_strict,
        [
            "application_id", "letter_n", "first_letter_date", "last_letter_date",
            "letter_ids", "primary_category_sequence", "category_sets_sequence",
            "primary_category_changed", "any_category_set_changed",
        ],
    )
    write_latex_table(
        output_tables / f"phase3_category_distribution_v{vintage}.tex",
        ["Sample", "Category", "Primary N", "Primary share", "Any N", "Any share"],
        [
            [
                row["sample"], row["category"], row["primary_n"],
                f"{row['primary_share']:.1%}", row["any_n"], f"{row['any_share']:.1%}",
            ]
            for row in categories
        ],
        "llrrrr",
    )
    write_latex_table(
        output_tables / f"phase3_redaction_comparison_v{vintage}.tex",
        ["Category", "Light N", "Heavy N", "Light share", "Heavy share", "Difference", "p-value"],
        [
            [
                row["category"], row["light_any_n"], row["heavy_any_n"],
                f"{row['light_any_share']:.1%}", f"{row['heavy_any_share']:.1%}",
                f"{row['heavy_minus_light']:+.1%}", f"{row['two_sided_two_proportion_p']:.3g}",
            ]
            for row in redaction
        ],
        "lrrrrrr",
    )
    write_latex_table(
        output_tables / f"phase3_validation_summary_v{vintage}.tex",
        ["Metric", "Value"],
        [
            ["Validation sample", len(validation)],
            ["Primary-category agreement", f"{observed:.1%}"],
            ["Chance-expected agreement", f"{expected:.1%}"],
            ["Cohen's kappa", f"{kappa:.3f}"],
            ["Primary-category disagreements", len(disagreements)],
        ],
        "lr",
    )

    panel_path = final / f"analysis_panel_v{vintage}.csv"
    with panel_path.open(encoding="utf-8-sig", newline="") as handle:
        panel = list(csv.DictReader(handle))
        panel_fields = list(panel[0].keys())
    classification_fields = [
        "deficiency_categories", "primary_deficiency_category", "new_clinical_trial_required",
        "third_party_manufacturer", "otherwise_approvable", "classification_status",
        "classification_rationale", "redaction_marker_count", "redaction_markers_per_1000_chars",
    ]
    for row in panel:
        model = by_id.get(row["letter_id"])
        segment = next((x for x in segments if x["letter_id"] == row["letter_id"]), None)
        row.update({field: "" for field in classification_fields})
        if model and segment:
            row.update({
                "deficiency_categories": "|".join(model["categories"]),
                "primary_deficiency_category": model["primary_category"],
                "new_clinical_trial_required": int(model["new_clinical_trial_required"]),
                "third_party_manufacturer": model["third_party_manufacturer"],
                "otherwise_approvable": model["otherwise_approvable"],
                "classification_status": model["classification_status"],
                "classification_rationale": model["rationale"],
                "redaction_marker_count": segment["redaction_marker_count"],
                "redaction_markers_per_1000_chars": segment["redaction_markers_per_1000_chars"],
            })
    write_csv(final / f"analysis_panel_classified_v{vintage}.csv", panel, panel_fields + classification_fields)

    uncertain = [r for r in merged if r["classification_status"] != "ok"]
    usage_input_tokens = sum(r.get("usage", {}).get("input_tokens", 0) for r in merged)
    usage_output_tokens = sum(r.get("usage", {}).get("output_tokens", 0) for r in merged)
    summary = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "data_vintage": vintage,
        "classified_n": len(merged),
        "full_sample_n": len(merged),
        "census_window_n": sum(r["letter_date"] >= "2024-01-01" for r in merged),
        "validation_n": len(validation),
        "primary_agreement": observed,
        "chance_expected_agreement": expected,
        "cohens_kappa": kappa,
        "validation_disagreement_n": len(disagreements),
        "passes_prespecified_agreement_threshold": observed >= 0.75,
        "classification_uncertain_or_failed_n": len(uncertain),
        "classification_uncertain_or_failed_files": [r["file_name"] for r in uncertain],
        "classification_status_counts": dict(Counter(r["classification_status"] for r in merged)),
        "model": sorted(set(r.get("response_model") for r in merged)),
        "reasoning_effort": sorted(set(r.get("requested_reasoning_effort") for r in merged)),
        "usage_input_tokens": usage_input_tokens,
        "usage_output_tokens": usage_output_tokens,
        "approximate_api_cost_usd_at_2_input_12_output_per_million": round(
            usage_input_tokens * 2 / 1_000_000 + usage_output_tokens * 12 / 1_000_000, 4
        ),
        "redaction_comparison": redaction_meta,
        "repeated_application_n": len(repeated_applications_strict),
        "repeated_application_primary_changed_n": sum(
            r["primary_category_changed"] for r in repeated_applications_strict
        ),
        "repeated_application_any_category_set_changed_n": sum(
            r["any_category_set_changed"] for r in repeated_applications_strict
        ),
        "repeated_application_all_classified_actions_n": len(repeated_applications_all),
        "strict_crl_successor_letter_n": sum(
            r["letter_n"] - 1 for r in repeated_applications_strict
        ),
    }
    (interim / f"phase3_validation_summary_v{vintage}.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        f"Validated {len(merged)} classifications: agreement={observed:.3f}, "
        f"kappa={kappa:.3f}, disagreements={len(disagreements)}."
    )


if __name__ == "__main__":
    main()
