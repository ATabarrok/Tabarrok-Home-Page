"""Record an LLM-assisted source-text review of the 28 facility first-pair recurrences.
Decisions below are case assessments, not automated matches or human validation.
Rebuilds the audit trail and verifies source evidence against the frozen FDA text.
"""
import csv,json,re
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/revision/facility-recurrence-check'
# Same plant requires matching FEI or a sufficiently specific plant/unit/location.
IDENTIFIED={
 'BLA761225':('Hugel; FEI 3012163998','3012163998','3012163998'),
 'BLA761299':('Alvotech hf; Reykjavik, Iceland; FEI 3013702557','3013702557','3013702557'),
 'NDA204311':('Mylan Laboratories Unit 8 in both letters; FEI transcription differs by an extra zero','Mylan Laboratories Limited, Unit 8','Mylan Laboratories Limited Unit-8'),
 'NDA204957':('B. Braun Medical; FEI 2021236','2021236','2021236'),
 'NDA206185':('Sun Pharmaceutical Industries; Halol, India in both letters','Halol, India','Halol, India'),
 'NDA208574':('Teva Pharmaceutical Works; FEI 3002875215','3002875215','3002875215'),
 'NDA208742':('Ocular Therapeutix; FEI 3008477155','3008477155','3008477155'),
 'NDA210526':('Tris Pharma; FEI 3004712471','3004712471','3004712471'),
 'NDA210649':('Macleods Pharmaceuticals; FEI 3007517881','3007517881','3007517881'),
 'NDA214520':('Rovi Pharma Industrial Services; FEI 3016688535 recurs; later letter also cites another redacted facility','3016688535','3016688535'),
}
NARRATIVE={
 'BLA761147':('Multiple previous inspections and insufficient evidence of resolution support continuity, but plant identity is redacted','Following pre-license inspection','The responses from the facility provided insufficient evidence'),
 'BLA761308':('Later letter explicitly reports re-inspection, supporting continuity; plant identity is redacted','Following pre-license inspection','Following the re-inspection'),
}
INDETERMINATE={
 'BLA761219':'Manufacturing plant identities are obscured in both letters; separate CMO device observations in the second are explicitly not approvability issues.',
 'BLA761266':'Plant identities are obscured; first describes a pre-license inspection, second a remote regulatory assessment. Neither identifies a common inspection episode.',
 'BLA761271':'Drug product facility identities are obscured; common facility role and general CGMP wording do not establish the same plant.',
 'BLA761376':'Plant identities and substantial surrounding text are obscured. Remaining objectionable conditions in the first letter do not establish persistence into the second.',
 'BLA761377':'First letter cites several obscured facilities; second cites an obscured facility. Cannot determine which plant recurs.',
 'NDA208313':'Both name Sun Pharmaceutical Industries, but only the second identifies FEI 3002809586. A common manufacturer without a location or identifier in the first is insufficient to confirm the same plant.',
 'NDA209510':'Plant identities obscured in both letters; generic inspection deficiency language only.',
 'NDA210852':'First names Dr. Reddy and FEI 3006549835; second obscures both manufacturer and FEI, preventing confirmation.',
 'NDA212501':'Plant identities obscured in both letters. Request for a statement that issues are resolved is a remedy, not explicit identification of an earlier unresolved finding.',
 'NDA214952':'First letter cites multiple obscured facilities and assessment types; second cites an obscured manufacturing plant. Cannot match identities.',
 'NDA215644':'Plant identities obscured; repeated CGMP/PAI language does not identify a shared inspection or finding.',
 'NDA216987':'Both describe multiple facilities with obscured identities; second lists three facility paragraphs. Cannot match plants individually.',
 'NDA218600':'Plant identities obscured; generic CGMP and possible re-inspection language only.',
 'NDA218607':'Plant identities obscured; first describes CGMP/PAI, second CGMP. No identifiable common inspection episode.',
 'NDA218762':'Both describe drug product and drug substance facilities, but identities are obscured. Matching roles do not confirm matching sites.',
 'NDA218923':'Plant identities obscured; first discusses expedited inspection review, second generic PAI findings. No identifiable common inspection episode.',
}
def normalize(t):return re.sub(r'\s+',' ',t).strip()
def excerpt(t,needle):
    i=t.find(needle);assert i>=0,needle
    return t[max(0,i-90):min(len(t),i+850)]
def body(t):
    match=re.search(r'(?:FACILIT(?:Y|IES) INSPECTION|PRODUCT QUALITY / FACILITY|PRODUCT QUALITY/FACILITY|PRODUCT QUALITY AND FACILITY|Facility Inspection|Facility:)',t)
    if not match:raise AssertionError('Missing inspection section')
    return t[match.start():match.start()+2100]
def main():
    OUT.mkdir(parents=True,exist_ok=True)
    texts={r['letter_id']:normalize(r.get('text','')) for r in map(json.loads,(ROOT/'data/interim/crl_letters_parsed_v20260807.jsonl').read_text(encoding='utf-8-sig').splitlines())}
    with (ROOT/'output/revision/tables/consecutive_pairs.csv').open(encoding='utf-8-sig') as f:
        pairs=[r for r in csv.DictReader(f) if r['pair_sequence']=='1' and r['first']==r['second']=='facility_inspection']
    assert len(pairs)==28 and {r['application_id'] for r in pairs}==set(IDENTIFIED)|set(NARRATIVE)|set(INDETERMINATE)
    rows=[]
    for p in pairs:
        app=p['application_id'];a=texts[p['first_letter_id']];b=texts[p['second_letter_id']]
        if app in IDENTIFIED:
            note,an,bn=IDENTIFIED[app];status='same_facility_identified';ea,eb=excerpt(a,an),excerpt(b,bn)
        elif app in NARRATIVE:
            note,an,bn=NARRATIVE[app];status='continuity_supported_by_narrative';ea,eb=excerpt(a,an),excerpt(b,bn)
        else:
            note=INDETERMINATE[app];status='indeterminate';ea,eb=body(a),body(b)
        rows.append({**p,'review_method':'LLM-assisted source-text review','facility_continuity':status,
            'explicit_previous_findings_resolution_unproven':int(app=='BLA761147'),
            'additional_facility_in_second':int(app=='NDA214520'),
            'different_facility_replacement_identified':0,
            'same_specific_deficiency_confirmed':0,
            'assessment':note,'first_evidence':ea,'second_evidence':eb})
    with (OUT/'pair_review.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    summary={'pairs_reviewed':28,'review_method':'LLM-assisted source-text review; not independent human validation',
             'facility_continuity':dict(Counter(r['facility_continuity'] for r in rows)),
             'explicit_previous_findings_resolution_unproven':sum(r['explicit_previous_findings_resolution_unproven'] for r in rows),
             'additional_facility_in_second':1,'different_facility_replacement_identified':0,
             'same_specific_deficiency_confirmed':0,
             'interpretation':'Ten identify a common plant; two more support continuity through narrative. Sixteen do not establish plant identity, including fifteen with obscured identities and one with only a common manufacturer name. No pair explicitly establishes replacement by a different facility. One later letter explicitly says resolution of earlier inspection findings has not been demonstrated; it does not enumerate the earlier finding.'}
    assert summary['facility_continuity']=={'same_facility_identified':10,'continuity_supported_by_narrative':2,'indeterminate':16}
    (OUT/'review_summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
