"""Check corrected sequence endpoints, two-year events, and manuscript statistics."""
import csv,json,re
from pathlib import Path
from datetime import date
ROOT=Path(__file__).resolve().parents[1]
def read(p):
    with (ROOT/p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
raw=read('data/final/analysis_panel_classified_v20260807.csv')
rows=read('output/revision/tables/strict_crl_analysis_corrected_secondary.csv')
pairs=read('output/revision/tables/consecutive_pairs.csv')
assert len(rows)==443 and len(pairs)==109
assert len({p['application_id'] for p in pairs})==81
assert all(p['first_date']<p['second_date'] for p in pairs)
texts={r['letter_id']:r.get('text','') for r in map(json.loads,(ROOT/'data/interim/crl_letters_parsed_v20260807.jsonl').read_text(encoding='utf-8-sig').splitlines())}
normalize=lambda t:re.sub(r'\s+',' ',t).strip()
assert normalize(texts['crl_576c1a1c58b5e49e'])==normalize(texts['crl_22b1602ed588d05c'])
assert 'ACKNOWLEDGE INCOMPLETE RESPONSE' in normalize(texts['crl_01ec5422214c2272'])
assert not {'crl_576c1a1c58b5e49e','crl_01ec5422214c2272'} & {r['letter_id'] for r in rows}
assert [(p['first_letter_id'],p['second_letter_id']) for p in pairs if p['application_id']=='NDA204017']==[('crl_b0bc6c42eff353bb','crl_003b86c6f4832821')]
assert [(p['first_letter_id'],p['second_letter_id']) for p in pairs if p['application_id']=='BLA761303']==[('crl_ea7d7ff20ff84a36','crl_f91e6bb32eb0d7fc')]
old={r['application_id']:r for r in raw if r['is_first_strict_crl']=='1'}
first={r['application_id']:r for r in rows if r['is_first_strict_crl']=='1'}
assert len(first)==333 and set(first)==set(old)
assert all(first[a]['letter_id']==old[a]['letter_id'] for a in first)
changes=[a for a in first if first[a]['second_crl_within_730d_event']!=old[a]['second_crl_within_730d_event']]
assert set(changes)=={'NDA204017','BLA761215'},changes
eligible=[r for r in first.values() if (date(2026,8,28)-date.fromisoformat(r['letter_date'])).days>=730]
assert len(eligible)==250
# Independently count later retained letters; neither anomalous same-day record is an event.
for r in eligible:
    dates=[date.fromisoformat(x['letter_date']) for x in rows if x['application_id']==r['application_id'] and x['letter_date']>r['letter_date']]
    event=any((d-date.fromisoformat(r['letter_date'])).days<=730 for d in dates)
    assert event==(r['second_crl_within_730d_event']=='1')
for facility,n,events in [(True,84,24),(False,166,24)]:
    q=[r for r in eligible if (r['primary_deficiency_category']=='facility_inspection')==facility]
    assert len(q)==n and sum(r['second_crl_within_730d_event']=='1' for r in q)==events
fac=[p for p in pairs if p['pair_sequence']=='1' and p['first']=='facility_inspection']
assert len(fac)==33 and sum(p['second']=='facility_inspection' for p in fac)==28
main=(ROOT/'Paper/revision/latex/first-look-fda-crls.tex').read_text()
for phrase in ['443 released letters','24 of 166','14.5 percent','14.1 percentage points','3.6 to 25.5','109 pairs','63 pairs (57.8 percent)','7 of 14 beginning with clinical efficacy']:
    assert phrase in main,phrase
report={'status':'passed','letters':443,'applications':333,'linked_pairs':109,'repeat_applications':81,'two_year_events':48,'changed_event_applications':changes,'facility_first_pair':'28/33','raw_source_text_checks':'duplicate and incomplete acknowledgement confirmed'}
(ROOT/'output/revision/sequence-check').mkdir(parents=True,exist_ok=True)
(ROOT/'output/revision/sequence-check/corrected_analysis_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

