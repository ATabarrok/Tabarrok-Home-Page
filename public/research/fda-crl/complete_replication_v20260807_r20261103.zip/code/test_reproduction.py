"""Regression tests for cross-platform comparison without weakening integrity checks."""
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from reproduce_revision import compare_rebuilt, verify


class ReproductionComparisonTests(unittest.TestCase):
    def test_line_endings_and_real_changes(self):
        with TemporaryDirectory() as directory:
            root=Path(directory)
            for suffix in ['.csv','.tex','.json']:
                a,b=root/('a'+suffix),root/('b'+suffix)
                a.write_bytes(b'count: 32\r\nshare: 12.3\r\n')
                b.write_bytes(b'count: 32\nshare: 12.3\n')
                self.assertTrue(compare_rebuilt(a,b))
                self.assertTrue(compare_rebuilt(b,a))
                b.write_bytes(b'count: 20\nshare: 12.3\n')
                self.assertFalse(compare_rebuilt(a,b))
                b.write_bytes(b'count: 32\nshare:  12.3\n')
                self.assertFalse(compare_rebuilt(a,b))

    def test_missing_and_binary_outputs(self):
        with TemporaryDirectory() as directory:
            a,b=Path(directory)/'a.pdf',Path(directory)/'b.pdf'
            a.write_bytes(b'a\r\nb')
            self.assertFalse(compare_rebuilt(a,b))
            b.write_bytes(b'a\nb')
            self.assertFalse(compare_rebuilt(a,b))

    def test_release_hashes_remain_byte_exact(self):
        with TemporaryDirectory() as directory:
            root=Path(directory)
            data=b'count: 32\r\n'
            (root/'source.csv').write_bytes(data)
            (root/'RELEASE_MANIFEST.json').write_text(json.dumps({'files':[
                {'path':'source.csv','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}]}))
            verify(root)
            (root/'source.csv').write_bytes(data.replace(b'\r\n',b'\n'))
            with self.assertRaisesRegex(RuntimeError,'Release integrity mismatch'):
                verify(root)
            (root/'source.csv').write_bytes(data.replace(b'32',b'20'))
            with self.assertRaisesRegex(RuntimeError,'Release integrity mismatch'):
                verify(root)


if __name__=='__main__':
    unittest.main()
