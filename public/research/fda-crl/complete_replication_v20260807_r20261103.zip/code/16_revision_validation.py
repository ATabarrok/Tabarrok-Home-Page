"""Verify the existing human workbook and revised analysis without new coding."""
import csv, json, re, zipfile, hashlib
from pathlib import Path
from collections import Counter
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/revision'
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def readcsv(path):
    with path.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))

def main():
    wb=ROOT/'output/human-validation/human_validation_coding_workbook_50_letters_v20260807_completed.xlsx'
    # Read existing saved values only; no workbook is modified.
    with zipfile.ZipFile(wb) as z:
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            shared=[''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',NS)]
        book=ET.fromstring(z.read('xl/workbook.xml'))
        sheet=next(x for x in book.find('m:sheets',NS) if x.attrib['name']=='Review')
        rid=sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
        rel=next(x for x in ET.fromstring(z.read('xl/_rels/workbook.xml.rels')) if x.attrib['Id']==rid)
        target=rel.attrib['Target']; path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        labels={}
        for row in ET.fromstring(z.read(path)).findall('.//m:sheetData/m:row',NS):
            values={}
            for c in row:
                col=re.match('[A-Z]+',c.attrib['r']).group(); typ=c.attrib.get('t'); v=c.find('m:v',NS)
                val=v.text if v is not None else ''
                if typ=='s': val=shared[int(val)]
                elif typ=='inlineStr': val=''.join(t.text or '' for t in c.findall('.//m:t',NS))
                values[col]=val
            if values.get('A','').isdigit(): labels[int(values['A'])]=values.get('B','')
    sample=readcsv(ROOT/'data/manual/classification_validation_sample_v20260807.csv')
    panel={x['letter_id']:x for x in readcsv(ROOT/'data/final/analysis_panel_classified_v20260807.csv')}
    assert set(labels)==set(range(1,51)) and len(sample)==50
    rows=[dict(packet_number=i,letter_id=r['letter_id'],application_id=r['application_id'],letter_date=r['letter_date'],human_primary_category=labels[i],model_primary_category=panel[r['letter_id']]['primary_deficiency_category']) for i,r in enumerate(sample,1)]
    agreements=sum(r['human_primary_category']==r['model_primary_category'] for r in rows)
    hc=Counter(r['human_primary_category'] for r in rows); mc=Counter(r['model_primary_category'] for r in rows)
    expected=sum(hc[c]*mc[c] for c in hc)/2500; kappa=(agreements/50-expected)/(1-expected)
    assert agreements==41 and round(kappa,3)==.763
    for name,items in [('existing_human_labels',rows),('existing_human_disagreements',[r for r in rows if r['human_primary_category']!=r['model_primary_category']])]:
        with (OUT/'tables'/f'{name}.csv').open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(items)
    report={'existing_human_review':{'n':50,'agreements':agreements,'kappa':kappa,'source_workbook':str(wb.relative_to(ROOT)).replace('\\','/'),'workbook_sha256':hashlib.sha256(wb.read_bytes()).hexdigest(),'mapping':'Packet number equals row order of frozen classification_validation_sample_v20260807.csv, as in build_human_validation_packet.py.','reviewer_identity':'not_recorded_in_workbook','review_dates':'not_recorded_in_workbook'},'checks':[]}
    summary=json.loads((OUT/'analysis_summary.json').read_text())
    matrix=readcsv(OUT/'tables/transition_counts.csv')
    assert sum(sum(int(v) for k,v in r.items() if k!='first_category') for r in matrix)==112
    assert sum(int(r[r['first_category']]) for r in matrix)==66
    assert summary['facility_cmc_cooccurrence']==74
    co=readcsv(OUT/'tables/category_overlap.csv')
    assert sum(int(r['primary_n']) for r in co)==445
    assert all(int(r['primary_n'])+int(r['secondary_n'])==int(r['any_n']) for r in co)
    panelrows=list(panel.values()); strict=[r for r in panelrows if r['is_strict_crl']=='1']
    assert len(strict)==445 and len(set(r['application_id'] for r in strict))==333
    # Reconstruct the new cross-tab from original labels and the correction ledger.
    corrected={r['letter_id']:set(r['deficiency_categories'].split('|')) for r in strict}
    for r in readcsv(ROOT/'data/final/segmentation_corrections_v20260807.csv'):
        if r['letter_id'] in corrected: corrected[r['letter_id']].add(r['recovered_category'])
    flags=readcsv(OUT/'tables/manufacturing_clinical_letter_flags.csv')
    assert {r['letter_id'] for r in flags}==set(corrected)
    for r in flags:
        cats=corrected[r['letter_id']]
        assert int(r['has_manufacturing'])==int(bool(cats&{'facility_inspection','cmc'}))
        assert int(r['has_core_clinical'])==int(bool(cats&{'clinical_efficacy','clinical_safety','trial_design_conduct'}))
        assert int(r['has_broad_clinical'])==int(bool(cats&{'clinical_efficacy','clinical_safety','trial_design_conduct','bioequivalence_bioavailability'}))
    for sample,n,expected in [('All strict CRLs',445,[259,82,86,18]),('Unflagged classifications',369,[208,72,76,13])]:
        cells=[r for r in readcsv(OUT/'tables/manufacturing_clinical_overlap.csv') if r['sample']==sample and r['clinical_definition']=='Broad clinical']
        assert [int(r['count']) for r in cells]==expected and sum(expected)==n
    report['manufacturing_without_broad_clinical']={'all':{'count':259,'letters':445},'unflagged':{'count':208,'letters':369}}
    # Verify fixed-horizon flags against dates, rather than only accepting stored events.
    from datetime import date
    first=[r for r in strict if r['is_first_strict_crl']=='1']
    for r in first:
        eligible=(date.fromisoformat(r['followup_cutoff_date'])-date.fromisoformat(r['letter_date'])).days>=730
        assert eligible==(r['second_crl_730d_eligible']=='1')
        if eligible:
            event=bool(r['next_crl_date']) and (date.fromisoformat(r['next_crl_date'])-date.fromisoformat(r['letter_date'])).days<=730
            assert event==(r['second_crl_within_730d_event']=='1')
    manuscript=(ROOT/'Paper/revision/latex/first-look-fda-crls.tex').read_text(encoding='utf-8')
    appendix=(ROOT/'Paper/revision/latex/crl-methods-appendix.tex').read_text(encoding='utf-8')
    for token in ['121 of 333','36.3','42.2','24 of 84','26 of 166','28 of 33','41 of 45','259 of 445','41 of 50']:
        assert token in manuscript, 'Missing revised result '+token
    for token in ['74 of 445','60 of 65','257 letters','87 of 158']:
        assert token in appendix, 'Missing supporting result '+token
    applications=readcsv(OUT/'application-analysis/first_observed_crl_applications.csv')
    expected_first={}
    for r in sorted(strict,key=lambda r:(r['application_id'],r['letter_date'],r['letter_id'])):
        expected_first.setdefault(r['application_id'],r)
    assert {r['letter_id'] for r in applications}=={r['letter_id'] for r in expected_first.values()}
    distributions=readcsv(OUT/'application-analysis/application_primary_categories.csv')
    for r in distributions:
        for prefix,group in [('full',list(expected_first.values())),('recent',[v for v in expected_first.values() if v['letter_date']>='2024-01-01'])]:
            count=sum(v['primary_deficiency_category']==r['category'] for v in group)
            assert int(r[prefix+'_n'])==count and int(r[prefix+'_denominator'])==len(group)
            assert abs(float(r[prefix+'_share'])-count/len(group))<1e-12
    assert next(int(r['full_n']) for r in distributions if r['category']=='facility_inspection')==121
    assert next(int(r['recent_n']) for r in distributions if r['category']=='facility_inspection')==54
    for r in readcsv(OUT/'application-analysis/application_facility_sensitivity.csv'):
        group=[v for v in expected_first.values() if r['cohort']=='Full' or v['letter_date']>='2024-01-01']
        group=[v for v in group if r['sample']=='All'
               or r['sample']=='Unflagged' and v['classification_status']=='ok'
               or r['sample']=='Exclude OCR' and v['classification_status']!='uncertain_ocr'
               or r['sample']=='Exclude redaction' and v['classification_status']!='uncertain_redaction']
        count=sum(v['primary_deficiency_category']=='facility_inspection' for v in group)
        assert int(r['applications'])==len(group) and int(r['facility_n'])==count
        assert abs(float(r['facility_share'])-count/len(group))<1e-12
    eligible=[r for r in first if r['second_crl_730d_eligible']=='1']
    for category,n,events in [('facility_inspection',84,24),('cmc',54,8)]:
        group=[r for r in eligible if r['primary_deficiency_category']==category]
        assert len(group)==n and sum(r['second_crl_within_730d_event']=='1' for r in group)==events
    report['application_summary']={'applications':333,'recent_applications':128,'facility_initial':121,'facility_recent':54}
    assert 'unusually persistent' not in manuscript
    assert 'result is specific to facility compliance' not in manuscript
    report['checks']=['human workbook agreement and kappa','source/letter/application accounting','transition totals and diagonal','primary-secondary-any reconciliation','calendar eligibility and observed-event flags','application-level distributions and classification sensitivities','facility and CMC two-year outcomes','revised manuscript and appendix numerical anchors']

    # Independently check the facts corrected after the November replication report.
    facility={r['letter_id']:r for r in readcsv(ROOT/'data/final/analysis_panel_facility_subclassified_v20260807.csv')}
    correction_ids={r['letter_id'] for r in readcsv(ROOT/'data/final/segmentation_corrections_v20260807.csv')}
    facility_rows=[facility[r['letter_id']] for r in strict if facility[r['letter_id']]['facility_state'] or r['letter_id'] in correction_ids]
    any_not_conducted=[r for r in facility_rows if r['not_conducted_present']=='1' or r['letter_id'] in correction_ids]
    exclusive_5b=[r for r in facility_rows if r['facility_state']=='5b_not_conducted' or r['letter_id'] in correction_ids]
    assert (len(facility_rows),len(any_not_conducted),len(exclusive_5b))==(260,32,20)
    assert sum(r['letter_date']>='2024-01-01' for r in any_not_conducted)==5
    assert sum(r['letter_date']>='2024-01-01' for r in exclusive_5b)==2
    assert sum(r['facility_state']=='5a_failed' for r in any_not_conducted)==12
    assert min(r['letter_date'] for r in strict)=='2009-05-15'
    recent=[r for r in strict if r['letter_date']>='2024-01-01']
    assert sum(r['drugsfda_matched']=='1' for r in strict)==322
    assert sum(r['drugsfda_matched']=='1' for r in recent)==44 and len(recent)==158
    segment_sample=[panel[r['letter_id']] for r in readcsv(ROOT/'data/manual/segmentation_hand_audit_v20260807.csv')]
    eras=[sum(r['letter_date']<'2008-01-01' for r in segment_sample),
          sum('2008-01-01'<=r['letter_date']<'2024-01-01' for r in segment_sample),
          sum(r['letter_date']>='2024-01-01' for r in segment_sample)]
    assert eras==[3,14,13] and sum(r['is_strict_crl']!='1' for r in segment_sample)==4
    assert all(panel[r['letter_id']]['is_strict_crl']=='1' for r in readcsv(ROOT/'data/manual/classification_validation_sample_v20260807.csv'))
    # Reconstruct CMC-to-facility pairs from classifications and frozen case judgments.
    by_app={}
    for r in sorted(strict,key=lambda r:(r['application_id'],r['letter_date'],r['letter_id'])):
        by_app.setdefault(r['application_id'],[]).append(r)
    transitions=[(a,b) for group in by_app.values() for a,b in zip(group,group[1:])
                 if a['primary_deficiency_category']=='cmc' and b['primary_deficiency_category']=='facility_inspection']
    judgments={r['application_id']:r for r in readcsv(ROOT/'data/manual/checkpoint6_cmc_facility_transition_adjudications_v20260807.csv')}
    same=[a for a,b in transitions if judgments[a['application_id']]['verdict']=='same_underlying_problem']
    assert len(transitions)==9 and len(same)==5
    assert all('facility_inspection' in r['deficiency_categories'].split('|') for r in same)
    armstrong=facility['crl_028388c369cccac9']; kashiv=facility['crl_a5ddce1474406b6e']
    mediwound=facility['crl_a09fb33ecd44ec94']; redhill=facility['crl_3733bf3e5a36c9f2']
    assert armstrong['primary_deficiency_category']=='trial_design_conduct' and armstrong['facility_state']=='5a_failed'
    assert kashiv['facility_state']=='5a_failed' and kashiv['not_conducted_present']=='1'
    assert mediwound['primary_deficiency_category']=='facility_inspection' and mediwound['facility_state']=='5b_not_conducted'
    assert redhill['primary_deficiency_category']=='cmc' and 'facility_inspection' in redhill['deficiency_categories'].split('|')
    # Verify quoted words against raw FDA records, allowing only whitespace and explicit ellipses.
    raw=json.loads((ROOT/'data/raw/crl_20260828.json').read_text(encoding='utf-8'))['results']
    norm=lambda value:' '.join(value.split())
    for heading,row in [('A failed inspection (5a)',armstrong),('An inspection that could not happen (5b)',mediwound),('A chemistry deficiency (category 4)',redhill)]:
        section=appendix.split('\\subsubsection{'+heading,1)[1].split('\\end{quote}',1)[0]
        quote=section.split('\\begin{quote}',1)[1]
        source=next(r for r in raw if r['file_name']==row['file_name'])['text']
        source=norm(source)
        for paragraph in quote.strip().split('\n\n'):
            for fragment in paragraph.split('{[}...{]}'):
                assert norm(fragment) in source, 'Quoted words not found in FDA source: '+norm(fragment)
    for token in ['from May 2009','322 match Drugs@FDA','44 of the 158','32 letters (12.3 percent)']:
        assert token in manuscript, 'Missing corrected manuscript fact: '+token
    for token in ['three before 2008, fourteen','four predecessor actions excluded','In all five same-problem pairs','The stored main reason is trial design and conduct','BLA 761192, MediWound, June 25, 2021']:
        assert token in appendix, 'Missing corrected appendix fact: '+token
    period=readcsv(OUT/'tables/facility_by_period_type.csv')
    assert period[0]['period']=='2009--2014' and sum(int(r['n']) for r in period if r['period']=='2009--2014')==28
    tex=(ROOT/'Paper/revision/latex/generated/transitions.tex').read_text()
    assert '(12.5)' in tex and '(37.5)' in tex
    report['replication_report_audit']={'earliest_strict_crl':'2009-05-15','matched_strict':322,'matched_recent':44,
        'facility_letters':260,'any_uncompleted_inspection':32,'recent_any_uncompleted_inspection':5,
        'exclusive_5b':20,'recent_exclusive_5b':2,'segmentation_review_eras':eras,
        'segmentation_review_predecessors':4,'classification_validation_predecessors':0,
        'same_problem_pairs_with_prior_facility':5,'worked_examples_and_raw_quotes':'verified'}
    report['checks'].append('replication-report corrections checked against records, classifications, and frozen adjudications')

    report['status']='passed'
    (OUT/'validation_report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
