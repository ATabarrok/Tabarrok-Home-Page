#!/usr/bin/env python3
"""Build Checkpoint 5 Tasks B-D from the pinned local panel.

No acquisition or model calls occur here. Outputs cover Phase 3 validation reporting,
consecutive-CRL persistence, and the three requested corrections.
"""

from __future__ import annotations

import csv
import json
import math
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[1]
VINTAGE = "20260807"
CATEGORIES = [
    "clinical_efficacy", "clinical_safety", "trial_design_conduct", "cmc",
    "facility_inspection", "stability_shelf_life", "bioequivalence_bioavailability",
    "nonclinical_toxicology", "labeling_proprietary_name", "administrative_procedural",
]
FACILITY_STATES = ["5a_failed", "5b_not_conducted", "5c_pending_conditional", "5e_unclear"]
LABELS = {
    "clinical_efficacy": "Clinical efficacy",
    "clinical_safety": "Clinical safety",
    "trial_design_conduct": "Trial design/conduct",
    "cmc": "CMC",
    "facility_inspection": "Facility inspection",
    "stability_shelf_life": "Stability/shelf life",
    "bioequivalence_bioavailability": "Bioequivalence/bioavailability",
    "nonclinical_toxicology": "Nonclinical/toxicology",
    "labeling_proprietary_name": "Labeling/proprietary name",
    "administrative_procedural": "Administrative/procedural",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(rows[0]) if rows else []
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def tex_escape(value: Any) -> str:
    text = str(value)
    replacements = [
        ("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"),
        ("$", r"\$"), ("#", r"\#"), ("_", r"\_"),
        ("{", r"\{"), ("}", r"\}"),
    ]
    for old, new in replacements:
        text = text.replace(old, new)
    return text


def write_tex(path: Path, headers: list[str], rows: list[list[Any]], alignment: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"\\begin{{tabular}}{{{alignment}}}", "\\toprule",
             " & ".join(tex_escape(x) for x in headers) + r" \\", "\\midrule"]
    lines.extend(" & ".join(tex_escape(x) for x in row) + r" \\" for row in rows)
    lines.extend(["\\bottomrule", "\\end{tabular}", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def as_int(value: Any) -> int:
    if value is None or str(value).strip() == "":
        return 0
    return int(float(str(value)))


def as_float(value: Any) -> float:
    if value is None or str(value).strip() == "":
        return 0.0
    return float(str(value))


def json_string_list(value: Any) -> list[str]:
    text = str(value or "").strip()
    if not text:
        return []
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return [text]
    if isinstance(parsed, list):
        return [str(item).strip() for item in parsed if str(item).strip()]
    return [str(parsed).strip()] if str(parsed).strip() else []


def pct(n: int | float, d: int | float) -> float | None:
    return None if not d else n / d


def wilson(successes: int, n: int, z: float = 1.959964) -> tuple[float | None, float | None, float | None]:
    if not n:
        return None, None, None
    p = successes / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return p, max(0.0, center - half), min(1.0, center + half)


def quantile(values: list[float], probability: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = (len(ordered) - 1) * probability
    lower = math.floor(index)
    upper = math.ceil(index)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (index - lower)


def average_ranks(values: list[float]) -> list[float]:
    indexed = sorted(enumerate(values), key=lambda pair: pair[1])
    ranks = [0.0] * len(values)
    position = 0
    while position < len(indexed):
        end = position + 1
        while end < len(indexed) and indexed[end][1] == indexed[position][1]:
            end += 1
        rank = (position + 1 + end) / 2
        for source_index, _ in indexed[position:end]:
            ranks[source_index] = rank
        position = end
    return ranks


def pearson(left: list[float], right: list[float]) -> float | None:
    if len(left) != len(right) or len(left) < 2:
        return None
    left_mean = sum(left) / len(left)
    right_mean = sum(right) / len(right)
    numerator = sum((a - left_mean) * (b - right_mean) for a, b in zip(left, right))
    left_ss = sum((a - left_mean) ** 2 for a in left)
    right_ss = sum((b - right_mean) ** 2 for b in right)
    if not left_ss or not right_ss:
        return None
    return numerator / math.sqrt(left_ss * right_ss)


def spearman(left: list[float], right: list[float]) -> float | None:
    return pearson(average_ranks(left), average_ranks(right))


def era(year: int) -> str:
    if year <= 2014:
        return "2002-2014"
    if year <= 2019:
        return "2015-2019"
    if year <= 2023:
        return "2020-2023"
    return "2024-2026"


def task_b(panel: list[dict[str, str]], tables: Path) -> dict[str, Any]:
    manual = read_csv(ROOT / "data" / "manual" / f"classification_validation_sample_v{VINTAGE}.csv")
    panel_by_id = {row["letter_id"]: row for row in panel}
    category_rows: list[dict[str, Any]] = []
    for category in CATEGORIES:
        manual_n = sum(row["manual_primary_category"] == category for row in manual)
        model_n = sum(panel_by_id[row["letter_id"]]["primary_deficiency_category"] == category for row in manual)
        correct_n = sum(
            row["manual_primary_category"] == category
            and panel_by_id[row["letter_id"]]["primary_deficiency_category"] == category
            for row in manual
        )
        category_rows.append({
            "category": category, "category_label": LABELS[category],
            "hand_coded_n": manual_n, "correct_among_hand_coded_n": correct_n,
            "agreement_among_hand_coded": pct(correct_n, manual_n),
            "model_assigned_n": model_n, "correct_among_model_assigned_n": correct_n,
            "agreement_among_model_assigned": pct(correct_n, model_n),
        })
    write_csv(tables / f"checkpoint5B_primary_validation_by_category_v{VINTAGE}.csv", category_rows)

    full_status = Counter(row["classification_status"] for row in panel)
    eligible = [row for row in panel if as_int(row["is_strict_crl"]) == 1
                and as_int(row["is_first_strict_crl"]) == 1
                and as_int(row["second_crl_730d_eligible"]) == 1]
    if len(eligible) != 250:
        raise RuntimeError(f"Expected 250 eligible first strict CRLs; found {len(eligible)}")
    eligible_status = Counter(row["classification_status"] for row in eligible)
    status_rows: list[dict[str, Any]] = []
    for status in ["ok", "uncertain_redaction", "uncertain_ocr", "failed"]:
        status_rows.append({
            "classification_status": status,
            "full_sample_n": full_status[status], "full_sample_share": pct(full_status[status], len(panel)),
            "eligible_730d_n": eligible_status[status], "eligible_730d_share": pct(eligible_status[status], len(eligible)),
            "definition": {
                "ok": "defensible classification without material OCR or redaction uncertainty",
                "uncertain_redaction": "redaction materially limits category or flag certainty",
                "uncertain_ocr": "OCR damage materially limits category or flag certainty",
                "failed": "no defensible substantive classification",
            }[status],
        })
    write_csv(tables / f"checkpoint5B_classification_status_v{VINTAGE}.csv", status_rows)

    profile_rows: list[dict[str, Any]] = []
    for name, rows in [("ok", [row for row in eligible if row["classification_status"] == "ok"]),
                       ("uncertain_or_failed", [row for row in eligible if row["classification_status"] != "ok"])]:
        years = [int(row["letter_date"][:4]) for row in rows]
        profile_rows.append({
            "group": name, "n": len(rows), "mean_letter_year": sum(years) / len(years),
            "bla_n": sum(row["application_type"] == "BLA" for row in rows),
            "bla_share": pct(sum(row["application_type"] == "BLA" for row in rows), len(rows)),
            "any_redaction_n": sum(as_int(row["redaction_marker_count"]) > 0 for row in rows),
            "any_redaction_share": pct(sum(as_int(row["redaction_marker_count"]) > 0 for row in rows), len(rows)),
            "mean_redaction_markers_per_1000_chars": sum(as_float(row["redaction_markers_per_1000_chars"]) for row in rows) / len(rows),
            "facility_primary_n": sum(row["primary_deficiency_category"] == "facility_inspection" for row in rows),
            "facility_primary_share": pct(sum(row["primary_deficiency_category"] == "facility_inspection" for row in rows), len(rows)),
            "cmc_primary_n": sum(row["primary_deficiency_category"] == "cmc" for row in rows),
            "cmc_primary_share": pct(sum(row["primary_deficiency_category"] == "cmc" for row in rows), len(rows)),
        })
    write_csv(tables / f"checkpoint5B_eligible_status_profile_v{VINTAGE}.csv", profile_rows)

    segments = read_jsonl(ROOT / "data" / "interim" / f"deficiency_segments_v{VINTAGE}.jsonl")
    segment_by_id = {row["letter_id"]: row for row in segments}
    hand_seg = read_csv(ROOT / "data" / "manual" / f"segmentation_hand_audit_v{VINTAGE}.csv")
    audited_failures = [row for row in hand_seg if not (
        as_int(row["hand_start_correct"]) and as_int(row["hand_end_correct"])
        and as_int(row["hand_deficiencies_complete"]))]
    flagged = [row for row in segments if as_int(row["automatic_flag_count"]) > 0]
    flagged_rows = []
    for row in flagged:
        panel_row = panel_by_id[row["letter_id"]]
        flagged_rows.append({
            "letter_id": row["letter_id"], "file_name": row["file_name"],
            "letter_date": row["letter_date"], "primary_category": panel_row["primary_deficiency_category"],
            "automatic_flags": "|".join(row["automatic_flags"]),
            "manual_review_result": "boundaries and binding deficiency body confirmed correct",
        })
    write_csv(tables / f"checkpoint5B_segmentation_flagged_records_v{VINTAGE}.csv", flagged_rows)
    segmentation_summary = [
        {"metric": "hand-audited segmentation failures", "events": len(audited_failures),
         "denominator": len(hand_seg), "share": pct(len(audited_failures), len(hand_seg)),
         "interpretation": "zero observed failures; year/category correlation not estimable"},
        {"metric": "automatic flags before hand review", "events": len(flagged),
         "denominator": len(segments), "share": pct(len(flagged), len(segments)),
         "interpretation": "all three manually reviewed and confirmed correct; not failures"},
        {"metric": "empty deficiency segments", "events": sum(not row["deficiency_text"].strip() for row in segments),
         "denominator": len(segments), "share": pct(sum(not row["deficiency_text"].strip() for row in segments), len(segments)),
         "interpretation": "none"},
    ]
    write_csv(tables / f"checkpoint5B_segmentation_validation_summary_v{VINTAGE}.csv", segmentation_summary)

    manual_recent = sum(row["letter_date"] >= "2024-01-01" for row in manual)
    return {
        "validation_n": len(manual), "validation_recent_n": manual_recent,
        "validation_historical_n": len(manual) - manual_recent,
        "primary_agreement_n": sum(
            row["manual_primary_category"] == panel_by_id[row["letter_id"]]["primary_deficiency_category"]
            for row in manual),
        "eligible_n": len(eligible), "eligible_ok_n": eligible_status["ok"],
        "eligible_other_n": len(eligible) - eligible_status["ok"],
        "segmentation_audit_n": len(hand_seg), "segmentation_failures_n": len(audited_failures),
        "automatic_flagged_n": len(flagged),
    }


def task_c(panel: list[dict[str, str]], tables: Path) -> dict[str, Any]:
    strict = [row for row in panel if as_int(row["is_strict_crl"]) == 1]
    by_application: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in strict:
        by_application[row["application_id"]].append(row)
    pairs: list[dict[str, Any]] = []
    repeat_applications = 0
    for application_id, rows in sorted(by_application.items()):
        ordered = sorted(rows, key=lambda row: (row["letter_date"], row["letter_id"]))
        if len(ordered) < 2:
            continue
        repeat_applications += 1
        for pair_index, (first, second) in enumerate(zip(ordered, ordered[1:]), start=1):
            first_category = first["primary_deficiency_category"]
            second_category = second["primary_deficiency_category"]
            days = (datetime.fromisoformat(second["letter_date"]) - datetime.fromisoformat(first["letter_date"])).days
            pairs.append({
                "application_id": application_id, "pair_index": pair_index,
                "first_letter_id": first["letter_id"], "second_letter_id": second["letter_id"],
                "first_file_name": first["file_name"], "second_file_name": second["file_name"],
                "first_letter_date": first["letter_date"], "second_letter_date": second["letter_date"],
                "days_between_crls": days, "first_primary_category": first_category,
                "second_primary_category": second_category,
                "primary_category_repeated": int(first_category == second_category),
                "first_facility_state": first.get("facility_state", ""),
                "second_facility_state": second.get("facility_state", ""),
                "first_third_party_flag": first.get("third_party_flag", ""),
                "second_third_party_flag": second.get("third_party_flag", ""),
            })
    if repeat_applications != 82 or len(pairs) != 112:
        raise RuntimeError(f"Expected 82 repeat applications and 112 pairs; found {repeat_applications}, {len(pairs)}")
    write_csv(tables / f"checkpoint5C_consecutive_crl_pairs_v{VINTAGE}.csv", pairs)

    matrix_rows: list[dict[str, Any]] = []
    for source in CATEGORIES:
        row: dict[str, Any] = {"first_primary_category": source}
        for target in CATEGORIES:
            row[f"to_{target}"] = sum(
                pair["first_primary_category"] == source and pair["second_primary_category"] == target
                for pair in pairs)
        row["row_total"] = sum(pair["first_primary_category"] == source for pair in pairs)
        matrix_rows.append(row)
    write_csv(tables / f"checkpoint5C_primary_transition_matrix_v{VINTAGE}.csv", matrix_rows)
    write_tex(
        tables / f"checkpoint5C_primary_transition_matrix_v{VINTAGE}.tex",
        ["First category", *[LABELS[c] for c in CATEGORIES], "Total"],
        [[LABELS[row["first_primary_category"]], *[row[f"to_{c}"] for c in CATEGORIES], row["row_total"]]
         for row in matrix_rows],
        "l" + "r" * (len(CATEGORIES) + 1),
    )

    diagonal_n = sum(pair["primary_category_repeated"] for pair in pairs)
    rate, low, high = wilson(diagonal_n, len(pairs))
    persistence_rows: list[dict[str, Any]] = []
    for category in CATEGORIES:
        category_pairs = [pair for pair in pairs if pair["first_primary_category"] == category]
        repeats = sum(pair["primary_category_repeated"] for pair in category_pairs)
        c_rate, c_low, c_high = wilson(repeats, len(category_pairs))
        persistence_rows.append({
            "first_primary_category": category, "category_label": LABELS[category],
            "pair_n": len(category_pairs), "same_category_n": repeats,
            "diagonal_share": c_rate, "wilson_95_low": c_low, "wilson_95_high": c_high,
            "small_n_caution": int(len(category_pairs) < 10),
        })
    persistence_rows.append({
        "first_primary_category": "all", "category_label": "All categories",
        "pair_n": len(pairs), "same_category_n": diagonal_n,
        "diagonal_share": rate, "wilson_95_low": low, "wilson_95_high": high,
        "small_n_caution": 0,
    })
    write_csv(tables / f"checkpoint5C_primary_persistence_by_category_v{VINTAGE}.csv", persistence_rows)

    facility_pairs = [pair for pair in pairs if pair["first_primary_category"] == "facility_inspection"
                      and pair["second_primary_category"] == "facility_inspection"]
    facility_matrix: list[dict[str, Any]] = []
    for source in FACILITY_STATES:
        row = {"first_facility_state": source}
        for target in FACILITY_STATES:
            row[f"to_{target}"] = sum(
                pair["first_facility_state"] == source and pair["second_facility_state"] == target
                for pair in facility_pairs)
        row["row_total"] = sum(pair["first_facility_state"] == source for pair in facility_pairs)
        facility_matrix.append(row)
    write_csv(tables / f"checkpoint5C_facility_state_transition_matrix_v{VINTAGE}.csv", facility_matrix)
    write_tex(
        tables / f"checkpoint5C_facility_state_transition_matrix_v{VINTAGE}.tex",
        ["First state", *FACILITY_STATES, "Total"],
        [[row["first_facility_state"], *[row[f"to_{state}"] for state in FACILITY_STATES], row["row_total"]]
         for row in facility_matrix], "lrrrrr",
    )
    five_b_pairs = [pair for pair in facility_pairs if pair["first_facility_state"] == "5b_not_conducted"
                    and pair["second_facility_state"] == "5b_not_conducted"]
    write_csv(tables / f"checkpoint5C_facility_5b_to_5b_applications_v{VINTAGE}.csv", five_b_pairs,
              list(pairs[0]))

    duration_rows: list[dict[str, Any]] = []
    for label, selected in [
        ("same primary category", [pair for pair in pairs if pair["primary_category_repeated"]]),
        ("different primary category", [pair for pair in pairs if not pair["primary_category_repeated"]]),
        ("all consecutive pairs", pairs),
    ]:
        values = [float(pair["days_between_crls"]) for pair in selected]
        duration_rows.append({
            "group": label, "pair_n": len(values), "q1_days": quantile(values, 0.25),
            "median_days": quantile(values, 0.5), "q3_days": quantile(values, 0.75),
            "minimum_days": min(values), "maximum_days": max(values),
        })
    write_csv(tables / f"checkpoint5C_days_between_crls_v{VINTAGE}.csv", duration_rows)

    facility_diagonal = sum(pair["first_facility_state"] == pair["second_facility_state"]
                            for pair in facility_pairs)
    non_simultaneous = [pair for pair in pairs if pair["days_between_crls"] > 0]
    non_simultaneous_same = sum(pair["primary_category_repeated"] for pair in non_simultaneous)
    return {
        "repeat_application_n": repeat_applications, "consecutive_pair_n": len(pairs),
        "same_primary_n": diagonal_n, "same_primary_share": rate,
        "same_primary_wilson_low": low, "same_primary_wilson_high": high,
        "facility_primary_to_facility_primary_pair_n": len(facility_pairs),
        "facility_state_diagonal_n": facility_diagonal,
        "facility_state_diagonal_share": pct(facility_diagonal, len(facility_pairs)),
        "facility_5b_to_5b_n": len(five_b_pairs),
        "facility_5b_to_5b_applications": [pair["application_id"] for pair in five_b_pairs],
        "same_day_pair_n": len(pairs) - len(non_simultaneous),
        "same_primary_excluding_same_day_n": non_simultaneous_same,
        "pair_n_excluding_same_day": len(non_simultaneous),
        "same_primary_share_excluding_same_day": pct(non_simultaneous_same, len(non_simultaneous)),
        "duration_summary": duration_rows,
    }


def task_d(panel: list[dict[str, str]], tables: Path) -> dict[str, Any]:
    strict = [row for row in panel if as_int(row["is_strict_crl"]) == 1]
    recent = [row for row in strict if row["letter_date"] >= "2024-01-01"]
    if len(strict) != 445 or len(recent) != 158:
        raise RuntimeError(f"Strict comparison expected 445 and 158 rows; found {len(strict)}, {len(recent)}")
    comparison_rows: list[dict[str, Any]] = []
    for category in CATEGORIES:
        full_n = sum(row["primary_deficiency_category"] == category for row in strict)
        recent_n = sum(row["primary_deficiency_category"] == category for row in recent)
        full_share = full_n / len(strict)
        recent_share = recent_n / len(recent)
        comparison_rows.append({
            "primary_category": category, "category_label": LABELS[category],
            "full_strict_n": full_n, "full_strict_denominator": len(strict), "full_strict_share": full_share,
            "2024_forward_n": recent_n, "2024_forward_denominator": len(recent),
            "2024_forward_share": recent_share,
            "recent_minus_full_percentage_points": 100 * (recent_share - full_share),
        })
    write_csv(tables / f"checkpoint5D_strict_crl_primary_comparison_v{VINTAGE}.csv", comparison_rows)
    write_tex(
        tables / f"checkpoint5D_strict_crl_primary_comparison_v{VINTAGE}.tex",
        ["Primary category", "Full N", "Full share", "2024+ N", "2024+ share", "Difference (pp)"],
        [[row["category_label"], row["full_strict_n"], f"{100*row['full_strict_share']:.1f}%",
          row["2024_forward_n"], f"{100*row['2024_forward_share']:.1f}%",
          f"{row['recent_minus_full_percentage_points']:+.1f}"] for row in comparison_rows], "lrrrrr",
    )

    years = [float(row["letter_date"][:4]) for row in panel]
    intensities = [as_float(row["redaction_markers_per_1000_chars"]) for row in panel]
    any_markers = [float(as_int(row["redaction_marker_count"]) > 0) for row in panel]
    positive = sorted([as_float(row["redaction_markers_per_1000_chars"]) for row in panel
                       if as_int(row["redaction_marker_count"]) > 0])
    cutoff_index = max(0, math.ceil(0.75 * len(positive)) - 1)
    heavy_cutoff = positive[cutoff_index]
    zero_rows = [row for row in panel if as_int(row["redaction_marker_count"]) == 0]
    heavy_rows = [row for row in panel if as_float(row["redaction_markers_per_1000_chars"]) >= heavy_cutoff
                  and as_int(row["redaction_marker_count"]) > 0]
    correlation_rows = [
        {"measure": "Spearman rank correlation: year vs marker density", "n": len(panel),
         "value": spearman(years, intensities), "interpretation": "positive means later letters are more intensely redacted"},
        {"measure": "Point-biserial/Pearson correlation: year vs any marker", "n": len(panel),
         "value": pearson(years, any_markers), "interpretation": "positive means later letters are more likely to show a marker"},
        {"measure": "Mean year: zero-marker letters", "n": len(zero_rows),
         "value": sum(int(row["letter_date"][:4]) for row in zero_rows) / len(zero_rows),
         "interpretation": "Phase 3 light-redaction group"},
        {"measure": "Mean year: heavy-redaction letters", "n": len(heavy_rows),
         "value": sum(int(row["letter_date"][:4]) for row in heavy_rows) / len(heavy_rows),
         "interpretation": "top quartile of density among marker-positive letters"},
        {"measure": "Heavy density cutoff per 1,000 chars", "n": len(heavy_rows),
         "value": heavy_cutoff, "interpretation": "same definition as Checkpoint 3"},
    ]
    write_csv(tables / f"checkpoint5D_redaction_year_correlations_v{VINTAGE}.csv", correlation_rows)

    redaction_era_rows: list[dict[str, Any]] = []
    for era_name in ["2002-2014", "2015-2019", "2020-2023", "2024-2026"]:
        rows = [row for row in panel if era(int(row["letter_date"][:4])) == era_name]
        densities = [as_float(row["redaction_markers_per_1000_chars"]) for row in rows]
        redaction_era_rows.append({
            "era": era_name, "letter_n": len(rows),
            "any_marker_n": sum(as_int(row["redaction_marker_count"]) > 0 for row in rows),
            "any_marker_share": pct(sum(as_int(row["redaction_marker_count"]) > 0 for row in rows), len(rows)),
            "mean_markers_per_1000_chars": sum(densities) / len(densities),
            "median_markers_per_1000_chars": quantile(densities, 0.5),
            "heavy_marker_n": sum(as_float(row["redaction_markers_per_1000_chars"]) >= heavy_cutoff
                                  and as_int(row["redaction_marker_count"]) > 0 for row in rows),
            "heavy_marker_share": pct(sum(as_float(row["redaction_markers_per_1000_chars"]) >= heavy_cutoff
                                          and as_int(row["redaction_marker_count"]) > 0 for row in rows), len(rows)),
        })
    write_csv(tables / f"checkpoint5D_redaction_by_era_v{VINTAGE}.csv", redaction_era_rows)

    unmatched_apps = read_csv(ROOT / "data" / "final" / f"unmatched_bla_review_centers_v{VINTAGE}.csv")
    unmatched_ids = {row["application_id"] for row in unmatched_apps}
    if len(unmatched_ids) != 33:
        raise RuntimeError(f"Expected 33 unmatched BLA applications; found {len(unmatched_ids)}")
    class_by_app = {row["application_id"]: row["review_center_class"] for row in unmatched_apps}
    unmatched_letters = [row for row in panel if row["application_id"] in unmatched_ids]
    center_rows: list[dict[str, Any]] = []
    for center_class in ["CBER", "CDER", "UNKNOWN"]:
        app_ids = {app_id for app_id, value in class_by_app.items() if value == center_class}
        rows = [row for row in unmatched_letters if row["application_id"] in app_ids]
        center_rows.append({
            "review_center_class": center_class, "application_n": len(app_ids),
            "application_share_of_33": pct(len(app_ids), 33), "classified_letter_n": len(rows),
            "literal_approver_center_present_letter_n": sum(bool(json_string_list(row["approver_center"])) for row in rows),
            "facility_primary_n": sum(row["primary_deficiency_category"] == "facility_inspection" for row in rows),
            "facility_primary_share": pct(sum(row["primary_deficiency_category"] == "facility_inspection" for row in rows), len(rows)),
            "cmc_primary_n": sum(row["primary_deficiency_category"] == "cmc" for row in rows),
            "cmc_primary_share": pct(sum(row["primary_deficiency_category"] == "cmc" for row in rows), len(rows)),
            "cmc_or_facility_primary_n": sum(row["primary_deficiency_category"] in {"cmc", "facility_inspection"} for row in rows),
            "cmc_or_facility_primary_share": pct(sum(row["primary_deficiency_category"] in {"cmc", "facility_inspection"} for row in rows), len(rows)),
        })
    center_rows.append({
        "review_center_class": "TOTAL", "application_n": 33, "application_share_of_33": 1.0,
        "classified_letter_n": len(unmatched_letters),
        "literal_approver_center_present_letter_n": sum(bool(json_string_list(row["approver_center"])) for row in unmatched_letters),
        "facility_primary_n": sum(row["primary_deficiency_category"] == "facility_inspection" for row in unmatched_letters),
        "facility_primary_share": pct(sum(row["primary_deficiency_category"] == "facility_inspection" for row in unmatched_letters), len(unmatched_letters)),
        "cmc_primary_n": sum(row["primary_deficiency_category"] == "cmc" for row in unmatched_letters),
        "cmc_primary_share": pct(sum(row["primary_deficiency_category"] == "cmc" for row in unmatched_letters), len(unmatched_letters)),
        "cmc_or_facility_primary_n": sum(row["primary_deficiency_category"] in {"cmc", "facility_inspection"} for row in unmatched_letters),
        "cmc_or_facility_primary_share": pct(sum(row["primary_deficiency_category"] in {"cmc", "facility_inspection"} for row in unmatched_letters), len(unmatched_letters)),
    })
    write_csv(tables / f"checkpoint5D_unmatched_bla_center_summary_v{VINTAGE}.csv", center_rows)

    literal_counts: dict[str, set[str]] = defaultdict(set)
    literal_letters = Counter()
    for row in unmatched_letters:
        values = json_string_list(row["approver_center"]) or ["[missing]"]
        for literal in values:
            literal_counts[literal].add(row["application_id"])
            literal_letters[literal] += 1
    literal_rows = [{"literal_approver_center": value, "application_n": len(literal_counts[value]),
                     "classified_letter_n": literal_letters[value]} for value in sorted(literal_counts)]
    write_csv(tables / f"checkpoint5D_unmatched_bla_literal_approver_center_v{VINTAGE}.csv", literal_rows)

    bla_match_rows: list[dict[str, Any]] = []
    for label, rows in [
        ("Drugs@FDA matched BLA letters", [row for row in panel if row["application_type"] == "BLA" and as_int(row["drugsfda_matched"]) == 1]),
        ("Drugs@FDA unmatched BLA letters", unmatched_letters),
    ]:
        facility_n = sum(row["primary_deficiency_category"] == "facility_inspection" for row in rows)
        cmc_n = sum(row["primary_deficiency_category"] == "cmc" for row in rows)
        bla_match_rows.append({
            "group": label, "classified_letter_n": len(rows),
            "facility_primary_n": facility_n, "facility_primary_share": pct(facility_n, len(rows)),
            "cmc_primary_n": cmc_n, "cmc_primary_share": pct(cmc_n, len(rows)),
            "cmc_or_facility_primary_n": facility_n + cmc_n,
            "cmc_or_facility_primary_share": pct(facility_n + cmc_n, len(rows)),
        })
    write_csv(tables / f"checkpoint5D_bla_match_comparison_v{VINTAGE}.csv", bla_match_rows)

    return {
        "strict_full_n": len(strict), "strict_recent_n": len(recent),
        "redaction_spearman_year_density": correlation_rows[0]["value"],
        "redaction_point_biserial_year_any": correlation_rows[1]["value"],
        "zero_marker_mean_year": correlation_rows[2]["value"],
        "heavy_marker_mean_year": correlation_rows[3]["value"],
        "unmatched_bla_application_n": len(unmatched_ids),
        "unmatched_bla_center_counts": dict(Counter(class_by_app.values())),
        "unmatched_bla_letter_n": len(unmatched_letters),
        "unmatched_bla_facility_primary_n": center_rows[-1]["facility_primary_n"],
        "unmatched_bla_cmc_or_facility_primary_n": center_rows[-1]["cmc_or_facility_primary_n"],
        "bla_match_comparison": bla_match_rows,
    }


def main() -> None:
    panel_path = ROOT / "data" / "final" / f"analysis_panel_facility_subclassified_v{VINTAGE}.csv"
    panel = read_csv(panel_path)
    classified = [row for row in panel if as_int(row["is_deficiency_action"]) == 1]
    if len(classified) != 449:
        raise RuntimeError(f"Expected 449 classified deficiency actions; found {len(classified)}")
    tables = ROOT / "output" / "tables"
    summary = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "data_vintage": VINTAGE,
        "task_b": task_b(classified, tables),
        "task_c": task_c(classified, tables),
        "task_d": task_d(classified, tables),
    }
    path = ROOT / "data" / "interim" / f"checkpoint5BCD_summary_v{VINTAGE}.json"
    path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
