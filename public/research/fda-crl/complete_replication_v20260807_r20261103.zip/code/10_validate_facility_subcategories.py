#!/usr/bin/env python3
"""Validate Task A facility labels and build Checkpoint 5A tables.

This script deliberately fails closed: it requires one model result for every
facility-coded letter, verifies the extracted-passage hash, and refuses to
produce accepted results when headline-state agreement on the frozen hand
sample is below 0.80.
"""

from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[1]
VINTAGE = "20260807"
STATES = ["5a_failed", "5b_not_conducted", "5c_pending_conditional", "5e_unclear"]
STATE_LABELS = {
    "5a_failed": "5a Failed inspection",
    "5b_not_conducted": "5b Inspection not conducted",
    "5c_pending_conditional": "5c Pending/conditional",
    "5e_unclear": "5e Unclear",
    "5d_third_party": "5d Third-party overlay",
}
ERA_ORDER = ["2002-2014", "2015-2019", "2020-2023", "2024-2026"]


def current_prompt_sha256() -> str:
    path = ROOT / "code" / "09_classify_facility_subcategories.py"
    spec = importlib.util.spec_from_file_location("facility_classifier", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load facility-classifier prompt from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return hashlib.sha256(module.prompt_text().encode("utf-8")).hexdigest()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(rows[0]) if rows else []
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def tex_escape(value: Any) -> str:
    text = str(value)
    for old, new in [
        ("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"),
        ("$", r"\$"), ("#", r"\#"), ("_", r"\_"), ("{", r"\{"),
        ("}", r"\}"), ("~", r"\textasciitilde{}"), ("^", r"\textasciicircum{}"),
    ]:
        text = text.replace(old, new)
    return text


def write_tex(path: Path, rows: list[dict[str, Any]], fields: list[str], note: str = "") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    cols = "l" + "r" * (len(fields) - 1)
    lines = [r"\begin{tabular}{" + cols + "}", r"\toprule"]
    lines.append(" & ".join(tex_escape(field.replace("_", " ").title()) for field in fields) + r" \\")
    lines.append(r"\midrule")
    for row in rows:
        lines.append(" & ".join(tex_escape(row.get(field, "")) for field in fields) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    if note:
        lines.extend(["", "% Note: " + note])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def era(date_text: str) -> str:
    year = int(date_text[:4])
    if year <= 2014:
        return "2002-2014"
    if year <= 2019:
        return "2015-2019"
    if year <= 2023:
        return "2020-2023"
    return "2024-2026"


def pct(n: int, d: int) -> str:
    return f"{100 * n / d:.1f}%" if d else "NA"


def cohen_kappa(pairs: Iterable[tuple[str, str]], labels: list[str]) -> float | None:
    values = list(pairs)
    n = len(values)
    if not n:
        return None
    observed = sum(a == b for a, b in values) / n
    left = Counter(a for a, _ in values)
    right = Counter(b for _, b in values)
    expected = sum(left[label] * right[label] for label in labels) / (n * n)
    return None if expected == 1 else (observed - expected) / (1 - expected)


def distribution_rows(rows: list[dict[str, Any]], universe: str) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    n = len(rows)
    for state in STATES:
        count = sum(row["facility_state"] == state for row in rows)
        output.append({"universe": universe, "category": state, "label": STATE_LABELS[state],
                       "n": count, "denominator": n, "share": pct(count, n)})
    third_party = sum(row["third_party_flag"] == "yes" for row in rows)
    output.append({"universe": universe, "category": "5d_third_party",
                   "label": STATE_LABELS["5d_third_party"], "n": third_party,
                   "denominator": n, "share": pct(third_party, n)})
    return output


def main() -> None:
    interim = ROOT / "data" / "interim"
    manual_dir = ROOT / "data" / "manual"
    tables = ROOT / "output" / "tables"
    passages = read_jsonl(interim / f"facility_passages_v{VINTAGE}.jsonl")
    facility = [row for row in passages if row["facility_in_categories"]]
    model_rows = read_jsonl(interim / f"facility_subclassifications_v{VINTAGE}.jsonl")

    expected_ids = {row["letter_id"] for row in facility}
    model_ids = [row["letter_id"] for row in model_rows]
    if len(model_ids) != len(set(model_ids)):
        raise RuntimeError("Duplicate model classifications found")
    if set(model_ids) != expected_ids:
        missing = sorted(expected_ids - set(model_ids))
        extra = sorted(set(model_ids) - expected_ids)
        raise RuntimeError(f"Incomplete classification: expected={len(expected_ids)}, "
                           f"observed={len(model_ids)}, missing={missing[:5]}, extra={extra[:5]}")
    if len(model_rows) != 257:
        raise RuntimeError(f"Expected 257 facility-coded letters; found {len(model_rows)}")
    expected_prompt_hash = current_prompt_sha256()
    observed_prompt_hashes = {row.get("prompt_sha256", "") for row in model_rows}
    if observed_prompt_hashes != {expected_prompt_hash}:
        raise RuntimeError(
            "Frozen facility classifications do not match the current prompt: "
            f"expected={expected_prompt_hash}, observed={sorted(observed_prompt_hashes)}"
        )
    response_ids = [row.get("response_id", "") for row in model_rows]
    if any(not value for value in response_ids) or len(response_ids) != len(set(response_ids)):
        raise RuntimeError("Facility-classification response IDs must be present and unique")

    passage_by_id = {row["letter_id"]: row for row in facility}
    for row in model_rows:
        source = passage_by_id[row["letter_id"]]
        digest = hashlib.sha256(source["facility_passage"].encode("utf-8")).hexdigest()
        if row["facility_passage_sha256"] != digest:
            raise RuntimeError(f"Passage hash mismatch for {row['letter_id']}")
        if row["facility_state"] not in STATES:
            raise RuntimeError(f"Invalid state for {row['letter_id']}: {row['facility_state']}")

    by_id = {row["letter_id"]: row for row in model_rows}
    reason_corrections_path = manual_dir / f"facility_subcategory_reason_corrections_v{VINTAGE}.csv"
    reason_corrections = ({row["letter_id"]: row for row in read_csv(reason_corrections_path)}
                          if reason_corrections_path.exists() else {})
    manual = read_csv(manual_dir / f"facility_subcategory_validation_sample_v{VINTAGE}.csv")
    if len(manual) != 40 or len({row["letter_id"] for row in manual}) != 40:
        raise RuntimeError("Frozen hand-validation sample must contain 40 unique letters")
    if sum(row["letter_date"] >= "2024-01-01" for row in manual) < 15:
        raise RuntimeError("Frozen sample has fewer than 15 letters from 2024 forward")

    confusion: list[dict[str, Any]] = []
    for hand_state in STATES:
        confusion.append({
            "hand_coded": hand_state,
            **{f"model_{model_state}": sum(
                row["manual_facility_state"] == hand_state
                and by_id[row["letter_id"]]["facility_state"] == model_state
                for row in manual
            ) for model_state in STATES},
            "row_total": sum(row["manual_facility_state"] == hand_state for row in manual),
        })

    state_pairs = [(row["manual_facility_state"], by_id[row["letter_id"]]["facility_state"])
                   for row in manual]
    state_correct = sum(a == b for a, b in state_pairs)
    state_agreement = state_correct / len(state_pairs)
    kappa = cohen_kappa(state_pairs, STATES)

    validation_fields = [
        ("facility_state", "manual_facility_state"),
        ("failed_present", "manual_failed_present"),
        ("not_conducted_present", "manual_not_conducted_present"),
        ("pending_conditional_present", "manual_pending_conditional_present"),
        ("third_party_flag", "manual_third_party_flag"),
        ("template_only", "manual_template_only"),
    ]
    validation_summary: list[dict[str, Any]] = []
    disagreements: list[dict[str, Any]] = []
    for model_field, manual_field in validation_fields:
        correct = 0
        for hand in manual:
            predicted = by_id[hand["letter_id"]][model_field]
            actual: Any = hand[manual_field]
            if model_field in {"failed_present", "not_conducted_present",
                               "pending_conditional_present", "template_only"}:
                actual = as_bool(actual)
            match = predicted == actual
            correct += match
            if not match:
                disagreements.append({
                    "field": model_field,
                    "letter_id": hand["letter_id"],
                    "file_name": hand["file_name"],
                    "letter_date": hand["letter_date"],
                    "hand_code": actual,
                    "model_code": predicted,
                    "model_rationale": by_id[hand["letter_id"]].get("rationale", ""),
                    "relevant_passage": hand["facility_passage"],
                })
        validation_summary.append({
            "field": model_field, "n": len(manual), "agreements": correct,
            "disagreements": len(manual) - correct, "agreement_rate": pct(correct, len(manual)),
        })

    if state_agreement < 0.80:
        write_csv(tables / f"checkpoint5A_facility_validation_confusion_v{VINTAGE}.csv", confusion)
        write_csv(tables / f"checkpoint5A_facility_validation_disagreements_v{VINTAGE}.csv", disagreements)
        raise RuntimeError(f"Headline-state agreement {state_agreement:.3f} is below 0.80; "
                           "revise definitions and rerun before reporting")

    enriched: list[dict[str, Any]] = []
    for row in model_rows:
        source = passage_by_id[row["letter_id"]]
        corrected_reason = reason_corrections.get(row["letter_id"], {}).get(
            "corrected_reason", row["not_conducted_reason"])
        enriched.append({**row, "not_conducted_reason": corrected_reason,
                         "not_conducted_reason_model_raw": row["not_conducted_reason"],
                         "not_conducted_reason_manually_corrected": row["letter_id"] in reason_corrections,
                         "era": era(row["letter_date"]),
                         "template_language_families": ";".join(source["template_language_families"]),
                         "near_template_cluster": source["near_template_cluster"],
                         "near_template_cluster_n": source["near_template_cluster_n"]})

    full = enriched
    recent = [row for row in enriched if row["letter_date"] >= "2024-01-01"]
    primary = [row for row in enriched if row["facility_primary"]]
    primary_recent = [row for row in primary if row["letter_date"] >= "2024-01-01"]
    distributions: list[dict[str, Any]] = []
    for rows, name in [(full, "all facility-coded"), (recent, "2024+ facility-coded"),
                       (primary, "all facility-primary"),
                       (primary_recent, "2024+ facility-primary")]:
        distributions.extend(distribution_rows(rows, name))

    era_rows: list[dict[str, Any]] = []
    for era_name in ERA_ORDER:
        era_data = [row for row in enriched if row["era"] == era_name]
        counts = Counter(row["facility_state"] for row in era_data)
        era_rows.append({
            "era": era_name, "facility_coded_n": len(era_data),
            **{f"{state}_n": counts[state] for state in STATES},
            **{f"{state}_share": pct(counts[state], len(era_data)) for state in STATES},
            "5d_third_party_n": sum(row["third_party_flag"] == "yes" for row in era_data),
            "5d_third_party_share": pct(sum(row["third_party_flag"] == "yes" for row in era_data), len(era_data)),
        })

    primary_era_rows: list[dict[str, Any]] = []
    for era_name in ERA_ORDER:
        era_data = [row for row in primary if row["era"] == era_name]
        counts = Counter(row["facility_state"] for row in era_data)
        primary_era_rows.append({
            "era": era_name, "facility_primary_n": len(era_data),
            **{f"{state}_n": counts[state] for state in STATES},
            **{f"{state}_share": pct(counts[state], len(era_data)) for state in STATES},
            "5d_third_party_n": sum(row["third_party_flag"] == "yes" for row in era_data),
            "5d_third_party_share": pct(sum(row["third_party_flag"] == "yes" for row in era_data), len(era_data)),
        })

    boilerplate_rows: list[dict[str, Any]] = []
    for rows, name in [(full, "all facility-coded"), (recent, "2024+ facility-coded"),
                       (primary, "all facility-primary"),
                       (primary_recent, "2024+ facility-primary")]:
        template_n = sum(row["template_only"] for row in rows)
        boilerplate_rows.append({"universe": name, "template_only_n": template_n,
                                 "denominator": len(rows), "template_only_share": pct(template_n, len(rows))})

    event_rows: list[dict[str, Any]] = []
    for rows, name in [(full, "all facility-coded"), (recent, "2024+ facility-coded"),
                       (primary, "all facility-primary"),
                       (primary_recent, "2024+ facility-primary")]:
        for event_field in ["failed_present", "not_conducted_present", "pending_conditional_present"]:
            count = sum(row[event_field] for row in rows)
            event_rows.append({"universe": name, "event_flag": event_field, "n": count,
                               "denominator": len(rows), "share": pct(count, len(rows))})

    third_party_rows: list[dict[str, Any]] = []
    for rows, name in [(full, "all facility-coded"), (recent, "2024+ facility-coded"),
                       (primary, "all facility-primary"),
                       (primary_recent, "2024+ facility-primary")]:
        for flag in ["yes", "no", "unclear"]:
            count = sum(row["third_party_flag"] == flag for row in rows)
            third_party_rows.append({"universe": name, "third_party_flag": flag, "n": count,
                                     "denominator": len(rows), "share": pct(count, len(rows))})

    write_csv(tables / f"checkpoint5A_facility_subcategory_distribution_v{VINTAGE}.csv", distributions)
    write_tex(tables / f"checkpoint5A_facility_subcategory_distribution_v{VINTAGE}.tex", distributions,
              ["universe", "category", "n", "denominator", "share"],
              "5d is an overlay and can co-occur with the mutually exclusive headline states.")
    write_csv(tables / f"checkpoint5A_facility_subcategory_by_era_v{VINTAGE}.csv", era_rows)
    write_csv(tables / f"checkpoint5A_facility_primary_subcategory_by_era_v{VINTAGE}.csv", primary_era_rows)
    write_csv(tables / f"checkpoint5A_facility_boilerplate_summary_v{VINTAGE}.csv", boilerplate_rows)
    write_csv(tables / f"checkpoint5A_facility_event_flags_v{VINTAGE}.csv", event_rows)
    write_csv(tables / f"checkpoint5A_facility_third_party_summary_v{VINTAGE}.csv", third_party_rows)
    write_csv(tables / f"checkpoint5A_facility_validation_confusion_v{VINTAGE}.csv", confusion)
    write_tex(tables / f"checkpoint5A_facility_validation_confusion_v{VINTAGE}.tex", confusion,
              ["hand_coded", *[f"model_{state}" for state in STATES], "row_total"])
    write_csv(tables / f"checkpoint5A_facility_validation_summary_v{VINTAGE}.csv", validation_summary)
    write_csv(tables / f"checkpoint5A_facility_validation_disagreements_v{VINTAGE}.csv", disagreements,
              ["field", "letter_id", "file_name", "letter_date", "hand_code", "model_code",
               "model_rationale", "relevant_passage"])

    validated_jsonl = interim / f"facility_subclassifications_validated_v{VINTAGE}.jsonl"
    with validated_jsonl.open("w", encoding="utf-8") as handle:
        for row in enriched:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")

    panel_path = ROOT / "data" / "final" / f"analysis_panel_classified_v{VINTAGE}.csv"
    panel = read_csv(panel_path)
    facility_fields = ["facility_state", "failed_present", "not_conducted_present",
                       "not_conducted_reason", "not_conducted_reason_model_raw",
                       "not_conducted_reason_manually_corrected",
                       "pending_conditional_present", "third_party_flag",
                       "template_only", "facility_codes", "facility_subclassification_status"]
    enriched_by_id = {row["letter_id"]: row for row in enriched}
    merged_panel: list[dict[str, Any]] = []
    for row in panel:
        model = enriched_by_id.get(row["letter_id"])
        add = {field: "" for field in facility_fields}
        if model:
            add.update({
                "facility_state": model["facility_state"],
                "failed_present": int(model["failed_present"]),
                "not_conducted_present": int(model["not_conducted_present"]),
                "not_conducted_reason": model["not_conducted_reason"],
                "not_conducted_reason_model_raw": model["not_conducted_reason_model_raw"],
                "not_conducted_reason_manually_corrected": int(
                    model["not_conducted_reason_manually_corrected"]),
                "pending_conditional_present": int(model["pending_conditional_present"]),
                "third_party_flag": model["third_party_flag"],
                "template_only": int(model["template_only"]),
                "facility_codes": json.dumps(model["facility_codes"], ensure_ascii=False),
                "facility_subclassification_status": model["classification_status"],
            })
        merged_panel.append({**row, **add})
    write_csv(ROOT / "data" / "final" / f"analysis_panel_facility_subclassified_v{VINTAGE}.csv",
              merged_panel, list(panel[0]) + facility_fields)

    usage = Counter()
    for row in model_rows:
        usage["input_tokens"] += row.get("usage", {}).get("input_tokens", 0)
        usage["output_tokens"] += row.get("usage", {}).get("output_tokens", 0)
        usage["reasoning_tokens"] += row.get("usage", {}).get("output_tokens_details", {}).get("reasoning_tokens", 0)
    # Prices for gpt-5.6-terra when run: $2/M input and $12/M output.
    estimated_cost = usage["input_tokens"] * 2 / 1_000_000 + usage["output_tokens"] * 12 / 1_000_000
    summary = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "data_vintage": VINTAGE,
        "facility_coded_n": len(full),
        "facility_primary_n": len(primary),
        "recent_facility_coded_n": len(recent),
        "recent_facility_primary_n": len(primary_recent),
        "headline_state_agreement_n": state_correct,
        "validation_n": len(manual),
        "headline_state_agreement": state_agreement,
        "headline_state_kappa": kappa,
        "template_only_primary_n": sum(row["template_only"] for row in primary),
        "template_only_primary_share": sum(row["template_only"] for row in primary) / len(primary),
        "manual_reason_corrections_n": len(reason_corrections),
        "model": sorted({row["response_model"] for row in model_rows}),
        "usage": dict(usage),
        "estimated_api_cost_usd": round(estimated_cost, 4),
        "outputs": {
            "distribution": str(tables / f"checkpoint5A_facility_subcategory_distribution_v{VINTAGE}.csv"),
            "validation": str(tables / f"checkpoint5A_facility_validation_summary_v{VINTAGE}.csv"),
            "disagreements": str(tables / f"checkpoint5A_facility_validation_disagreements_v{VINTAGE}.csv"),
        },
    }
    (interim / f"checkpoint5A_summary_v{VINTAGE}.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
