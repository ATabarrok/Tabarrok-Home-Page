#!/usr/bin/env python3
"""Extract facility passages, cluster near-template language, and freeze validation sample."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
FACILITY = "facility_inspection"
STRONG_PATTERNS = [
    r"\binspect(?:ion|ions|ed|or|ors|ing)\b",
    r"\bpre[- ]?(?:approval|license) inspection\b",
    r"\bform (?:fda )?483\b",
    r"\bofficial action indicated\b",
    r"\bobjectionable conditions\b",
    r"\bdata integrity (?:finding|findings|concern|concerns|issue|issues)\b",
    r"\b(?:c|current )?gmp deficiencies\b",
    r"\bfacilit(?:y|ies).{0,120}\bdeficien",
    r"\bfacilit(?:y|ies).{0,160}\b(?:issue|issues|observation|observations)\b",
    r"\bmanufacturing site\b.{0,240}\bsatisfactory resolution\b",
    r"\bsatisfactory resolution of (?:the )?(?:remaining )?(?:issues|observations)\b",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--validation-seed", type=int, default=20260807)
    return parser.parse_args()


def find_vintage() -> str:
    paths = sorted((ROOT / "data" / "interim").glob("deficiency_segments_v*.jsonl"))
    if len(paths) != 1:
        raise RuntimeError(f"Expected one segment file, found {[p.name for p in paths]}")
    return re.search(r"_v(\d{8})\.jsonl$", paths[0].name).group(1)  # type: ignore[union-attr]


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def is_heading(line: str) -> bool:
    value = re.sub(r"^\s*\d+[.)]?\s*", "", line.strip())
    if not value or len(value) > 100 or value.startswith(("NDA ", "BLA ", "PAGE ", "REFERENCE ID")):
        return False
    letters = [char for char in value if char.isalpha()]
    return len(letters) >= 3 and sum(char.isupper() for char in letters) / len(letters) >= 0.92


def strong_match(text: str) -> bool:
    lowered = text.lower()
    return any(re.search(pattern, lowered, flags=re.DOTALL) for pattern in STRONG_PATTERNS)


def split_sections(text: str) -> list[tuple[str, str]]:
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    sections: list[tuple[str, list[str]]] = []
    current_heading = ""
    current_lines: list[str] = []
    for line in lines:
        if is_heading(line):
            if current_lines:
                sections.append((current_heading, current_lines))
            current_heading = line.strip()
            current_lines = []
        else:
            current_lines.append(line)
    if current_lines:
        sections.append((current_heading, current_lines))
    return [(heading, "\n".join(lines).strip()) for heading, lines in sections]


def extract_windows(section: str, radius: int = 1400) -> list[str]:
    matches: list[tuple[int, int]] = []
    lowered = section.lower()
    for pattern in STRONG_PATTERNS:
        matches.extend((match.start(), match.end()) for match in re.finditer(pattern, lowered, flags=re.DOTALL))
    if not matches:
        return []
    intervals: list[tuple[int, int]] = []
    for start, end in sorted(matches):
        left = max(0, start - radius)
        right = min(len(section), end + radius)
        if intervals and left <= intervals[-1][1]:
            intervals[-1] = (intervals[-1][0], max(intervals[-1][1], right))
        else:
            intervals.append((left, right))
    return [section[left:right].strip() for left, right in intervals]


def extract_facility_passage(text: str) -> tuple[str, str]:
    selected: list[str] = []
    methods: list[str] = []
    for heading, body in split_sections(text):
        combined = (heading + "\n\n" + body).strip()
        heading_is_facility = bool(re.search(r"FACILIT|INSPECTION|MANUFACTUR", heading, flags=re.I))
        if heading_is_facility and strong_match(combined):
            if len(combined) <= 6500:
                selected.append(combined)
                methods.append("facility_heading")
            else:
                selected.extend(extract_windows(combined))
                methods.append("facility_heading_window")
        elif strong_match(body):
            selected.extend(extract_windows(combined))
            methods.append("keyword_window")
    deduplicated: list[str] = []
    seen: set[str] = set()
    for passage in selected:
        key = re.sub(r"\s+", " ", passage).strip()
        if key and key not in seen:
            deduplicated.append(passage)
            seen.add(key)
    return "\n\n[... FACILITY PASSAGE ...]\n\n".join(deduplicated), "+".join(sorted(set(methods)))


def normalize_passage(text: str) -> str:
    value = text.lower()
    value = re.sub(r"https?://\S+", " <url> ", value)
    value = re.sub(r"\b(?:nda|bla)\s*\d+[a-z0-9-]*\b", " <application> ", value)
    value = re.sub(r"\breference id\s*:?\s*\d+\b", " <reference> ", value)
    value = re.sub(r"\b(?:fei|duns)\s*:?\s*\d+\b", " <site-id> ", value)
    value = re.sub(
        r"\b(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2},?\s+\d{4}\b",
        " <date> ", value,
    )
    value = re.sub(r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b", " <date> ", value)
    value = re.sub(r"\(b\)\s*\(\d\)", " <redacted> ", value)
    value = re.sub(r"[®©□■]+", " <redacted> ", value)
    value = re.sub(r"\b\d+(?:\.\d+)?\b", " <number> ", value)
    value = re.sub(r"\bpage\s*<number>\b", " ", value)
    value = re.sub(r"[^a-z<> ]+", " ", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def template_language_families(text: str) -> list[str]:
    lowered = re.sub(r"\s+", " ", text.lower())
    families: list[str] = []
    patterns = [
        (
            "legacy_recent_inspection_conveyed_deficiencies",
            r"during a recent inspection.{0,500}(?:investigator|investigators).{0,300}conveyed (?:deficiencies|observations)",
        ),
        (
            "modern_form483_response_template",
            r"following .{0,120}(?:cgmp|pre[- ]?(?:approval|license)).{0,120}inspection.{0,500}fda conveyed deficiencies.{0,1200}fda (?:form )?483",
        ),
        (
            "objectionable_conditions_template",
            r"(?:observed|found) objectionable conditions.{0,500}satisfactory resolution",
        ),
        (
            "not_ready_for_inspection_template",
            r"(?:could not|unable to) complete (?:the )?inspection.{0,300}(?:not ready|unavailable)",
        ),
        (
            "travel_restriction_template",
            r"(?:travel restrictions|restrictions on travel).{0,500}(?:unable|could not).{0,200}inspection",
        ),
        (
            "section_704_records_review_template",
            r"review of records requested under section 704\(a\)\(4\).{0,500}(?:issues|observations)",
        ),
        (
            "generic_satisfactory_inspection_condition",
            r"satisfactory inspection(?:s| outcomes)? (?:is|are) required before.{0,120}(?:approved|approval)",
        ),
    ]
    for name, pattern in patterns:
        if re.search(pattern, lowered):
            families.append(name)
    return families or (["other_inspection_language"] if text else [])


def passage_simhash(text: str) -> tuple[int, int]:
    words = text.split()
    shingles = [" ".join(words[index:index + 4]) for index in range(max(1, len(words) - 3))]
    weights = [0] * 64
    for shingle in shingles:
        value = int.from_bytes(hashlib.blake2b(shingle.encode("utf-8"), digest_size=8).digest(), "big")
        for bit in range(64):
            weights[bit] += 1 if value & (1 << bit) else -1
    fingerprint = sum((1 << bit) for bit, weight in enumerate(weights) if weight >= 0)
    return fingerprint, len(words)


def cluster_passages(rows: list[dict[str, Any]], max_hamming_distance: int = 6) -> None:
    representatives: list[tuple[int, int]] = []
    members: list[list[int]] = []
    nonempty = sorted(
        [index for index, row in enumerate(rows) if row["normalized_facility_passage"]],
        key=lambda index: (len(rows[index]["normalized_facility_passage"]), rows[index]["letter_id"]),
    )
    for index in nonempty:
        text = rows[index]["normalized_facility_passage"]
        fingerprint, word_n = passage_simhash(text)
        best_cluster = -1
        best_distance = 65
        for cluster_id, (representative_fingerprint, representative_word_n) in enumerate(representatives):
            length_ratio = min(word_n, representative_word_n) / max(word_n, representative_word_n)
            if length_ratio < 0.72:
                continue
            distance = (fingerprint ^ representative_fingerprint).bit_count()
            if distance < best_distance:
                best_cluster = cluster_id
                best_distance = distance
        if best_cluster >= 0 and best_distance <= max_hamming_distance:
            members[best_cluster].append(index)
        else:
            representatives.append((fingerprint, word_n))
            members.append([index])
            best_cluster = len(members) - 1
            best_distance = 0
        rows[index]["near_template_cluster"] = f"cluster_{best_cluster + 1:03d}"
        rows[index]["similarity_to_cluster_representative"] = round(1 - best_distance / 64, 6)
    for cluster_id, cluster_members in enumerate(members, start=1):
        size = len(cluster_members)
        for index in cluster_members:
            rows[index]["near_template_cluster"] = f"cluster_{cluster_id:03d}"
            rows[index]["near_template_cluster_n"] = size
    for row in rows:
        row.setdefault("near_template_cluster", "")
        row.setdefault("near_template_cluster_n", 0)
        row.setdefault("similarity_to_cluster_representative", None)


def prepare_validation_sample(rows: list[dict[str, Any]], vintage: str, seed: int) -> Path:
    eligible = [row for row in rows if row["facility_primary"] and row["facility_passage"]]
    historical = sorted([row for row in eligible if row["letter_date"] < "2024-01-01"], key=lambda row: row["letter_id"])
    recent = sorted([row for row in eligible if row["letter_date"] >= "2024-01-01"], key=lambda row: row["letter_id"])
    rng = random.Random(seed)
    selected = rng.sample(historical, 20) + rng.sample(recent, 20)
    selected.sort(key=lambda row: (row["letter_date"], row["letter_id"]))
    path = ROOT / "data" / "manual" / f"facility_subcategory_validation_sample_v{vintage}.csv"
    fields = [
        "letter_id", "application_id", "letter_date", "file_name", "company_name",
        "drugsfda_sponsor_name", "facility_passage",
        "manual_facility_state", "manual_failed_present", "manual_not_conducted_present",
        "manual_pending_conditional_present", "manual_third_party_flag",
        "manual_template_only", "manual_not_conducted_reason", "manual_notes",
    ]
    existing: dict[str, dict[str, str]] = {}
    if path.exists():
        with path.open(encoding="utf-8-sig", newline="") as handle:
            existing = {row["letter_id"]: row for row in csv.DictReader(handle)}
    labels_path = ROOT / "data" / "manual" / f"facility_subcategory_validation_labels_v{vintage}.csv"
    labels: dict[str, dict[str, str]] = {}
    if labels_path.exists():
        with labels_path.open(encoding="utf-8-sig", newline="") as handle:
            labels = {row["letter_id"]: row for row in csv.DictReader(handle)}
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in selected:
            old = existing.get(row["letter_id"], {})
            hand = labels.get(row["letter_id"], {})
            writer.writerow({
                "letter_id": row["letter_id"],
                "application_id": row["application_id"],
                "letter_date": row["letter_date"],
                "file_name": row["file_name"],
                "company_name": row["company_name"],
                "drugsfda_sponsor_name": row["drugsfda_sponsor_name"],
                "facility_passage": row["facility_passage"],
                **{field: hand.get(field, old.get(field, "")) for field in fields[7:]},
            })
    return path


def main() -> None:
    args = parse_args()
    vintage = find_vintage()
    interim = ROOT / "data" / "interim"
    segments = read_jsonl(interim / f"deficiency_segments_v{vintage}.jsonl")
    classifications = read_jsonl(interim / f"llm_deficiency_classifications_v{vintage}.jsonl")
    by_id = {row["letter_id"]: row for row in classifications}
    panel_path = ROOT / "data" / "final" / f"analysis_panel_classified_v{vintage}.csv"
    with panel_path.open(encoding="utf-8-sig", newline="") as handle:
        panel_by_id = {row["letter_id"]: row for row in csv.DictReader(handle)}
    rows: list[dict[str, Any]] = []
    for segment in segments:
        model = by_id[segment["letter_id"]]
        panel_row = panel_by_id[segment["letter_id"]]
        passage, method = extract_facility_passage(segment["deficiency_text"])
        normalized = normalize_passage(passage)
        language_families = template_language_families(passage)
        rows.append({
            "letter_id": segment["letter_id"],
            "application_id": segment["application_id"],
            "letter_date": segment["letter_date"],
            "file_name": segment["file_name"],
            "company_name": panel_row.get("company_name", ""),
            "drugsfda_sponsor_name": panel_row.get("drugsfda_sponsor_name", ""),
            "primary_category": model["primary_category"],
            "facility_in_categories": FACILITY in model["categories"],
            "facility_primary": model["primary_category"] == FACILITY,
            "facility_passage": passage,
            "facility_passage_sha256": hashlib.sha256(passage.encode("utf-8")).hexdigest(),
            "facility_passage_chars": len(passage),
            "facility_extraction_method": method,
            "normalized_facility_passage": normalized,
            "normalized_facility_passage_sha256": hashlib.sha256(normalized.encode("utf-8")).hexdigest(),
            "template_language_families": language_families,
        })
    cluster_passages(rows)
    output_path = interim / f"facility_passages_v{vintage}.jsonl"
    with output_path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")

    cluster_summary: dict[str, dict[str, Any]] = {}
    for row in rows:
        cluster = row["near_template_cluster"] or "no_passage"
        summary = cluster_summary.setdefault(cluster, {
            "near_template_cluster": cluster,
            "letter_n": 0,
            "facility_coded_n": 0,
            "facility_primary_n": 0,
            "representative_letter_id": row["letter_id"],
            "representative_normalized_passage": row["normalized_facility_passage"],
        })
        summary["letter_n"] += 1
        summary["facility_coded_n"] += int(row["facility_in_categories"])
        summary["facility_primary_n"] += int(row["facility_primary"])
    cluster_path = interim / f"facility_template_clusters_v{vintage}.csv"
    with cluster_path.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "near_template_cluster", "letter_n", "facility_coded_n", "facility_primary_n",
            "representative_letter_id", "representative_normalized_passage",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(sorted(cluster_summary.values(), key=lambda row: (-row["letter_n"], row["near_template_cluster"])))

    family_summary: list[dict[str, Any]] = []
    family_names = sorted({family for row in rows for family in row["template_language_families"]})
    for family in family_names:
        family_rows = [row for row in rows if family in row["template_language_families"]]
        family_summary.append({
            "template_language_family": family,
            "all_letters_n": len(family_rows),
            "all_letters_share": round(len(family_rows) / len(rows), 6),
            "facility_coded_n": sum(row["facility_in_categories"] for row in family_rows),
            "facility_primary_n": sum(row["facility_primary"] for row in family_rows),
            "facility_primary_share": round(
                sum(row["facility_primary"] for row in family_rows) /
                max(1, sum(row["facility_primary"] for row in rows)), 6
            ),
        })
    family_path = interim / f"facility_template_language_families_v{vintage}.csv"
    with family_path.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "template_language_family", "all_letters_n", "all_letters_share",
            "facility_coded_n", "facility_primary_n", "facility_primary_share",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(sorted(family_summary, key=lambda row: (-row["facility_primary_n"], row["template_language_family"])))

    validation_path = prepare_validation_sample(rows, vintage, args.validation_seed)
    facility_rows = [row for row in rows if row["facility_in_categories"]]
    empty_facility = [row for row in facility_rows if not row["facility_passage"]]
    largest = max((row["near_template_cluster_n"] for row in rows), default=0)
    print(
        f"Extracted facility passages for {sum(bool(row['facility_passage']) for row in rows)}/{len(rows)} letters; "
        f"facility-coded={len(facility_rows)}, facility-primary={sum(row['facility_primary'] for row in rows)}, "
        f"empty among facility-coded={len(empty_facility)}, largest near-template cluster={largest}. "
        f"Validation sample: {validation_path.name}."
    )


if __name__ == "__main__":
    main()
