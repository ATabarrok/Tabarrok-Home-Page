#!/usr/bin/env python3
"""Pre-Phase-4 exploratory audit of the classified CRL panel."""

from __future__ import annotations

import csv
import os
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".mplconfig"))
(ROOT / ".mplconfig").mkdir(exist_ok=True)

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


CATEGORIES = [
    "clinical_efficacy", "clinical_safety", "trial_design_conduct", "cmc",
    "facility_inspection", "stability_shelf_life", "bioequivalence_bioavailability",
    "nonclinical_toxicology", "labeling_proprietary_name", "administrative_procedural",
]
LABELS = {
    "clinical_efficacy": "Clinical efficacy",
    "clinical_safety": "Clinical safety",
    "trial_design_conduct": "Trial design/conduct",
    "cmc": "CMC",
    "facility_inspection": "Facility inspection",
    "stability_shelf_life": "Stability/shelf life",
    "bioequivalence_bioavailability": "Bioequivalence/availability",
    "nonclinical_toxicology": "Nonclinical/toxicology",
    "labeling_proprietary_name": "Labeling/name",
    "administrative_procedural": "Administrative/procedural",
}


def find_vintage() -> str:
    paths = sorted((ROOT / "data" / "final").glob("analysis_panel_classified_v*.csv"))
    if len(paths) != 1:
        raise RuntimeError(f"Expected one classified panel, found {[p.name for p in paths]}")
    return re.search(r"_v(\d{8})\.csv$", paths[0].name).group(1)  # type: ignore[union-attr]


def missing(series: pd.Series) -> pd.Series:
    return series.isna() | series.astype(str).str.strip().eq("")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def latex_escape(value: Any) -> str:
    text = str(value)
    for old, new in {
        "\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
        "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
    }.items():
        text = text.replace(old, new)
    return text


def write_latex(path: Path, headers: list[str], rows: list[list[Any]], alignment: str) -> None:
    lines = [
        f"\\begin{{tabular}}{{{alignment}}}", "\\toprule",
        " & ".join(latex_escape(x) for x in headers) + r" \\", "\\midrule",
    ]
    lines.extend(" & ".join(latex_escape(x) for x in row) + r" \\" for row in rows)
    lines.extend(["\\bottomrule", "\\end{tabular}", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def sponsor_group(value: Any) -> str:
    if pd.isna(value) or str(value).strip() == "":
        return "Unknown/unmatched"
    count = int(float(value))
    if count == 1:
        return "1 application"
    if count <= 9:
        return "2-9 applications"
    return "10+ applications"


def named_division_group(frame: pd.DataFrame, minimum_n: int = 10) -> pd.Series:
    raw = frame["review_division"].fillna("").astype(str).str.strip()
    counts = raw[raw.ne("")].value_counts()
    retained = set(counts[counts >= minimum_n].index)
    return raw.map(lambda x: "Unknown" if not x else (x if x in retained else "Other named divisions"))


def main() -> None:
    vintage = find_vintage()
    panel_path = ROOT / "data" / "final" / f"analysis_panel_classified_v{vintage}.csv"
    panel = pd.read_csv(panel_path, dtype=str, keep_default_na=False)
    classified = panel.loc[panel["deficiency_categories"].ne("")].copy()
    strict = classified.loc[classified["is_strict_crl"].eq("1")].copy()
    first = strict.loc[strict["is_first_strict_crl"].eq("1")].copy()
    eligible = first.loc[first["second_crl_730d_eligible"].eq("1")].copy()
    ineligible = first.loc[first["second_crl_730d_eligible"].ne("1")].copy()

    tables = ROOT / "output" / "tables"
    figures = ROOT / "output" / "figures"
    tables.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)

    sample_flow = [
        {"stage": "Endpoint records", "n": len(panel), "unit": "letter/action"},
        {"stage": "Classified deficiency actions", "n": len(classified), "unit": "letter/action"},
        {"stage": "Strict complete-response letters", "n": len(strict), "unit": "letter"},
        {"stage": "Applications with a first strict CRL", "n": len(first), "unit": "application"},
        {"stage": "Applications eligible for 730-day outcome", "n": len(eligible), "unit": "application"},
        {
            "stage": "Second CRL within 730 days",
            "n": int(eligible["second_crl_within_730d_event"].eq("1").sum()),
            "unit": "application/event",
        },
        {
            "stage": "2024-forward classified strict CRLs",
            "n": int(strict["is_2024_forward_strict_crl"].eq("1").sum()),
            "unit": "letter",
        },
    ]
    write_csv(tables / f"eda_sample_flow_v{vintage}.csv", sample_flow, ["stage", "n", "unit"])
    write_latex(
        tables / f"eda_sample_flow_v{vintage}.tex",
        ["Stage", "N", "Unit"],
        [[row["stage"], row["n"], row["unit"]] for row in sample_flow],
        "lrl",
    )

    audit_fields = [
        "primary_deficiency_category", "classification_status", "application_type",
        "review_division", "therapeutic_area_proxy", "sponsor_application_count",
        "original_submission_date", "review_priority", "orphan_status",
        "drugsfda_sponsor_name", "approval_date",
    ]
    missingness: list[dict[str, Any]] = []
    for scope_name, frame in [("classified_letters", classified), ("first_strict_crl_applications", first)]:
        for field in audit_fields:
            missing_n = int(missing(frame[field]).sum())
            missingness.append({
                "scope": scope_name,
                "field": field,
                "sample_n": len(frame),
                "missing_n": missing_n,
                "missing_share": round(missing_n / len(frame), 6),
            })
    write_csv(
        tables / f"eda_missingness_v{vintage}.csv",
        missingness,
        ["scope", "field", "sample_n", "missing_n", "missing_share"],
    )

    category_sets = classified["deficiency_categories"].str.split("|").map(set)
    co_counts = pd.DataFrame(0, index=CATEGORIES, columns=CATEGORIES, dtype=int)
    for left in CATEGORIES:
        for right in CATEGORIES:
            co_counts.loc[left, right] = int(category_sets.map(lambda values: left in values and right in values).sum())
    co_shares = co_counts / len(classified)
    co_counts.to_csv(tables / f"eda_category_cooccurrence_counts_v{vintage}.csv", encoding="utf-8-sig")
    co_shares.to_csv(tables / f"eda_category_cooccurrence_shares_v{vintage}.csv", encoding="utf-8-sig")

    def binary_share(frame: pd.DataFrame, condition: pd.Series) -> float:
        return float(condition.loc[frame.index].mean()) if len(frame) else float("nan")

    eligibility_rows: list[dict[str, Any]] = []
    comparisons: list[tuple[str, pd.Series]] = []
    for category in CATEGORIES:
        comparisons.append((f"primary_{category}", first["primary_deficiency_category"].eq(category)))
    comparisons.extend([
        ("application_type_BLA", first["application_type"].eq("BLA")),
        ("drugsfda_matched", first["drugsfda_matched"].eq("1")),
        ("classification_non_ok", first["classification_status"].ne("ok")),
        ("visible_redaction_marker", pd.to_numeric(first["redaction_marker_count"], errors="coerce").fillna(0).gt(0)),
        ("new_clinical_trial_required", first["new_clinical_trial_required"].eq("1")),
        ("third_party_manufacturer_yes", first["third_party_manufacturer"].eq("yes")),
        ("review_division_missing", missing(first["review_division"])),
        ("sponsor_size_missing", missing(first["sponsor_application_count"])),
    ])
    for measure, condition in comparisons:
        eligible_share = binary_share(eligible, condition)
        ineligible_share = binary_share(ineligible, condition)
        eligibility_rows.append({
            "measure": measure,
            "eligible_n": len(eligible),
            "ineligible_n": len(ineligible),
            "eligible_value": round(eligible_share, 6),
            "ineligible_value": round(ineligible_share, 6),
            "ineligible_minus_eligible": round(ineligible_share - eligible_share, 6),
            "value_type": "share",
        })
    for measure, values in [
        ("mean_first_crl_year", pd.to_datetime(first["letter_date"]).dt.year),
        ("mean_redaction_markers_per_1000_chars", pd.to_numeric(first["redaction_markers_per_1000_chars"], errors="coerce")),
    ]:
        eligible_value = float(values.loc[eligible.index].mean())
        ineligible_value = float(values.loc[ineligible.index].mean())
        eligibility_rows.append({
            "measure": measure,
            "eligible_n": len(eligible),
            "ineligible_n": len(ineligible),
            "eligible_value": round(eligible_value, 6),
            "ineligible_value": round(ineligible_value, 6),
            "ineligible_minus_eligible": round(ineligible_value - eligible_value, 6),
            "value_type": "mean",
        })
    write_csv(
        tables / f"eda_outcome_eligibility_comparison_v{vintage}.csv",
        eligibility_rows,
        [
            "measure", "eligible_n", "ineligible_n", "eligible_value", "ineligible_value",
            "ineligible_minus_eligible", "value_type",
        ],
    )

    classified["sponsor_size_group"] = classified["sponsor_application_count"].map(sponsor_group)
    classified["division_group"] = named_division_group(classified)
    sparse_rows: list[dict[str, Any]] = []
    for dimension, column in [
        ("application_type", "application_type"),
        ("sponsor_size", "sponsor_size_group"),
        ("review_division", "division_group"),
    ]:
        for group_name, group in classified.groupby(column, dropna=False):
            for category in CATEGORIES:
                category_n = int(group["primary_deficiency_category"].eq(category).sum())
                sparse_rows.append({
                    "dimension": dimension,
                    "group": group_name,
                    "group_n": len(group),
                    "category": category,
                    "primary_n": category_n,
                    "sparse_under_10": int(category_n < 10),
                    "zero_cell": int(category_n == 0),
                })
    write_csv(
        tables / f"eda_sparse_cells_v{vintage}.csv",
        sparse_rows,
        ["dimension", "group", "group_n", "category", "primary_n", "sparse_under_10", "zero_cell"],
    )

    plt.rcParams.update({"font.size": 9, "axes.titlesize": 12, "axes.labelsize": 10})
    fig, ax = plt.subplots(figsize=(9.2, 7.5))
    image = ax.imshow(co_shares.values * 100, cmap="Blues", vmin=0)
    ax.set_xticks(range(len(CATEGORIES)), [LABELS[c] for c in CATEGORIES], rotation=45, ha="right")
    ax.set_yticks(range(len(CATEGORIES)), [LABELS[c] for c in CATEGORIES])
    for i in range(len(CATEGORIES)):
        for j in range(len(CATEGORIES)):
            value = co_shares.iloc[i, j] * 100
            ax.text(j, i, f"{value:.0f}", ha="center", va="center", fontsize=7,
                    color="white" if value > 30 else "#1f2937")
    ax.set_title("Deficiency-category co-occurrence (% of 449 classified actions)")
    fig.colorbar(image, ax=ax, label="Percent of classified actions", fraction=0.045)
    fig.tight_layout()
    fig.savefig(figures / f"eda_category_cooccurrence_v{vintage}.pdf", bbox_inches="tight")
    plt.close(fig)

    first["first_crl_year"] = pd.to_datetime(first["letter_date"]).dt.year
    by_year = first.groupby(["first_crl_year", "second_crl_730d_eligible"]).size().unstack(fill_value=0)
    eligible_counts = by_year.get("1", pd.Series(0, index=by_year.index))
    ineligible_counts = by_year.sum(axis=1) - eligible_counts
    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    ax.bar(by_year.index, eligible_counts, color="#2563eb", label="730-day eligible")
    ax.bar(by_year.index, ineligible_counts, bottom=eligible_counts, color="#cbd5e1", label="Right-truncated")
    ax.axvline(2024.66, color="#b91c1c", linestyle="--", linewidth=1, label="730-day cutoff")
    ax.set(title="First strict CRLs and fixed-horizon outcome eligibility", xlabel="First CRL year", ylabel="Applications")
    ax.set_xticks(by_year.index)
    ax.tick_params(axis="x", rotation=45)
    ax.legend(frameon=False, ncol=3, loc="upper left")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(figures / f"eda_outcome_eligibility_by_year_v{vintage}.pdf", bbox_inches="tight")
    plt.close(fig)

    first_missing = pd.DataFrame([row for row in missingness if row["scope"] == "first_strict_crl_applications"])
    first_missing = first_missing.sort_values("missing_share")
    fig, ax = plt.subplots(figsize=(8.4, 5.2))
    ax.barh(first_missing["field"].map(lambda x: x.replace("_", " ")),
            first_missing["missing_share"] * 100, color="#64748b")
    ax.set(title="Missingness among 333 first-CRL applications", xlabel="Missing (%)", ylabel="")
    ax.set_xlim(0, max(5, first_missing["missing_share"].max() * 110))
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(figures / f"eda_first_crl_missingness_v{vintage}.pdf", bbox_inches="tight")
    plt.close(fig)

    print(
        f"EDA complete: {len(classified)} classified actions, {len(first)} first strict CRLs, "
        f"{len(eligible)} eligible applications, "
        f"{int(eligible['second_crl_within_730d_event'].eq('1').sum())} events."
    )


if __name__ == "__main__":
    main()
