$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$out=Join-Path $root 'output/revision/sequence-check'
[IO.Directory]::CreateDirectory($out) | Out-Null
$letters=@{}
Get-Content (Join-Path $root 'data/interim/crl_letters_parsed_v20260807.jsonl') | ForEach-Object { $r=$_ | ConvertFrom-Json; $letters[$r.letter_id]=$r }
# Reconstruct the original pre-correction pairs so this audit remains reproducible.
$panel=Import-Csv (Join-Path $root 'data/final/analysis_panel_classified_v20260807.csv')
$pairs=@(foreach($group in ($panel | Where-Object is_strict_crl -eq '1' | Group-Object application_id)) {
 $g=@($group.Group | Sort-Object letter_date,letter_id)
 for($i=0;$i -lt $g.Count-1;$i++) {
  $a=$g[$i];$b=$g[$i+1]
  [pscustomobject]@{application_id=$a.application_id;pair_sequence=$i+1;first_letter_id=$a.letter_id;second_letter_id=$b.letter_id;first_date=$a.letter_date;second_date=$b.letter_date;first=$a.primary_deficiency_category;second=$b.primary_deficiency_category}
 }
})
$month='(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}'
$rows=foreach($pair in $pairs) {
 $a=$letters[$pair.first_letter_id]; $b=$letters[$pair.second_letter_id]
 $ta=($a.text -replace '\s+',' ').Trim(); $tb=($b.text -replace '\s+',' ').Trim()
 $date=[datetime]::ParseExact($pair.first_date,'yyyy-MM-dd',[cultureinfo]::InvariantCulture)
 $pattern='(?i)'+$date.ToString('MMMM',[cultureinfo]::InvariantCulture)+'\s+0?'+$date.Day+',?\s+'+$date.Year
 $mentions=@([regex]::Matches($tb,$pattern))
 $contexts=@($mentions | ForEach-Object { $i=[Math]::Max(0,$_.Index-180); $tb.Substring($i,[Math]::Min(450,$tb.Length-$i)) })
 $direct=@($contexts | Where-Object { $_ -match '(?i)(complete response to|response to our|complete response letter|action letter)' }).Count -gt 0
 $introA=$ta.Substring(0,[Math]::Min(2300,$ta.Length)); $introB=$tb.Substring(0,[Math]::Min(2300,$tb.Length))
 $ack=[regex]::Match($introB,'(?i)(?:We acknowledge|We also acknowledge|Your resubmission).{0,650}')
 $origPattern='(?i)(?:application|supplement|BLA|NDA)\)?\s+(?:dated(?: and (?:received|submitted))?|submitted|received)\s+('+$month+')'
 $da=[regex]::Match($introA,$origPattern); $db=[regex]::Match($introB,$origPattern)
 $sameOrig=$false
 if($da.Success -and $db.Success) {try {$sameOrig=[datetime]::Parse($da.Groups[1].Value,[cultureinfo]::InvariantCulture) -eq [datetime]::Parse($db.Groups[1].Value,[cultureinfo]::InvariantCulture)} catch {} }
 $refsA=$a.target_submission_refs_by_application | ConvertTo-Json -Compress -Depth 8
 $refsB=$b.target_submission_refs_by_application | ConvertTo-Json -Compress -Depth 8
 $status=if($pair.first_date -eq $pair.second_date){'same_date'} elseif($direct){'explicit_prior_date_candidate'} elseif($sameOrig){'matching_submission_date_candidate'} else {'needs_review'}
 [pscustomobject]@{application_id=$pair.application_id;pair_sequence=$pair.pair_sequence;first_letter_id=$pair.first_letter_id;second_letter_id=$pair.second_letter_id;first_date=$pair.first_date;second_date=$pair.second_date;first_category=$pair.first;second_category=$pair.second;screen_status=$status;first_submission_date=$da.Groups[1].Value;second_submission_date=$db.Groups[1].Value;first_refs=$refsA;second_refs=$refsB;prior_date_context=($contexts -join ' | ');acknowledgement=$ack.Value;first_intro=$introA;second_intro=$introB}
}
$rows | Export-Csv (Join-Path $out 'pair_evidence.csv') -NoTypeInformation
# Case decisions from inspection of the stored full-text introductions and acknowledgement passages.
$exceptions=@{
 'BLA761215/1'=@('duplicate_record','Same date, same Original 2 subject, and identical whitespace-normalized full text. Not two review cycles.')
 'BLA761303/1'=@('different_original_submissions','Same-day Original 2 (LBCL) and Original 1 (follicular lymphoma) decisions. Not successive reviews.')
 'BLA761303/2'=@('matching_original_identifier','Both concern Original 1; later letter explicitly acknowledges its resubmission, but action date is redacted.')
 'NDA204017/1'=@('incomplete_response_acknowledgement','Later document is titled ACKNOWLEDGE INCOMPLETE RESPONSE and explicitly states FDA will not start the review clock. Same submission, not a second CRL decision.')
 'NDA204017/2'=@('incomplete_response_acknowledgement','Earlier document is the incomplete-response acknowledgement; later CRL explicitly responds to the February 13, 2013 CRL, not this July acknowledgement.')
 'NDA202860/1'=@('uncertain_review_continuity','Same NDA and GENOsyl product, but 2019 letter gives a July 2018 submission date; 2013 letter gives March/August 2012. No explicit link to earlier CRL found in introduction.')
 'NDA204417/1'=@('intervening_approval_rescinded','Same original application date; later letter follows rescission of March 2015 approval. It explicitly treats a pending labeling supplement as an amendment to the original NDA. Not an unrelated supplement, but not uninterrupted nonapproval.')
 'NDA205394/1'=@('likely_link_date_discrepancy','Same NDA and Rizaport product; later letter cites January 21, 2014 rather than stored January 31, 2014. Application dates also differ by days. Exact date linkage remains unresolved.')
 'NDA208276/1'=@('likely_link_date_discrepancy','Same NDA and Remodulin implantable system; later letter cites October 8 rather than stored October 7, 2016. Same device deficiency described. Exact date linkage remains unresolved.')
 'NDA210136/1'=@('same_submission_intervening_action','Both identify July 19, 2017 BRIXADI NDA. Later letter responds to December 21, 2018 action, absent between the observed January 2018 and December 2020 letters.')
}
$audit=foreach($row in $rows) {
 $key=$row.application_id+'/'+$row.pair_sequence
 if($exceptions.ContainsKey($key)) {$decision=$exceptions[$key][0];$note=$exceptions[$key][1]}
 elseif($row.screen_status -eq 'explicit_prior_date_candidate') {$decision='explicit_prior_crl_date';$note='Later letter explicitly acknowledges response to the earlier letter date; passage inspected.'}
 elseif($row.screen_status -eq 'needs_review') {$decision='resubmission_acknowledged_date_obscured';$note='Later letter explicitly acknowledges response to an earlier action, but its date is obscured. Supports a resubmission sequence without proving this exact adjacent link.'}
 else {throw "Unreviewed pair $key"}
 $row | Add-Member -NotePropertyName review_decision -NotePropertyValue $decision
 $row | Add-Member -NotePropertyName review_note -NotePropertyValue $note
 $row
}
$audit | Export-Csv (Join-Path $out 'reviewed_pair_audit.csv') -NoTypeInformation
$audit | Group-Object review_decision | Select-Object Name,Count | Export-Csv (Join-Path $out 'decision_counts.csv') -NoTypeInformation
$facility=@($audit | Where-Object {$_.pair_sequence -eq '1' -and $_.first_category -eq 'facility_inspection'})
$exact=@($facility | Where-Object review_decision -eq 'explicit_prior_crl_date')
$sensitivity=@(
 [pscustomobject]@{sample='All original facility first pairs';n=$facility.Count;repeat=@($facility | Where-Object second_category -eq 'facility_inspection').Count}
 [pscustomobject]@{sample='Explicit prior-CRL date linkage';n=$exact.Count;repeat=@($exact | Where-Object second_category -eq 'facility_inspection').Count}
)
$sensitivity | Export-Csv (Join-Path $out 'facility_linkage_sensitivity.csv') -NoTypeInformation
$audit | Group-Object review_decision | Select-Object Name,Count | Format-Table
$sensitivity | Format-Table
$rows | Group-Object screen_status | Select-Object Name,Count | Format-Table
$rows | Where-Object screen_status -in 'needs_review','same_date' | ForEach-Object {"$($_.application_id) #$($_.pair_sequence) $($_.first_date) -> $($_.second_date) [$($_.screen_status)]`nFIRST: $($_.first_intro.Substring(0,[Math]::Min(1100,$_.first_intro.Length)))`nSECOND: $($_.second_intro)`n"} | Set-Content (Join-Path $out 'cases_to_review.txt')
