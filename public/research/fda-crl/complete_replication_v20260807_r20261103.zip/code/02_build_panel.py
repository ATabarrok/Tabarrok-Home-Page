#!/usr/bin/env python3
"""Build the letter-level Phase 2 CRL analysis panel.

The script uses the dated raw CRL response and Drugs@FDA JSON archive created by
``01_acquire.py``.  It never edits raw inputs.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import sys
import zipfile
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterable


FORWARD_WINDOW_START = date(2024, 1, 1)
SECOND_CRL_HORIZON_DAYS = 730
APP_RE = re.compile(r"\b(NDA|BLA|BL|ANDA)\s*(\d{6})\b", re.IGNORECASE)
ORIG_RE = re.compile(r"/\s*Orig(?:inal)?\s*[- ]?(\d+)", re.IGNORECASE)
SUPPL_RE = re.compile(r"/\s*S\s*-?\s*0*(\d+)", re.IGNORECASE)
MONTH_DATE = (
    r"(?:January|February|March|April|May|June|July|August|September|October|"
    r"November|December)\s+\d{1,2},\s+\d{4}"
)
RESUBMISSION_ACK_RE = re.compile(
    r"acknowledge(?:d)?\s+receipt\s+of\s+your\s+(?:major\s+)?"
    r"(?:amendment|resubmission)\s+dated\s+(?P<resub>" + MONTH_DATE + r")"
    r".{0,700}?complete\s+response\s+to\s+(?:our\s+)?"
    r"(?P<action>" + MONTH_DATE + r")",
    re.IGNORECASE | re.DOTALL,
)
DRUGSFDA_DOCUMENTATION_URL = (
    "https://open.fda.gov/apis/drug/drugsfda/understanding-the-api-results/"
)
DRUGSATFDA_DEFINITIONS_URL = (
    "https://www.fda.gov/drugs/drug-approvals-and-databases/drugsfda-data-files"
)
FDA_2025_RELEASE_URL = (
    "https://www.fda.gov/news-events/press-announcements/"
    "fda-announces-real-time-release-complete-response-letters-posts-previously-unpublished-batch-89"
)
PDUFA_2024_REPORT_URL = "https://www.fda.gov/media/188188/download"
PDUFA_2025_REPORT_URL = "https://www.fda.gov/media/191112/download"


def parse_mmddyyyy(value: str) -> date:
    return datetime.strptime(value, "%m/%d/%Y").date()


def parse_yyyymmdd(value: Any) -> date | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        return datetime.strptime(value.strip(), "%Y%m%d").date()
    except ValueError:
        return None


def parse_month_date(value: str) -> date:
    return datetime.strptime(value, "%B %d, %Y").date()


def normalize_app_type(value: str) -> str:
    value = value.upper()
    return "BLA" if value in {"BL", "BLA"} else value


def parse_application_entries(
    values: list[str] | None,
) -> tuple[list[str], dict[str, list[tuple[str, int]]]]:
    app_ids: list[str] = []
    targets: dict[str, list[tuple[str, int]]] = defaultdict(list)
    for value in values or []:
        for match in APP_RE.finditer(value):
            app_id = normalize_app_type(match.group(1)) + match.group(2)
            if app_id not in app_ids:
                app_ids.append(app_id)
            suffix = value[match.end() :]
            orig = ORIG_RE.search(suffix)
            suppl = SUPPL_RE.search(suffix)
            target: tuple[str, int] | None = None
            if orig:
                target = ("ORIG", int(orig.group(1)))
            elif suppl:
                target = ("SUPPL", int(suppl.group(1)))
            if target and target not in targets[app_id]:
                targets[app_id].append(target)
    return app_ids, dict(targets)


def stable_letter_id(record: dict[str, Any]) -> str:
    identity = json.dumps(
        {
            "file_name": record.get("file_name"),
            "letter_date": record.get("letter_date"),
            "application_number": record.get("application_number"),
            "letter_type": record.get("letter_type"),
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return "crl_" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:16]


def normalize_sponsor(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    return re.sub(r"\s+", " ", value).strip().upper()


def action_family(record: dict[str, Any], letter_date: date) -> str:
    letter_type = record.get("letter_type")
    if letter_type == "COMPLETE RESPONSE":
        return "COMPLETE_RESPONSE"
    if letter_type:
        return str(letter_type).replace(" ", "_")
    text = " ".join(str(record.get("text") or "").split()).lower()
    if letter_date < date(2008, 8, 11) and (
        "not approvable" in text or "nonapproval" in text
    ):
        return "PRE_2008_NOT_APPROVABLE"
    if not record.get("text") and record.get("file_name") == "Under Review for Release":
        return "PLACEHOLDER_UNDER_REVIEW"
    return "UNCLASSIFIED_MISSING_TYPE"


def center_classification(centers: list[str], text: str) -> str:
    blob = " ".join(centers) + " " + (text or "")
    blob = " ".join(blob.lower().split())
    if re.search(r"center\s+f.r\s+biologics\s+evaluation\s+and\s+research", blob):
        return "CBER"
    if re.search(r"center\s+f.r\s+drug\s+evaluation\s+and\s+research", blob):
        return "CDER"
    return "UNKNOWN"


def load_crl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    records = payload.get("results")
    if not isinstance(records, list):
        raise ValueError(f"No results list in {path}")
    return records


def load_drugsfda(path: Path) -> list[dict[str, Any]]:
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != 1:
            raise ValueError(f"Expected one JSON member in {path}; found {len(names)}")
        with archive.open(names[0]) as handle:
            payload = json.load(handle)
    records = payload.get("results")
    if not isinstance(records, list):
        raise ValueError(f"No results list in {path}")
    return records


def inspect_drugsatfda_tab(path: Path) -> dict[str, Any]:
    with zipfile.ZipFile(path) as archive:
        with io.TextIOWrapper(
            archive.open("Applications.txt"), encoding="utf-8-sig", newline=""
        ) as handle:
            applications = {
                row["ApplType"].strip().upper() + row["ApplNo"].strip().zfill(6)
                for row in csv.DictReader(handle, delimiter="\t")
            }
        with io.TextIOWrapper(
            archive.open("Submissions.txt"), encoding="utf-8-sig", newline=""
        ) as handle:
            submission_fields = next(csv.reader(handle, delimiter="\t"))
    return {
        "application_ids": applications,
        "submission_fields": submission_fields,
    }


def choose_submission_and_approval(
    drug_record: dict[str, Any] | None,
    explicit_targets: list[tuple[str, int]],
    letter_date: date,
) -> dict[str, Any]:
    blank = {
        "selected_submission": None,
        "approval_date": None,
        "approval_method": "application_unmatched",
        "chemical_submission": None,
    }
    if drug_record is None:
        return blank

    submissions = drug_record.get("submissions") or []
    keyed: dict[tuple[str, int], dict[str, Any]] = {}
    for submission in submissions:
        try:
            key = (
                str(submission.get("submission_type", "")).upper(),
                int(submission.get("submission_number")),
            )
        except (TypeError, ValueError):
            continue
        keyed[key] = submission

    explicit_matches = [keyed[target] for target in explicit_targets if target in keyed]
    original_submissions = [
        item
        for (submission_type, _), item in keyed.items()
        if submission_type == "ORIG"
    ]
    candidates = explicit_matches if explicit_targets else original_submissions
    approval_candidates: list[tuple[date, dict[str, Any]]] = []
    for submission in candidates:
        status_date = parse_yyyymmdd(submission.get("submission_status_date"))
        if (
            submission.get("submission_status") == "AP"
            and status_date is not None
            and status_date >= letter_date
        ):
            approval_candidates.append((status_date, submission))

    if approval_candidates:
        approval_date, selected = min(approval_candidates, key=lambda item: item[0])
        method = "explicit_submission_target" if explicit_targets else "first_post_crl_orig_approval"
    else:
        approval_date = None
        selected = explicit_matches[0] if explicit_matches else None
        if selected is None and len(original_submissions) == 1:
            selected = original_submissions[0]
        method = "no_post_crl_approval_in_target_submissions"

    chemical_submission = None
    if selected and selected.get("submission_type") == "ORIG":
        chemical_submission = selected
    elif original_submissions:
        chemical_submission = min(
            original_submissions,
            key=lambda item: int(item.get("submission_number", 999999)),
        )
    return {
        "selected_submission": selected,
        "approval_date": approval_date,
        "approval_method": method,
        "chemical_submission": chemical_submission,
    }


def submission_is_orphan(submission: dict[str, Any] | None) -> bool | None:
    if submission is None:
        return None
    properties = submission.get("submission_property_type") or []
    return any(str(item.get("code", "")).lower() == "orphan" for item in properties)


def extract_resubmission_links(
    parsed_records: list[dict[str, Any]],
) -> tuple[dict[tuple[str, date], date], list[dict[str, str]]]:
    candidates: dict[tuple[str, date], set[date]] = defaultdict(set)
    evidence: list[dict[str, str]] = []
    seen_texts: set[str] = set()
    for item in parsed_records:
        text = item.get("text") or ""
        text_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
        if text_hash in seen_texts:
            continue
        seen_texts.add(text_hash)
        normalized = " ".join(text.split())
        for match in RESUBMISSION_ACK_RE.finditer(normalized):
            resub_date = parse_month_date(match.group("resub"))
            action_date = parse_month_date(match.group("action"))
            if resub_date < action_date:
                continue
            for app_id in item["associated_application_ids"]:
                candidates[(app_id, action_date)].add(resub_date)
                evidence.append(
                    {
                        "application_id": app_id,
                        "action_date": action_date.isoformat(),
                        "resubmission_date": resub_date.isoformat(),
                        "evidence_file": str(item.get("file_name", "")),
                    }
                )

    resolved = {key: min(values) for key, values in candidates.items()}
    return resolved, evidence


def json_cell(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field) for field in fields})


def rate(numerator: int, denominator: int) -> float | None:
    return round(numerator / denominator, 6) if denominator else None


def build_match_summary(panel: list[dict[str, Any]], all_ids: set[str], drug_ids: set[str]) -> dict[str, Any]:
    with_app = [row for row in panel if row["application_id"]]
    forward = [
        row for row in panel if row["is_2024_forward_window"] and row["application_id"]
    ]
    strict = [row for row in panel if row["is_strict_crl"] and row["application_id"]]
    summary: dict[str, Any] = {
        "letter_level_primary_application": {
            "matched": sum(row["drugsfda_matched"] for row in with_app),
            "denominator": len(with_app),
        },
        "letter_level_primary_application_including_missing_id": {
            "matched": sum(row["drugsfda_matched"] for row in panel),
            "denominator": len(panel),
        },
        "letter_level_primary_application_2024_forward": {
            "matched": sum(row["drugsfda_matched"] for row in forward),
            "denominator": len(forward),
        },
        "letter_level_primary_application_strict_crl": {
            "matched": sum(row["drugsfda_matched"] for row in strict),
            "denominator": len(strict),
        },
        "unique_all_associated_applications": {
            "matched": len(all_ids & drug_ids),
            "denominator": len(all_ids),
        },
    }
    for application_type in ("NDA", "BLA"):
        rows = [row for row in with_app if row["application_type"] == application_type]
        unique = {row["application_id"] for row in rows}
        summary[f"letter_level_{application_type.lower()}"] = {
            "matched": sum(row["drugsfda_matched"] for row in rows),
            "denominator": len(rows),
        }
        summary[f"unique_primary_{application_type.lower()}"] = {
            "matched": len(unique & drug_ids),
            "denominator": len(unique),
        }
        forward_rows = [
            row
            for row in forward
            if row["application_type"] == application_type
        ]
        summary[f"letter_level_2024_forward_{application_type.lower()}"] = {
            "matched": sum(row["drugsfda_matched"] for row in forward_rows),
            "denominator": len(forward_rows),
        }
    for values in summary.values():
        values["rate"] = rate(values["matched"], values["denominator"])
    return summary


PANEL_FIELDS = [
    "letter_id",
    "source_record_index",
    "file_name",
    "letter_date",
    "letter_year_source",
    "letter_type",
    "analysis_action_family",
    "is_strict_crl",
    "is_deficiency_action",
    "is_2024_forward_window",
    "is_2024_forward_strict_crl",
    "approval_status_source",
    "application_id",
    "application_type",
    "application_number",
    "associated_application_ids",
    "associated_application_count",
    "multiple_distinct_applications",
    "target_submission_refs",
    "endpoint_letter_sequence_number",
    "endpoint_letter_count_application",
    "crl_sequence_number",
    "crl_count_application",
    "next_crl_date",
    "days_to_next_crl",
    "is_first_strict_crl",
    "first_crl_followup_days",
    "second_crl_ever_observed",
    "second_crl_730d_eligible",
    "second_crl_within_730d_event",
    "days_first_to_second_crl",
    "company_name",
    "company_rep",
    "company_address",
    "approver_name",
    "approver_title",
    "approver_center",
    "review_division",
    "therapeutic_area_proxy",
    "drugsfda_matched",
    "drugsfda_sponsor_name",
    "sponsor_application_count",
    "selected_submission_type",
    "selected_submission_number",
    "selected_submission_status",
    "selected_submission_status_date",
    "review_priority",
    "chemical_type_code",
    "chemical_type_description",
    "orphan_status",
    "original_submission_date",
    "original_submission_date_status",
    "failed_cycle_resubmission_date",
    "days_to_failed_cycle_resubmission",
    "failed_cycle_resubmission_observed",
    "failed_cycle_evidence_type",
    "approval_date",
    "days_crl_to_approval",
    "approval_event",
    "approval_duration_days",
    "approval_timing_status",
    "approval_date_method",
    "followup_cutoff_date",
]


CODEBOOK = {
    "letter_id": "Stable hash identifier for one endpoint record/letter.",
    "application_id": "Primary normalized application identifier; first distinct application in source order.",
    "associated_application_ids": "JSON list of every normalized application referenced by the letter.",
    "is_strict_crl": "1 only when letter_type is exactly COMPLETE RESPONSE.",
    "is_deficiency_action": "1 for a strict CRL or a derived pre-2008 not-approvable predecessor action.",
    "analysis_action_family": "Source letter type normalized to an analysis family; missing pre-2008 types are derived from explicit not-approvable language.",
    "is_2024_forward_window": "1 for letter_date on or after 2024-01-01; not a verified census or viable outcome sample.",
    "crl_sequence_number": "Chronological sequence among strict CRLs for the primary application.",
    "crl_count_application": "Count of strict CRLs for the primary application.",
    "drugsfda_matched": "1 when the primary application is present in the dated Drugs@FDA JSON.",
    "sponsor_application_count": "Count of Drugs@FDA applications with the exact normalized Drugs@FDA sponsor name.",
    "therapeutic_area_proxy": "Most specific approver_center entry (first source-list value); not manually harmonized.",
    "chemical_type_code": "Submission class code from the selected/earliest original Drugs@FDA submission.",
    "orphan_status": "Whether the selected/earliest original Drugs@FDA submission has property code Orphan.",
    "second_crl_within_730d_event": "Primary outcome: among eligible first strict CRLs, 1 when another strict CRL occurs within 730 days.",
    "second_crl_730d_eligible": "1 only for first strict CRLs with at least 730 days from letter date to follow-up cutoff.",
    "second_crl_ever_observed": "Descriptive right-truncated indicator that any later strict CRL appears in the corpus.",
    "days_first_to_second_crl": "Days from first to second strict CRL, observed only when a second strict CRL exists.",
    "failed_cycle_resubmission_date": "Exact amendment date visible only because another adverse/nonfinal action later acknowledged it; not a general resubmission outcome.",
    "failed_cycle_resubmission_observed": "Selection flag for failed-cycle acknowledgement evidence; never use as a representative duration sample.",
    "approval_date": "First matching post-CRL AP status date in Drugs@FDA target/original submissions.",
    "approval_event": "1 for dated post-CRL approval, 0 when validly censored, blank when timing is unresolved.",
    "approval_duration_days": "Days to approval event or follow-up cutoff for validly censored observations.",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pull-date", default="20260828", help="YYYYMMDD")
    parser.add_argument("--raw-dir", type=Path, default=Path("data/raw"))
    parser.add_argument("--interim-dir", type=Path, default=Path("data/interim"))
    parser.add_argument("--final-dir", type=Path, default=Path("data/final"))
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        cutoff = datetime.strptime(args.pull_date, "%Y%m%d").date()
    except ValueError:
        print("--pull-date must use YYYYMMDD", file=sys.stderr)
        return 2

    crl_path = args.raw_dir / f"crl_{args.pull_date}.json"
    drugs_path = args.raw_dir / f"drug-drugsfda-0001-of-0001_{args.pull_date}.json.zip"
    drugs_tab_path = args.raw_dir / f"drugsatfda_{args.pull_date}.zip"
    crl_records = load_crl(crl_path)
    drug_records = load_drugsfda(drugs_path)
    tab_inspection = inspect_drugsatfda_tab(drugs_tab_path)
    source_vintage = max(parse_mmddyyyy(row["letter_date"]) for row in crl_records)
    vintage_tag = "v" + source_vintage.strftime("%Y%m%d")
    drug_by_id = {str(row["application_number"]).upper(): row for row in drug_records}
    drug_ids = set(drug_by_id)
    sponsor_counts = Counter(
        normalize_sponsor(row.get("sponsor_name"))
        for row in drug_records
        if normalize_sponsor(row.get("sponsor_name"))
    )

    parsed: list[dict[str, Any]] = []
    link_rows: list[dict[str, Any]] = []
    all_associated_ids: set[str] = set()
    for index, record in enumerate(crl_records):
        app_ids, targets = parse_application_entries(record.get("application_number"))
        letter_id = stable_letter_id(record)
        letter_date = parse_mmddyyyy(record["letter_date"])
        primary = app_ids[0] if app_ids else None
        item = dict(record)
        item.update(
            {
                "letter_id": letter_id,
                "source_record_index": index,
                "letter_date_parsed": letter_date,
                "associated_application_ids": app_ids,
                "target_submission_refs_by_application": targets,
                "application_id": primary,
            }
        )
        parsed.append(item)
        for position, app_id in enumerate(app_ids, start=1):
            all_associated_ids.add(app_id)
            link_rows.append(
                {
                    "letter_id": letter_id,
                    "letter_date": letter_date.isoformat(),
                    "file_name": record.get("file_name"),
                    "application_id": app_id,
                    "application_type": re.match(r"[A-Z]+", app_id).group(),
                    "application_position": position,
                    "is_primary_application": int(position == 1),
                    "drugsfda_matched": int(app_id in drug_ids),
                }
            )

    resub_links, resub_evidence = extract_resubmission_links(parsed)

    all_groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    crl_groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in parsed:
        app_id = item["application_id"]
        if app_id:
            all_groups[app_id].append(item)
            if item.get("letter_type") == "COMPLETE RESPONSE":
                crl_groups[app_id].append(item)
    for group in all_groups.values():
        group.sort(key=lambda item: (item["letter_date_parsed"], item["letter_id"]))
    for group in crl_groups.values():
        group.sort(key=lambda item: (item["letter_date_parsed"], item["letter_id"]))

    all_sequence: dict[str, tuple[int, int]] = {}
    crl_sequence: dict[str, tuple[int, int, date | None]] = {}
    for group in all_groups.values():
        for position, item in enumerate(group, start=1):
            all_sequence[item["letter_id"]] = (position, len(group))
    for group in crl_groups.values():
        for position, item in enumerate(group, start=1):
            next_date = group[position]["letter_date_parsed"] if position < len(group) else None
            crl_sequence[item["letter_id"]] = (position, len(group), next_date)

    panel: list[dict[str, Any]] = []
    for item in parsed:
        letter_date = item["letter_date_parsed"]
        app_id = item["application_id"]
        drug = drug_by_id.get(app_id) if app_id else None
        target_refs = item["target_submission_refs_by_application"].get(app_id, []) if app_id else []
        selection = choose_submission_and_approval(drug, target_refs, letter_date)
        selected = selection["selected_submission"]
        chemical = selection["chemical_submission"]
        approval_date = selection["approval_date"]
        source_status = item.get("approval_status")

        if approval_date is not None:
            approval_event: int | None = 1
            approval_duration = (approval_date - letter_date).days
            approval_timing_status = "event_observed_drugsfda"
        elif drug is None and source_status == "Approved":
            approval_event = None
            approval_duration = None
            approval_timing_status = "approved_but_date_unavailable_unmatched"
        elif drug is not None and source_status == "Approved":
            approval_event = None
            approval_duration = None
            approval_timing_status = "approved_but_target_timing_unresolved"
        else:
            approval_event = 0
            approval_duration = (cutoff - letter_date).days
            approval_timing_status = (
                "censored_no_post_crl_approval_in_drugsfda"
                if drug is not None
                else "censored_application_absent_from_drugsfda"
            )

        resub_date = resub_links.get((app_id, letter_date)) if app_id else None
        resub_days = (resub_date - letter_date).days if resub_date else None
        endpoint_seq = all_sequence.get(item["letter_id"])
        strict_seq = crl_sequence.get(item["letter_id"])
        next_crl_date = strict_seq[2] if strict_seq else None
        is_first_strict = bool(strict_seq and strict_seq[0] == 1)
        first_followup_days = (cutoff - letter_date).days if is_first_strict else None
        second_crl_ever = int(bool(next_crl_date)) if is_first_strict else None
        second_crl_eligible = (
            int(first_followup_days >= SECOND_CRL_HORIZON_DAYS)
            if is_first_strict and first_followup_days is not None
            else None
        )
        second_crl_730d = (
            int(
                next_crl_date is not None
                and (next_crl_date - letter_date).days <= SECOND_CRL_HORIZON_DAYS
            )
            if second_crl_eligible
            else None
        )
        if not resub_date:
            failed_cycle_evidence_type = None
        elif item.get("letter_type") == "COMPLETE RESPONSE" and next_crl_date:
            failed_cycle_evidence_type = "later_strict_crl_acknowledgement"
        elif item.get("letter_type") == "COMPLETE RESPONSE":
            failed_cycle_evidence_type = "later_non_cr_action_acknowledgement"
        else:
            failed_cycle_evidence_type = "non_cr_action_followed_by_later_action"
        centers = item.get("approver_center") or []
        sponsor = normalize_sponsor(drug.get("sponsor_name")) if drug else None

        row = {
            "letter_id": item["letter_id"],
            "source_record_index": item["source_record_index"],
            "file_name": item.get("file_name"),
            "letter_date": letter_date.isoformat(),
            "letter_year_source": item.get("letter_year"),
            "letter_type": item.get("letter_type"),
            "analysis_action_family": action_family(item, letter_date),
            "is_strict_crl": int(item.get("letter_type") == "COMPLETE RESPONSE"),
            "is_deficiency_action": int(
                action_family(item, letter_date)
                in {"COMPLETE_RESPONSE", "PRE_2008_NOT_APPROVABLE"}
            ),
            "is_2024_forward_window": int(letter_date >= FORWARD_WINDOW_START),
            "is_2024_forward_strict_crl": int(
                letter_date >= FORWARD_WINDOW_START
                and item.get("letter_type") == "COMPLETE RESPONSE"
            ),
            "approval_status_source": source_status,
            "application_id": app_id,
            "application_type": re.match(r"[A-Z]+", app_id).group() if app_id else None,
            "application_number": app_id[len(re.match(r"[A-Z]+", app_id).group()) :] if app_id else None,
            "associated_application_ids": json_cell(item["associated_application_ids"]),
            "associated_application_count": len(item["associated_application_ids"]),
            "multiple_distinct_applications": int(len(item["associated_application_ids"]) > 1),
            "target_submission_refs": json_cell(target_refs),
            "endpoint_letter_sequence_number": endpoint_seq[0] if endpoint_seq else None,
            "endpoint_letter_count_application": endpoint_seq[1] if endpoint_seq else None,
            "crl_sequence_number": strict_seq[0] if strict_seq else None,
            "crl_count_application": strict_seq[1] if strict_seq else 0,
            "next_crl_date": next_crl_date.isoformat() if next_crl_date else None,
            "days_to_next_crl": (next_crl_date - letter_date).days if next_crl_date else None,
            "is_first_strict_crl": int(is_first_strict),
            "first_crl_followup_days": first_followup_days,
            "second_crl_ever_observed": second_crl_ever,
            "second_crl_730d_eligible": second_crl_eligible,
            "second_crl_within_730d_event": second_crl_730d,
            "days_first_to_second_crl": (
                (next_crl_date - letter_date).days
                if is_first_strict and next_crl_date
                else None
            ),
            "company_name": item.get("company_name"),
            "company_rep": item.get("company_rep"),
            "company_address": item.get("company_address"),
            "approver_name": item.get("approver_name"),
            "approver_title": item.get("approver_title"),
            "approver_center": json_cell(centers),
            "review_division": centers[0] if centers else None,
            "therapeutic_area_proxy": centers[0] if centers else None,
            "drugsfda_matched": int(drug is not None),
            "drugsfda_sponsor_name": drug.get("sponsor_name") if drug else None,
            "sponsor_application_count": sponsor_counts.get(sponsor) if sponsor else None,
            "selected_submission_type": selected.get("submission_type") if selected else None,
            "selected_submission_number": selected.get("submission_number") if selected else None,
            "selected_submission_status": selected.get("submission_status") if selected else None,
            "selected_submission_status_date": (
                parse_yyyymmdd(selected.get("submission_status_date")).isoformat()
                if selected and parse_yyyymmdd(selected.get("submission_status_date"))
                else None
            ),
            "review_priority": selected.get("review_priority") if selected else None,
            "chemical_type_code": chemical.get("submission_class_code") if chemical else None,
            "chemical_type_description": (
                chemical.get("submission_class_code_description") if chemical else None
            ),
            "orphan_status": submission_is_orphan(chemical),
            "original_submission_date": None,
            "original_submission_date_status": "not_available_in_public_drugsfda_sources",
            "failed_cycle_resubmission_date": resub_date.isoformat() if resub_date else None,
            "days_to_failed_cycle_resubmission": resub_days,
            "failed_cycle_resubmission_observed": int(resub_date is not None),
            "failed_cycle_evidence_type": failed_cycle_evidence_type,
            "approval_date": approval_date.isoformat() if approval_date else None,
            "days_crl_to_approval": (
                (approval_date - letter_date).days if approval_date else None
            ),
            "approval_event": approval_event,
            "approval_duration_days": approval_duration,
            "approval_timing_status": approval_timing_status,
            "approval_date_method": selection["approval_method"],
            "followup_cutoff_date": cutoff.isoformat(),
        }
        panel.append(row)

    panel.sort(key=lambda row: (row["letter_date"], row["letter_id"]))
    if len(panel) != len(crl_records) or len({row["letter_id"] for row in panel}) != len(panel):
        raise AssertionError("Panel is not one unique row per CRL endpoint record")
    if any(
        row["days_crl_to_approval"] is not None and row["days_crl_to_approval"] < 0
        for row in panel
    ):
        raise AssertionError("Negative CRL-to-approval duration")
    if any(
        row["days_to_failed_cycle_resubmission"] is not None
        and row["days_to_failed_cycle_resubmission"] < 0
        for row in panel
    ):
        raise AssertionError("Negative failed-cycle resubmission duration")

    args.interim_dir.mkdir(parents=True, exist_ok=True)
    args.final_dir.mkdir(parents=True, exist_ok=True)
    parsed_path = args.interim_dir / f"crl_letters_parsed_{vintage_tag}.jsonl"
    with parsed_path.open("w", encoding="utf-8", newline="\n") as handle:
        for item in parsed:
            output = {
                key: value
                for key, value in item.items()
                if key not in {"letter_date_parsed", "target_submission_refs_by_application"}
            }
            output["letter_date_iso"] = item["letter_date_parsed"].isoformat()
            output["target_submission_refs_by_application"] = item[
                "target_submission_refs_by_application"
            ]
            handle.write(json.dumps(output, ensure_ascii=False, sort_keys=True) + "\n")

    panel_path = args.final_dir / f"analysis_panel_{vintage_tag}.csv"
    write_csv(panel_path, panel, PANEL_FIELDS)
    write_csv(
        args.interim_dir / f"letter_application_links_{vintage_tag}.csv",
        link_rows,
        [
            "letter_id",
            "letter_date",
            "file_name",
            "application_id",
            "application_type",
            "application_position",
            "is_primary_application",
            "drugsfda_matched",
        ],
    )
    write_csv(
        args.interim_dir / f"failed_cycle_resubmission_evidence_{vintage_tag}.csv",
        resub_evidence,
        ["application_id", "action_date", "resubmission_date", "evidence_file"],
    )

    unmatched_rows = []
    for app_id in sorted(all_associated_ids - drug_ids):
        linked = [row for row in link_rows if row["application_id"] == app_id]
        dates = sorted(row["letter_date"] for row in linked)
        unmatched_rows.append(
            {
                "application_id": app_id,
                "application_type": re.match(r"[A-Z]+", app_id).group(),
                "letter_count": len(linked),
                "first_letter_date": dates[0],
                "last_letter_date": dates[-1],
                "has_2024_forward_letter": int(any(value >= "2024-01-01" for value in dates)),
                "example_file": linked[0]["file_name"],
            }
        )
    write_csv(
        args.final_dir / f"unmatched_applications_{vintage_tag}.csv",
        unmatched_rows,
        [
            "application_id",
            "application_type",
            "letter_count",
            "first_letter_date",
            "last_letter_date",
            "has_2024_forward_letter",
            "example_file",
        ],
    )

    coverage_rows = []
    for year in range(FORWARD_WINDOW_START.year, cutoff.year + 1):
        year_panel = [row for row in panel if int(row["letter_date"][:4]) == year]
        year_links = [row for row in link_rows if int(row["letter_date"][:4]) == year]
        coverage_rows.append(
            {
                "calendar_year": year,
                "letters_all_endpoint_types": len(year_panel),
                "letters_strict_complete_response": sum(row["is_strict_crl"] for row in year_panel),
                "distinct_primary_applications": len(
                    {row["application_id"] for row in year_panel if row["application_id"]}
                ),
                "distinct_all_associated_applications": len(
                    {row["application_id"] for row in year_links}
                ),
                "published_cder_complete_response_actions": None,
                "coverage_ratio": None,
                "comparison_status": "no_comparable_authoritative_calendar_year_count_found",
                "pdufa_receipt_cohort": "FY2024" if year == 2024 else None,
                "pdufa_original_application_cohort_size": 129 if year == 2024 else None,
                "pdufa_implied_first_cycle_nonapproval_low": 37 if year == 2024 else None,
                "pdufa_implied_first_cycle_nonapproval_high": 38 if year == 2024 else None,
                "pdufa_bound_scope": (
                    "original FY2024 receipt cohort; not calendar-year actions"
                    if year == 2024
                    else None
                ),
            }
        )
    write_csv(
        args.final_dir / f"coverage_check_{vintage_tag}.csv",
        coverage_rows,
        list(coverage_rows[0]),
    )

    application_outcomes = []
    for row in panel:
        if not row["is_first_strict_crl"]:
            continue
        application_outcomes.append(
            {
                "application_id": row["application_id"],
                "application_type": row["application_type"],
                "first_crl_letter_id": row["letter_id"],
                "first_crl_date": row["letter_date"],
                "first_crl_file_name": row["file_name"],
                "strict_crl_count": row["crl_count_application"],
                "second_crl_ever_observed": row["second_crl_ever_observed"],
                "second_crl_date": row["next_crl_date"],
                "days_first_to_second_crl": row["days_first_to_second_crl"],
                "followup_days_at_cutoff": row["first_crl_followup_days"],
                "second_crl_730d_eligible": row["second_crl_730d_eligible"],
                "second_crl_within_730d_event": row["second_crl_within_730d_event"],
                "right_truncation_status": (
                    "eligible_730d_fixed_horizon"
                    if row["second_crl_730d_eligible"]
                    else "insufficient_730d_followup"
                ),
                "company_name": row["company_name"],
                "review_division": row["review_division"],
                "drugsfda_matched": row["drugsfda_matched"],
            }
        )
    outcome_fields = list(application_outcomes[0])
    write_csv(
        args.final_dir / f"application_second_crl_outcomes_{vintage_tag}.csv",
        application_outcomes,
        outcome_fields,
    )

    non_cr_rows = [
        {
            "letter_id": row["letter_id"],
            "letter_date": row["letter_date"],
            "letter_type_source": row["letter_type"],
            "analysis_action_family": row["analysis_action_family"],
            "application_id": row["application_id"],
            "approval_status_source": row["approval_status_source"],
            "file_name": row["file_name"],
        }
        for row in panel
        if not row["is_strict_crl"]
    ]
    write_csv(
        args.final_dir / f"non_complete_response_records_{vintage_tag}.csv",
        non_cr_rows,
        list(non_cr_rows[0]),
    )

    unmatched_bla_ids = {
        app_id
        for app_id in all_associated_ids - drug_ids
        if app_id.startswith("BLA")
    }
    unmatched_bla_rows = []
    unmatched_bla_center_counts: Counter[str] = Counter()
    for app_id in sorted(unmatched_bla_ids):
        linked_items = [
            item for item in parsed if app_id in item["associated_application_ids"]
        ]
        classifications = {
            center_classification(item.get("approver_center") or [], item.get("text") or "")
            for item in linked_items
        }
        known = classifications - {"UNKNOWN"}
        if len(known) == 1:
            center_class = next(iter(known))
        elif len(known) > 1:
            center_class = "MIXED"
        else:
            center_class = "UNKNOWN"
        unmatched_bla_center_counts[center_class] += 1
        center_values = sorted(
            {
                center
                for item in linked_items
                for center in (item.get("approver_center") or [])
                if center
            }
        )
        unmatched_bla_rows.append(
            {
                "application_id": app_id,
                "review_center_class": center_class,
                "classification_evidence_across_letters": json_cell(sorted(classifications)),
                "approver_center_values": json_cell(center_values),
                "letter_count": len(linked_items),
                "first_letter_date": min(item["letter_date_parsed"] for item in linked_items).isoformat(),
                "last_letter_date": max(item["letter_date_parsed"] for item in linked_items).isoformat(),
                "company_names": json_cell(
                    sorted({str(item.get("company_name")) for item in linked_items if item.get("company_name")})
                ),
            }
        )
    write_csv(
        args.final_dir / f"unmatched_bla_review_centers_{vintage_tag}.csv",
        unmatched_bla_rows,
        list(unmatched_bla_rows[0]),
    )

    write_csv(
        args.final_dir / "panel_codebook.csv",
        ({"variable": field, "definition": CODEBOOK.get(field, "Source or derived field; see Phase 2 log.")} for field in PANEL_FIELDS),
        ["variable", "definition"],
    )

    match_summary = build_match_summary(panel, all_associated_ids, drug_ids)
    audit = {
        "pull_date": args.pull_date,
        "crl_data_vintage": source_vintage.isoformat(),
        "central_identification_problem": (
            "The sample with observable approval outcomes is selected on approval, while "
            "the recent sample without that selection lacks broadly observable outcomes."
        ),
        "sample_sizes": {
            "full_endpoint_records": len(panel),
            "strict_complete_response_records": sum(row["is_strict_crl"] for row in panel),
            "forward_2024_endpoint_records": sum(
                row["is_2024_forward_window"] for row in panel
            ),
            "forward_2024_strict_complete_response_records": sum(
                row["is_2024_forward_strict_crl"] for row in panel
            ),
            "records_with_primary_application": sum(bool(row["application_id"]) for row in panel),
            "unique_primary_applications": len(
                {row["application_id"] for row in panel if row["application_id"]}
            ),
            "unique_all_associated_applications": len(all_associated_ids),
            "forward_2024_unique_primary_applications": len(
                {
                    row["application_id"]
                    for row in panel
                    if row["is_2024_forward_window"] and row["application_id"]
                }
            ),
            "forward_2024_unique_all_associated_applications": len(
                {
                    row["application_id"]
                    for row in link_rows
                    if row["letter_date"] >= FORWARD_WINDOW_START.isoformat()
                }
            ),
            "multiple_distinct_application_records": sum(
                row["multiple_distinct_applications"] for row in panel
            ),
        },
        "match_rates": match_summary,
        "unmatched_unique_associated_applications": len(all_associated_ids - drug_ids),
        "unmatched_bla_review_center_counts": dict(sorted(unmatched_bla_center_counts.items())),
        "non_complete_response_action_families": dict(
            sorted(Counter(row["analysis_action_family"] for row in non_cr_rows).items())
        ),
        "second_crl_outcome": {
            "strict_crl_applications": len(application_outcomes),
            "applications_with_second_crl_ever_observed": sum(
                row["second_crl_ever_observed"] for row in application_outcomes
            ),
            "crl_records_followed_by_another_strict_crl": sum(
                bool(row["next_crl_date"]) for row in panel if row["is_strict_crl"]
            ),
            "fixed_horizon_days": SECOND_CRL_HORIZON_DAYS,
            "fixed_horizon_eligible_applications": sum(
                row["second_crl_730d_eligible"] for row in application_outcomes
            ),
            "fixed_horizon_second_crl_events": sum(
                row["second_crl_within_730d_event"]
                for row in application_outcomes
                if row["second_crl_within_730d_event"] is not None
            ),
        },
        "timing_availability": {
            "failed_cycle_resubmission_dates_observed": sum(
                row["failed_cycle_resubmission_observed"] for row in panel
            ),
            "failed_cycle_evidence_types": dict(
                sorted(
                    Counter(
                        row["failed_cycle_evidence_type"]
                        for row in panel
                        if row["failed_cycle_evidence_type"]
                    ).items()
                )
            ),
            "post_crl_approval_dates_observed": sum(row["approval_event"] == 1 for row in panel),
            "approval_timing_unresolved": sum(row["approval_event"] is None for row in panel),
            "approval_censored": sum(row["approval_event"] == 0 for row in panel),
            "forward_2024_failed_cycle_resubmission_dates_observed": sum(
                row["failed_cycle_resubmission_observed"]
                for row in panel
                if row["is_2024_forward_window"]
            ),
            "forward_2024_post_crl_approval_dates_observed": sum(
                row["approval_event"] == 1
                for row in panel
                if row["is_2024_forward_window"]
            ),
            "drugsfda_limitation": (
                "Public Drugs@FDA sources expose a current status date per ORIG/SUPPL "
                "record, not original receipt or post-CRL resubmission receipt dates."
            ),
            "failed_cycle_selection_warning": (
                "All recovered amendment dates are visible because another adverse or "
                "nonfinal action later acknowledged the response; they are not a sample "
                "of resubmissions and must not be used for a general duration model."
            ),
        },
        "coverage_check": {
            "rows": coverage_rows,
            "result": "partial_coverage_unquantified_with_noncommensurate_pdufa_bound",
            "reason": (
                "No comparable authoritative calendar-year count of CDER NDA/BLA complete-"
                "response actions was found. The FY 2024 and FY 2025 PDUFA reports are "
                "cohort- and fiscal-year-based, and the September 2025 release reports a "
                "batch of 89 previously unpublished 2024-present letters rather than total "
                "annual actions."
            ),
            "pdufa_fy2024_receipt_cohort_bound": {
                "priority_original_applications": 49,
                "standard_original_applications": 80,
                "reported_first_cycle_approval_rates": {
                    "priority": 0.76,
                    "standard": 0.68,
                },
                "implied_first_cycle_nonapprovals": "37-38",
                "interpretation": (
                    "Contextual upper bound for first-cycle CRLs in the FY2024 original-"
                    "application receipt cohort, subject to rounded rates and other "
                    "nonapproval actions. It is not commensurate with calendar-2024 letters."
                ),
            },
            "sources_checked": [
                PDUFA_2024_REPORT_URL,
                PDUFA_2025_REPORT_URL,
                FDA_2025_RELEASE_URL,
            ],
        },
        "tab_delimited_source_validation": {
            "application_count": len(tab_inspection["application_ids"]),
            "json_application_count": len(drug_ids),
            "crl_associated_ids_matched_in_json_but_not_tab": sorted(
                (all_associated_ids & drug_ids) - tab_inspection["application_ids"]
            ),
            "crl_associated_ids_matched_in_tab_but_not_json": sorted(
                (all_associated_ids & tab_inspection["application_ids"]) - drug_ids
            ),
            "submissions_fields": tab_inspection["submission_fields"],
            "resubmission_receipt_field_present": any(
                "resub" in field.lower() or "receipt" in field.lower()
                for field in tab_inspection["submission_fields"]
            ),
        },
        "source_schema_documentation": [
            DRUGSFDA_DOCUMENTATION_URL,
            DRUGSATFDA_DEFINITIONS_URL,
        ],
    }
    audit_path = args.interim_dir / f"phase2_audit_{vintage_tag}.json"
    with audit_path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(audit, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps(audit, indent=2, sort_keys=True))
    print(f"Wrote panel: {panel_path}")
    print(f"Wrote audit: {audit_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
