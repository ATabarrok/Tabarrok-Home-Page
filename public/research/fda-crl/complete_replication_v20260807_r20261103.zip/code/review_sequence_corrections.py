"""Apply the documented submission-linkage audit without altering frozen inputs."""
from datetime import date

EXCLUDED = {
    'crl_576c1a1c58b5e49e': 'Duplicate of crl_22b1602ed588d05c (identical letter text)',
    'crl_01ec5422214c2272': 'Acknowledgement of incomplete response, not a CRL',
}

def corrected_records(records):
    rows = sorted((dict(r) for r in records if r['is_strict_crl']=='1' and r['letter_id'] not in EXCLUDED),
                  key=lambda r:(r['application_id'],r['letter_date'],r['letter_id']))
    groups = {}
    for r in rows:
        r['review_sequence_id'] = r['application_id']
        if r['application_id']=='BLA761303':
            r['review_sequence_id'] += ':Original2' if r['letter_id']=='crl_1b841b4e93b4f3bd' else ':Original1'
        groups.setdefault(r['application_id'], []).append(r)
    for group in groups.values():
        first = group[0]
        first_date = date.fromisoformat(first['letter_date'])
        # A later decision must follow a submission observed on the initial date.
        initial_sequences = {r['review_sequence_id'] for r in group if r['letter_date']==first['letter_date']}
        later = [r for r in group if r['letter_date']>first['letter_date'] and r['review_sequence_id'] in initial_sequences]
        days = (date.fromisoformat(later[0]['letter_date'])-first_date).days if later else None
        for j,r in enumerate(group):
            r['is_first_strict_crl'] = str(int(j==0))
            r['crl_sequence_number'] = str(j+1)
            r['crl_count_application'] = str(len(group))
            following = [b for b in group if b['review_sequence_id']==r['review_sequence_id'] and b['letter_date']>r['letter_date']]
            r['next_crl_date'] = following[0]['letter_date'] if following else ''
            r['days_to_next_crl'] = str((date.fromisoformat(following[0]['letter_date'])-date.fromisoformat(r['letter_date'])).days) if following else ''
            r['first_crl_followup_days'] = str((date.fromisoformat(r['followup_cutoff_date'])-first_date).days)
            r['second_crl_730d_eligible'] = str(int(int(r['first_crl_followup_days'])>=730))
            r['second_crl_ever_observed'] = str(int(bool(later)))
            r['second_crl_within_730d_event'] = str(int(days is not None and days<=730)) if r['second_crl_730d_eligible']=='1' else ''
            r['days_first_to_second_crl'] = str(days) if days is not None else ''
    return rows

def linked_pairs(rows):
    groups = {}
    for r in rows: groups.setdefault(r['review_sequence_id'],[]).append(r)
    pairs=[]
    for sequence,g in sorted(groups.items()):
        for a,b in zip(g,g[1:]):
            assert a['letter_date']<b['letter_date'], sequence
            pairs.append(dict(application_id=a['application_id'],review_sequence_id=sequence,
                first_letter_id=a['letter_id'],second_letter_id=b['letter_id'],first_date=a['letter_date'],second_date=b['letter_date'],
                first=a['primary_deficiency_category'],second=b['primary_deficiency_category']))
    pairs.sort(key=lambda r:(r['application_id'],r['first_date'],r['second_date'],r['first_letter_id']))
    counts={}
    for p in pairs:
        counts[p['application_id']]=counts.get(p['application_id'],0)+1
        p['pair_sequence']=counts[p['application_id']]
    return pairs
