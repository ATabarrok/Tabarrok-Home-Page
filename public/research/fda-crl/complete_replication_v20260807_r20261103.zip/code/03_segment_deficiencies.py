#!/usr/bin/env python3
"""Extract the decision-specific deficiency section from each FDA action letter.

The extraction is deliberately structural.  It uses recurring FDA decision and
closing language to delimit the text supplied to the Phase 3 classifier; it does
not assign deficiency categories.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PULL_DATE = "20260828"


START_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (
        "reasons_for_action",
        re.compile(
            r"(?:we\s+have\s+)?described\s+(?:be[^a-z0-9]{0,3}low\s+|below\s+)?"
            r"(?:our\s+)?reason(?:s)?\s+for\s+this\s+action\s+"
            r"(?:be[^a-z0-9]{0,3}low|below)[^.]*[.:]?",
            re.IGNORECASE,
        ),
    ),
    (
        "reasons_for_action_reversed",
        re.compile(
            r"(?:we\s+have\s+)?described\s+(?:be[^a-z0-9]{0,3}low|below)\s+"
            r"(?:our\s+)?reason(?:s)?\s+for\s+this\s+action[^.]*[.:]?",
            re.IGNORECASE,
        ),
    ),
    (
        "deficiencies_outlined",
        re.compile(
            r"deficienc(?:y|ies)[^.]{0,180}?"
            r"(?:are\s+|is\s+)?(?:outlined|described|summarized|identified)"
            r"[^.]{0,100}?(?:below|here|as\s+follows)[^.]*[.:]?",
            re.IGNORECASE,
        ),
    ),
    (
        "deficiencies_each_study",
        re.compile(
            r"deficienc(?:y|ies)[^.]{0,160}?(?:each|stud(?:y|ies))"
            r"[^.]{0,120}?(?:outlined|described|summarized)[^.]*[.:]?",
            re.IGNORECASE,
        ),
    ),
]


HEADING_PATTERN = re.compile(
    r"(?m)^[ \t]*(?:\d+\.\s*)?(?:"
    r"FACILITY INSPECTIONS?|CLINICAL(?: AND STATISTICAL)?|CLINICAL PHARMACOLOGY|"
    r"STATISTICAL|CHEMISTRY(?:,| AND)? MANUFACTURING(?:,| AND)? CONTROLS|"
    r"CHEMISTRY, MANUFACTURING, AND CONTROLS \(CMC\)|CMC|PRODUCT QUALITY|"
    r"MANUFACTURING|MICROBIOLOGY|NONCLINICAL|PHARMACOLOGY(?:/| AND )TOXICOLOGY|"
    r"TOXICOLOGY|BIOEQUIVALENCE|BIOAVAILABILITY|BIOPHARMACEUTICS|"
    r"PRESCRIBING INFORMATION|LABELING|PROPRIETARY NAME|HUMAN FACTORS|"
    r"DEVICE|RISK EVALUATION AND MITIGATION STRATEGY|REMS|"
    r"Deficienc(?:y|ies) Identified"
    r")[ \t]*:?\s*$",
    re.IGNORECASE,
)


END_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (
        "other_requests_and_comments",
        re.compile(r"(?m)^\s*OTHER REQUESTS? AND COMMENTS?\s*$", re.IGNORECASE),
    ),
    (
        "safety_update",
        re.compile(r"(?m)^\s*SAFETY UPDATE\s*$", re.IGNORECASE),
    ),
    (
        "additional_comments_not_approvability",
        re.compile(
            r"(?ims)^\s*ADDITIONAL COMMENTS?\s*$"
            r"(?=.{0,240}?(?:not (?:an? )?approvability issue|not approvability issues))",
            re.IGNORECASE,
        ),
    ),
    (
        "within_days",
        re.compile(r"(?m)^\s*Within \d+ days after (?:the )?date of this letter", re.IGNORECASE),
    ),
    (
        "within_one_year",
        re.compile(r"(?m)^\s*Within one year after (?:the )?date of this letter", re.IGNORECASE),
    ),
    (
        "resubmission_must_address",
        re.compile(r"(?m)^\s*A resubmission must fully address", re.IGNORECASE),
    ),
    (
        "decide_to_resubmit",
        re.compile(r"(?m)^\s*If you decide to resubmit", re.IGNORECASE),
    ),
    (
        "required_to_resubmit",
        re.compile(r"(?m)^\s*You are required to resubmit", re.IGNORECASE),
    ),
]


LATE_END_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("meeting_request", re.compile(r"(?m)^\s*You may request a meeting", re.IGNORECASE)),
    ("questions", re.compile(r"(?m)^\s*If you have any questions", re.IGNORECASE)),
    ("sincerely", re.compile(r"(?m)^\s*Sincerely(?: yours)?,?\s*$", re.IGNORECASE)),
]


# These section headings are usually terminal boilerplate, but some public letters
# resume binding deficiencies after them.  Do not cut at the heading when the tail
# contains an approvability-relevant inspection, manufacturing-site, or expressly
# identified deficiency.  Closing/resubmission instructions remain terminal.
CONDITIONALLY_TERMINAL_END_METHODS = {
    "other_requests_and_comments",
    "safety_update",
    "additional_comments_not_approvability",
}

POST_BOUNDARY_APPROVABILITY_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (
        "inspection_required_or_not_conducted",
        re.compile(
            r"(?is)\binspect(?:ion|ions|ed|or|ors|ing)\b.{0,420}?"
            r"(?:required before.{0,100}approv|cannot be approved|"
            r"(?:could not|unable to) (?:complete|conduct).{0,260}?(?:approv|required)|"
            r"not (?:performed|conducted|completed).{0,260}?(?:approv|required)|"
            r"inspectional issues.{0,220}?required before.{0,100}?approv)",
        ),
    ),
    (
        "inspection_condition_reversed",
        re.compile(
            r"(?is)(?:required before.{0,100}approv|cannot be approved|"
            r"(?:could not|unable to) (?:complete|conduct).{0,260}?(?:approv|required)|"
            r"not (?:performed|conducted|completed).{0,260}?(?:approv|required))"
            r".{0,420}?\binspect(?:ion|ions|ed|or|ors|ing)\b",
        ),
    ),
    (
        "manufacturing_site_approvability",
        re.compile(
            r"(?is)\b(?:manufacturing (?:site|facility)|facilit(?:y|ies))\b.{0,520}?"
            r"(?:satisfactory resolution.{0,180}?required before.{0,100}?approv|"
            r"required before.{0,100}?approv|cannot be approved)",
        ),
    ),
    (
        "explicit_binding_deficiency",
        re.compile(
            r"(?is)\b(?:deficienc(?:y|ies)|issue|issues)\b.{0,520}?"
            r"(?:cannot be approved|preclude(?:s|d)? approval|required before.{0,100}?approv|"
            r"still deficient)",
        ),
    ),
]


def post_boundary_approvability_signal(text: str, boundary_end: int, method: str) -> str:
    """Return the first substantive signal after a conditionally terminal heading."""
    tail = text[boundary_end:]
    for name, pattern in POST_BOUNDARY_APPROVABILITY_PATTERNS[:3]:
        if pattern.search(tail):
            return name
    # A section explicitly introduced as non-approvability commentary stays out of
    # the deficiency segment unless its own content contains one of the contradictory
    # inspection/manufacturing approval conditions above.  For SAFETY UPDATE, also
    # keep generic deficiency detection from reaching into a later such section.
    if method == "additional_comments_not_approvability":
        return ""
    generic_tail = tail
    nonbinding = END_PATTERNS[2][1].search(generic_tail)
    if nonbinding:
        generic_tail = generic_tail[:nonbinding.start()]
    name, pattern = POST_BOUNDARY_APPROVABILITY_PATTERNS[3]
    if pattern.search(generic_tail):
        return name
    return ""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pull-date", default=DEFAULT_PULL_DATE, help="Raw snapshot date (YYYYMMDD)")
    parser.add_argument(
        "--audit-seed", type=int, default=20260807, help="Seed for the fixed 30-letter audit sample"
    )
    return parser.parse_args()


def normalize_text(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip()


def find_vintage(panel_dir: Path) -> str:
    panels = sorted(panel_dir.glob("analysis_panel_v*.csv"))
    if not panels:
        raise FileNotFoundError("No analysis_panel_v*.csv found; run Phase 2 first")
    if len(panels) > 1:
        raise RuntimeError(f"Multiple analysis panels found: {[p.name for p in panels]}")
    return re.search(r"_v(\d{8})\.csv$", panels[0].name).group(1)  # type: ignore[union-attr]


def find_start(text: str) -> tuple[int, str, bool]:
    candidates: list[tuple[int, int, str]] = []
    for method, pattern in START_PATTERNS:
        for match in pattern.finditer(text):
            if match.start() >= 150:
                candidates.append((match.start(), match.end(), method))

    if candidates:
        _, end, method = min(candidates)
        # Begin after the structural decision sentence, retaining the first
        # deficiency heading or narrative paragraph.
        return end, method, False

    # Prefer the decision sentence to a later heading because some letters put
    # their first (often clinical or facility) deficiency in unheaded prose.
    decision = re.search(
        r"(?:cannot|could not)[^.]{0,140}?(?:approve|grant final approval)"
        r"[^.]{0,160}?(?:present|current) form[^.]*[.]",
        text,
        re.IGNORECASE,
    )
    if decision:
        return decision.end(), "end_of_decision_sentence", True

    # A heading is a conservative fallback for atypical or OCR-damaged decision
    # language. Ignore letterhead/header occurrences near the top of a document.
    headings = [m for m in HEADING_PATTERN.finditer(text) if m.start() >= 300]
    if headings:
        return headings[0].start(), "first_substantive_heading", True

    return 0, "not_found", True


def find_end(text: str, start: int) -> tuple[int, str, bool]:
    candidates: list[tuple[int, str]] = []
    for method, pattern in END_PATTERNS:
        match = pattern.search(text, pos=start + 100)
        if match:
            if (
                method in CONDITIONALLY_TERMINAL_END_METHODS
                and post_boundary_approvability_signal(text, match.end(), method)
            ):
                continue
            candidates.append((match.start(), method))
    if candidates:
        end, method = min(candidates)
        # Drop an immediately preceding generic OTHER heading, but do not drop
        # substantive sections merely because their headings contain that word.
        prefix = text[start:end]
        other = re.search(r"(?im)\n\s*OTHER\s*\n\s*$", prefix)
        if other:
            end = start + other.start()
            method = f"other_before_{method}"
        return end, method, False

    for method, pattern in LATE_END_PATTERNS:
        match = pattern.search(text, pos=start + 100)
        if match:
            return match.start(), method, True

    return len(text), "document_end", True


def redaction_metrics(text: str) -> dict[str, Any]:
    patterns = {
        "b4_markers": r"\(\s*b\s*\)\s*\(\s*4\s*\)",
        "b6_markers": r"\(\s*b\s*\)\s*\(\s*6\s*\)",
        "cci_markers": r"\bCCI\b|commercial confidential information",
        "withheld_markers": r"\bwithheld\b|\bredacted\b",
        # The endpoint OCR commonly renders black redaction boxes as copyright
        # or registered-trademark glyphs. These are visible disclosure artifacts,
        # not ordinary marks in the deficiency prose.
        "ocr_redaction_glyphs": r"[©®]",
    }
    counts = {name: len(re.findall(pattern, text, re.IGNORECASE)) for name, pattern in patterns.items()}
    counts["redaction_marker_count"] = sum(counts.values())
    counts["has_redaction_marker"] = int(counts["redaction_marker_count"] > 0)
    counts["redaction_markers_per_1000_chars"] = round(
        1000 * counts["redaction_marker_count"] / max(1, len(text)), 6
    )
    return counts


def segment_record(record: dict[str, Any]) -> dict[str, Any]:
    text = normalize_text(record.get("text", ""))
    start, start_method, start_fallback = find_start(text)
    end, end_method, end_fallback = find_end(text, start)
    segment = text[start:end].strip() if start else ""
    ratio = len(segment) / len(text) if text else 0.0
    flags: list[str] = []
    if not text:
        flags.append("empty_document")
    if not start:
        flags.append("start_not_found")
    if end_method == "document_end":
        flags.append("end_not_found")
    if segment and len(segment) < 100:
        flags.append("segment_under_100_chars")
    if ratio > 0.90:
        flags.append("segment_over_90pct_document")
    if end <= start and start:
        flags.append("invalid_boundaries")

    metrics = redaction_metrics(segment)
    return {
        "letter_id": record["letter_id"],
        "source_record_index": record.get("source_record_index"),
        "application_id": record.get("application_id"),
        "file_name": record.get("file_name"),
        "letter_date": record.get("letter_date_iso") or record.get("letter_date"),
        "letter_type": record.get("letter_type"),
        "segment_start_method": start_method,
        "segment_end_method": end_method,
        "segment_start_fallback": int(start_fallback),
        "segment_end_fallback": int(end_fallback),
        "document_char_count": len(text),
        "segment_char_count": len(segment),
        "segment_document_ratio": round(ratio, 6),
        "automatic_flag_count": len(flags),
        "automatic_flags": flags,
        "segment_sha256": hashlib.sha256(segment.encode("utf-8")).hexdigest(),
        **metrics,
        "deficiency_text": segment,
    }


def choose_audit_sample(rows: list[dict[str, Any]], seed: int) -> tuple[list[dict[str, Any]], str]:
    """Fixed random sample, stratified only by era so old templates are represented."""
    rng = random.Random(seed)
    strata: dict[str, list[dict[str, Any]]] = {"pre_2008": [], "2008_2023": [], "2024_forward": []}
    for row in rows:
        date = row["letter_date"] or ""
        if date < "2008-08-11":
            strata["pre_2008"].append(row)
        elif date < "2024-01-01":
            strata["2008_2023"].append(row)
        else:
            strata["2024_forward"].append(row)
    allocation = {"pre_2008": 4, "2008_2023": 13, "2024_forward": 13}
    selected: list[dict[str, Any]] = []
    for label, count in allocation.items():
        pool = sorted(strata[label], key=lambda r: r["letter_id"])
        selected.extend(rng.sample(pool, min(count, len(pool))))
    return sorted(selected, key=lambda r: (r["letter_date"], r["letter_id"])), json.dumps(allocation)


def load_inputs(vintage: str) -> tuple[list[dict[str, Any]], set[str]]:
    parsed_path = ROOT / "data" / "interim" / f"crl_letters_parsed_v{vintage}.jsonl"
    panel_path = ROOT / "data" / "final" / f"analysis_panel_v{vintage}.csv"
    parsed: list[dict[str, Any]] = []
    with parsed_path.open(encoding="utf-8") as handle:
        for line in handle:
            parsed.append(json.loads(line))
    with panel_path.open(encoding="utf-8-sig", newline="") as handle:
        deficiency_ids = {
            row["letter_id"] for row in csv.DictReader(handle) if row["is_deficiency_action"] == "1"
        }
    return parsed, deficiency_ids


def write_outputs(rows: list[dict[str, Any]], vintage: str, pull_date: str, seed: int) -> None:
    interim = ROOT / "data" / "interim"
    segments_path = interim / f"deficiency_segments_v{vintage}.jsonl"
    with segments_path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")

    sample, allocation = choose_audit_sample(rows, seed)
    manual_path = ROOT / "data" / "manual" / f"segmentation_hand_audit_v{vintage}.csv"
    manual_reviews: dict[str, dict[str, str]] = {}
    if manual_path.exists():
        with manual_path.open(encoding="utf-8-sig", newline="") as handle:
            manual_reviews = {row["letter_id"]: row for row in csv.DictReader(handle)}
    audit_path = interim / f"segmentation_audit_sample_v{vintage}.csv"
    audit_fields = [
        "letter_id", "application_id", "file_name", "letter_date", "segment_start_method",
        "segment_end_method", "segment_char_count", "segment_document_ratio", "automatic_flags",
        "hand_start_correct", "hand_end_correct", "hand_deficiencies_complete", "hand_notes",
    ]
    with audit_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=audit_fields, extrasaction="ignore")
        writer.writeheader()
        for row in sample:
            out = dict(row)
            out["automatic_flags"] = "|".join(row["automatic_flags"])
            review = manual_reviews.get(row["letter_id"], {})
            out.update(
                hand_start_correct=review.get("hand_start_correct", ""),
                hand_end_correct=review.get("hand_end_correct", ""),
                hand_deficiencies_complete=review.get("hand_deficiencies_complete", ""),
                hand_notes=review.get("hand_notes", ""),
            )
            writer.writerow(out)

    flagged_path = interim / f"segmentation_flagged_records_v{vintage}.csv"
    flagged_fields = [
        "letter_id", "application_id", "file_name", "letter_date", "segment_start_method",
        "segment_end_method", "document_char_count", "segment_char_count", "segment_document_ratio",
        "automatic_flags",
    ]
    with flagged_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=flagged_fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            if row["automatic_flag_count"] or row["segment_start_fallback"] or row["segment_end_fallback"]:
                out = dict(row)
                out["automatic_flags"] = "|".join(row["automatic_flags"])
                writer.writerow(out)

    audited = [manual_reviews.get(row["letter_id"], {}) for row in sample]
    audited = [row for row in audited if row.get("hand_start_correct", "")]
    failed_audits = [
        row for row in audited
        if any(row.get(field) != "1" for field in (
            "hand_start_correct", "hand_end_correct", "hand_deficiencies_complete"
        ))
    ]
    summary = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "pull_date": pull_date,
        "data_vintage": vintage,
        "deficiency_action_count": len(rows),
        "audit_seed": seed,
        "audit_sample_count": len(sample),
        "hand_audited_count": len(audited),
        "hand_audit_failure_count": len(failed_audits),
        "hand_audit_failure_share": round(len(failed_audits) / len(audited), 6) if audited else None,
        "audit_stratum_allocation": json.loads(allocation),
        "automatic_flagged_count": sum(r["automatic_flag_count"] > 0 for r in rows),
        "start_fallback_count": sum(r["segment_start_fallback"] for r in rows),
        "end_fallback_count": sum(r["segment_end_fallback"] for r in rows),
        "empty_segment_count": sum(not r["deficiency_text"] for r in rows),
        "start_methods": dict(Counter(r["segment_start_method"] for r in rows)),
        "end_methods": dict(Counter(r["segment_end_method"] for r in rows)),
        "has_redaction_marker_count": sum(r["has_redaction_marker"] for r in rows),
        "notes": [
            "Boundaries use FDA action/closing language and section headings; no deficiency category is assigned here.",
            "The audit sample is reproducible and stratified to include all four pre-2008 predecessor actions.",
        ],
    }
    summary_path = interim / f"segmentation_summary_v{vintage}.json"
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    vintage = find_vintage(ROOT / "data" / "final")
    parsed, deficiency_ids = load_inputs(vintage)
    records = [record for record in parsed if record["letter_id"] in deficiency_ids]
    if len(records) != len(deficiency_ids):
        missing = sorted(deficiency_ids - {r["letter_id"] for r in records})
        raise RuntimeError(f"Missing parsed text for {len(missing)} deficiency actions: {missing[:5]}")
    rows = [segment_record(record) for record in records]
    rows.sort(key=lambda r: (r["letter_date"] or "", r["letter_id"]))
    write_outputs(rows, vintage, args.pull_date, args.audit_seed)
    print(
        f"Segmented {len(rows)} deficiency actions; "
        f"{sum(bool(r['automatic_flag_count']) for r in rows)} automatic flags; vintage v{vintage}."
    )


if __name__ == "__main__":
    main()
