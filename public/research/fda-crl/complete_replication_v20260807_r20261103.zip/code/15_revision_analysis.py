"""Offline R&R additions. Preserve every historical input and primary assignment."""
from pathlib import Path
import os, json, math, hashlib
ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / 'tmp' / 'revision-mpl'))
os.environ.setdefault('MPLBACKEND', 'Agg')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from review_sequence_corrections import corrected_records, linked_pairs, EXCLUDED

OUT = ROOT / 'output/revision'
TEX = ROOT / 'Paper/revision/latex/generated'
CATS = ['facility_inspection','cmc','clinical_efficacy','clinical_safety','trial_design_conduct','stability_shelf_life','bioequivalence_bioavailability','nonclinical_toxicology','labeling_proprietary_name','administrative_procedural']
NAMES = ['Facility inspection','CMC','Clinical efficacy','Clinical safety','Trial design/conduct','Stability/shelf life','Bioequivalence/availability','Nonclinical toxicology','Labeling/name','Administrative/procedural']
LABEL = dict(zip(CATS,NAMES))
SHORT = ['Fac','CMC','Eff','Saf','Trial','Stab','Bio','Noncl','Label','Admin']
PRIMARY = 'primary_deficiency_category'

def wilson(x,n):
    if not n: return (float('nan'),float('nan'))
    z=1.959963984540054; p=x/n; d=1+z*z/n
    c=(p+z*z/(2*n))/d; h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return c-h,c+h

def difference(x,n,y,m):
    p,q=x/n,y/m; l,u=wilson(x,n); a,b=wilson(y,m)
    return p-q,p-q-math.sqrt((p-l)**2+(b-q)**2),p-q+math.sqrt((u-p)**2+(q-a)**2)

def table(name,headers,rows,align):
    text=['\\begin{tabular}{'+align+'}','\\toprule',' & '.join(headers)+r' \\',r'\midrule']
    text += [' & '.join(map(str,row))+r' \\' for row in rows]
    text += [r'\bottomrule',r'\end{tabular}','']
    (TEX/(name+'.tex')).write_text('\n'.join(text),encoding='utf-8',newline='\n')

def save(frame,name):
    frame.to_csv(OUT/'tables'/(name+'.csv'),index=False,lineterminator='\n')

def main():
    for d in [OUT/'tables',OUT/'figures',TEX]: d.mkdir(parents=True,exist_ok=True)
    panel=pd.read_csv(ROOT/'data/final/analysis_panel_classified_v20260807.csv',dtype=str,keep_default_na=False)
    s=pd.DataFrame(corrected_records(panel.to_dict('records')))
    save(pd.DataFrame([dict(letter_id=k,reason=v) for k,v in EXCLUDED.items()]),'review_sequence_exclusions')
    assert len(panel)==458 and len(s)==443 and s.application_id.nunique()==333
    # Preserve simultaneous decisions as letters, but do not pair unrelated originals.
    save(s[s.duplicated(['application_id','letter_date'],keep=False)].drop(columns=[],errors='ignore'),'same_date_records')
    s['categories_corrected']=s.deficiency_categories.map(lambda x:set(x.split('|')))
    corrections=pd.read_csv(ROOT/'data/final/segmentation_corrections_v20260807.csv',dtype=str)
    for _,r in corrections.iterrows():
        ix=s.index[s.letter_id.eq(r.letter_id)]
        for i in ix: s.at[i,'categories_corrected']=s.at[i,'categories_corrected']|{r.recovered_category}
    assert (s[PRIMARY].value_counts().reindex(CATS).to_list()==[184,73,72,45,10,1,18,27,5,8])
    corrected=s.copy(); corrected['deficiency_categories_original']=corrected.deficiency_categories
    corrected['deficiency_categories']=corrected.categories_corrected.map(lambda x:'|'.join(c for c in CATS if c in x))
    save(corrected.drop(columns='categories_corrected'),'strict_crl_analysis_corrected_secondary')
    catrows=[]
    for c in CATS:
        p=int(s[PRIMARY].eq(c).sum()); a=int(s.categories_corrected.map(lambda x:c in x).sum())
        catrows.append(dict(category=c,letters=len(s),primary_n=p,secondary_n=a-p,any_n=a,any_share=a/len(s)))
    cats=pd.DataFrame(catrows); save(cats,'category_overlap')
    table('category_overlap',['Category','Primary','Secondary','Any','Any (\\%)'],[[LABEL[r.category],r.primary_n,r.secondary_n,r.any_n,f'{100*r.any_share:.1f}'] for r in cats.itertuples()],'lrrrr')
    co=pd.DataFrame([[sum(c in x and d in x for x in s.categories_corrected) for d in CATS] for c in CATS],index=CATS,columns=CATS)
    save(co.reset_index(names='category'),'cooccurrence')
    # Presence of any primary or secondary finding, not the primary-category distribution.
    manufacturing={'facility_inspection','cmc'}
    clinical_core={'clinical_efficacy','clinical_safety','trial_design_conduct'}
    clinical_broad=clinical_core|{'bioequivalence_bioavailability'}
    overlap=[]
    groups=[(True,False,'Manufacturing without clinical'),(True,True,'Both'),
            (False,True,'Clinical without manufacturing'),(False,False,'Neither')]
    for sample,g in [('All strict CRLs',s),('Unflagged classifications',s[s.classification_status.eq('ok')])]:
        for definition,clinical in [('Broad clinical',clinical_broad),('Core clinical',clinical_core)]:
            m=g.categories_corrected.map(lambda x:bool(x&manufacturing))
            c=g.categories_corrected.map(lambda x:bool(x&clinical))
            for has_m,has_c,label in groups:
                n=int((m.eq(has_m)&c.eq(has_c)).sum())
                overlap.append(dict(sample=sample,clinical_definition=definition,group=label,
                                    letters=len(g),count=n,share=n/len(g)))
    overlap=pd.DataFrame(overlap); save(overlap,'manufacturing_clinical_overlap')
    broad=overlap[overlap.clinical_definition.eq('Broad clinical')]
    tabrows=[]
    for _,_,label in groups:
        records=[broad[(broad.group.eq(label))&(broad['sample'].eq(sample))].iloc[0]
                 for sample in ['All strict CRLs','Unflagged classifications']]
        tabrows.append([label]+[f'{int(r["count"])} ({100*r["share"]:.1f})' for r in records])
    table('manufacturing_clinical_overlap',['Coded findings','All letters','Unflagged'],tabrows,'lrr')
    flags=s[['letter_id','application_id','classification_status']].copy()
    flags['has_manufacturing']=s.categories_corrected.map(lambda x:int(bool(x&manufacturing)))
    flags['has_broad_clinical']=s.categories_corrected.map(lambda x:int(bool(x&clinical_broad)))
    flags['has_core_clinical']=s.categories_corrected.map(lambda x:int(bool(x&clinical_core)))
    save(flags,'manufacturing_clinical_letter_flags')
    pairs=pd.DataFrame(linked_pairs(s.to_dict('records')))
    assert len(pairs)==109 and pairs.application_id.nunique()==81
    save(pairs,'consecutive_pairs')
    matrix=pd.crosstab(pairs['first'],pairs.second).reindex(index=CATS,columns=CATS,fill_value=0)
    save(matrix.reset_index(names='first_category'),'transition_counts')
    save(matrix.div(matrix.sum(axis=1).replace(0,np.nan),axis=0).reset_index(names='first_category'),'transition_row_proportions')
    rows=[]
    for c in CATS:
        n=int(matrix.loc[c].sum())
        rows.append([LABEL[c]]+[f'{int(v)} ({100*v/n:.1f})' if n else '---' for v in matrix.loc[c]]+[n])
    table('transitions',['First / next']+SHORT+['N'],rows,'l'+'r'*11)
    merge=lambda c:'manufacturing_quality' if c in ['facility_inspection','cmc'] else c
    pairs['first_merged']=pairs['first'].map(merge); pairs['second_merged']=pairs.second.map(merge)
    stats=[]
    for sample,p in [('All observed pairs',pairs),('First pair per application',pairs[pairs.pair_sequence.eq(1)]),('Exclude same-date pairs',pairs[pairs.first_date.ne(pairs.second_date)])]:
        for scheme in ['separate','merged']:
            a,b=('first','second') if scheme=='separate' else ('first_merged','second_merged')
            for cat in ['all','facility_inspection','cmc'] if scheme=='separate' else ['all','manufacturing_quality']:
                q=p if cat=='all' else p[p[a].eq(cat)]
                n=len(q); x=int(q[a].eq(q[b]).sum()); lo,hi=wilson(x,n)
                stats.append(dict(sample=sample,scheme=scheme,category=cat,n=n,repeated=x,share=x/n,ci_low=lo,ci_high=hi))
    stats=pd.DataFrame(stats); save(stats,'recurrence_sensitivity')
    recurrence_rows=[]
    for category,label in [('all','All categories'),('facility_inspection','Facility inspection'),('cmc','CMC'),('manufacturing_quality','Manufacturing quality (facility or CMC)')]:
        scheme='merged' if category=='manufacturing_quality' else 'separate'
        row=[label]
        for sample in ['First pair per application','All observed pairs']:
            r=stats[stats.category.eq(category)&stats.scheme.eq(scheme)&stats['sample'].eq(sample)].iloc[0]
            row.append(f'{r.repeated}/{r.n} ({100*r.share:.1f}\\%)')
        recurrence_rows.append(row)
    table('recurrence',['Initial main reason',r'\shortstack{First pair per\\application}',r'\shortstack{All consecutive\\pairs}'],recurrence_rows,'lrr')
    first=s[s.is_first_strict_crl.eq('1')].copy()
    eligible=first[first.second_crl_730d_eligible.eq('1')].copy(); assert len(eligible)==250
    horizon=[]
    for group,mask in [('Facility',eligible[PRIMARY].eq('facility_inspection')),('Other than facility',~eligible[PRIMARY].eq('facility_inspection')),('Manufacturing quality',eligible[PRIMARY].isin(['facility_inspection','cmc'])),('Other than manufacturing quality',~eligible[PRIMARY].isin(['facility_inspection','cmc']))]:
        q=eligible[mask]; x=int(q.second_crl_within_730d_event.eq('1').sum()); n=len(q); lo,hi=wilson(x,n)
        horizon.append(dict(group=group,n=n,events=x,share=x/n,ci_low=lo,ci_high=hi))
    save(pd.DataFrame(horizon),'two_year_rates')
    diffs=[]
    for a,b in [(horizon[0],horizon[1]),(horizon[2],horizon[3])]:
        d,l,u=difference(a['events'],a['n'],b['events'],b['n'])
        diffs.append(dict(comparison=a['group']+' versus '+b['group'],difference=d,ci_low=l,ci_high=u))
    save(pd.DataFrame(diffs),'two_year_differences')
    table('two_year',['First-letter category','Applications','Another CRL','\\%','95\\% CI'],[[r['group'],r['n'],r['events'],f"{100*r['share']:.1f}",f"{100*r['ci_low']:.1f}--{100*r['ci_high']:.1f}"] for r in horizon],'lrrrr')
    # Compare facility versus other initial reasons within application type.
    by_type=[]
    for typ in ['NDA','BLA']:
        group=eligible[eligible.application_type.eq(typ)]
        facility=group[group[PRIMARY].eq('facility_inspection')]
        other=group[~group[PRIMARY].eq('facility_inspection')]
        x=int(facility.second_crl_within_730d_event.eq('1').sum()); n=len(facility)
        y=int(other.second_crl_within_730d_event.eq('1').sum()); m=len(other)
        d,lo,hi=difference(x,n,y,m)
        by_type.append(dict(application_type=typ,facility_events=x,facility_n=n,facility_share=x/n,
                            other_events=y,other_n=m,other_share=y/m,difference=d,ci_low=lo,ci_high=hi))
    assert sum(r['facility_n'] for r in by_type)==84 and sum(r['other_n'] for r in by_type)==166
    assert sum(r['facility_events'] for r in by_type)==24 and sum(r['other_events'] for r in by_type)==24
    save(pd.DataFrame(by_type),'two_year_by_application_type')
    table('two_year_by_application_type',['Type',r'\shortstack{Initial facility\\reason}',r'\shortstack{Other initial\\reason}',r'\shortstack{Difference\\(points)}',r'\shortstack{95\% CI\\(points)}'],
          [[r['application_type'],f"{r['facility_events']}/{r['facility_n']} ({100*r['facility_share']:.1f}\\%)",
            f"{r['other_events']}/{r['other_n']} ({100*r['other_share']:.1f}\\%)",
            f"{100*r['difference']:.1f}",f"{100*r['ci_low']:.1f} to {100*r['ci_high']:.1f}"] for r in by_type],'lrrrr')
    s['era']=pd.cut(s.letter_date.str[:4].astype(int),[2008,2014,2019,2023,2026],labels=['2009--2014','2015--2019','2020--2023','2024--2026'])
    era=[]
    for (period,typ),g in s.groupby(['era','application_type'],observed=True):
        x=int(g[PRIMARY].eq('facility_inspection').sum())
        era.append(dict(period=str(period),application_type=typ,n=len(g),facility_n=x,facility_share=x/len(g)))
    save(pd.DataFrame(era),'facility_by_period_type')
    table('period_type',['Period','Type','Letters','Facility','\\%'],[[r['period'],r['application_type'],r['n'],r['facility_n'],f"{100*r['facility_share']:.1f}"] for r in era],'llrrr')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
    fig,axes=plt.subplots(1,2,figsize=(10,5.4),sharey=True)
    dist=[]
    for ax,(name,g) in zip(axes,[('Full corpus',s),('2024 onward',s[s.letter_date.ge('2024-01-01')])]):
        ns=[int(g[PRIMARY].eq(c).sum()) for c in CATS]; ps=np.array(ns)/len(g)*100
        ci=np.array([wilson(x,len(g)) for x in ns])*100
        ax.barh(range(10),ps,color='#216b83',height=.65)
        ax.errorbar(ps,range(10),xerr=np.vstack([ps-ci[:,0],ci[:,1]-ps]),fmt='none',color='#333333',capsize=3)
        for y,(x,p) in enumerate(zip(ns,ps)): ax.text(ci[y,1]+1,y,f'n={x}',va='center',fontsize=8)
        ax.set_xlim(0,65); ax.set_title(f'{name} (N={len(g)} letters)'); ax.set_xlabel('Main reason for nonapproval (%)')
        ax.spines[['top','right']].set_visible(False)
        for c,x,p,bounds in zip(CATS,ns,ps,ci): dist.append(dict(cohort=name,category=c,n=len(g),count=x,percent=p,ci_low=bounds[0],ci_high=bounds[1]))
    axes[0].set_yticks(range(10),NAMES); axes[0].invert_yaxis()
    fig.tight_layout(); fig.savefig(OUT/'figures/primary_categories.pdf'); fig.savefig(OUT/'figures/primary_categories.png',dpi=180); plt.close(fig)
    save(pd.DataFrame(dist),'primary_categories_with_intervals')
    # A flow diagram distinguishes record, application, and pair units.
    fig,ax=plt.subplots(figsize=(9,5.8)); ax.set(xlim=(0,1),ylim=(0,1)); ax.axis('off')
    def box(x,y,t): ax.text(x,y,t,ha='center',va='center',fontsize=10,bbox=dict(boxstyle='round,pad=.6',facecolor='#edf5f7',edgecolor='#216b83'))
    def arrow(a,b): ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->',color='#445566'))
    box(.32,.91,'458 source records'); box(.77,.72,'15 excluded records\n4 predecessor actions; 8 other actions\n1 placeholder; 1 duplicate\n1 incomplete-response acknowledgement')
    box(.32,.64,'443 strict CRLs\n333 primary applications'); arrow((.32,.86),(.32,.72)); arrow((.34,.81),(.62,.76))
    box(.22,.38,'252 applications\nwith one letter'); box(.73,.38,'81 applications\nwith multiple letters\n191 letters; 109 linked pairs')
    arrow((.29,.56),(.22,.46)); arrow((.38,.56),(.68,.48))
    box(.4,.12,'Separate application-level cohort:\n250 first letters with 730 days of calendar follow-up\n83 applications excluded for shorter follow-up')
    arrow((.09,.64),(.09,.14)); arrow((.09,.14),(.13,.14))
    fig.tight_layout(); fig.savefig(OUT/'figures/sample_flow.pdf'); fig.savefig(OUT/'figures/sample_flow.png',dpi=180); plt.close(fig)
    summaries={'source_records':len(panel),'strict_letters':len(s),'applications':333,'pairs':len(pairs),'repeat_applications':int(pairs.application_id.nunique()),'eligible_730':250,'secondary_corrections':len(corrections),'facility_cmc_cooccurrence':int(co.loc['facility_inspection','cmc']),'manufacturing_primary':int(s[PRIMARY].isin(['facility_inspection','cmc']).sum()),'manufacturing_recent_primary':int(s.loc[s.letter_date.ge('2024-01-01'),PRIMARY].isin(['facility_inspection','cmc']).sum()),'recurrence':stats.to_dict('records'),'horizon':horizon,'differences':diffs,'multiple_application_letters':int(s.multiple_distinct_applications.eq('1').sum()),'target_submission_refs':s.target_submission_refs.value_counts().to_dict(),'checks':'passed'}
    (OUT/'analysis_summary.json').write_text(json.dumps(summaries,indent=2)+'\n',encoding='utf-8',newline='\n')
    # TeX-ready figures live beside the manuscript for a portable Overleaf folder.
    import shutil
    for f in (OUT/'figures').glob('*.pdf'): shutil.copy2(f,TEX/f.name)
    print(json.dumps(summaries,indent=2))

if __name__=='__main__': main()
