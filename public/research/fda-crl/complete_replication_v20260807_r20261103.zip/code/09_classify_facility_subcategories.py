#!/usr/bin/env python3
"""Classify facility-coded letters into inspection states with structured API output."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
STATES = ["5a_failed", "5b_not_conducted", "5c_pending_conditional", "5e_unclear"]
OUTPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "facility_state": {"type": "string", "enum": STATES},
        "failed_present": {"type": "boolean"},
        "not_conducted_present": {"type": "boolean"},
        "pending_conditional_present": {"type": "boolean"},
        "third_party_flag": {"type": "string", "enum": ["yes", "no", "unclear"]},
        "template_only": {"type": "boolean"},
        "not_conducted_reason": {"type": "string"},
        "classification_status": {
            "type": "string",
            "enum": ["ok", "uncertain_redaction", "uncertain_ocr", "failed"],
        },
        "rationale": {"type": "string"},
    },
    "required": [
        "facility_state", "failed_present", "not_conducted_present",
        "pending_conditional_present", "third_party_flag", "template_only",
        "not_conducted_reason", "classification_status", "rationale",
    ],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default=os.environ.get("CRL_CLASSIFIER_MODEL", "gpt-5.6-terra"))
    parser.add_argument(
        "--reasoning-effort",
        choices=["none", "low", "medium", "high", "xhigh", "max"],
        default=os.environ.get("CRL_CLASSIFIER_REASONING_EFFORT", "low"),
    )
    parser.add_argument("--api-base", default=os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1"))
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--max-retries", type=int, default=6)
    return parser.parse_args()


def find_vintage() -> str:
    paths = sorted((ROOT / "data" / "interim").glob("facility_passages_v*.jsonl"))
    if len(paths) != 1:
        raise RuntimeError(f"Expected one facility passage file, found {[p.name for p in paths]}")
    return re.search(r"_v(\d{8})\.jsonl$", paths[0].name).group(1)  # type: ignore[union-attr]


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def load_api_key() -> str:
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if api_key:
        return api_key
    path = ROOT / ".env"
    if not path.exists():
        return ""
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        if "=" not in raw_line or raw_line.lstrip().startswith("#"):
            continue
        name, value = raw_line.split("=", 1)
        if name.strip() == "OPENAI_API_KEY":
            candidate = value.strip().strip('"').strip("'")
            return "" if candidate == "replace-with-your-api-key" else candidate
    return ""


def prompt_text() -> str:
    codebook = (ROOT / "notes" / "facility_subcategory_codebook.md").read_text(encoding="utf-8")
    return (
        "You are coding facility-inspection facts in an FDA action letter for a research dataset. "
        "Use only the supplied facility passage and sponsor metadata. Apply the hierarchy exactly. "
        "Repeated FDA wording does not make a completed adverse inspection template-only. "
        "Keep the rationale to at most 60 words and preserve any stated reason an inspection was "
        "not conducted verbatim or as a close extract. If none, return an empty reason.\n\n" + codebook
    )


def request_payload(model: str, reasoning_effort: str, instructions: str, row: dict[str, Any]) -> dict[str, Any]:
    user_input = (
        f"Letter ID: {row['letter_id']}\n"
        f"Application: {row['application_id']}\n"
        f"Letter date: {row['letter_date']}\n"
        f"Endpoint company: {row.get('company_name', '')}\n"
        f"Drugs@FDA sponsor: {row.get('drugsfda_sponsor_name', '')}\n"
        f"Original primary category: {row['primary_category']}\n\n"
        "EXTRACTED FACILITY PASSAGE\n"
        f"{row['facility_passage']}"
    )
    return {
        "model": model,
        "reasoning": {"effort": reasoning_effort},
        "store": False,
        "instructions": instructions,
        "input": user_input,
        "max_output_tokens": 900,
        "text": {
            "format": {
                "type": "json_schema",
                "name": "facility_subcategory_classification",
                "description": "Facility inspection state, event flags, third-party overlay, and boilerplate test.",
                "strict": True,
                "schema": OUTPUT_SCHEMA,
            }
        },
    }


def post_response(api_base: str, api_key: str, payload: dict[str, Any], max_retries: int) -> dict[str, Any]:
    body = json.dumps(payload).encode("utf-8")
    url = api_base.rstrip("/") + "/responses"
    for attempt in range(max_retries + 1):
        request = urllib.request.Request(
            url,
            data=body,
            method="POST",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(request, timeout=180) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            retryable = exc.code in {408, 409, 429, 500, 502, 503, 504}
            if not retryable or attempt == max_retries:
                raise RuntimeError(f"API HTTP {exc.code}: {detail[:1000]}") from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            if attempt == max_retries:
                raise RuntimeError(f"API request failed after retries: {exc}") from exc
        time.sleep(min(60, 2 ** attempt))
    raise AssertionError("unreachable")


def extract_output_text(response: dict[str, Any]) -> str:
    chunks: list[str] = []
    for item in response.get("output", []):
        if item.get("type") != "message":
            continue
        for content in item.get("content", []):
            if content.get("type") == "output_text":
                chunks.append(content.get("text", ""))
    if not chunks:
        raise RuntimeError(f"No output_text in response {response.get('id')}")
    return "".join(chunks)


def validate_result(result: dict[str, Any]) -> None:
    state = result["facility_state"]
    if state == "5a_failed" and not result["failed_present"]:
        raise ValueError("5a_failed requires failed_present=true")
    if state == "5b_not_conducted" and (result["failed_present"] or not result["not_conducted_present"]):
        raise ValueError("5b_not_conducted requires no 5a event and not_conducted_present=true")
    if state == "5c_pending_conditional" and (
        result["failed_present"] or result["not_conducted_present"] or not result["pending_conditional_present"]
    ):
        raise ValueError("5c_pending_conditional requires only a pending conditional event")


def completed_ids(path: Path) -> set[str]:
    if not path.exists():
        return set()
    output: set[str] = set()
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            try:
                output.add(json.loads(line)["letter_id"])
            except (json.JSONDecodeError, KeyError):
                continue
    return output


def main() -> None:
    args = parse_args()
    vintage = find_vintage()
    passage_path = ROOT / "data" / "interim" / f"facility_passages_v{vintage}.jsonl"
    rows = [row for row in read_jsonl(passage_path) if row["facility_in_categories"]]
    if not rows or any(not row["facility_passage"] for row in rows):
        raise RuntimeError("Every facility-coded letter must have an extracted passage")
    instructions = prompt_text()
    prompt_hash = hashlib.sha256(instructions.encode("utf-8")).hexdigest()
    validation_path = ROOT / "data" / "manual" / f"facility_subcategory_validation_sample_v{vintage}.csv"
    if not validation_path.exists():
        raise RuntimeError("Frozen facility validation sample is missing")
    print(f"Prepared {len(rows)} facility-coded letters; frozen validation sample={validation_path.name}.")
    if args.prepare_only:
        return
    output_path = ROOT / "data" / "interim" / f"facility_subclassifications_v{vintage}.jsonl"
    completed = completed_ids(output_path)
    pending = [row for row in rows if row["letter_id"] not in completed]
    if args.limit is not None:
        pending = pending[:args.limit]
    if not pending:
        print(f"No pending facility subclassifications; frozen output is complete at {output_path.name}.")
        return
    api_key = load_api_key()
    if not api_key:
        raise SystemExit(
            "OPENAI_API_KEY is unavailable in the process or project .env file. Supply a "
            "complete frozen classification file or configure the key for a new run."
        )
    with output_path.open("a", encoding="utf-8", newline="\n") as handle:
        for index, row in enumerate(pending, start=1):
            response = post_response(
                args.api_base,
                api_key,
                request_payload(args.model, args.reasoning_effort, instructions, row),
                args.max_retries,
            )
            result = json.loads(extract_output_text(response))
            validate_result(result)
            codes = [result["facility_state"]]
            if result["third_party_flag"] == "yes":
                codes.append("5d_third_party")
            output = {
                "letter_id": row["letter_id"],
                "application_id": row["application_id"],
                "letter_date": row["letter_date"],
                "file_name": row["file_name"],
                "facility_primary": row["facility_primary"],
                "facility_passage_sha256": row["facility_passage_sha256"],
                "prompt_sha256": prompt_hash,
                "requested_model": args.model,
                "requested_reasoning_effort": args.reasoning_effort,
                "response_model": response.get("model"),
                "response_id": response.get("id"),
                "usage": response.get("usage"),
                "classified_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "facility_codes": codes,
                **result,
            }
            handle.write(json.dumps(output, ensure_ascii=False, sort_keys=True) + "\n")
            handle.flush()
            print(f"[{index}/{len(pending)}] {row['letter_id']} -> {result['facility_state']}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Interrupted; completed facility records are preserved for resume.", file=sys.stderr)
        raise
