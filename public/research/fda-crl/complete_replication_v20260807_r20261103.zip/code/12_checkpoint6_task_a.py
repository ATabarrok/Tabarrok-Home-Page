#!/usr/bin/env python3
"""Checkpoint 6A: audit inspection language before and after segmentation.

This script is deliberately read-only with respect to the frozen analysis panel. It
creates accounting and audit artifacts; it does not re-pull FDA data or silently
rewrite classifications.
"""

from __future__ import annotations

import csv
import importlib.util
import json
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
VINTAGE = "20260807"
CUTOFF = "2026-08-28"
INSPECTION_RE = re.compile(r"\binspect(?:ion|ions|ed|or|ors|ing)\b", re.IGNORECASE)


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def excerpt(text: str, radius: int = 560) -> str:
    match = INSPECTION_RE.search(text)
    if not match:
        return re.sub(r"\s+", " ", text).strip()[: 2 * radius]
    start = max(0, match.start() - radius)
    end = min(len(text), match.end() + radius)
    return re.sub(r"\s+", " ", text[start:end]).strip()


def load_facility_extractor():
    path = ROOT / "code" / "08_extract_facility_passages.py"
    spec = importlib.util.spec_from_file_location("facility_extractor", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.extract_facility_passage


def load_raw_only_audit() -> dict[str, dict[str, str]]:
    path = (
        ROOT / "data" / "manual" /
        f"checkpoint6_raw_only_inspection_adjudications_v{VINTAGE}.csv"
    )
    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 5 or len({row["letter_id"] for row in rows}) != 5:
        raise RuntimeError("Raw-only inspection adjudication file must contain five unique letters")
    return {row["letter_id"]: row for row in rows}


SEGMENTER_RULES = [
    {"rule_group": "start", "rule_name": "reasons_for_action", "pattern": r"(?:we\s+have\s+)?described\s+(?:be[^a-z0-9]{0,3}low\s+|below\s+)?(?:our\s+)?reason(?:s)?\s+for\s+this\s+action\s+(?:be[^a-z0-9]{0,3}low|below)[^.]*[.:]?"},
    {"rule_group": "start", "rule_name": "reasons_for_action_reversed", "pattern": r"(?:we\s+have\s+)?described\s+(?:be[^a-z0-9]{0,3}low|below)\s+(?:our\s+)?reason(?:s)?\s+for\s+this\s+action[^.]*[.:]?"},
    {"rule_group": "start", "rule_name": "deficiencies_outlined", "pattern": r"deficienc(?:y|ies)[^.]{0,180}?(?:are\s+|is\s+)?(?:outlined|described|summarized|identified)[^.]{0,100}?(?:below|here|as\s+follows)[^.]*[.:]?"},
    {"rule_group": "start", "rule_name": "deficiencies_each_study", "pattern": r"deficienc(?:y|ies)[^.]{0,160}?(?:each|stud(?:y|ies))[^.]{0,120}?(?:outlined|described|summarized)[^.]*[.:]?"},
    {"rule_group": "start_fallback", "rule_name": "end_of_decision_sentence", "pattern": r"(?:cannot|could not)[^.]{0,140}?(?:approve|grant final approval)[^.]{0,160}?(?:present|current) form[^.]*[.]"},
    {"rule_group": "start_fallback", "rule_name": "first_substantive_heading", "pattern": "first recognized deficiency heading after character 300"},
    {"rule_group": "end", "rule_name": "other_requests_and_comments", "pattern": r"(?m)^\s*OTHER REQUESTS? AND COMMENTS?\s*$"},
    {"rule_group": "end", "rule_name": "safety_update", "pattern": r"(?m)^\s*SAFETY UPDATE\s*$"},
    {"rule_group": "end", "rule_name": "additional_comments_not_approvability", "pattern": r"(?ims)^\s*ADDITIONAL COMMENTS?\s*$(?=.{0,240}?(?:not (?:an? )?approvability issue|not approvability issues))"},
    {"rule_group": "end", "rule_name": "within_days", "pattern": r"(?m)^\s*Within \d+ days after (?:the )?date of this letter"},
    {"rule_group": "end", "rule_name": "within_one_year", "pattern": r"(?m)^\s*Within one year after (?:the )?date of this letter"},
    {"rule_group": "end", "rule_name": "resubmission_must_address", "pattern": r"(?m)^\s*A resubmission must fully address"},
    {"rule_group": "end", "rule_name": "decide_to_resubmit", "pattern": r"(?m)^\s*If you decide to resubmit"},
    {"rule_group": "end", "rule_name": "required_to_resubmit", "pattern": r"(?m)^\s*You are required to resubmit"},
    {"rule_group": "late_end", "rule_name": "meeting_request", "pattern": r"(?m)^\s*You may request a meeting"},
    {"rule_group": "late_end", "rule_name": "questions", "pattern": r"(?m)^\s*If you have any questions"},
    {"rule_group": "late_end", "rule_name": "sincerely", "pattern": r"(?m)^\s*Sincerely(?: yours)?,?\s*$"},
]


def main() -> None:
    raw_only_audit = load_raw_only_audit()
    panel_path = ROOT / "data" / "final" / f"analysis_panel_facility_subclassified_v{VINTAGE}.csv"
    raw_path = ROOT / "data" / "interim" / f"crl_letters_parsed_v{VINTAGE}.jsonl"
    segment_path = ROOT / "data" / "interim" / f"deficiency_segments_v{VINTAGE}.jsonl"
    passage_path = ROOT / "data" / "interim" / f"facility_passages_v{VINTAGE}.jsonl"

    with panel_path.open(encoding="utf-8-sig", newline="") as handle:
        panel = [row for row in csv.DictReader(handle) if row["is_deficiency_action"] == "1"]
    raw_by_id = {row["letter_id"]: row for row in read_jsonl(raw_path)}
    segment_by_id = {row["letter_id"]: row for row in read_jsonl(segment_path)}
    passage_by_id = {row["letter_id"]: row for row in read_jsonl(passage_path)}
    extract_facility_passage = load_facility_extractor()

    if len(panel) != 449:
        raise AssertionError(f"Expected 449 classified actions, found {len(panel)}")

    letter_rows: list[dict[str, Any]] = []
    for row in panel:
        letter_id = row["letter_id"]
        raw_text = raw_by_id[letter_id]["text"]
        segment = segment_by_id[letter_id]
        segment_text = segment["deficiency_text"]
        raw_mention = int(bool(INSPECTION_RE.search(raw_text)))
        segmented_mention = int(bool(INSPECTION_RE.search(segment_text)))
        raw_passage, raw_method = extract_facility_passage(raw_text)
        segmented_passage = passage_by_id[letter_id]["facility_passage"]
        facility_assigned = int("facility_inspection" in row["deficiency_categories"].split("|"))
        audit = raw_only_audit.get(letter_id, {})
        letter_rows.append(
            {
                "letter_id": letter_id,
                "application_id": row["application_id"],
                "file_name": row["file_name"],
                "letter_date": row["letter_date"],
                "is_2024_forward": int(row["letter_date"] >= "2024-01-01"),
                "primary_deficiency_category": row["primary_deficiency_category"],
                "deficiency_categories": row["deficiency_categories"],
                "classification_status": row["classification_status"],
                "segment_end_method": segment["segment_end_method"],
                "raw_inspection_mention": raw_mention,
                "segmented_inspection_mention": segmented_mention,
                "entire_literal_inspection_mention_removed": int(raw_mention and not segmented_mention),
                "raw_rule_based_facility_passage": int(bool(raw_passage)),
                "segmented_rule_based_facility_passage": int(bool(segmented_passage)),
                "facility_assigned": facility_assigned,
                "facility_primary": int(row["primary_deficiency_category"] == "facility_inspection"),
                "manual_substantive_facility_after_segmentation": audit.get(
                    "manual_substantive_facility_after_segmentation", ""
                ),
                "manual_pure_template": audit.get("manual_pure_template", ""),
                "manual_disposition": audit.get("manual_disposition", ""),
                "manual_missing_facility_category": audit.get("manual_missing_facility_category", ""),
                "manual_notes": audit.get("manual_notes", ""),
                "raw_inspection_excerpt": excerpt(raw_text) if raw_mention and not segmented_mention else "",
                "segmented_facility_excerpt": re.sub(r"\s+", " ", segmented_passage).strip()[:1400],
                "raw_extraction_method": raw_method,
            }
        )

    raw_only = [row for row in letter_rows if row["entire_literal_inspection_mention_removed"]]
    if {row["letter_id"] for row in raw_only} != set(raw_only_audit):
        raise AssertionError("Frozen raw-only audit IDs no longer match computed population")

    def subset(recent: bool) -> list[dict[str, Any]]:
        return [row for row in letter_rows if not recent or row["is_2024_forward"]]

    accounting_rows: list[dict[str, Any]] = []
    for label, recent in [("all_449", False), ("2024_forward", True)]:
        rows = subset(recent)
        raw_n = sum(row["raw_inspection_mention"] for row in rows)
        raw_only_rows = [row for row in rows if row["entire_literal_inspection_mention_removed"]]
        no_substantive_rows = [
            row
            for row in raw_only_rows
            if row["manual_substantive_facility_after_segmentation"] == 0
        ]
        pure_template_rows = [row for row in no_substantive_rows if row["manual_pure_template"] == 1]
        unclear_rows = [row for row in no_substantive_rows if row["manual_pure_template"] == "unclear"]
        accounting_rows.append(
            {
                "universe": label,
                "classified_actions_n": len(rows),
                "raw_inspection_mentions_n": raw_n,
                "raw_rule_based_facility_passage_n": sum(
                    row["raw_rule_based_facility_passage"] for row in rows
                ),
                "literal_inspection_mention_fully_removed_n": len(raw_only_rows),
                "removed_and_no_substantive_facility_in_segment_n": len(no_substantive_rows),
                "confirmed_pure_template_removed_n": len(pure_template_rows),
                "pure_template_share_of_raw_inspection_mentions": (
                    len(pure_template_rows) / raw_n if raw_n else ""
                ),
                "unclear_redacted_removed_n": len(unclear_rows),
                "conservative_upper_bound_pure_template_share": (
                    (len(pure_template_rows) + len(unclear_rows)) / raw_n if raw_n else ""
                ),
                "facility_assigned_among_confirmed_pure_template_n": sum(
                    row["facility_assigned"] for row in pure_template_rows
                ),
                "facility_assigned_among_removed_no_substantive_n": sum(
                    row["facility_assigned"] for row in no_substantive_rows
                ),
                "segmented_rule_based_facility_passage_n": sum(
                    row["segmented_rule_based_facility_passage"] for row in rows
                ),
                "facility_coded_with_substantive_segment_n": sum(row["facility_assigned"] for row in rows),
                "segmented_literal_inspection_mention_n": sum(row["segmented_inspection_mention"] for row in rows),
                "known_genuine_conditional_5b_removed_n": sum(
                    row["manual_disposition"] == "genuine_conditional_5b_removed" for row in raw_only_rows
                ),
                "known_missing_facility_secondary_code_n": sum(
                    row["manual_missing_facility_category"] == 1 for row in raw_only_rows
                ),
                "literal_count_criterion": "Contains the literal token inspect* in the indicated raw or retained text.",
                "rule_based_count_criterion": "Meets the broader inspection/site rule, including manufacturing-site language tied to satisfactory resolution.",
            }
        )

    audit_rows = [row for row in raw_only]
    pattern_fields = ["rule_group", "rule_name", "pattern"]
    letter_fields = list(letter_rows[0])
    audit_fields = letter_fields
    accounting_fields = list(accounting_rows[0])

    tables = ROOT / "output" / "tables"
    write_csv(tables / f"checkpoint6A_boilerplate_accounting_v{VINTAGE}.csv", accounting_rows, accounting_fields)
    write_csv(tables / f"checkpoint6A_raw_only_inspection_audit_v{VINTAGE}.csv", audit_rows, audit_fields)
    write_csv(tables / f"checkpoint6A_inspection_letter_accounting_v{VINTAGE}.csv", letter_rows, letter_fields)
    write_csv(tables / f"checkpoint6A_segmenter_rules_v{VINTAGE}.csv", SEGMENTER_RULES, pattern_fields)

    summary = {
        "data_vintage": VINTAGE,
        "followup_cutoff": CUTOFF,
        "mechanism": {
            "facility_specific_boilerplate_removal": False,
            "description": (
                "The segmenter uses structural start and end boundaries. It does not contain a facility- or "
                "inspection-specific boilerplate deletion list. The earliest end boundary can nevertheless "
                "remove substantive inspection language appearing after SAFETY UPDATE or similar headings."
            ),
            "rules": SEGMENTER_RULES,
        },
        "accounting": accounting_rows,
        "raw_only_population_n": len(raw_only),
        "manual_audit_population_n": len(audit_rows),
        "unsupported_facility_assignments": [
            row["letter_id"]
            for row in audit_rows
            if row["facility_assigned"] and not row["manual_substantive_facility_after_segmentation"]
        ],
        "known_missing_facility_secondary_codes": [
            row["letter_id"] for row in audit_rows if row["manual_missing_facility_category"] == 1
        ],
    }
    interim = ROOT / "data" / "interim" / f"checkpoint6A_summary_v{VINTAGE}.json"
    interim.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
