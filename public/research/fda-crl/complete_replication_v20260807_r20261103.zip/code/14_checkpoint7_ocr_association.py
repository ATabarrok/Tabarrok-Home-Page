"""Checkpoint 7: resolve the OCR/facility association without changing the frozen panel."""

from __future__ import annotations

import csv
import json
import math
import statistics
from collections import Counter
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
VINTAGE = "20260807"
ERA_ORDER = ["2002-2014", "2015-2019", "2020-2023", "2024-2026"]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0]) if rows else []
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def era(year: int) -> str:
    if year <= 2014:
        return "2002-2014"
    if year <= 2019:
        return "2015-2019"
    if year <= 2023:
        return "2020-2023"
    return "2024-2026"


def wilson(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float | None, float | None, float | None]:
    if not n:
        return None, None, None
    p = successes / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return p, max(0.0, center - half), min(1.0, center + half)


def newcombe(a: int, n_a: int, b: int, n_b: int) -> tuple[float | None, float | None, float | None]:
    """Difference a/n_a minus b/n_b using Wilson-score Newcombe bounds."""
    if not n_a or not n_b:
        return None, None, None
    p_a, lo_a, hi_a = wilson(a, n_a)
    p_b, lo_b, hi_b = wilson(b, n_b)
    assert p_a is not None and p_b is not None and lo_a is not None and hi_a is not None
    assert lo_b is not None and hi_b is not None
    return p_a - p_b, lo_a - hi_b, hi_a - lo_b


def is_facility(row: dict[str, str]) -> bool:
    return row["primary_deficiency_category"] == "facility_inspection"


def composition(panel: list[dict[str, str]], tables: Path) -> dict[str, Any]:
    groups = []
    for universe, rows in [
        ("full_strict_crl", panel),
        ("2024_forward_strict_crl", [r for r in panel if r["letter_date"] >= "2024-01-01"]),
    ]:
        for status in ["ok", "uncertain_ocr"]:
            subset = [r for r in rows if r["classification_status"] == status]
            years = [int(r["letter_date"][:4]) for r in subset]
            available = [r for r in subset if r["review_division"].strip()]
            groups.append({
                "universe": universe,
                "classification_status": status,
                "n": len(subset),
                "mean_letter_year": statistics.fmean(years) if years else None,
                "median_letter_year": statistics.median(years) if years else None,
                "bla_n": sum(r["application_type"] == "BLA" for r in subset),
                "bla_share": sum(r["application_type"] == "BLA" for r in subset) / len(subset) if subset else None,
                "nda_n": sum(r["application_type"] == "NDA" for r in subset),
                "nda_share": sum(r["application_type"] == "NDA" for r in subset) / len(subset) if subset else None,
                "review_division_available_n": len(available),
                "review_division_missing_n": len(subset) - len(available),
                "review_division_available_share": len(available) / len(subset) if subset else None,
            })
    write_csv(tables / f"checkpoint7_composition_summary_v{VINTAGE}.csv", groups)

    era_rows = []
    division_rows = []
    for universe, rows in [
        ("full_strict_crl", panel),
        ("2024_forward_strict_crl", [r for r in panel if r["letter_date"] >= "2024-01-01"]),
    ]:
        for status in ["ok", "uncertain_ocr"]:
            subset = [r for r in rows if r["classification_status"] == status]
            counts = Counter(era(int(r["letter_date"][:4])) for r in subset)
            for era_name in ERA_ORDER:
                era_rows.append({
                    "universe": universe,
                    "classification_status": status,
                    "era": era_name,
                    "n": counts[era_name],
                    "denominator": len(subset),
                    "share": counts[era_name] / len(subset) if subset else None,
                })
            available = [r for r in subset if r["review_division"].strip()]
            div_counts = Counter(r["review_division"].strip() for r in available)
            for division, n in sorted(div_counts.items(), key=lambda item: (-item[1], item[0])):
                division_rows.append({
                    "universe": universe,
                    "classification_status": status,
                    "review_division": division,
                    "n": n,
                    "available_denominator": len(available),
                    "share_among_available": n / len(available) if available else None,
                })
    write_csv(tables / f"checkpoint7_era_distribution_v{VINTAGE}.csv", era_rows)
    write_csv(tables / f"checkpoint7_review_division_distribution_v{VINTAGE}.csv", division_rows)

    stratified = []
    for era_name in ["pooled", *ERA_ORDER]:
        rows = panel if era_name == "pooled" else [r for r in panel if era(int(r["letter_date"][:4])) == era_name]
        ok = [r for r in rows if r["classification_status"] == "ok"]
        ocr = [r for r in rows if r["classification_status"] == "uncertain_ocr"]
        ok_fac = sum(is_facility(r) for r in ok)
        ocr_fac = sum(is_facility(r) for r in ocr)
        ok_share, ok_low, ok_high = wilson(ok_fac, len(ok))
        ocr_share, ocr_low, ocr_high = wilson(ocr_fac, len(ocr))
        gap, gap_low, gap_high = newcombe(ocr_fac, len(ocr), ok_fac, len(ok))
        stratified.append({
            "era": era_name,
            "ok_n": len(ok),
            "ok_facility_n": ok_fac,
            "ok_facility_share": ok_share,
            "ok_wilson_95_low": ok_low,
            "ok_wilson_95_high": ok_high,
            "uncertain_ocr_n": len(ocr),
            "uncertain_ocr_facility_n": ocr_fac,
            "uncertain_ocr_facility_share": ocr_share,
            "uncertain_ocr_wilson_95_low": ocr_low,
            "uncertain_ocr_wilson_95_high": ocr_high,
            "gap_ocr_minus_ok": gap,
            "newcombe_95_low": gap_low,
            "newcombe_95_high": gap_high,
        })
    write_csv(tables / f"checkpoint7_facility_gap_within_era_v{VINTAGE}.csv", stratified)

    ocr_rates = []
    for era_name in ERA_ORDER:
        rows = [r for r in panel if era(int(r["letter_date"][:4])) == era_name]
        n_ocr = sum(r["classification_status"] == "uncertain_ocr" for r in rows)
        share, low, high = wilson(n_ocr, len(rows))
        facility_n = sum(is_facility(r) for r in rows)
        facility_share, facility_low, facility_high = wilson(facility_n, len(rows))
        ocr_rates.append({
            "era": era_name,
            "strict_crl_n": len(rows),
            "uncertain_ocr_n": n_ocr,
            "uncertain_ocr_rate": share,
            "ocr_wilson_95_low": low,
            "ocr_wilson_95_high": high,
            "facility_primary_n": facility_n,
            "facility_primary_share": facility_share,
            "facility_wilson_95_low": facility_low,
            "facility_wilson_95_high": facility_high,
        })
    write_csv(tables / f"checkpoint7_ocr_rate_by_era_v{VINTAGE}.csv", ocr_rates)
    return {"summary": groups, "stratified": stratified, "ocr_rates": ocr_rates}


def hand_audit(panel: list[dict[str, str]], segments: dict[str, dict[str, Any]], tables: Path) -> dict[str, Any]:
    labels = read_csv(ROOT / "data" / "manual" / f"checkpoint7_uncertain_ocr_hand_census_v{VINTAGE}.csv")
    ocr = [r for r in panel if r["classification_status"] == "uncertain_ocr"]
    if len(ocr) != 26 or len(labels) != 26:
        raise AssertionError("Checkpoint 7 OCR census must contain exactly 26 strict CRLs")
    label_by_id = {r["letter_id"]: r for r in labels}
    if set(label_by_id) != {r["letter_id"] for r in ocr}:
        raise AssertionError("Hand-census IDs do not match the frozen 26-letter OCR universe")

    merged = []
    for row in ocr:
        hand = label_by_id[row["letter_id"]]
        segment = segments[row["letter_id"]]
        model_facility = is_facility(row)
        merged.append({
            "letter_id": row["letter_id"],
            "application_id": row["application_id"],
            "letter_date": row["letter_date"],
            "file_name": row["file_name"],
            "model_primary_category": row["primary_deficiency_category"],
            "hand_primary_category": hand["hand_primary_category"],
            "primary_agreement": int(row["primary_deficiency_category"] == hand["hand_primary_category"]),
            "binding_deficiency_legible": hand["binding_deficiency_legible"],
            "illegible_assignment_basis": hand["illegible_assignment_basis"],
            "model_facility_assignment": int(model_facility),
            "hand_facility_confirmed": int(hand["hand_facility_confirmed"] == "1") if model_facility else "",
            "segment_char_count": int(segment["segment_char_count"]),
            "hand_notes": hand["hand_notes"],
        })
    write_csv(tables / f"checkpoint7_uncertain_ocr_hand_census_merged_v{VINTAGE}.csv", merged)

    model_categories = sorted({r["model_primary_category"] for r in merged})
    hand_categories = sorted({r["hand_primary_category"] for r in merged})
    matrix = []
    for hand_category in hand_categories:
        matrix.append({
            "hand_primary_category": hand_category,
            **{
                f"model_{model}": sum(
                    r["hand_primary_category"] == hand_category and r["model_primary_category"] == model
                    for r in merged
                )
                for model in model_categories
            },
            "row_total": sum(r["hand_primary_category"] == hand_category for r in merged),
        })
    write_csv(tables / f"checkpoint7_uncertain_ocr_confusion_matrix_v{VINTAGE}.csv", matrix)

    median_chars = statistics.median(r["segment_char_count"] for r in merged)
    severity_rows = []
    for group, subset in [
        ("shorter_or_equal_median_more_damaged", [r for r in merged if r["segment_char_count"] <= median_chars]),
        ("longer_than_median_less_damaged", [r for r in merged if r["segment_char_count"] > median_chars]),
    ]:
        facility_n = sum(r["model_facility_assignment"] for r in subset)
        share, low, high = wilson(facility_n, len(subset))
        severity_rows.append({
            "proxy": "retained_deficiency_segment_char_count",
            "proxy_limitation": "Phase 3 contains no direct OCR-confidence score; shorter retained text is a weak, content-dependent extraction proxy.",
            "median_split_value_chars": median_chars,
            "severity_group": group,
            "n": len(subset),
            "mean_segment_chars": statistics.fmean(r["segment_char_count"] for r in subset),
            "facility_primary_n": facility_n,
            "facility_primary_share": share,
            "wilson_95_low": low,
            "wilson_95_high": high,
        })
    damaged = severity_rows[0]
    less_damaged = severity_rows[1]
    sev_gap, sev_low, sev_high = newcombe(
        damaged["facility_primary_n"], damaged["n"],
        less_damaged["facility_primary_n"], less_damaged["n"],
    )
    for row in severity_rows:
        row["gap_more_minus_less_damaged"] = sev_gap
        row["gap_newcombe_95_low"] = sev_low
        row["gap_newcombe_95_high"] = sev_high
    write_csv(tables / f"checkpoint7_ocr_severity_split_v{VINTAGE}.csv", severity_rows)

    facility_model_n = sum(r["model_facility_assignment"] for r in merged)
    facility_confirmed_n = sum(r["hand_facility_confirmed"] == 1 for r in merged)
    return {
        "n": len(merged),
        "agreement_n": sum(r["primary_agreement"] for r in merged),
        "agreement_share": sum(r["primary_agreement"] for r in merged) / len(merged),
        "legible_n": sum(r["binding_deficiency_legible"] == "yes" for r in merged),
        "illegible_n": sum(r["binding_deficiency_legible"] == "no" for r in merged),
        "model_facility_n": facility_model_n,
        "hand_confirmed_facility_n": facility_confirmed_n,
        "facility_confirmation_share": facility_confirmed_n / facility_model_n,
        "severity": severity_rows,
    }


def sensitivity(panel: list[dict[str, str]], tables: Path) -> list[dict[str, Any]]:
    rows_out = []
    for universe, rows in [
        ("full_strict_crl", panel),
        ("2024_forward_strict_crl", [r for r in panel if r["letter_date"] >= "2024-01-01"]),
    ]:
        for definition, subset in [
            ("pooled", rows),
            ("exclude_uncertain_ocr", [r for r in rows if r["classification_status"] != "uncertain_ocr"]),
            ("ok_only", [r for r in rows if r["classification_status"] == "ok"]),
        ]:
            facility_n = sum(is_facility(r) for r in subset)
            share, low, high = wilson(facility_n, len(subset))
            rows_out.append({
                "universe": universe,
                "definition": definition,
                "n": len(subset),
                "facility_primary_n": facility_n,
                "facility_primary_share": share,
                "wilson_95_low": low,
                "wilson_95_high": high,
            })
    write_csv(tables / f"checkpoint7_facility_headline_sensitivity_v{VINTAGE}.csv", rows_out)
    return rows_out


def main() -> None:
    panel_all = read_csv(ROOT / "data" / "final" / f"analysis_panel_facility_subclassified_v{VINTAGE}.csv")
    panel = [r for r in panel_all if r["is_strict_crl"] == "1"]
    if len(panel) != 445:
        raise AssertionError(f"Expected 445 strict CRLs, found {len(panel)}")
    segments = {
        row["letter_id"]: row
        for row in map(json.loads, (ROOT / "data" / "interim" / f"deficiency_segments_v{VINTAGE}.jsonl").open(encoding="utf-8"))
    }
    tables = ROOT / "output" / "tables"
    result = {
        "data_vintage": VINTAGE,
        "followup_cutoff": "2026-08-28",
        "composition": composition(panel, tables),
        "hand_audit": hand_audit(panel, segments, tables),
        "sensitivity": sensitivity(panel, tables),
    }
    path = ROOT / "data" / "interim" / f"checkpoint7_summary_v{VINTAGE}.json"
    path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
