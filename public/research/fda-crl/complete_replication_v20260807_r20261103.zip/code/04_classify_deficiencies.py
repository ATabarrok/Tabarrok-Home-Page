#!/usr/bin/env python3
"""Classify one segmented CRL per structured-output model call.

The script uses only the Python standard library.  It is resumable: successful records
already present in the JSONL output are not sent again.  `--prepare-only` validates inputs
and writes a reproducible random 50-letter validation sample without making API calls.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import random
import re
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
CATEGORIES = [
    "clinical_efficacy",
    "clinical_safety",
    "trial_design_conduct",
    "cmc",
    "facility_inspection",
    "stability_shelf_life",
    "bioequivalence_bioavailability",
    "nonclinical_toxicology",
    "labeling_proprietary_name",
    "administrative_procedural",
]


OUTPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "categories": {
            "type": "array",
            "items": {"type": "string", "enum": CATEGORIES},
            "minItems": 1,
        },
        "primary_category": {"type": "string", "enum": CATEGORIES},
        "new_clinical_trial_required": {"type": "boolean"},
        "third_party_manufacturer": {"type": "string", "enum": ["yes", "no", "unclear"]},
        "otherwise_approvable": {"type": "string", "enum": ["yes", "no", "unclear"]},
        "classification_status": {
            "type": "string",
            "enum": ["ok", "uncertain_redaction", "uncertain_ocr", "failed"],
        },
        "rationale": {"type": "string"},
    },
    "required": [
        "categories",
        "primary_category",
        "new_clinical_trial_required",
        "third_party_manufacturer",
        "otherwise_approvable",
        "classification_status",
        "rationale",
    ],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default=os.environ.get("CRL_CLASSIFIER_MODEL", "gpt-5.6-terra"))
    parser.add_argument(
        "--reasoning-effort",
        choices=["none", "low", "medium", "high", "xhigh", "max"],
        default=os.environ.get("CRL_CLASSIFIER_REASONING_EFFORT", "low"),
    )
    parser.add_argument("--api-base", default=os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1"))
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--limit", type=int, help="Send only this many uncoded records (testing only)")
    parser.add_argument("--validation-seed", type=int, default=20260807)
    parser.add_argument("--max-retries", type=int, default=6)
    return parser.parse_args()


def find_vintage() -> str:
    paths = sorted((ROOT / "data" / "interim").glob("deficiency_segments_v*.jsonl"))
    if len(paths) != 1:
        raise RuntimeError(f"Expected one deficiency_segments file, found {[p.name for p in paths]}")
    match = re.search(r"_v(\d{8})\.jsonl$", paths[0].name)
    return match.group(1)  # type: ignore[union-attr]


def load_segments(vintage: str) -> list[dict[str, Any]]:
    path = ROOT / "data" / "interim" / f"deficiency_segments_v{vintage}.jsonl"
    with path.open(encoding="utf-8") as handle:
        rows = [json.loads(line) for line in handle]
    if not rows or any(not row.get("deficiency_text") for row in rows):
        raise RuntimeError("Segment file is empty or contains empty deficiency text")
    return rows


def prompt_text() -> str:
    codebook = (ROOT / "notes" / "phase3_codebook.md").read_text(encoding="utf-8")
    return (
        "You are coding the binding grounds in an FDA action letter for a research dataset. "
        "Apply the codebook conservatively. Use only the supplied deficiency segment. "
        "Do not classify generic labeling, proprietary-name, or safety-update boilerplate. "
        "The primary category must also appear in categories. Keep the rationale to at most "
        "60 words and explain the binding remedy.\n\n" + codebook
    )


def prepare_validation_sample(rows: list[dict[str, Any]], vintage: str, seed: int) -> Path:
    rng = random.Random(seed)
    selected = rng.sample(sorted(rows, key=lambda row: row["letter_id"]), 50)
    selected.sort(key=lambda row: (row["letter_date"], row["letter_id"]))
    path = ROOT / "data" / "manual" / f"classification_validation_sample_v{vintage}.csv"
    fields = [
        "letter_id", "application_id", "letter_date", "file_name", "manual_categories",
        "manual_primary_category", "manual_new_clinical_trial_required",
        "manual_third_party_manufacturer", "manual_otherwise_approvable",
        "manual_classification_status", "manual_notes",
    ]
    existing: dict[str, dict[str, str]] = {}
    if path.exists():
        with path.open(encoding="utf-8-sig", newline="") as handle:
            existing = {row["letter_id"]: row for row in csv.DictReader(handle)}
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in selected:
            old = existing.get(row["letter_id"], {})
            writer.writerow({
                "letter_id": row["letter_id"],
                "application_id": row.get("application_id", ""),
                "letter_date": row.get("letter_date", ""),
                "file_name": row.get("file_name", ""),
                **{field: old.get(field, "") for field in fields[4:]},
            })
    return path


def request_payload(
    model: str,
    reasoning_effort: str,
    instructions: str,
    row: dict[str, Any],
) -> dict[str, Any]:
    user_input = (
        f"Letter ID: {row['letter_id']}\n"
        f"Application: {row.get('application_id', '')}\n"
        f"Letter date: {row.get('letter_date', '')}\n\n"
        "DEFICIENCY SEGMENT\n"
        f"{row['deficiency_text']}"
    )
    return {
        "model": model,
        "reasoning": {"effort": reasoning_effort},
        "store": False,
        "instructions": instructions,
        "input": user_input,
        "max_output_tokens": 1200,
        "text": {
            "format": {
                "type": "json_schema",
                "name": "crl_deficiency_classification",
                "description": "Binding deficiency categories and research flags for one FDA action letter.",
                "strict": True,
                "schema": OUTPUT_SCHEMA,
            }
        },
    }


def post_response(api_base: str, api_key: str, payload: dict[str, Any], max_retries: int) -> dict[str, Any]:
    body = json.dumps(payload).encode("utf-8")
    url = api_base.rstrip("/") + "/responses"
    for attempt in range(max_retries + 1):
        request = urllib.request.Request(
            url,
            data=body,
            method="POST",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(request, timeout=180) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            retryable = exc.code in {408, 409, 429, 500, 502, 503, 504}
            if not retryable or attempt == max_retries:
                raise RuntimeError(f"API HTTP {exc.code}: {detail[:1000]}") from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            if attempt == max_retries:
                raise RuntimeError(f"API request failed after retries: {exc}") from exc
        time.sleep(min(60, 2 ** attempt))
    raise AssertionError("unreachable")


def extract_output_text(response: dict[str, Any]) -> str:
    chunks: list[str] = []
    for item in response.get("output", []):
        if item.get("type") != "message":
            continue
        for content in item.get("content", []):
            if content.get("type") == "output_text":
                chunks.append(content.get("text", ""))
    if not chunks:
        raise RuntimeError(f"No output_text in response {response.get('id')}")
    return "".join(chunks)


def validate_classification(result: dict[str, Any]) -> None:
    categories = result.get("categories", [])
    primary = result.get("primary_category")
    if not categories or primary not in categories:
        raise ValueError("primary_category must be present in nonempty categories")
    if any(category not in CATEGORIES for category in categories):
        raise ValueError("unknown category returned")


def load_completed(path: Path) -> set[str]:
    if not path.exists():
        return set()
    completed: set[str] = set()
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            try:
                completed.add(json.loads(line)["letter_id"])
            except (json.JSONDecodeError, KeyError):
                continue
    return completed


def load_api_key() -> str:
    """Load the API key from the process or a git-ignored project .env file."""
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if api_key:
        return api_key
    env_path = ROOT / ".env"
    if not env_path.exists():
        return ""
    for raw_line in env_path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        if name.strip() == "OPENAI_API_KEY":
            api_key = value.strip().strip('"').strip("'")
            return "" if api_key == "replace-with-your-api-key" else api_key
    return ""


def main() -> None:
    args = parse_args()
    vintage = find_vintage()
    rows = load_segments(vintage)
    validation_path = prepare_validation_sample(rows, vintage, args.validation_seed)
    instructions = prompt_text()
    prompt_hash = hashlib.sha256(instructions.encode("utf-8")).hexdigest()
    print(f"Prepared {len(rows)} segmented letters and validation sample {validation_path.name}.")
    if args.prepare_only:
        return

    output_path = ROOT / "data" / "interim" / f"llm_deficiency_classifications_v{vintage}.jsonl"
    completed = load_completed(output_path)
    pending = [row for row in rows if row["letter_id"] not in completed]
    if args.limit is not None:
        pending = pending[: args.limit]
    if not pending:
        print(f"No pending classifications; frozen output is complete at {output_path.name}.")
        return
    api_key = load_api_key()
    if not api_key:
        raise SystemExit(
            "OPENAI_API_KEY is not available in the process or the project .env file. "
            "Run with --prepare-only, supply a complete frozen classification file, or "
            "configure the key to execute the required one-call-per-letter classifier."
        )
    with output_path.open("a", encoding="utf-8", newline="\n") as handle:
        for index, row in enumerate(pending, start=1):
            response = post_response(
                args.api_base,
                api_key,
                request_payload(args.model, args.reasoning_effort, instructions, row),
                args.max_retries,
            )
            result = json.loads(extract_output_text(response))
            validate_classification(result)
            output = {
                "letter_id": row["letter_id"],
                "application_id": row.get("application_id"),
                "letter_date": row.get("letter_date"),
                "segment_sha256": row["segment_sha256"],
                "prompt_sha256": prompt_hash,
                "requested_model": args.model,
                "requested_reasoning_effort": args.reasoning_effort,
                "response_model": response.get("model"),
                "response_id": response.get("id"),
                "usage": response.get("usage"),
                "classified_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                **result,
            }
            handle.write(json.dumps(output, ensure_ascii=False, sort_keys=True) + "\n")
            handle.flush()
            print(f"[{index}/{len(pending)}] {row['letter_id']} -> {result['primary_category']}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Interrupted; completed JSONL records are preserved for resume.", file=sys.stderr)
        raise
