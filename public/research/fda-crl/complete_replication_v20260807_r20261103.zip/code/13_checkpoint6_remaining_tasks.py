#!/usr/bin/env python3
"""Checkpoint 6 amendment and Tasks B-D from the pinned 2026-08-07 corpus.

No FDA acquisition or model call occurs. The frozen classified panel is read but never
rewritten; patched-segmenter results are emitted as sensitivity artifacts.
"""

from __future__ import annotations

import csv
import importlib.util
import json
import math
import re
from collections import Counter
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
VINTAGE = "20260807"
CATEGORIES = [
    "clinical_efficacy", "clinical_safety", "trial_design_conduct", "cmc",
    "facility_inspection", "stability_shelf_life", "bioequivalence_bioavailability",
    "nonclinical_toxicology", "labeling_proprietary_name", "administrative_procedural",
]
LABELS = {
    "clinical_efficacy": "Clinical efficacy",
    "clinical_safety": "Clinical safety",
    "trial_design_conduct": "Trial design/conduct",
    "cmc": "CMC",
    "facility_inspection": "Facility inspection",
    "stability_shelf_life": "Stability/shelf life",
    "bioequivalence_bioavailability": "Bioequivalence/bioavailability",
    "nonclinical_toxicology": "Nonclinical/toxicology",
    "labeling_proprietary_name": "Labeling/proprietary name",
    "administrative_procedural": "Administrative/procedural",
}
FIVE_C_NOTE = (
    "None observed after segmentation; rare post-cutoff cases may be missed."
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(rows[0]) if rows else []
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def load_segmenter():
    path = ROOT / "code" / "03_segment_deficiencies.py"
    spec = importlib.util.spec_from_file_location("patched_segmenter", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def as_int(value: Any) -> int:
    return 0 if value is None or str(value).strip() == "" else int(float(str(value)))


def as_float(value: Any) -> float:
    return 0.0 if value is None or str(value).strip() == "" else float(str(value))


def wilson(successes: int, n: int, z: float = 1.959964) -> tuple[float | None, float | None, float | None]:
    if not n:
        return None, None, None
    p = successes / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return p, max(0.0, center - half), min(1.0, center + half)


def difference_newcombe(
    success_a: int, n_a: int, success_b: int, n_b: int
) -> tuple[float | None, float | None, float | None]:
    """Difference p_a-p_b with a conservative Wilson/Newcombe interval."""
    pa, la, ua = wilson(success_a, n_a)
    pb, lb, ub = wilson(success_b, n_b)
    if None in (pa, la, ua, pb, lb, ub):
        return None, None, None
    return pa - pb, la - ub, ua - lb  # type: ignore[operator]


def quantile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    index = (len(ordered) - 1) * probability
    lower = math.floor(index)
    upper = math.ceil(index)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (index - lower)


def extract_recovered_inspection_text(text: str) -> str:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    matches = list(re.finditer(r"(?i)\binspect(?:ion|ions|ed|or|ors|ing)\b", normalized))
    intervals: list[tuple[int, int]] = []
    for match in matches:
        left = max(0, match.start() - 420)
        right = min(len(normalized), match.end() + 1050)
        window = normalized[left:right].strip()
        if re.search(
            r"(?is)(?:required before.{0,120}approv|cannot be approved|"
            r"(?:unable|could not).{0,120}(?:inspect|conduct|complete)|"
            r"not (?:performed|conducted|completed).{0,220}(?:required|approv))",
            window,
        ):
            intervals.append((left, right))
    merged: list[tuple[int, int]] = []
    for left, right in sorted(intervals):
        if merged and left <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], right))
        else:
            merged.append((left, right))
    windows = [re.sub(r"\n{3,}", "\n\n", normalized[left:right].strip()) for left, right in merged]
    return "\n\n[... RECOVERED INSPECTION CONDITION ...]\n\n".join(windows)


def segmenter_sensitivity() -> dict[str, Any]:
    panel = [
        row for row in read_csv(
            ROOT / "data" / "final" / f"analysis_panel_facility_subclassified_v{VINTAGE}.csv"
        ) if row["is_deficiency_action"] == "1"
    ]
    ids = {row["letter_id"] for row in panel}
    panel_by_id = {row["letter_id"]: row for row in panel}
    parsed = [
        row for row in read_jsonl(
            ROOT / "data" / "interim" / f"crl_letters_parsed_v{VINTAGE}.jsonl"
        ) if row["letter_id"] in ids
    ]
    old_rows = read_jsonl(
        ROOT / "data" / "interim" / f"deficiency_segments_v{VINTAGE}.jsonl"
    )
    old_by_id = {row["letter_id"]: row for row in old_rows}
    segmenter = load_segmenter()
    patched = [segmenter.segment_record(row) for row in parsed]
    patched.sort(key=lambda row: (row["letter_date"] or "", row["letter_id"]))
    write_jsonl(
        ROOT / "data" / "interim" / f"deficiency_segments_patched_v{VINTAGE}.jsonl",
        patched,
    )

    changed: list[dict[str, Any]] = []
    for new in patched:
        old = old_by_id[new["letter_id"]]
        if old["segment_sha256"] == new["segment_sha256"]:
            continue
        old_text = old["deficiency_text"]
        new_text = new["deficiency_text"]
        recovered = new_text[len(old_text):].strip() if new_text.startswith(old_text) else new_text
        panel_row = panel_by_id[new["letter_id"]]
        changed.append({
            "letter_id": new["letter_id"],
            "application_id": panel_row["application_id"],
            "letter_date": panel_row["letter_date"],
            "primary_deficiency_category": panel_row["primary_deficiency_category"],
            "deficiency_categories": panel_row["deficiency_categories"],
            "old_end_method": old["segment_end_method"],
            "patched_end_method": new["segment_end_method"],
            "old_segment_chars": old["segment_char_count"],
            "patched_segment_chars": new["segment_char_count"],
            "recovered_chars": len(recovered),
            "recovered_text_span": recovered,
        })
    write_csv(
        ROOT / "output" / "tables" / f"checkpoint6_segmenter_changed_records_v{VINTAGE}.csv",
        changed,
    )

    correction_ids = {
        "crl_62b2964eeb676abd",
        "crl_b17c79e28f899f4d",
        "crl_91ff2b834a8e838b",
    }
    correction_rows: list[dict[str, Any]] = []
    for row in changed:
        if row["letter_id"] not in correction_ids:
            continue
        correction_rows.append({
            "letter_id": row["letter_id"],
            "application_id": row["application_id"],
            "letter_date": row["letter_date"],
            "recovered_category": "facility_inspection",
            "recovered_subcategory": "5b_not_conducted",
            "triggering_end_pattern": row["old_end_method"],
            "patched_end_pattern": row["patched_end_method"],
            "recovered_text_span": extract_recovered_inspection_text(row["recovered_text_span"]),
            "panel_rebuild_status": "sensitivity_only_frozen_panel_not_rebuilt",
        })
    if {row["letter_id"] for row in correction_rows} != correction_ids:
        raise AssertionError("Patched segmenter did not recover the three frozen corrections")
    write_csv(
        ROOT / "data" / "final" / f"segmentation_corrections_v{VINTAGE}.csv",
        correction_rows,
        [
            "letter_id", "application_id", "letter_date", "recovered_category",
            "recovered_subcategory", "triggering_end_pattern", "patched_end_pattern",
            "recovered_text_span", "panel_rebuild_status",
        ],
    )

    end_methods = Counter(row["segment_end_method"] for row in old_rows)
    changes_by_old_end = Counter(row["old_end_method"] for row in changed)
    vulnerability_rows = []
    for method in [
        "safety_update", "other_requests_and_comments",
        "additional_comments_not_approvability", "within_days", "within_one_year",
        "resubmission_must_address", "decide_to_resubmit", "required_to_resubmit",
    ]:
        vulnerability_rows.append({
            "end_pattern": method,
            "old_use_n": end_methods[method],
            "patched_boundary_change_n": changes_by_old_end[method],
            "material_new_category_recovery_n": sum(
                row["old_end_method"] == method and row["letter_id"] in correction_ids
                for row in changed
            ),
            "assessment": (
                "vulnerable: four inspection conditions followed this heading; three add a missing category"
                if method == "safety_update" else
                "no approvability-relevant post-boundary recovery in the 449-action rerun"
                if method in {"other_requests_and_comments", "additional_comments_not_approvability"} else
                "kept terminal; no vulnerability signal in rerun"
            ),
        })
    write_csv(
        ROOT / "output" / "tables" / f"checkpoint6_segmenter_end_pattern_audit_v{VINTAGE}.csv",
        vulnerability_rows,
    )
    return {
        "classified_actions_n": len(panel),
        "changed_segment_n": len(changed),
        "material_new_category_recovery_n": len(correction_rows),
        "correction_rows": correction_rows,
        "end_pattern_audit": vulnerability_rows,
        "changed_records": changed,
    }


def task_b(panel: list[dict[str, str]], tables: Path) -> dict[str, Any]:
    universes = {
        "full_strict_crl": [row for row in panel if as_int(row["is_strict_crl"]) == 1],
        "2024_forward_strict_crl": [
            row for row in panel if as_int(row["is_2024_forward_strict_crl"]) == 1
        ],
    }
    if len(universes["full_strict_crl"]) != 445 or len(universes["2024_forward_strict_crl"]) != 158:
        raise AssertionError("Strict-CRL universe changed")

    distribution_rows: list[dict[str, Any]] = []
    facility_rows: list[dict[str, Any]] = []
    for universe, rows in universes.items():
        for status in ["all", "ok", "uncertain_redaction", "uncertain_ocr", "failed"]:
            group = rows if status == "all" else [row for row in rows if row["classification_status"] == status]
            for category in CATEGORIES:
                count = sum(row["primary_deficiency_category"] == category for row in group)
                distribution_rows.append({
                    "universe": universe,
                    "classification_status": status,
                    "category": category,
                    "category_label": LABELS[category],
                    "n": count,
                    "denominator": len(group),
                    "share": count / len(group) if group else None,
                })
            facility_n = sum(row["primary_deficiency_category"] == "facility_inspection" for row in group)
            share, low, high = wilson(facility_n, len(group))
            facility_rows.append({
                "universe": universe,
                "classification_status": status,
                "n": len(group),
                "facility_primary_n": facility_n,
                "facility_primary_share": share,
                "wilson_95_low": low,
                "wilson_95_high": high,
            })
    write_csv(tables / f"checkpoint6B_primary_distribution_by_status_v{VINTAGE}.csv", distribution_rows)
    write_csv(tables / f"checkpoint6B_facility_share_by_status_v{VINTAGE}.csv", facility_rows)

    comparison_rows: list[dict[str, Any]] = []
    for universe, rows in universes.items():
        ok = [row for row in rows if row["classification_status"] == "ok"]
        ok_facility = sum(row["primary_deficiency_category"] == "facility_inspection" for row in ok)
        for status in ["uncertain_redaction", "uncertain_ocr"]:
            uncertain = [row for row in rows if row["classification_status"] == status]
            uncertain_facility = sum(
                row["primary_deficiency_category"] == "facility_inspection" for row in uncertain
            )
            diff, low, high = difference_newcombe(
                uncertain_facility, len(uncertain), ok_facility, len(ok)
            )
            comparison_rows.append({
                "universe": universe,
                "comparison": f"{status}_minus_ok",
                "ok_n": len(ok),
                "ok_facility_n": ok_facility,
                "ok_facility_share": ok_facility / len(ok) if ok else None,
                "uncertain_n": len(uncertain),
                "uncertain_facility_n": uncertain_facility,
                "uncertain_facility_share": uncertain_facility / len(uncertain) if uncertain else None,
                "difference_pp": diff,
                "newcombe_95_low": low,
                "newcombe_95_high": high,
            })
    write_csv(tables / f"checkpoint6B_clean_uncertain_facility_comparison_v{VINTAGE}.csv", comparison_rows)

    strict = universes["full_strict_crl"]
    densities = [as_float(row["redaction_markers_per_1000_chars"]) for row in strict]
    positive_densities = [value for value in densities if value > 0]
    q25, q50, q75 = (quantile(positive_densities, p) for p in (0.25, 0.5, 0.75))
    density_rows: list[dict[str, Any]] = []
    zero_group: list[dict[str, str]] = []
    quartile_groups: list[list[dict[str, str]]] = [[], [], [], []]
    for row in strict:
        value = as_float(row["redaction_markers_per_1000_chars"])
        if value == 0:
            zero_group.append(row)
            continue
        index = 0 if value <= q25 else 1 if value <= q50 else 2 if value <= q75 else 3
        quartile_groups[index].append(row)
    shares: list[float] = []
    grouped = [("zero", zero_group)] + [
        (f"Q{index}_positive", group) for index, group in enumerate(quartile_groups, start=1)
    ]
    for group_index, (label, group) in enumerate(grouped):
        facility_n = sum(row["primary_deficiency_category"] == "facility_inspection" for row in group)
        share, low, high = wilson(facility_n, len(group))
        shares.append(share or 0.0)
        density_rows.append({
            "density_group": label,
            "lower_rule": (
                0 if group_index == 0 else "greater_than_zero"
                if group_index == 1 else [q25, q50, q75][group_index - 2]
            ),
            "upper_inclusive": (
                0 if group_index == 0 else [q25, q50, q75, max(positive_densities)][group_index - 1]
            ),
            "n": len(group),
            "facility_primary_n": facility_n,
            "facility_primary_share": share,
            "wilson_95_low": low,
            "wilson_95_high": high,
            "uncertain_redaction_n": sum(
                row["classification_status"] == "uncertain_redaction" for row in group
            ),
            "uncertain_redaction_share": (
                sum(row["classification_status"] == "uncertain_redaction" for row in group) / len(group)
                if group else None
            ),
        })
    monotonic = all(left <= right for left, right in zip(shares, shares[1:]))
    write_csv(tables / f"checkpoint6B_redaction_density_quartiles_v{VINTAGE}.csv", density_rows)
    return {
        "distribution": distribution_rows,
        "facility_by_status": facility_rows,
        "comparisons": comparison_rows,
        "redaction_quartiles": density_rows,
        "facility_share_monotonic_in_redaction_density": monotonic,
    }


def load_cmc_facility_audit() -> dict[str, dict[str, str]]:
    path = (
        ROOT / "data" / "manual" /
        f"checkpoint6_cmc_facility_transition_adjudications_v{VINTAGE}.csv"
    )
    rows = read_csv(path)
    if len(rows) != 9 or len({row["application_id"] for row in rows}) != 9:
        raise RuntimeError("CMC-to-facility adjudication file must contain nine unique applications")
    fields = ["same_site_process_or_attribute", "refers_back_unresolved", "verdict", "notes"]
    return {
        row["application_id"]: {field: row[field] for field in fields}
        for row in rows
    }


# Legacy copy retained only to verify that migration to the provenance file was lossless.
LEGACY_CMC_FACILITY_AUDIT = {
    "BLA761082": {
        "same_site_process_or_attribute": "yes_same_Kashiv_site_and_data_reliability_problem",
        "refers_back_unresolved": "yes",
        "verdict": "same_underlying_problem",
        "notes": "The second letter revisits the same Kashiv site, retrospective audit, source-data traceability, and analytical-similarity reliability defects.",
    },
    "BLA761126": {
        "same_site_process_or_attribute": "yes_same_Tanvex_site_and_analytical_data_integrity",
        "refers_back_unresolved": "yes",
        "verdict": "same_underlying_problem",
        "notes": "Both cycles concern the Tanvex site and omitted/unreliable comparative analytical data; the second explicitly cites the prior CR comment.",
    },
    "BLA761311": {
        "same_site_process_or_attribute": "cannot_tell_first_letter_fully_redacted",
        "refers_back_unresolved": "no_visible_reference",
        "verdict": "cannot_tell",
        "notes": "The first CMC body and site identity are redacted; the second facility finding cannot be linked reliably.",
    },
    "NDA205394": {
        "same_site_process_or_attribute": "yes_at_least_one_same_manufacturing_site",
        "refers_back_unresolved": "no_explicit_reference",
        "verdict": "same_underlying_problem",
        "notes": "The first cycle already carried a binding facility finding; the second repeats facility defects and names drug-substance and drug-product sites.",
    },
    "NDA210274": {
        "same_site_process_or_attribute": "cannot_tell_first_CMC_body_redacted",
        "refers_back_unresolved": "no_visible_reference",
        "verdict": "cannot_tell",
        "notes": "The first product-quality body is redacted, so the later Zhejiang facility finding cannot be matched to a process or attribute.",
    },
    "NDA210735": {
        "same_site_process_or_attribute": "no_visible_particles_and_drug_substance_site_differ",
        "refers_back_unresolved": "no_explicit_reference",
        "verdict": "distinct_problem",
        "notes": "The first letter focuses on drug-product visible particles and inspection methods; the second is a drug-substance facility finding.",
    },
    "NDA212937": {
        "same_site_process_or_attribute": "yes_same_commercial_manufacturing_configuration",
        "refers_back_unresolved": "no_explicit_reference",
        "verdict": "same_underlying_problem",
        "notes": "Both cycles combine the same redacted manufacturing facility with assay/master-batch and commercial-process deficiencies.",
    },
    "NDA214835": {
        "same_site_process_or_attribute": "yes_same_ROVI_site",
        "refers_back_unresolved": "implicit_same_unresolved_site",
        "verdict": "same_underlying_problem",
        "notes": "The second letter names the same Laboratorios Farmacéuticos ROVI site that was deficient in the first cycle.",
    },
    "NDA216962": {
        "same_site_process_or_attribute": "no_first_cycle_device_and_product_quality_second_CGMP_site",
        "refers_back_unresolved": "no_explicit_reference",
        "verdict": "distinct_problem",
        "notes": "The first cycle is dominated by delivery-device/product-quality issues without a facility code; the second adds a CGMP surveillance/PAI condition.",
    },
}


def task_c(panel: list[dict[str, str]], tables: Path) -> dict[str, Any]:
    cmc_facility_audit = load_cmc_facility_audit()
    legacy_core = {
        key: {field: value for field, value in row.items()}
        for key, row in LEGACY_CMC_FACILITY_AUDIT.items()
    }
    file_core = {
        key: {field: row[field] for field in legacy_core[key]}
        for key, row in cmc_facility_audit.items()
    }
    if file_core != legacy_core:
        raise RuntimeError("CMC-to-facility provenance file differs from the frozen legacy judgments")
    pairs = read_csv(tables / f"checkpoint5C_consecutive_crl_pairs_v{VINTAGE}.csv")
    panel_by_id = {row["letter_id"]: row for row in panel}
    selected = [
        row for row in pairs
        if row["first_primary_category"] == "cmc"
        and row["second_primary_category"] == "facility_inspection"
    ]
    if len(selected) != 9 or {row["application_id"] for row in selected} != set(cmc_facility_audit):
        raise AssertionError("CMC-to-facility pair universe changed")
    audit_rows: list[dict[str, Any]] = []
    for pair in selected:
        first = panel_by_id[pair["first_letter_id"]]
        second = panel_by_id[pair["second_letter_id"]]
        hand = cmc_facility_audit[pair["application_id"]]
        audit_rows.append({
            "application_id": pair["application_id"],
            "first_letter_id": pair["first_letter_id"],
            "first_letter_date": pair["first_letter_date"],
            "second_letter_id": pair["second_letter_id"],
            "second_letter_date": pair["second_letter_date"],
            "days_between_crls": pair["days_between_crls"],
            "first_categories": first["deficiency_categories"],
            "second_categories": second["deficiency_categories"],
            "first_facility_secondary": int("facility_inspection" in first["deficiency_categories"].split("|")),
            "second_cmc_secondary": int("cmc" in second["deficiency_categories"].split("|")),
            **hand,
        })
    write_csv(tables / f"checkpoint6C_cmc_to_facility_hand_audit_v{VINTAGE}.csv", audit_rows)

    groups = [
        ("manufacturing_collapsed", {"cmc", "facility_inspection"}),
        ("clinical_efficacy", {"clinical_efficacy"}),
        ("clinical_safety", {"clinical_safety"}),
        ("nonclinical_toxicology", {"nonclinical_toxicology"}),
    ]
    robustness_rows: list[dict[str, Any]] = []
    for label, categories in groups:
        outgoing = [row for row in pairs if row["first_primary_category"] in categories]
        same = sum(row["second_primary_category"] in categories for row in outgoing)
        share, low, high = wilson(same, len(outgoing))
        robustness_rows.append({
            "starting_group": label,
            "pair_n": len(outgoing),
            "same_collapsed_group_n": same,
            "diagonal_share": share,
            "wilson_95_low": low,
            "wilson_95_high": high,
        })
    write_csv(tables / f"checkpoint6C_collapsed_manufacturing_persistence_v{VINTAGE}.csv", robustness_rows)
    return {
        "hand_audit": audit_rows,
        "verdict_counts": dict(Counter(row["verdict"] for row in audit_rows)),
        "collapsed_persistence": robustness_rows,
    }


def has_redaction_evidence(passage: str, rationale: str, status: str) -> bool:
    if status == "uncertain_redaction":
        return True
    combined = f"{passage}\n{rationale}"
    return bool(
        re.search(r"(?i)\(\s*b\s*\)\s*\(\s*[346]\s*\)|\b(?:redacted|withheld)\b|[©®□■]", combined)
        or re.search(r"(?i)(?:facility|site) (?:identity )?(?:is |was )?(?:not identified|not named|not provided)", rationale)
    )


def task_d(panel: list[dict[str, str]], tables: Path) -> dict[str, Any]:
    facility = [row for row in panel if "facility_inspection" in row["deficiency_categories"].split("|")]
    if len(facility) != 257:
        raise AssertionError("Frozen facility-coded universe changed")
    passages = {
        row["letter_id"]: row for row in read_jsonl(
            ROOT / "data" / "interim" / f"facility_passages_v{VINTAGE}.jsonl"
        )
    }
    subclasses = {
        row["letter_id"]: row for row in read_jsonl(
            ROOT / "data" / "interim" / f"facility_subclassifications_validated_v{VINTAGE}.jsonl"
        )
    }
    recoded: list[dict[str, Any]] = []
    for row in facility:
        model = subclasses[row["letter_id"]]
        passage = passages[row["letter_id"]]["facility_passage"]
        old = row["third_party_flag"]
        if old == "yes":
            ownership = "third_party"
        elif old == "no":
            ownership = "sponsor_site"
        else:
            ownership = (
                "unclear_redacted"
                if has_redaction_evidence(passage, model["rationale"], model["classification_status"])
                else "unclear_other"
            )
        recoded.append({
            "letter_id": row["letter_id"],
            "application_id": row["application_id"],
            "letter_date": row["letter_date"],
            "company_name": row["company_name"],
            "facility_primary": int(row["primary_deficiency_category"] == "facility_inspection"),
            "old_third_party_flag": old,
            "facility_ownership_recode": ownership,
            "redaction_driven_uncertainty": int(ownership == "unclear_redacted"),
            "recode_basis": (
                "existing validated explicit third-party identification"
                if ownership == "third_party" else
                "existing validated no-third-party classification"
                if ownership == "sponsor_site" else
                "facility identity obscured by redaction/OCR disclosure marker"
                if ownership == "unclear_redacted" else
                "ownership relationship not stated despite legible passage"
            ),
            "model_rationale": model["rationale"],
            "facility_passage": passage,
        })
    write_csv(tables / f"checkpoint6D_facility_ownership_recoded_v{VINTAGE}.csv", recoded)
    recode_by_id = {row["letter_id"]: row for row in recoded}

    distribution_rows: list[dict[str, Any]] = []
    counts = Counter(row["facility_ownership_recode"] for row in recoded)
    for status in ["sponsor_site", "third_party", "both", "unclear_redacted", "unclear_other"]:
        distribution_rows.append({
            "universe": "all_frozen_facility_coded",
            "ownership_status": status,
            "n": counts[status],
            "denominator": len(recoded),
            "share": counts[status] / len(recoded),
        })
    # Patched-segmenter sensitivity adds one sponsor site and two redacted-unclear sites.
    corrected_counts = counts.copy()
    corrected_counts["sponsor_site"] += 1
    corrected_counts["unclear_redacted"] += 2
    for status in ["sponsor_site", "third_party", "both", "unclear_redacted", "unclear_other"]:
        distribution_rows.append({
            "universe": "patched_segmenter_facility_coded_sensitivity",
            "ownership_status": status,
            "n": corrected_counts[status],
            "denominator": 260,
            "share": corrected_counts[status] / 260,
        })

    pairs = read_csv(tables / f"checkpoint5C_consecutive_crl_pairs_v{VINTAGE}.csv")
    starts = [row for row in pairs if row["first_primary_category"] == "facility_inspection"]
    pair_rows: list[dict[str, Any]] = []
    comparison_groups: dict[str, list[dict[str, Any]]] = {"persistent": [], "nonpersistent": []}
    for pair in starts:
        group = "persistent" if pair["second_primary_category"] == "facility_inspection" else "nonpersistent"
        ownership = recode_by_id[pair["first_letter_id"]]["facility_ownership_recode"]
        pair_row = {
            "application_id": pair["application_id"],
            "first_letter_id": pair["first_letter_id"],
            "second_letter_id": pair["second_letter_id"],
            "persistence_group": group,
            "first_letter_ownership_status": ownership,
            "identified_third_party_involvement": int(ownership in {"third_party", "both"}),
            "ownership_identified": int(ownership in {"sponsor_site", "third_party", "both"}),
        }
        pair_rows.append(pair_row)
        comparison_groups[group].append(pair_row)
    write_csv(tables / f"checkpoint6D_facility_persistence_ownership_pairs_v{VINTAGE}.csv", pair_rows)

    for group, rows in comparison_groups.items():
        group_counts = Counter(row["first_letter_ownership_status"] for row in rows)
        for status in ["sponsor_site", "third_party", "both", "unclear_redacted", "unclear_other"]:
            distribution_rows.append({
                "universe": f"facility_primary_start_{group}",
                "ownership_status": status,
                "n": group_counts[status],
                "denominator": len(rows),
                "share": group_counts[status] / len(rows),
            })
    write_csv(tables / f"checkpoint6D_facility_ownership_distribution_v{VINTAGE}.csv", distribution_rows)

    persistent = comparison_groups["persistent"]
    nonpersistent = comparison_groups["nonpersistent"]
    p_identified = [row for row in persistent if row["ownership_identified"]]
    n_identified = [row for row in nonpersistent if row["ownership_identified"]]
    p_third = sum(row["identified_third_party_involvement"] for row in p_identified)
    n_third = sum(row["identified_third_party_involvement"] for row in n_identified)
    p_share, p_low, p_high = wilson(p_third, len(p_identified))
    n_share, n_low, n_high = wilson(n_third, len(n_identified))
    diff, low, high = difference_newcombe(p_third, len(p_identified), n_third, len(n_identified))
    comparison = [{
        "estimand": "third_party_share_among_identified_first_letter_ownership",
        "persistent_pairs_n": len(persistent),
        "persistent_identified_n": len(p_identified),
        "persistent_third_party_n": p_third,
        "persistent_third_party_share": p_share,
        "persistent_wilson_95_low": p_low,
        "persistent_wilson_95_high": p_high,
        "nonpersistent_pairs_n": len(nonpersistent),
        "nonpersistent_identified_n": len(n_identified),
        "nonpersistent_third_party_n": n_third,
        "nonpersistent_third_party_share": n_share,
        "nonpersistent_wilson_95_low": n_low,
        "nonpersistent_wilson_95_high": n_high,
        "difference_persistent_minus_nonpersistent": diff,
        "newcombe_95_low": low,
        "newcombe_95_high": high,
    }]
    write_csv(tables / f"checkpoint6D_third_party_persistence_comparison_v{VINTAGE}.csv", comparison)

    unclear_n = counts["unclear_redacted"] + counts["unclear_other"]
    redaction_share_unclear = counts["unclear_redacted"] / unclear_n if unclear_n else None
    return {
        "distribution": distribution_rows,
        "comparison": comparison,
        "unclear_n": unclear_n,
        "unclear_redacted_n": counts["unclear_redacted"],
        "unclear_attributable_to_redaction_share": redaction_share_unclear,
        "unclear_redacted_share_of_all_facility_letters": counts["unclear_redacted"] / len(recoded),
    }


FIVE_C_NOTE = "None observed after segmentation; rare post-cutoff cases may be missed."


def patch_checkpoint5_reporting(tables: Path) -> None:
    """Qualify 5c zeroes and suppress the invalid administrative repeat rate."""
    targets = [
        "checkpoint5A_facility_subcategory_distribution_v20260807.csv",
        "checkpoint5A_facility_subcategory_by_era_v20260807.csv",
        "checkpoint5A_facility_primary_subcategory_by_era_v20260807.csv",
        "checkpoint5A_facility_validation_confusion_v20260807.csv",
        "checkpoint5C_facility_state_transition_matrix_v20260807.csv",
    ]
    for name in targets:
        path = tables / name
        rows = read_csv(path)
        for row in rows:
            row["5c_observation_note"] = (
                FIVE_C_NOTE if row.get("era") or "5c_pending_conditional" in row.values() else ""
            )
            if row.get("category") == "5c_pending_conditional":
                row["label"] = "5c Pending/conditional — none observed after segmentation"
        write_csv(path, rows)

    persistence_path = tables / f"checkpoint5C_primary_persistence_by_category_v{VINTAGE}.csv"
    persistence = read_csv(persistence_path)
    for row in persistence:
        if row["first_primary_category"] == "administrative_procedural":
            for field in ["pair_n", "same_category_n", "diagonal_share", "wilson_95_low", "wilson_95_high"]:
                row[field] = ""
            row["small_n_caution"] = "suppressed: validation error and N=4"
    write_csv(persistence_path, persistence)


def items_a_reporting(panel: list[dict[str, str]], tables: Path) -> dict[str, Any]:
    task_a = read_csv(tables / f"checkpoint6A_inspection_letter_accounting_v{VINTAGE}.csv")
    full = task_a
    recent = [r for r in task_a if r["letter_date"] >= "2024-01-01"]
    accounting_rows = []
    criteria = [
        ("raw_literal_inspection_mention", "Raw full text contains the literal token 'inspect*'.", "raw_inspection_mention"),
        ("raw_rule_based_inspection_or_site_signal", "Raw full text meets the broader inspection/site rule, including manufacturing-site language tied to satisfactory resolution.", "raw_rule_based_facility_passage"),
        ("retained_literal_inspection_mention", "Retained deficiency segment contains the literal token 'inspect*'.", "segmented_inspection_mention"),
        ("retained_rule_based_inspection_or_site_signal", "Retained deficiency segment meets the same broader inspection/site rule used on raw text.", "segmented_rule_based_facility_passage"),
    ]
    for universe_name, rows in [("full_strict_crl", full), ("2024_forward_strict_crl", recent)]:
        for line, criterion, field in criteria:
            accounting_rows.append({
                "universe": universe_name,
                "line": line,
                "criterion": criterion,
                "n": sum(int(r[field]) for r in rows),
                "denominator": len(rows),
            })
    write_csv(tables / f"checkpoint6_itemsA_accounting_reconciled_v{VINTAGE}.csv", accounting_rows)

    facility_rows = [r for r in panel if r["facility_state"]]
    recent_facility = [r for r in facility_rows if r["letter_date"] >= "2024-01-01"]
    frozen_5b = sum(r["facility_state"] == "5b_not_conducted" for r in facility_rows)
    recent_5b = sum(r["facility_state"] == "5b_not_conducted" for r in recent_facility)
    sensitivity_rows = [
        {"universe": "all_facility_coded", "figure": "frozen_panel", "5b_n": frozen_5b, "facility_coded_n": len(facility_rows), "5b_share": frozen_5b / len(facility_rows)},
        {"universe": "all_facility_coded", "figure": "patched_segmenter_sensitivity", "5b_n": frozen_5b + 3, "facility_coded_n": len(facility_rows) + 3, "5b_share": (frozen_5b + 3) / (len(facility_rows) + 3)},
        {"universe": "2024_forward_facility_coded", "figure": "frozen_panel", "5b_n": recent_5b, "facility_coded_n": len(recent_facility), "5b_share": recent_5b / len(recent_facility)},
        {"universe": "2024_forward_facility_coded", "figure": "patched_segmenter_sensitivity", "5b_n": recent_5b, "facility_coded_n": len(recent_facility), "5b_share": recent_5b / len(recent_facility)},
    ]
    write_csv(tables / f"checkpoint6_itemsA_facility_5b_sensitivity_v{VINTAGE}.csv", sensitivity_rows)
    return {"accounting": accounting_rows, "5b_sensitivity": sensitivity_rows, "5c_note": FIVE_C_NOTE}


def main() -> None:
    panel = [
        row for row in read_csv(
            ROOT / "data" / "final" / f"analysis_panel_facility_subclassified_v{VINTAGE}.csv"
        ) if row["is_deficiency_action"] == "1"
    ]
    tables = ROOT / "output" / "tables"
    patch_checkpoint5_reporting(tables)
    segmenter = segmenter_sensitivity()
    if segmenter["material_new_category_recovery_n"] > 3:
        raise RuntimeError("STOP: patched segmenter recovered materially more than three new categories")
    result = {
        "data_vintage": VINTAGE,
        "followup_cutoff": "2026-08-28",
        "segmenter": segmenter,
        "items_a": items_a_reporting(panel, tables),
        "task_b": task_b(panel, tables),
        "task_c": task_c(panel, tables),
        "task_d": task_d(panel, tables),
    }
    summary_path = ROOT / "data" / "interim" / f"checkpoint6_summary_v{VINTAGE}.json"
    summary_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
