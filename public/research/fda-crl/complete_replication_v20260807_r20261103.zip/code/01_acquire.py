#!/usr/bin/env python3
"""Download and audit the public FDA Complete Response Letter data.

Raw HTTP response bodies are written without transformation.  If the CRL endpoint ever
requires more than one page, each additional response is stored as its own immutable raw
file with a ``_skipNNNNNN`` suffix.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterable


CRL_URL = "https://api.fda.gov/transparency/crl.json"
DRUGSFDA_URL = (
    "https://download.open.fda.gov/drug/drugsfda/"
    "drug-drugsfda-0001-of-0001.json.zip"
)
DRUGSATFDA_TAB_URL = "https://www.fda.gov/media/89850/download"
DEFAULT_PULL_DATE = date.today().strftime("%Y%m%d")
PAGE_LIMIT = 1000
EXPECTED_LETTER_TYPE = "COMPLETE RESPONSE"
REQUIRED_FIELDS = (
    "letter_date",
    "letter_year",
    "application_number",
    "approval_status",
    "company_name",
    "company_rep",
    "company_address",
    "approver_name",
    "approver_title",
    "approver_center",
    "letter_type",
    "text",
    "file_name",
)
APPLICATION_RE = re.compile(r"\b(?:NDA|BLA|BL|ANDA)\s*\d{6}\b", re.IGNORECASE)
VALID_APPROVAL_STATUSES = {"Approved", "Unapproved"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def download_immutable(url: str, destination: Path, retries: int = 4) -> bool:
    """Download URL to destination atomically; return False if already present."""
    if destination.exists():
        print(f"Using existing raw file: {destination}")
        return False

    destination.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "FDA-CRL-research/1.0 (public-data-replication)"},
    )
    last_error: Exception | None = None
    for attempt in range(1, retries + 1):
        temp_path: Path | None = None
        try:
            with urllib.request.urlopen(request, timeout=120) as response:
                with tempfile.NamedTemporaryFile(
                    mode="wb", delete=False, dir=destination.parent
                ) as temp:
                    temp_path = Path(temp.name)
                    shutil.copyfileobj(response, temp)
            os.replace(temp_path, destination)
            print(f"Downloaded: {destination}")
            return True
        except (OSError, urllib.error.URLError) as error:
            last_error = error
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)
            if attempt < retries:
                time.sleep(2 ** (attempt - 1))
    raise RuntimeError(f"Failed to download {url}: {last_error}")


def crl_page_path(raw_dir: Path, pull_date: str, skip: int) -> Path:
    suffix = "" if skip == 0 else f"_skip{skip:06d}"
    return raw_dir / f"crl_{pull_date}{suffix}.json"


def acquire_crl(raw_dir: Path, pull_date: str) -> list[Path]:
    page_paths: list[Path] = []
    skip = 0
    expected_total: int | None = None
    while expected_total is None or skip < expected_total:
        query = urllib.parse.urlencode({"limit": PAGE_LIMIT, "skip": skip})
        path = crl_page_path(raw_dir, pull_date, skip)
        download_immutable(f"{CRL_URL}?{query}", path)
        with path.open("r", encoding="utf-8") as handle:
            page = json.load(handle)

        results = page.get("results")
        if not isinstance(results, list):
            raise ValueError(f"CRL response has no results list: {path}")
        total = page.get("meta", {}).get("results", {}).get("total")
        if not isinstance(total, int) or total < 0:
            raise ValueError(f"CRL response has malformed meta.results.total: {path}")
        if expected_total is None:
            expected_total = total
        elif total != expected_total:
            raise ValueError(
                f"CRL total changed during pagination: {expected_total} to {total}"
            )
        page_paths.append(path)
        if not results:
            break
        skip += len(results)
    return page_paths


def load_crl_records(paths: Iterable[Path]) -> tuple[list[dict[str, Any]], int]:
    records: list[dict[str, Any]] = []
    reported_total: int | None = None
    for path in paths:
        with path.open("r", encoding="utf-8") as handle:
            page = json.load(handle)
        total = page["meta"]["results"]["total"]
        if reported_total is None:
            reported_total = total
        records.extend(page["results"])
    if reported_total is None:
        raise ValueError("No CRL pages found")
    if len(records) != reported_total:
        raise ValueError(
            f"Loaded {len(records)} CRL records but endpoint reports {reported_total}"
        )
    return records, reported_total


def is_missing(value: Any) -> bool:
    return (
        value is None
        or (isinstance(value, str) and not value.strip())
        or (isinstance(value, list) and not value)
    )


def field_problem(field: str, value: Any) -> str | None:
    if is_missing(value):
        return "missing"
    if field == "letter_year":
        # The documentation describes an integer, but the live endpoint currently emits
        # four-digit strings.  Both are losslessly parseable; the type drift is reported
        # separately in the audit rather than mislabeled as corrupt data.
        if isinstance(value, int):
            return None if 1900 <= value <= 2100 else "malformed"
        if isinstance(value, str):
            return None if re.fullmatch(r"(?:19|20|21)\d{2}", value) else "malformed"
        return "malformed"
    if field == "letter_date":
        if not isinstance(value, str):
            return "malformed"
        try:
            datetime.strptime(value, "%m/%d/%Y")
            return None
        except ValueError:
            return "malformed"
    if field == "application_number":
        if not isinstance(value, list):
            return "malformed"
        return (
            None
            if all(
                isinstance(item, str)
                and item.strip()
                and APPLICATION_RE.search(item.strip())
                for item in value
            )
            else "malformed"
        )
    if field == "approver_center":
        if not isinstance(value, list):
            return "malformed"
        return None if all(isinstance(item, str) and item.strip() for item in value) else "malformed"
    if field == "approval_status":
        return None if value in VALID_APPROVAL_STATUSES else "malformed"
    if field == "file_name":
        return None if isinstance(value, str) and value.lower().endswith(".pdf") else "malformed"
    return None if isinstance(value, str) else "malformed"


def audit_records(
    records: list[dict[str, Any]], reported_total: int, raw_paths: list[Path]
) -> dict[str, Any]:
    field_issues: dict[str, Counter[str]] = {
        field: Counter() for field in REQUIRED_FIELDS
    }
    records_with_any_issue = 0
    parsed_dates: list[datetime] = []
    letter_types: Counter[str] = Counter()
    letter_type_files: dict[str, list[str]] = {}
    letter_year_types: Counter[str] = Counter()
    letter_year_date_mismatches: list[str] = []
    issue_records: dict[str, dict[str, list[str]]] = {
        field: {"missing": [], "malformed": []} for field in REQUIRED_FIELDS
    }

    records_with_missing = 0
    records_with_malformed = 0
    for record in records:
        record_issue_kinds: set[str] = set()
        for field in REQUIRED_FIELDS:
            issue = field_problem(field, record.get(field))
            if issue:
                field_issues[field][issue] += 1
                issue_records[field][issue].append(str(record.get("file_name", "<missing>")))
                record_issue_kinds.add(issue)

        raw_date = record.get("letter_date")
        if isinstance(raw_date, str):
            try:
                parsed_dates.append(datetime.strptime(raw_date, "%m/%d/%Y"))
            except ValueError:
                pass
        raw_type = record.get("letter_type")
        type_label = str(raw_type) if raw_type is not None else "<missing>"
        letter_types[type_label] += 1
        letter_type_files.setdefault(type_label, []).append(
            str(record.get("file_name", "<missing>"))
        )
        raw_year = record.get("letter_year")
        letter_year_types[type(raw_year).__name__] += 1
        if isinstance(raw_date, str) and raw_year is not None:
            try:
                if datetime.strptime(raw_date, "%m/%d/%Y").year != int(raw_year):
                    mismatch_file = str(record.get("file_name", "<missing>"))
                    letter_year_date_mismatches.append(mismatch_file)
                    field_issues["letter_year"]["malformed"] += 1
                    issue_records["letter_year"]["malformed"].append(mismatch_file)
                    record_issue_kinds.add("malformed")
            except (TypeError, ValueError):
                pass

        if record_issue_kinds:
            records_with_any_issue += 1
        if "missing" in record_issue_kinds:
            records_with_missing += 1
        if "malformed" in record_issue_kinds:
            records_with_malformed += 1

    raw_files = [
        {
            "path": path.as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }
        for path in raw_paths
    ]
    nonstandard = {
        value: count
        for value, count in sorted(letter_types.items())
        if value != EXPECTED_LETTER_TYPE
    }
    return {
        "record_count": len(records),
        "endpoint_reported_total": reported_total,
        "date_range": {
            "min": min(parsed_dates).date().isoformat() if parsed_dates else None,
            "max": max(parsed_dates).date().isoformat() if parsed_dates else None,
        },
        "records_with_any_missing_or_malformed_required_field": records_with_any_issue,
        "records_with_any_missing_required_field": records_with_missing,
        "records_with_any_malformed_or_inconsistent_required_field": records_with_malformed,
        "field_issues": {
            field: dict(sorted(counts.items()))
            for field, counts in field_issues.items()
            if counts
        },
        "field_issue_records": {
            field: {issue: names for issue, names in issues.items() if names}
            for field, issues in issue_records.items()
            if any(issues.values())
        },
        "schema_observations": {
            "letter_year_python_type_counts": dict(sorted(letter_year_types.items())),
            "letter_year_date_mismatch_count": len(letter_year_date_mismatches),
            "letter_year_date_mismatch_files": letter_year_date_mismatches,
            "note": (
                "The live endpoint emits non-null letter_year values as four-digit "
                "strings, although the field notes describe integers."
            ),
        },
        "letter_type_counts": dict(sorted(letter_types.items())),
        "non_complete_response_letter_types": nonstandard,
        "non_complete_response_letter_type_files": {
            value: letter_type_files[value]
            for value in nonstandard
        },
        "raw_crl_files": raw_files,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pull-date", default=DEFAULT_PULL_DATE, help="YYYYMMDD")
    parser.add_argument("--raw-dir", type=Path, default=Path("data/raw"))
    parser.add_argument("--interim-dir", type=Path, default=Path("data/interim"))
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        datetime.strptime(args.pull_date, "%Y%m%d")
    except ValueError:
        print("--pull-date must use YYYYMMDD", file=sys.stderr)
        return 2

    crl_paths = acquire_crl(args.raw_dir, args.pull_date)
    drugsfda_path = (
        args.raw_dir / f"drug-drugsfda-0001-of-0001_{args.pull_date}.json.zip"
    )
    download_immutable(DRUGSFDA_URL, drugsfda_path)
    drugsatfda_tab_path = args.raw_dir / f"drugsatfda_{args.pull_date}.zip"
    download_immutable(DRUGSATFDA_TAB_URL, drugsatfda_tab_path)

    records, reported_total = load_crl_records(crl_paths)
    audit = audit_records(records, reported_total, crl_paths)
    audit["pull_date"] = args.pull_date
    audit["crl_data_vintage"] = audit["date_range"]["max"]
    audit["drugsfda_raw_file"] = {
        "path": drugsfda_path.as_posix(),
        "bytes": drugsfda_path.stat().st_size,
        "sha256": sha256(drugsfda_path),
    }
    audit["drugsatfda_tab_raw_file"] = {
        "path": drugsatfda_tab_path.as_posix(),
        "bytes": drugsatfda_tab_path.stat().st_size,
        "sha256": sha256(drugsatfda_tab_path),
    }
    args.interim_dir.mkdir(parents=True, exist_ok=True)
    vintage_tag = str(audit["crl_data_vintage"]).replace("-", "")
    audit_path = args.interim_dir / f"crl_acquisition_audit_v{vintage_tag}.json"
    with audit_path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(audit, handle, indent=2, sort_keys=True)
        handle.write("\n")

    print(json.dumps(audit, indent=2, sort_keys=True))
    print(f"Wrote audit: {audit_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
