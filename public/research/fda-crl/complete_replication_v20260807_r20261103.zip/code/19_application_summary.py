"""Rebuild application-level manuscript tables using the frozen classified panel."""
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/revision/application-analysis'
CATEGORIES = [
    ('facility_inspection', 'Facility inspection'),
    ('cmc', 'Chemistry and manufacturing controls'),
    ('clinical_efficacy', 'Clinical efficacy'),
    ('clinical_safety', 'Clinical safety'),
    ('nonclinical_toxicology', 'Nonclinical toxicology'),
    ('bioequivalence_bioavailability', 'Bioequivalence'),
    ('trial_design_conduct', 'Trial design and conduct'),
    ('administrative_procedural', 'Administrative'),
    ('labeling_proprietary_name', 'Labeling'),
    ('stability_shelf_life', 'Stability'),
]


def write_csv(name, rows, fields=None):
    with (OUT / (name + '.csv')).open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields or list(rows[0]), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def main():
    with (ROOT / 'data/final/analysis_panel_classified_v20260807.csv').open(encoding='utf-8-sig', newline='') as f:
        strict = sorted((r for r in csv.DictReader(f) if r['is_strict_crl'] == '1'),
                        key=lambda r: (r['application_id'], r['letter_date'], r['letter_id']))
    first_by_app = {}
    for row in strict:
        first_by_app.setdefault(row['application_id'], row)
    first = list(first_by_app.values())
    recent = [r for r in first if r['letter_date'] >= '2024-01-01']
    assert (len(strict), len(first), len(recent)) == (445, 333, 128)
    assert {r['letter_id'] for r in first} == {r['letter_id'] for r in strict if r['is_first_strict_crl'] == '1'}
    rows = []
    for category, label in CATEGORIES:
        a = sum(r['primary_deficiency_category'] == category for r in first)
        b = sum(r['primary_deficiency_category'] == category for r in recent)
        rows.append(dict(category=category, label=label, full_n=a, full_denominator=len(first),
                         full_share=a/len(first), recent_n=b, recent_denominator=len(recent), recent_share=b/len(recent)))
    assert sum(r['full_n'] for r in rows) == 333 and sum(r['recent_n'] for r in rows) == 128
    OUT.mkdir(parents=True, exist_ok=True)
    write_csv('application_primary_categories', rows)
    write_csv('first_observed_crl_applications', first,
              ['application_id', 'letter_id', 'letter_date', 'primary_deficiency_category', 'classification_status'])
    lines = [r'\begin{tabular}{@{}lrrrr@{}}', r'\toprule',
             r'Main reason & Full N & Full share & 2024+ N & 2024+ share \\', r'\midrule']
    for r in rows:
        lines.append(f"{r['label']} & {r['full_n']} & {100*r['full_share']:.1f}\\% & {r['recent_n']} & {100*r['recent_share']:.1f}\\% " + r'\\')
    lines += [r'\midrule', r'Total applications & 333 & 100\% & 128 & 100\% \\', r'\bottomrule', r'\end{tabular}']
    (ROOT / 'Paper/revision/latex/generated/application_primary_categories.tex').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    checks = []
    for era, group in [('Full', first), ('2024+', recent)]:
        for condition in ['All', 'Unflagged', 'Exclude OCR', 'Exclude redaction']:
            q = [r for r in group if condition == 'All'
                 or condition == 'Unflagged' and r['classification_status'] == 'ok'
                 or condition == 'Exclude OCR' and r['classification_status'] != 'uncertain_ocr'
                 or condition == 'Exclude redaction' and r['classification_status'] != 'uncertain_redaction']
            n = sum(r['primary_deficiency_category'] == 'facility_inspection' for r in q)
            checks.append(dict(cohort=era, sample=condition, applications=len(q), facility_n=n, facility_share=n/len(q)))
    write_csv('application_facility_sensitivity', checks)
    print('Rebuilt application tables: 333 applications, 128 recent, facility counts 121 and 54.')


if __name__ == '__main__':
    main()
