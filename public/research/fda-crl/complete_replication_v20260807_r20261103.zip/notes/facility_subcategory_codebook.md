# Facility-inspection subdivision codebook

Code the facts stated in the extracted facility passage, not the mere presence of standard
FDA phrasing. A named or redacted site plus a statement that an inspection occurred and
conveyed deficiencies is a letter-specific adverse event even when the surrounding sentence
is templated.

## Mutually exclusive headline state

Apply this hierarchy across every facility event in the passage:

1. `5a_failed`: at least one completed inspection, records review, or inspectional assessment
   produced adverse findings, unresolved observations, CGMP deficiencies, objectionable
   conditions, Form 483 issues, data-integrity findings, or a comparable site-specific
   compliance problem.
2. `5b_not_conducted`: no adverse completed finding is stated, and FDA says a required
   inspection could not be completed. Reasons include a site not being ready or operational,
   access or travel restrictions, scheduling, pandemic constraints, or site unavailability.
3. `5c_pending_conditional`: no adverse finding and no failed attempt are stated; the passage
   only says a satisfactory inspection is required or that a facility must be ready/acceptable
   before approval.
4. `5e_unclear`: redaction, OCR, or insufficient text prevents assignment.

If one letter contains both an adverse completed inspection and a different inspection that
was not conducted, headline state is `5a_failed`, but both event flags must be true and the
stated non-conducted reason must be retained. This hierarchy prevents a capacity event from
being lost while keeping the requested headline distribution mutually exclusive.

## Event flags

- `failed_present`: any 5a event appears.
- `not_conducted_present`: any 5b event appears, including in a 5a headline letter.
- `pending_conditional_present`: a facility is stated as still requiring inspection without
  an adverse result or failed-attempt reason, including in a letter with another 5a event.

## Third-party overlay (5d)

Code `third_party_flag=yes` only when the passage and supplied sponsor names identify a
contract manufacturer, supplier, testing site, or clearly separate manufacturer rather than
the sponsor or its evident corporate affiliate. Code `no` for the sponsor's own site or an
evident corporate affiliate. Code `unclear` when ownership is redacted or ambiguous. This is
an overlay: output `5d_third_party` alongside the headline state when `yes`.

## Template-only test

`template_only=true` only when the facility passage contains no letter-specific finding or
event: no completed inspection or records review with adverse findings, no failed inspection
attempt with a reason, and no other site-specific compliance fact. A generic condition such as
“satisfactory inspection is required before approval,” by itself, is template-only. Names and
dates inserted into otherwise generic conditional language do not make it substantive.

Standard wording that reports a completed adverse inspection is not template-only. The same
sentence may recur across many letters, but the asserted inspection and deficiencies are
letter-specific facts.

## Uncertainty

Use `uncertain_redaction` when withheld site or finding text materially affects the state,
third-party overlay, or template-only judgment. Use `uncertain_ocr` for materially damaged
text. Use `failed` only when no defensible coding is possible. Otherwise use `ok`.
