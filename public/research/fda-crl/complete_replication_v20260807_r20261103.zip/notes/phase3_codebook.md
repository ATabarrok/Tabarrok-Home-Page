# Phase 3 deficiency codebook (version 1)

Code only substantive grounds that FDA states must be resolved for approval. Do not code
routine language that reserves comment on labeling, requests a safety update with any
resubmission, asks that an acceptable proprietary name be resubmitted, or gives procedural
instructions after the deficiency body.

Each letter may receive multiple categories, but exactly one must be marked primary. The
primary category is the ground most directly responsible for the action, judged from FDA's
decision language and required remedy—not simply the first heading or the longest section.

1. `clinical_efficacy`: the submitted evidence does not establish effectiveness or the
   benefit is too small/uncertain.
2. `clinical_safety`: a specific safety signal, inadequate safety database, or unfavorable
   benefit-risk balance is a ground for nonapproval.
3. `trial_design_conduct`: a trial must be added or materially redesigned, or FDA identifies
   data integrity, GCP, statistical-design, endpoint, site, or conduct problems. A failed
   efficacy result that also requires a new adequate trial may receive both 1 and 3, with 1
   normally primary when lack of effectiveness is the stated decision ground.
4. `cmc`: formulation, specifications, analytical methods, process validation, controls,
   sterility assurance, container closure, or other product/manufacturing information in the
   application is inadequate.
5. `facility_inspection`: inspection, Form 483, CGMP compliance, or facility acceptability is
   a binding ground. Code alongside CMC only when a distinct application/product-quality
   deficiency is also stated.
6. `stability_shelf_life`: stability evidence, expiration dating, storage, degradation, or
   shelf life is independently at issue.
7. `bioequivalence_bioavailability`: bridging, comparative exposure, food effect,
   pharmacokinetic equivalence, or bioavailability evidence is inadequate.
8. `nonclinical_toxicology`: animal, in-vitro, carcinogenicity, genotoxicity, or other
   nonclinical safety evidence is inadequate.
9. `labeling_proprietary_name`: labeling, instructions for use, carton/container labels, or a
   name is itself a binding deficiency. Do not code standard "reserve comment" boilerplate.
10. `administrative_procedural`: the submission is incomplete or procedurally defective,
    required datasets/documents are missing, patent certification is defective, or a REMS or
    similarly administrative requirement blocks approval.

Additional fields:

- `new_clinical_trial_required`: yes only when the letter explicitly requires or recommends
  a new/additional clinical trial as necessary to resolve a deficiency.
- `third_party_manufacturer`: yes only when the deficient facility/manufacturer is clearly
  external to the applicant; use unclear when ownership cannot be determined from the text.
- `otherwise_approvable`: yes only when FDA explicitly says the application would otherwise
  be approvable/adequate but for the identified ground. Do not infer it from a single listed
  deficiency.
- `classification_status`: `ok`, `uncertain_redaction`, `uncertain_ocr`, or `failed`. Visible
  redaction alone is not uncertainty when the surviving heading and remedy identify the
  category.

