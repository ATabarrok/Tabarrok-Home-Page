# Human validation instructions: 50-letter classification sample

## Purpose

This review provides an independent human check of the primary and secondary deficiency
categories assigned to a fixed random sample of 50 FDA action letters. The packet shows the
same extracted deficiency segments supplied to the original classifier. It does not show any
model classifications, prior validation labels, approval outcomes, or study results.

Complete all 50 reviews before looking at the existing classifications. Save the completed
review as a blinded version before any comparison is made.

## What to code

A substantive or approval-blocking deficiency is a problem that FDA says prevents approval
in the application's present form and must be fixed. Code only those problems. Do not code
standard language about future labeling review, resubmission procedures, safety updates, or
proprietary-name review unless the letter makes the item an actual reason for nonapproval.

For every letter:

1. Select every category that is a substantive reason for nonapproval.
2. Select exactly one primary category. The primary category is the problem most directly
   responsible for the action, based on FDA's decision language and required remedy. It is
   not automatically the first heading or the longest section.
3. Complete the three additional fields and the text-quality status.
4. Write a short rationale identifying the decisive language or remedy.

Use only the text printed in the packet. Do not research the product, sponsor, later approval,
or other FDA records. Do not fill gaps from memory or inference.

## Categories

1. **Clinical efficacy**: The evidence does not establish effectiveness, or the benefit is too
   small or uncertain.
2. **Clinical safety**: A specific safety signal, an inadequate safety database, or an
   unfavorable benefit-risk balance prevents approval.
3. **Trial design and conduct**: FDA requires a new or materially redesigned trial, or cites
   data-integrity, good-clinical-practice, endpoint, statistical-design, site, or conduct
   problems. If failed efficacy evidence also requires a new adequate trial, code both 1 and
   3; category 1 is normally primary when lack of effectiveness is the stated reason.
4. **Chemistry and manufacturing controls (CMC)**: The application contains inadequate
   formulation, specifications, analytical methods, process validation, manufacturing
   controls, sterility assurance, container-closure information, or other product-quality
   information.
5. **Facility inspection**: An inspection, Form 483, CGMP compliance finding, or facility
   acceptability is an approval-blocking problem. Code both 4 and 5 only when the letter also
   states a distinct product- or process-information deficiency.
6. **Stability and shelf life**: Stability evidence, expiration dating, storage, degradation,
   or shelf life is independently deficient.
7. **Bioequivalence and bioavailability**: Bridging, comparative exposure, food effect,
   pharmacokinetic equivalence, or bioavailability evidence is inadequate.
8. **Nonclinical toxicology**: Animal, in-vitro, carcinogenicity, genotoxicity, or other
   nonclinical safety evidence is inadequate.
9. **Labeling and proprietary name**: Labeling, instructions for use, carton or container
   labels, or a proprietary name is itself a reason for nonapproval. Do not code standard
   language reserving comment on labeling.
10. **Administrative and procedural**: The submission is incomplete or procedurally
    defective; required datasets or documents are missing; patent certification is defective;
    or a REMS or similar administrative requirement blocks approval.

## Additional fields

- **New clinical trial required**: Yes only when the letter explicitly requires or recommends
  a new or additional clinical trial as necessary to resolve a deficiency.
- **Third-party manufacturer**: Yes only when the deficient manufacturer or facility is
  clearly external to the applicant. Use Unclear when ownership cannot be determined from
  the displayed text.
- **Otherwise approvable**: Yes only when FDA explicitly says the application is otherwise
  approvable or adequate except for the identified problem. Do not infer this from a letter
  listing only one deficiency.

## Text-quality status

- **OK**: The displayed text is sufficient to classify.
- **Uncertain - redaction**: Removed confidential text prevents a confident classification.
- **Uncertain - OCR**: Scanning or OCR damage prevents a confident classification.
- **Unable to classify**: The approval-blocking reason cannot be determined from the text.

Visible redaction or OCR errors do not by themselves make a letter uncertain. Use an
uncertain status only when the missing or damaged material affects the classification.

## Worked example (not part of the 50-letter sample)

The complete extracted letter below illustrates the coding rules. Read the letter first,
then compare your judgment with the answer that follows it. This letter is not included in
the validation sample and does not affect the agreement calculation.

**Application:** NDA 210649  
**Letter date:** September 12, 2018  
**Example ID:** `crl_efaca4c48347fb5b`

### Letter

Non-substantive web addresses, repeated reference IDs, and electronic-signature metadata
are shortened here. No deficiency or decision language is omitted.

```text
DEPARTMENT OF HEALTH AND HUMAN SERVICES
Food and Drug Administration
Silver Spring MD 20993

NDA 210649
COMPLETE RESPONSE

AB Pharmaceuticals, LLC
U.S. Agent for Macleods Pharmaceuticals Limited, India
Attention: Andrej Gasperlin, President
17471 Highland Way Drive
Chesterfield, MO 63005

Dear Mr. Gasperlin:

Please refer to your New Drug Application (NDA) dated and received September 14, 2017, and
your amendments, submitted pursuant to section 505(b)(2) of the Federal Food, Drug, and
Cosmetic Act for the following drug product:

Efavirenz, Lamivudine and Tenofovir Disoproxil Fumarate Tablets, 400 mg/300 mg/300 mg

We acknowledge receipt of your amendment dated March 15, 2018, which constituted a
complete response to our March 13, 2018, action letter.

We have completed our review of this application, as amended, and have determined that we
cannot tentatively approve this application in its present form. We have described our reasons
for this action below and, where possible, our recommendations to address these issues.

FACILITY INSPECTIONS

1. During a recent inspection of the Macleods Pharmaceuticals Limited (FEI #3007517881)
manufacturing facility for this NDA, our field investigator observed objectionable
conditions at the facility and conveyed that information to the representative of the
facility at the close of the inspection. Satisfactory resolution of the observations is
required before this NDA may be approved.

PRESCRIBING INFORMATION

2. We reserve comment on the proposed labeling until the application is otherwise
adequate. We encourage you to review the labeling review resources on the PLR
Requirements for Prescribing Information and Pregnancy and Lactation Labeling Final
Rule websites, including regulations and related guidance documents and the Selected
Requirements for Prescribing Information (SRPI) - a checklist of important format
items from labeling regulations and guidances.

If you revise labeling, use the SRPI checklist to ensure that the prescribing information
conforms with format items in regulations and guidances. Your response must include
updated content of labeling in structured product labeling (SPL) format.

OTHER

Within one year after the date of this letter, you are required to resubmit or take other actions
available under 21 CFR 314.110. If you do not take one of these actions, we may consider your
lack of response a request to withdraw the application under 21 CFR 314.65. You may also
request an extension of time in which to resubmit the application.

A resubmission must fully address all the deficiencies listed in this letter and should be clearly
marked with "RESUBMISSION" in large font, bolded type at the beginning of the cover letter
of the submission. The cover letter should clearly state that you consider this resubmission a
complete response to the deficiencies outlined in this letter. A partial response to this letter will
not be processed as a resubmission and will not start a new review cycle.

You may request a meeting or teleconference with us to discuss what steps you need to take
before the application may be approved.

The drug product is not eligible for procurement under the President's Emergency Plan for AIDS
Relief (PEPFAR) program until you have been notified in writing that this application is
approved.

If you have any questions, please call Monica Zeballos, Program Coordinator, at (301) 796-0840.

Sincerely yours,
{See appended electronic signature page}

Jeffrey Murray, M.D., M.P.H.
Deputy Director
Division of Antiviral Products
Office of Antimicrobial Products
Center for Drug Evaluation and Research
```

### Correct coding

- **Primary category:** 5. Facility inspection
- **Secondary categories:** None
- **New clinical trial required:** No
- **Third-party manufacturer:** Yes
- **Otherwise approvable:** No
- **Text-quality status:** OK

### Why this coding is correct

The approval-blocking problem is the completed inspection of the Macleods Pharmaceuticals
facility. FDA observed objectionable conditions and required satisfactory resolution before
approval. Facility inspection is therefore the only substantive category and the primary
category.

Do not add CMC because the letter identifies no separate problem with the product, process,
specifications, analytical methods, or manufacturing information in the application. Do not
add labeling because FDA says only that it reserves comment until the application is otherwise
adequate. That is standard future-review language, not a reason for nonapproval.

The deficient Macleods facility is external to the applicant, AB Pharmaceuticals, so the
third-party-manufacturer field is Yes. No new clinical trial is requested. The application is
not coded as otherwise approvable because FDA does not explicitly say that it is adequate
apart from the inspection problem. The text is clear enough to classify, so its status is OK.

## Review procedure

1. Work through the packet in numbered order.
2. Read the complete displayed deficiency segment before coding.
3. Choose exactly one primary category, then select any other applicable categories in the
   three optional additional-category dropdowns. Leave unused dropdowns blank and do not
   repeat a category.
4. Complete the additional fields and status.
5. Give a one- to three-sentence rationale. Quote only a short decisive phrase if useful.
6. Record answers in the companion Excel workbook using the provided dropdown menus, and
   resolve any row that is not marked `Complete`.
7. Save the completed workbook as a blinded copy before comparison. Do not open
   `classification_validation_sample_v20260807.csv`, the classified panel, or
   prior validation tables until all 50 records are complete.

## Source-text note

The packet uses the frozen deficiency segments originally supplied to the classifier, so the
human and model see the same information. One sampled record was later found to be affected
by the known segment-boundary correction. For the classifier-agreement calculation, code
only the text shown here. The segmenter correction should remain a separate sensitivity
check.
