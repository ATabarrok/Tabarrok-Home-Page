"""Verify the existing human workbook and revised analysis without new coding."""
import csv, json, re, zipfile, hashlib
from pathlib import Path
from collections import Counter
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/revision'
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def readcsv(path):
    with path.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))

def main():
    wb=ROOT/'output/human-validation/human_validation_coding_workbook_50_letters_v20260807_completed.xlsx'
    # Read existing saved values only; no workbook is modified.
    with zipfile.ZipFile(wb) as z:
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            shared=[''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',NS)]
        book=ET.fromstring(z.read('xl/workbook.xml'))
        sheet=next(x for x in book.find('m:sheets',NS) if x.attrib['name']=='Review')
        rid=sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
        rel=next(x for x in ET.fromstring(z.read('xl/_rels/workbook.xml.rels')) if x.attrib['Id']==rid)
        target=rel.attrib['Target']; path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        labels={}
        for row in ET.fromstring(z.read(path)).findall('.//m:sheetData/m:row',NS):
            values={}
            for c in row:
                col=re.match('[A-Z]+',c.attrib['r']).group(); typ=c.attrib.get('t'); v=c.find('m:v',NS)
                val=v.text if v is not None else ''
                if typ=='s': val=shared[int(val)]
                elif typ=='inlineStr': val=''.join(t.text or '' for t in c.findall('.//m:t',NS))
                values[col]=val
            if values.get('A','').isdigit(): labels[int(values['A'])]=values.get('B','')
    sample=readcsv(ROOT/'data/manual/classification_validation_sample_v20260807.csv')
    panel={x['letter_id']:x for x in readcsv(ROOT/'data/final/analysis_panel_classified_v20260807.csv')}
    assert set(labels)==set(range(1,51)) and len(sample)==50
    rows=[dict(packet_number=i,letter_id=r['letter_id'],application_id=r['application_id'],letter_date=r['letter_date'],human_primary_category=labels[i],model_primary_category=panel[r['letter_id']]['primary_deficiency_category']) for i,r in enumerate(sample,1)]
    agreements=sum(r['human_primary_category']==r['model_primary_category'] for r in rows)
    hc=Counter(r['human_primary_category'] for r in rows); mc=Counter(r['model_primary_category'] for r in rows)
    expected=sum(hc[c]*mc[c] for c in hc)/2500; kappa=(agreements/50-expected)/(1-expected)
    assert agreements==41 and round(kappa,3)==.763
    for name,items in [('existing_human_labels',rows),('existing_human_disagreements',[r for r in rows if r['human_primary_category']!=r['model_primary_category']])]:
        with (OUT/'tables'/f'{name}.csv').open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(items)
    report={'existing_human_review':{'n':50,'agreements':agreements,'kappa':kappa,'source_workbook':str(wb.relative_to(ROOT)).replace('\\','/'),'workbook_sha256':hashlib.sha256(wb.read_bytes()).hexdigest(),'mapping':'Packet number equals row order of frozen classification_validation_sample_v20260807.csv, as in build_human_validation_packet.py.','reviewer_identity':'not_recorded_in_workbook','review_dates':'not_recorded_in_workbook'},'checks':[]}
    summary=json.loads((OUT/'analysis_summary.json').read_text())
    matrix=readcsv(OUT/'tables/transition_counts.csv')
    assert sum(sum(int(v) for k,v in r.items() if k!='first_category') for r in matrix)==112
    assert sum(int(r[r['first_category']]) for r in matrix)==66
    assert summary['facility_cmc_cooccurrence']==74
    co=readcsv(OUT/'tables/category_overlap.csv')
    assert sum(int(r['primary_n']) for r in co)==445
    assert all(int(r['primary_n'])+int(r['secondary_n'])==int(r['any_n']) for r in co)
    panelrows=list(panel.values()); strict=[r for r in panelrows if r['is_strict_crl']=='1']
    assert len(strict)==445 and len(set(r['application_id'] for r in strict))==333
    # Verify fixed-horizon flags against dates, rather than only accepting stored events.
    from datetime import date
    first=[r for r in strict if r['is_first_strict_crl']=='1']
    for r in first:
        eligible=(date.fromisoformat(r['followup_cutoff_date'])-date.fromisoformat(r['letter_date'])).days>=730
        assert eligible==(r['second_crl_730d_eligible']=='1')
        if eligible:
            event=bool(r['next_crl_date']) and (date.fromisoformat(r['next_crl_date'])-date.fromisoformat(r['letter_date'])).days<=730
            assert event==(r['second_crl_within_730d_event']=='1')
    manuscript=(ROOT/'Paper/revision/latex/first-look-fda-crls.tex').read_text(encoding='utf-8')
    for token in ['74 of 445','257 of 445','87 of 158','60 of 65','28 of 33','41 of 45','32 of 138','18 of 112','-3.0 to 16.7','41 of 50']:
        assert token in manuscript, 'Missing revised result '+token
    assert 'unusually persistent' not in manuscript
    assert 'result is specific to facility compliance' not in manuscript
    report['checks']=['human workbook agreement and kappa','source/letter/application accounting','transition totals and diagonal','primary-secondary-any reconciliation','calendar eligibility and observed-event flags','revised manuscript numerical anchors']
    report['status']='passed'
    (OUT/'validation_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
