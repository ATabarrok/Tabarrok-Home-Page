/*===========================================================================
  20_effect_sizes.do  -  Chile School Competition Project

  Effect-size conversion table for the Magnitudes section (referee request:
  express results in standard deviations of the test).

  Re-estimates the five headline specifications and expresses each three ways:
    (a) per 10 pp of PS share, in individual test SD (= 50 by construction);
    (b) per 10 pp of PS share, in SD of commune mean scores (computed from
        the panel estimation sample, weighted by tested students);
    (c) implied per-student effect in test SD (= coefficient / 50), i.e. the
        effect on a student who moves from public to PS, under the
        assumption that competition/peer effects on non-movers are small.

  Specifications replicated (sources in parentheses), ordered by grade:
    1. Long difference, grade 4    (16_paper_regressions_ordered.do, hu1)
    2. Panel, grade 4              (16_paper_regressions_ordered.do, m3)
    3. Long difference, grade 10   (16_paper_regressions_ordered.do, hu2)
    4. Panel, grade 10             (16_paper_regressions_ordered.do, m4)
    5. Cohort value added          (07_cohort_value_added.do, V1)
    6. SES-restricted cohort VA    (15_ses_gap_regressions.do, C1)

  Input:  data_intermediate/panel_full.dta
          data_intermediate/panel_ses_gap.dta
          data_intermediate/cohort_va.dta
          data_intermediate/ses_sector_vars.dta
  Output: Paper/Latex/tables/tab_effect_sizes.tex
===========================================================================*/

version 18
clear all
set more off
set linesize 120

do "00_setup.do"

log using "$logs\20_effect_sizes.log", replace text
di "=== 20_effect_sizes.do START ==="

local sd_test = 50   /* individual SIMCE SD, by test construction */


/* ==================================================================
   1. Grade-specific panel FE (commune FE within each grade subsample;
      within a single grade, commune FE and commune x grade FE are the
      identical estimator, so these rows are invariant to that choice)
      +  commune-level SD of mean scores
   ================================================================== */

use "$data_int\panel_full.dta", clear
keep if !missing(score_mean) & !missing(share_subv) & !missing(share_paid)
gen share_priv = share_subv + share_paid
gen str25 gs_year_str = string(agno) + "_" + grade_std + "_" + subject
encode gs_year_str, gen(gs_year_fe)
drop gs_year_str

/* Unweighted SD across commune cells, matching the summary statistics
   table (tab_sumstats), so the reader can verify the denominator there. */
quietly sum score_mean
local sd_comm = r(sd)
di "Commune-level SD of mean scores (panel estimation sample): " %6.2f `sd_comm'

quietly reghdfe score_mean share_priv [aw=wt_tested] if grade_std == "4b", ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
local b1a  = _b[share_priv]
local se1a = _se[share_priv]
di "1a. Panel 4B (commune FE):  b = " %6.2f `b1a' "  (se = " %5.2f `se1a' ")"

quietly reghdfe score_mean share_priv [aw=wt_tested] if grade_std == "2m", ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
local b1b  = _b[share_priv]
local se1b = _se[share_priv]
di "1b. Panel 2M (commune FE):  b = " %6.2f `b1b' "  (se = " %5.2f `se1b' ")"


/* ==================================================================
   2. Grade-specific long differences (matching 16's construction)
   ================================================================== */

foreach g in 4b 2m {
    local y0 = cond("`g'" == "4b", 2005, 2006)
    use "$data_int\panel_full.dta", clear
    keep if grade_std == "`g'"
    keep if !missing(score_mean) & !missing(share_subv) & !missing(share_paid)
    gen share_priv = share_subv + share_paid
    gen double ws = score_mean * wt_tested
    gen double sh = share_priv * wt_tested
    collapse (sum) ws sh wt_tested, by(cod_com agno)
    gen score_mean = ws / wt_tested if wt_tested > 0
    gen share_priv = sh / wt_tested if wt_tested > 0
    drop ws sh
    keep if inlist(agno, `y0', 2024)
    reshape wide score_mean share_priv wt_tested, i(cod_com) j(agno)
    keep if !missing(score_mean`y0') & !missing(score_mean2024) ///
        & !missing(share_priv`y0') & !missing(share_priv2024)
    gen d_score = score_mean2024 - score_mean`y0'
    gen d_share = share_priv2024 - share_priv`y0'
    gen wt_ld = (wt_tested`y0' + wt_tested2024) / 2
    quietly regress d_score d_share score_mean`y0' share_priv`y0' ///
        [aw=wt_ld], vce(cluster cod_com)
    if "`g'" == "4b" {
        local b2  = _b[d_share]
        local se2 = _se[d_share]
        di "2. LD 4B-only:              b = " %6.2f `b2' "  (se = " %5.2f `se2' ")"
    }
    else {
        local b2b  = _b[d_share]
        local se2b = _se[d_share]
        di "2b. LD 2M-only:             b = " %6.2f `b2b' "  (se = " %5.2f `se2b' ")"
    }
}


/* ==================================================================
   3. Cohort value added (V1 in script 07)
   ================================================================== */

use "$data_int\cohort_va.dta", clear

quietly reghdfe score_2m share_priv_2m score_4b [aw=wt_2m], ///
    absorb(subj_cohort_fe) cluster(cod_com)
local b3  = _b[share_priv_2m]
local se3 = _se[share_priv_2m]
di "3. Cohort VA:               b = " %6.2f `b3' "  (se = " %5.2f `se3' ")"


/* ==================================================================
   4. SES-restricted cohort VA (C1 in script 15)
   ================================================================== */

use "$data_int\cohort_va.dta", clear
gen grade_std = "2m"
rename agno_2m agno
merge m:1 cod_com grade_std agno using "$data_int\ses_sector_vars.dta", ///
    keep(master match) nogen keepusing(delta_ses)
rename agno agno_2m
keep if !missing(delta_ses) & !missing(score_2m) & !missing(score_4b) ///
    & !missing(share_priv_2m)

quietly reghdfe score_2m share_priv_2m score_4b [aw=wt_2m], ///
    absorb(subj_cohort_fe) cluster(cod_com)
local b4  = _b[share_priv_2m]
local se4 = _se[share_priv_2m]
di "4. SES cohort VA:           b = " %6.2f `b4' "  (se = " %5.2f `se4' ")"


/* ==================================================================
   Write the conversion table.
   Rows ordered by identification margin: the primary (4B) margin,
   the strict within-commune-grade panel, then the secondary (2M)
   margin estimates.
   ================================================================== */

/* reassign into row order */
local r1 = `b2'
local rse1 = `se2'
local r2 = `b1a'
local rse2 = `se1a'
local r3 = `b2b'
local rse3 = `se2b'
local r4 = `b1b'
local rse4 = `se1b'
local r5 = `b3'
local rse5 = `se3'
local r6 = `b4'
local rse6 = `se4'
forvalues i = 1/6 {
    local b`i' = `r`i''
    local se`i' = `rse`i''
}

local lbl1 "Long difference, grade 4 (H--U's grade)"
local lbl2 "Panel, grade 4"
local lbl3 "Long difference, grade 10"
local lbl4 "Panel, grade 10"
local lbl5 "Cohort value added (grade 10 outcome)"
local lbl6 "SES-restricted cohort value added"

local sdc_disp : display %4.1f `sd_comm'

tempname fh
file open `fh' using "$tab\tab_effect_sizes.tex", write replace
file write `fh' "\begin{table}[htbp]\centering" _n
file write `fh' "\caption{Effect Sizes in Standard Deviation Units\label{tab:effectsizes}}" _n
file write `fh' "\begin{threeparttable}" _n
file write `fh' "\small" _n
file write `fh' "\begin{tabular}{lccccc}" _n
file write `fh' "\toprule" _n
file write `fh' "& & & \multicolumn{2}{c}{Per 10 pp of PS share} & Per student\\" _n
file write `fh' "\cmidrule(lr){4-5}" _n
file write `fh' "Specification & Coef. & SE & Test SD & Commune SD & Test SD\\" _n
file write `fh' "\midrule" _n
forvalues i = 1/6 {
    local bb   : display %6.2f `b`i''
    local ss   : display %5.2f `se`i''
    local t10  : display %6.3f `b`i'' / (10 * `sd_test')
    local c10  : display %6.3f `b`i'' / (10 * `sd_comm')
    local pst  : display %5.2f `b`i'' / `sd_test'
    file write `fh' "`lbl`i'' & `bb' & (`ss') & `t10' & `c10' & `pst'\\" _n
}
file write `fh' "\bottomrule" _n
file write `fh' "\end{tabular}" _n
file write `fh' "\begin{tablenotes}[flushleft]" _n
file write `fh' "\footnotesize" _n
file write `fh' "\item Coefficients are the PS-share estimates from the main text, ordered by grade and design: the grade-specific long differences and panel estimates (Tables~\ref{tab:hubenchmark} and \ref{tab:panelfull}), then the cohort value-added designs (Tables~\ref{tab:cohortva} and \ref{tab:sesgapva}). Within a single grade the commune and commune $\times$ grade fixed-effects estimators coincide, so the panel rows do not depend on that choice. Test SD is the individual SIMCE standard deviation (50 by test construction). Commune SD is the standard deviation of commune mean scores across commune-grade-subject-year cells in the panel estimation sample (`sdc_disp'; see Table~\ref{tab:sumstats}). The per-10-pp columns give the change in the commune population mean for a 10 percentage point increase in PS share. The per-student column divides the coefficient by the individual SD: it is the implied effect on a student who moves from the public to the PS sector, under the assumption that competition and peer effects on non-movers are small." _n
file write `fh' "\end{tablenotes}" _n
file write `fh' "\end{threeparttable}" _n
file write `fh' "\end{table}" _n
file close `fh'
di "Saved: tab_effect_sizes.tex"

di ""
di "=== Conversion summary (test SD = `sd_test', commune SD = " %5.2f `sd_comm' ") ==="
forvalues i = 1/6 {
    di "`lbl`i'':"
    di "   b = " %6.2f `b`i'' ///
       "   per10pp test SD = " %6.3f `b`i''/(10*`sd_test') ///
       "   per10pp commune SD = " %6.3f `b`i''/(10*`sd_comm') ///
       "   per student SD = " %5.2f `b`i''/`sd_test'
}

di "=== 20_effect_sizes.do COMPLETE ==="
log close
exit, clear
