/*===========================================================================
  21_robustness_pp_market.do  -  Chile School Competition Project

  Two robustness batteries for the appendix:

  (A) Sector definition / sample selection (referee R1 comment M1; also the
      "estimand" comment in the 2026-07-11 feedback):
        1. Baseline: PS-only universe, high-PP communes excluded
           (drop_pp=1, drop_high_pp=1) -- should reproduce the paper.
        2. Broad: PP schools included in scores and shares, all communes
           (drop_pp=0, drop_high_pp=0). Treatment = (PS+PP)/total.
        3. PS-only, no commune exclusion (drop_pp=1, drop_high_pp=0).
      Each variant: pooled panel FE and cohort VA (V1).

  (B) Market definition (referee R1 comment M3):
        1. Baseline communes.
        2. Greater Santiago aggregated into a single market
           (Provincia de Santiago 13101-13132 + Puente Alto 13201
            + San Bernardo 13401).
        3. Metropolitan Region excluded entirely.
        4. Provinces as markets nationwide (first 3 digits of commune code).
      Panel FE for all; cohort VA for 2 and 3.

  Inputs:  data_intermediate/simce_rbd_all.dta, enrollment_all.dta,
           high_pp_communes.dta
  Outputs: Paper/Latex/tables/tab_robust_pp.tex
           Paper/Latex/tables/tab_robust_market.tex
===========================================================================*/

version 18
clear all
set more off
set linesize 120

do "00_setup.do"

log using "$logs\21_robustness_pp_market.log", replace text
di "=== 21_robustness_pp_market.do START ==="

/* ==================================================================
   Program: build_panel <outfile> <droppp> <drophighpp>
   Replicates the construction in 13_panel_full.do with toggles as
   arguments. Produces a commune x grade x subject x year panel with
   score_mean, wt_tested, enroll_total, share_priv.
   ================================================================== */

capture program drop build_panel
program define build_panel
    args outfile droppp drophighpp

    /* --- SIMCE side --- */
    use agno grade_std rbd cod_com_rbd sector n_lect n_mate ///
        score_lect score_mate using "$data_int\simce_rbd_all.dta", clear
    keep if inlist(grade_std, "4b", "2m")
    if `droppp' {
        drop if sector == 3
    }
    drop sector
    replace n_lect = 0 if missing(score_lect)
    replace n_mate = 0 if missing(score_mate)
    gen double ws_l = score_lect * n_lect
    gen double ws_m = score_mate * n_mate
    replace ws_l = 0 if missing(ws_l)
    replace ws_m = 0 if missing(ws_m)
    drop if missing(cod_com_rbd)
    rename cod_com_rbd cod_com
    merge m:1 cod_com using "$data_int\high_pp_communes.dta", ///
        keep(master match) nogen keepusing(high_pp_commune)
    replace high_pp_commune = 0 if missing(high_pp_commune)
    if `drophighpp' {
        drop if high_pp_commune == 1
    }
    drop high_pp_commune
    collapse (sum) ws_l ws_m nalu_lect=n_lect nalu_mate=n_mate, ///
        by(cod_com grade_std agno)
    gen score_lect = ws_l / nalu_lect if nalu_lect > 0
    gen score_mate = ws_m / nalu_mate if nalu_mate > 0
    drop ws_l ws_m
    tempfile simce_side
    save `simce_side'

    /* --- Enrollment side --- */
    use agno rbd cod_com_rbd cod_ense mat_gra_4 mat_gra_2 sector ///
        using "$data_int\enrollment_all.dta", clear
    drop if missing(cod_com_rbd)
    rename cod_com_rbd cod_com
    merge m:1 cod_com using "$data_int\high_pp_communes.dta", ///
        keep(master match) nogen keepusing(high_pp_commune)
    replace high_pp_commune = 0 if missing(high_pp_commune)
    if `drophighpp' {
        drop if high_pp_commune == 1
    }
    drop high_pp_commune
    if `droppp' {
        drop if sector == 3
    }
    preserve
        keep if cod_ense == 110
        replace mat_gra_4 = 0 if missing(mat_gra_4)
        gen double es = mat_gra_4 * (sector == 2)
        gen double ep = mat_gra_4 * (sector == 3)
        collapse (sum) enroll_total=mat_gra_4 enroll_subv=es enroll_paid=ep, ///
            by(cod_com agno)
        gen share_subv = enroll_subv / enroll_total if enroll_total > 0
        gen share_paid = enroll_paid / enroll_total if enroll_total > 0
        drop enroll_subv enroll_paid
        gen str4 grade_std = "4b"
        tempfile e4b
        save `e4b'
    restore
    keep if inlist(cod_ense, 310, 410)
    replace mat_gra_2 = 0 if missing(mat_gra_2)
    gen double es = mat_gra_2 * (sector == 2)
    gen double ep = mat_gra_2 * (sector == 3)
    collapse (sum) enroll_total=mat_gra_2 enroll_subv=es enroll_paid=ep, ///
        by(cod_com agno)
    gen share_subv = enroll_subv / enroll_total if enroll_total > 0
    gen share_paid = enroll_paid / enroll_total if enroll_total > 0
    drop enroll_subv enroll_paid
    gen str4 grade_std = "2m"
    append using `e4b'
    tempfile enroll_side
    save `enroll_side'

    /* --- Merge and reshape long on subject --- */
    use `simce_side', clear
    merge 1:1 cod_com grade_std agno using `enroll_side', keep(master match) nogen
    preserve
        gen subject    = "lect"
        gen score_mean = score_lect
        gen wt_tested  = nalu_lect
        keep cod_com grade_std agno subject score_mean wt_tested ///
            enroll_total share_subv share_paid
        tempfile pl
        save `pl'
    restore
    gen subject    = "mate"
    gen score_mean = score_mate
    gen wt_tested  = nalu_mate
    keep cod_com grade_std agno subject score_mean wt_tested ///
        enroll_total share_subv share_paid
    append using `pl'
    keep if !missing(score_mean) & !missing(share_subv) & !missing(share_paid)
    gen share_priv = share_subv + share_paid
    save `"`outfile'"', replace
end


/* ==================================================================
   Program: run_panel <panelfile> <idvar>
   Pooled panel FE regression on a saved panel (or market-aggregated
   panel). Leaves e() results for eststo.
   ================================================================== */

capture program drop run_panel
program define run_panel
    args panelfile idvar fetype
    use `"`panelfile'"', clear
    gen str25 g = string(agno) + "_" + grade_std + "_" + subject
    encode g, gen(gs_year_fe)
    drop g
    if "`fetype'" == "strict" {
        /* unit x grade FE: temporal variation only (logged for prose) */
        egen ug_fe = group(`idvar' grade_std)
        reghdfe score_mean share_priv [aw=wt_tested], ///
            absorb(ug_fe gs_year_fe) cluster(`idvar')
    }
    else {
        /* main specification: unit FE */
        reghdfe score_mean share_priv [aw=wt_tested], ///
            absorb(`idvar' gs_year_fe) cluster(`idvar')
    }
end


/* ==================================================================
   Program: run_va <panelfile> <idvar>
   Builds the 4B(t) -> 2M(t+6) cohort match from a saved panel and
   runs the baseline VA spec (V1 of 07_cohort_value_added.do).
   ================================================================== */

capture program drop run_va
program define run_va
    args panelfile idvar
    use `"`panelfile'"', clear
    keep if grade_std == "2m"
    gen cohort_yr = agno - 6
    rename score_mean score_2m
    rename wt_tested  wt_2m
    rename share_priv share_priv_2m
    keep `idvar' subject cohort_yr score_2m wt_2m share_priv_2m
    tempfile oside
    save `oside'
    use `"`panelfile'"', clear
    keep if grade_std == "4b"
    gen cohort_yr = agno
    rename score_mean score_4b
    keep `idvar' subject cohort_yr score_4b
    merge 1:1 `idvar' subject cohort_yr using `oside', keep(match) nogen
    keep if !missing(score_2m) & !missing(score_4b) & !missing(share_priv_2m)
    gen str25 sc = subject + "_" + string(cohort_yr)
    encode sc, gen(subj_cohort_fe)
    drop sc
    reghdfe score_2m share_priv_2m score_4b [aw=wt_2m], ///
        absorb(subj_cohort_fe) cluster(`idvar')
end


/* ==================================================================
   Program: aggregate_market <infile> <outfile> <marketexpr>
   Collapses a commune panel to market level. Scores weighted by
   tested students; shares weighted by enrollment. The market variable
   must already exist in the file loaded (created by caller).
   ================================================================== */

capture program drop aggregate_market
program define aggregate_market
    args infile outfile
    use `"`infile'"', clear
    /* caller must have saved the file with a variable named market */
    gen double ws = score_mean * wt_tested
    gen double se = share_priv * enroll_total
    collapse (sum) ws wt_tested se enroll_total, ///
        by(market grade_std subject agno)
    gen score_mean = ws / wt_tested   if wt_tested > 0
    gen share_priv = se / enroll_total if enroll_total > 0
    drop ws se
    keep if !missing(score_mean) & !missing(share_priv)
    save `"`outfile'"', replace
end


/* ==================================================================
   PART A: Sector-definition variants
   ================================================================== */

di ""
di "=========================================="
di "  PART A: PP-inclusion robustness"
di "=========================================="

tempfile p_base p_broad p_noexcl

build_panel "`p_base'"   1 1
build_panel "`p_broad'"  0 0
build_panel "`p_noexcl'" 1 0

eststo clear

run_panel "`p_base'" cod_com main
eststo a1
estadd local design "Panel FE"
estadd local universe "PS only"
estadd local excl "Yes"
di "A1 Panel baseline (expect 10.52):  b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N) "  markets = " e(N_clust)

run_panel "`p_broad'" cod_com main
eststo a2
estadd local design "Panel FE"
estadd local universe "PS+PP"
estadd local excl "No"
di "A2 Panel broad PS+PP, all communes: b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N) "  markets = " e(N_clust)

run_panel "`p_noexcl'" cod_com main
eststo a3
estadd local design "Panel FE"
estadd local universe "PS only"
estadd local excl "No"
di "A3 Panel PS-only, all communes:     b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N) "  markets = " e(N_clust)

run_va "`p_base'" cod_com
eststo a4
estadd local design "Cohort VA"
estadd local universe "PS only"
estadd local excl "Yes"
di "A4 VA baseline (expect 14.05):      b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")  N = " e(N) "  markets = " e(N_clust)

run_va "`p_broad'" cod_com
eststo a5
estadd local design "Cohort VA"
estadd local universe "PS+PP"
estadd local excl "No"
di "A5 VA broad PS+PP, all communes:    b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")  N = " e(N) "  markets = " e(N_clust)

run_va "`p_noexcl'" cod_com
eststo a6
estadd local design "Cohort VA"
estadd local universe "PS only"
estadd local excl "No"
di "A6 VA PS-only, all communes:        b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")  N = " e(N) "  markets = " e(N_clust)

esttab a1 a2 a3 a4 a5 a6 using "$tab\tab_robust_pp.tex", replace booktabs ///
    rename(share_priv_2m share_priv) ///
    keep(share_priv) ///
    b(%8.2f) se(%8.2f) star(* 0.10 ** 0.05 *** 0.01) ///
    coeflabels(share_priv "Private share") ///
    mtitles("Baseline" "PS+PP" "No excl." "Baseline" "PS+PP" "No excl.") ///
    mgroups("Panel FE" "Cohort VA", pattern(1 0 0 1 0 0) ///
        prefix(\multicolumn{@span}{c}{) suffix(}) span ///
        erepeat(\cmidrule(lr){@span})) ///
    stats(universe excl N N_clust, ///
        labels("Private universe" "High-PP excluded" "Observations" "Communes") ///
        fmt(0 0 %9.0fc %9.0f)) ///
    title("Robustness: Sector Definition and Sample Selection\label{tab:robustpp}")
di "Saved: tab_robust_pp.tex"


/* ==================================================================
   PART B: Market-definition variants (baseline sector rules)
   ================================================================== */

di ""
di "=========================================="
di "  PART B: Market-definition robustness"
di "=========================================="

/* Greater Santiago aggregated into one market */
tempfile m_gs m_gs_agg
use "`p_base'", clear
gen long market = cod_com
replace market = 13999 if (cod_com >= 13101 & cod_com <= 13132) ///
    | cod_com == 13201 | cod_com == 13401
save `m_gs', replace
aggregate_market "`m_gs'" "`m_gs_agg'"

/* Metropolitan Region dropped */
tempfile m_norm
use "`p_base'", clear
drop if floor(cod_com/1000) == 13
gen long market = cod_com
save `m_norm', replace

run_panel "`p_base'" cod_com main
eststo b1
estadd local design "Panel FE"
estadd local mkt "Communes"
di "B1 Panel baseline:                  b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N) "  markets = " e(N_clust)

run_panel "`m_gs_agg'" market main
eststo b2
estadd local design "Panel FE"
estadd local mkt "GS as one"
di "B2 Panel Gran Santiago aggregated:  b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N) "  markets = " e(N_clust)

run_panel "`m_norm'" market main
eststo b3
estadd local design "Panel FE"
estadd local mkt "Excl. RM"
di "B3 Panel Metropolitan Region excl.: b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N) "  markets = " e(N_clust)

/* Strict (unit x grade FE) variants, not tabulated: logged for the
   appendix prose disclosing that the C x G estimate is concentrated
   in Greater Santiago. */
run_panel "`p_base'" cod_com strict
di "B1s Panel strict baseline:           b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N) "  markets = " e(N_clust)
run_panel "`m_gs_agg'" market strict
di "B2s Panel strict GS aggregated:      b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N) "  markets = " e(N_clust)
run_panel "`m_norm'" market strict
di "B3s Panel strict Metropolitan excl.: b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N) "  markets = " e(N_clust)

run_va "`m_gs_agg'" market
eststo b5
estadd local design "Cohort VA"
estadd local mkt "GS as one"
di "B5 VA Gran Santiago aggregated:     b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")  N = " e(N) "  markets = " e(N_clust)

run_va "`m_norm'" market
eststo b6
estadd local design "Cohort VA"
estadd local mkt "Excl. RM"
di "B6 VA Metropolitan Region excl.:    b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")  N = " e(N) "  markets = " e(N_clust)

esttab b1 b2 b3 b5 b6 using "$tab\tab_robust_market.tex", replace booktabs ///
    rename(share_priv_2m share_priv) ///
    keep(share_priv) ///
    b(%8.2f) se(%8.2f) star(* 0.10 ** 0.05 *** 0.01) ///
    coeflabels(share_priv "Private share") ///
    mtitles("Communes" "GS one mkt." "Excl. RM" "GS one mkt." "Excl. RM") ///
    mgroups("Panel FE" "Cohort VA", pattern(1 0 0 1 0) ///
        prefix(\multicolumn{@span}{c}{) suffix(}) span ///
        erepeat(\cmidrule(lr){@span})) ///
    stats(N N_clust, labels("Observations" "Markets") fmt(%9.0fc %9.0f)) ///
    title("Robustness: Market Definition\label{tab:robustmarket}")
di "Saved: tab_robust_market.tex"

di "=== 21_robustness_pp_market.do COMPLETE ==="
log close
exit, clear
