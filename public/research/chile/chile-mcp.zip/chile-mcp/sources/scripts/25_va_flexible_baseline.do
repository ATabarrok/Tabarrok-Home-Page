/*===========================================================================
  25_va_flexible_baseline.do  -  Chile School Competition Project

  Flexible baseline adjustment in the cohort value-added design.

  The baseline VA specification imposes one linear 4B persistence
  coefficient across subjects and cohorts. Two exercises close the
  remaining functional-form concerns:

  PART A (imposed-persistence profile). Conditional on the sample,
  weights, and fixed effects, the private-share coefficient is an exact
  affine function of the persistence coefficient lambda imposed on the
  4B score:  beta_share(lambda) = a - delta * lambda,  where a is the
  no-baseline-control estimate and delta is the auxiliary within-cell
  coefficient from regressing the 4B baseline on the 2M private share.
  We verify the line empirically and trace beta_share over
  lambda in {0, 0.25, 0.5, lambda_hat, 1, 1.2}.

  PART B (nonlinear f_st). Replace the linear 4B control with functions
  specific to each subject x cohort cell, built from the within-cell
  standardized baseline (so nonlinear terms cannot pick up cross-cohort
  scale differences otherwise absorbed by the FE):
    B1  linear, pooled slope           (paper baseline)
    B2  linear, cell-specific slopes   (subject x cohort persistence)
    B3  cell-specific quadratic
    B4  cell-specific restricted cubic spline (4 knots)
    B5  cell-specific baseline-score quintile indicators

  All specifications: identical estimation sample, weighted by 2M tested
  students, clustered by commune.

  Input:  data_intermediate/cohort_va.dta
  Output: Paper/Latex/tables/tab_va_flexbaseline.tex
===========================================================================*/

version 18
clear all
set more off
set linesize 120

do "00_setup.do"

log using "$logs\25_va_flexible_baseline.log", replace text
di "=== 25_va_flexible_baseline.do START ==="

use "$data_int\cohort_va.dta", clear

/* ==================================================================
   PART A: Affine profile of beta_share in the imposed persistence
   ================================================================== */

quietly reghdfe score_2m share_priv_2m score_4b [aw=wt_2m], ///
    absorb(subj_cohort_fe) cluster(cod_com)
gen byte smp = e(sample)
local b_base   = _b[share_priv_2m]
local se_base  = _se[share_priv_2m]
local lam_hat  = _b[score_4b]
di ""
di "Baseline VA:  beta_share = " %6.2f `b_base' " (se = " %5.2f `se_base' ///
   ")   lambda_hat = " %6.3f `lam_hat' "   N = " e(N)

/* intercept a: no baseline control */
quietly reghdfe score_2m share_priv_2m [aw=wt_2m] if smp, ///
    absorb(subj_cohort_fe) cluster(cod_com)
local a_int = _b[share_priv_2m]
di "No-baseline-control estimate (lambda = 0):  a = " %6.2f `a_int'

/* slope delta: auxiliary regression of the 4B baseline on 2M share */
quietly reghdfe score_4b share_priv_2m [aw=wt_2m] if smp, ///
    absorb(subj_cohort_fe) cluster(cod_com)
local delta = _b[share_priv_2m]
di "Auxiliary 4B-on-share coefficient:  delta = " %6.3f `delta'
di ""
di "Implied affine profile:  beta_share(lambda) = " %6.2f `a_int' ///
   " - " %5.3f `delta' " * lambda"

di ""
di "=== Imposed-persistence profile (direct estimation) ==="
di "  lambda    beta_share      se     affine check"
foreach lam of numlist 0 0.25 0.5 `=round(`lam_hat', .001)' 1 1.2 {
    quietly gen y_l = score_2m - `lam' * score_4b
    quietly reghdfe y_l share_priv_2m [aw=wt_2m] if smp, ///
        absorb(subj_cohort_fe) cluster(cod_com)
    local chk = `a_int' - `delta' * `lam'
    di %8.3f `lam' "  " %10.2f _b[share_priv_2m] "  " ///
       %8.2f _se[share_priv_2m] "  " %10.2f `chk'
    drop y_l
}

/* ==================================================================
   PART B: Nonlinear baseline adjustment, subject x cohort specific
   ================================================================== */

/* within-cell standardized baseline (estimation sample only) */
bysort subj_cohort_fe: egen double m4b = mean(score_4b) if smp
bysort subj_cohort_fe: egen double s4b = sd(score_4b)   if smp
gen double z4b  = (score_4b - m4b) / s4b
gen double z4b2 = z4b^2

/* restricted cubic spline, 4 knots (Harrell percentile placement) */
mkspline z4bs = z4b if smp, cubic nknots(4)

/* within-cell baseline-score quintiles */
gen int q5 = .
quietly levelsof subj_cohort_fe if smp, local(cells)
foreach c of local cells {
    quietly xtile tmpq = z4b if smp & subj_cohort_fe == `c', nq(5)
    quietly replace q5 = tmpq if smp & subj_cohort_fe == `c'
    drop tmpq
}
tab q5 if smp, missing

eststo clear

eststo b1: reghdfe score_2m share_priv_2m score_4b [aw=wt_2m] if smp, ///
    absorb(subj_cohort_fe) cluster(cod_com)
estadd local fform "Linear, pooled"
estadd scalar n_clust = e(N_clust)
di "B1 linear pooled:        b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")"

eststo b2: reghdfe score_2m share_priv_2m [aw=wt_2m] if smp, ///
    absorb(subj_cohort_fe subj_cohort_fe#c.z4b) cluster(cod_com)
estadd local fform "Linear, cell slopes"
estadd scalar n_clust = e(N_clust)
di "B2 cell-specific linear: b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")"

eststo b3: reghdfe score_2m share_priv_2m [aw=wt_2m] if smp, ///
    absorb(subj_cohort_fe subj_cohort_fe#c.z4b subj_cohort_fe#c.z4b2) ///
    cluster(cod_com)
estadd local fform "Quadratic"
estadd scalar n_clust = e(N_clust)
di "B3 cell quadratic:       b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")"

eststo b4: reghdfe score_2m share_priv_2m [aw=wt_2m] if smp, ///
    absorb(subj_cohort_fe subj_cohort_fe#c.z4bs1 subj_cohort_fe#c.z4bs2 ///
        subj_cohort_fe#c.z4bs3) cluster(cod_com)
estadd local fform "Cubic spline"
estadd scalar n_clust = e(N_clust)
di "B4 cell cubic spline:    b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")"

eststo b5: reghdfe score_2m share_priv_2m [aw=wt_2m] if smp, ///
    absorb(subj_cohort_fe#q5) cluster(cod_com)
estadd local fform "Quintile bins"
estadd scalar n_clust = e(N_clust)
di "B5 cell quintile bins:   b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")"

label variable share_priv_2m "PS share, grade 10"

esttab b1 b2 b3 b4 b5 using "$tab\tab_va_flexbaseline.tex", replace booktabs ///
    keep(share_priv_2m) ///
    b(%8.2f) se(%8.2f) star(* 0.10 ** 0.05 *** 0.01) ///
    label ///
    mtitles("Linear" "Cell slopes" "Quadratic" "Spline" "Quintiles") ///
    stats(N n_clust, labels("Observations" "Communes") fmt(%9.0fc %9.0f)) ///
    title("Cohort Value-Added: Flexible Baseline Adjustment\label{tab:vaflexbaseline}") ///
    addnotes("Each column re-estimates the baseline value-added specification with" ///
        "the 4B control entering as the indicated function of the baseline" ///
        "score, standardized within each subject \$\times\$ cohort cell: pooled" ///
        "linear slope (column 1, the paper baseline), cell-specific linear" ///
        "slopes, quadratics, restricted cubic splines (4 knots), and quintile" ///
        "indicators. Weighted by 2M tested students. Standard errors clustered" ///
        "by commune. Common sample.")

/* inject size command inside the float (class resets font in floats) */
tempfile tf
filefilter "$tab\tab_va_flexbaseline.tex" `tf', ///
    from("\BSbegin{table}[htbp]\BScentering") ///
    to("\BSbegin{table}[htbp]\BScentering\BSfootnotesize\BSsetlength{\BStabcolsep}{4pt}") replace
copy `tf' "$tab\tab_va_flexbaseline.tex", replace
di "Saved: tab_va_flexbaseline.tex"

di "=== 25_va_flexible_baseline.do COMPLETE ==="
log close
exit, clear
