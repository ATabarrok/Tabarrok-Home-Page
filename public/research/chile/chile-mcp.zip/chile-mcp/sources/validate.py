"""Compare PyFixest to fresh Stata outputs; read-only inputs, isolated outputs."""
from pathlib import Path
import os, time, json, hashlib, platform, subprocess, sys, importlib.metadata
START=time.perf_counter()
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
CACHE=HERE/'.cache'/'matplotlib'
CACHE.mkdir(parents=True,exist_ok=True)
os.environ.setdefault('MPLCONFIGDIR',str(CACHE))
import numpy as np
import pandas as pd
import pyfixest as pf
from pyfixest.demeaners import MapDemeaner
from scipy.stats import t

TOLERANCE=1e-8
DATAFILE=ROOT/'data_intermediate/cohort_va.dta'
data=pd.read_stata(DATAFILE,convert_categoricals=False)
data['source_row_id']=np.arange(1,len(data)+1)
# Stata stores these as floats but performs estimation in double precision.
for col in ['score_2m','share_priv_2m','score_4b','wt_2m']:
    data[col]=data[col].astype('float64')
for col in ['subj_cohort_fe','commune_fe','cod_com']:
    data[col]=data[col].astype('int64')
reference=pd.read_csv(HERE/'stata_reference.csv',skipinitialspace=True)
samples=pd.read_csv(HERE/'stata_samples.csv')
if 'PYTHON_PARITY_REFERENCE_COMPLETE' not in (HERE/'reference_run.log').read_text():
    raise RuntimeError('Stata reference run did not complete.')
if not np.array_equal(samples.source_row_id.to_numpy(),data.source_row_id.to_numpy()):
    raise RuntimeError('Source row IDs do not align with the Stata reference.')

ssc=dict(k_adj=True,k_fixef='nonnested',G_adj=True,G_df='min')
results=[]
models=[]
for model,fes in [('baseline','subj_cohort_fe'),('commune','commune_fe + subj_cohort_fe')]:
    start=time.perf_counter()
    fit=pf.feols('score_2m ~ share_priv_2m + score_4b | '+fes,data=data,
        weights='wt_2m',weights_type='aweights',vcov={'CRV1':'cod_com'},
        fixef_rm='singleton',ssc=pf.ssc(**ssc),
        demeaner=MapDemeaner(fixef_tol=1e-12,backend='rust'))
    elapsed=time.perf_counter()-start
    # Fitted-object metadata access is covered by the pinned package version.
    actual_ids=np.sort(fit._data['source_row_id'].to_numpy(dtype='int64'))
    expected_ids=samples.loc[samples['sample_'+model].eq(1),'source_row_id'].to_numpy(dtype='int64')
    same_rows=np.array_equal(actual_ids,expected_ids)
    clusters=int(fit._data.cod_com.nunique())
    ref_rows=reference.loc[reference.model.eq(model)]
    n_equal=int(fit._N)==int(ref_rows.iloc[0].N)
    clusters_equal=clusters==int(ref_rows.iloc[0].clusters)
    df_equal=float(fit._df_t)==float(ref_rows.iloc[0].df_r)
    models.append(dict(model=model,formula='score_2m ~ share_priv_2m + score_4b | '+fes,
        N=int(fit._N),clusters=clusters,df_t=float(fit._df_t),same_source_rows=bool(same_rows),
        source_rows_sha256=hashlib.sha256(actual_ids.astype('<i8').tobytes()).hexdigest(),
        excluded_source_rows=np.setdiff1d(data.source_row_id,actual_ids).tolist(),
        estimation_seconds=elapsed,ssc_multiplier=float(np.asarray(fit._ssc).ravel()[0]),
        sample_checks_pass=bool(same_rows and n_equal and clusters_equal and df_equal)))
    for term in ['share_priv_2m','score_4b']:
        ref=ref_rows.loc[ref_rows.term.eq(term)].iloc[0]
        b=float(fit.coef()[term]);se=float(fit.se()[term])
        bdiff=abs(b-float(ref.coefficient));sediff=abs(se-float(ref.se))
        critical=float(t.ppf(.975,fit._df_t))
        results.append(dict(model=model,term=term,stata_coefficient=float(ref.coefficient),
            python_coefficient=b,abs_coefficient_difference=bdiff,stata_se=float(ref.se),
            python_se=se,abs_se_difference=sediff,N=int(fit._N),clusters=clusters,
            df_t=float(fit._df_t),python_pvalue=float(2*t.sf(abs(b/se),fit._df_t)),
            python_ci95_low=b-critical*se,python_ci95_high=b+critical*se,
            passed=bool(bdiff<TOLERANCE and sediff<TOLERANCE and models[-1]['sample_checks_pass'])))

versions={name:importlib.metadata.version(name) for name in ['pyfixest','pandas','numpy','scipy','formulaic']}
paths=[DATAFILE,ROOT/'scripts/16_paper_regressions_ordered.do',HERE/'stata_reference.do',HERE/'stata_reference.csv',HERE/'stata_samples.csv',Path(__file__)]
hashes={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
audit=dict(passed=all(r['passed'] for r in results),absolute_tolerance=TOLERANCE,
    source_data_rows=len(data),source_hashes=hashes,python=sys.version,platform=platform.platform(),
    packages=versions,settings=dict(weights='wt_2m',weights_type='aweights',covariance={'CRV1':'cod_com'},fixef_rm='singleton',ssc=ssc,demeaner=dict(backend='rust',fixef_tol=1e-12)),
    models=models,comparisons=results,script_seconds_including_imports=time.perf_counter()-START)
(HERE/'comparison.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf8')
pd.DataFrame(results).to_csv(HERE/'comparison.csv',index=False)
freeze=subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True)
(HERE/'requirements.lock.txt').write_text(freeze,encoding='utf8')
lines=['# Python–Stata cohort replication test','',f"Result: **{'PASS' if audit['passed'] else 'FAIL'}**.",'',
 'Fresh Stata reghdfe runs were compared with PyFixest on the existing cohort_va.dta. Both the private-share coefficient and the baseline-score coefficient were checked. The dataset, manuscript, website, and canonical outputs were not modified.','',
 '| Model | Stata coefficient | Python coefficient | Stata SE | Python SE | Observations | Clusters |',
 '|---|---:|---:|---:|---:|---:|---:|']
for r in results:
    if r['term']=='share_priv_2m':
        lines.append(f"| {r['model']} | {r['stata_coefficient']:.12f} | {r['python_coefficient']:.12f} | {r['stata_se']:.12f} | {r['python_se']:.12f} | {r['N']:,} | {r['clusters']} |")
lines+=['','## Agreement','',
 f"- Maximum absolute coefficient difference: {max(r['abs_coefficient_difference'] for r in results):.3g}.",
 f"- Maximum absolute standard-error difference: {max(r['abs_se_difference'] for r in results):.3g}.",
 '- Acceptance: absolute differences below 1e-8 and exact estimation-row, observation-count, cluster-count, and inference-degrees-of-freedom agreement.',
 '- Baseline uses all 6,142 observations and 315 clusters. The commune-FE model drops the same singleton source row (227) in both programs, leaving 6,141 observations and 314 clusters.',
 '- Inference uses 314 and 313 degrees of freedom. The JSON also contains Python t-based p-values and confidence intervals; these are derived from matched coefficients, SEs, and degrees of freedom, rather than separately compared to Stata exports.',
 '', '## Settings','',
 '- Analytical weights: wt_2m. One-way CRV1 standard errors clustered by cod_com.',
 '- Baseline fixed effects: subj_cohort_fe. Alternative: commune_fe + subj_cohort_fe.',
 '- Singleton removal enabled. Source float32 values promoted to float64 for estimation without changing their stored values.',
 '- Python fixed-effect demeaning tolerance: 1e-12 (Rust MAP solver), tightened from its default to stabilize full-precision standard-error comparisons.',
 '- Small-sample corrections: k_adj=True, k_fixef="nonnested", G_adj=True, G_df="min". No post-hoc adjustment of coefficients or standard errors.',
 '- Stata reference: reghdfe 6.13.1, ftools 2.50.0, require 1.3.1.',
 '', '## Runtime and scope','']
for m in models:
    lines.append(f"- {m['model']}: {m['estimation_seconds']:.3f} seconds for model fitting locally, after imports and data loading.")
lines += [f"- Script time including imports: {audit['script_seconds_including_imports']:.2f} seconds, excluding process startup and environment setup.",
 '- These are local Windows measurements, not Vercel latency or deployment tests.',
 '- These two specifications do not validate all paper analyses, changed samples, arbitrary models, or raw-data preparation.',
 '', '## Reproduction','',
 'Run stata_reference.do from this directory in Stata, then validate.py with the Python environment specified by requirements.lock.txt. The Python script exits nonzero on a mismatch. Update the absolute data path in the Stata script if relocating the replication package.',
 '', 'Package versions: '+', '.join(f'{k} {v}' for k,v in versions.items())+'.',
 '', 'Files: comparison.json (full precision, metadata, hashes); comparison.csv; stata_reference.csv; stata_samples.csv; reference_run.log; stata_baseline.ster; stata_commune.ster; requirements.lock.txt.']
(HERE/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print('PASS' if audit['passed'] else 'FAIL')
for r in results:
    print(f"{r['model']:8s} {r['term']:15s} b={r['python_coefficient']:.12f} se={r['python_se']:.12f} db={r['abs_coefficient_difference']:.3g} dse={r['abs_se_difference']:.3g}")
print('Exact rows, counts, clusters, degrees of freedom:',all(m['sample_checks_pass'] for m in models))
print('Report:',HERE/'REPORT.md')
raise SystemExit(0 if audit['passed'] else 1)
