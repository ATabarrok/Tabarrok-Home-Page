/*===========================================================================
  16_paper_regressions_ordered.do
  Chile School Competition Project

  Purpose:
    Recreate the manuscript regression tables in the same order they appear
    in Paper/Latex/findings.tex.

  Manuscript tables generated here:
    1. tab_sumstats (body inserted into paper wrapper)
    2. tab_panel_full
    3. tab_ses_gap_pop
    4. tab_cohort_va
    5. tab_ses_gap_va
    6. tab_hu_benchmark
    Appendix: tab_ses_gap_gap, tab_ses_gap_sector, tab_ses_gap_robust


  Strategy:
    - Optionally rebuild the required intermediate datasets by calling the
      existing project scripts.
    - Re-estimate and export the regression tables in manuscript order.

  Upstream scripts used:
    13_panel_full.do          -> panel_full.dta
    07_cohort_value_added.do  -> cohort_va.dta
    15_ses_gap_regressions.do -> panel_ses_gap.dta, ses_sector_vars.dta
===========================================================================*/

version 18
clear all
set more off
set linesize 120

local rebuild_inputs 1

if `rebuild_inputs' {
    do "13_panel_full.do"
    do "14_ses_prep.do"
    do "07_cohort_value_added.do"
    do "15_ses_gap_regressions.do"
}

do "00_setup.do"

capture log close
log using "$logs\16_paper_regressions_ordered.log", replace text
di "=== 16_paper_regressions_ordered.do START ==="
capture estimates drop hu1 hu2 hu3 hu4 hu5


/* ==================================================================
   PAPER TABLE 2: Summary statistics
   ================================================================== */

di ""
di "==============================================="
di "  PAPER TABLE 2: tab_sumstats"
di "==============================================="

use "$data_int\panel_ses_gap.dta", clear
merge 1:1 cod_com grade_std agno subject using "$data_int\panel_full_ses.dta", ///
    keep(master match) nogen keepusing(ses_mean share_lowses ses_n_students)

keep if !missing(score_mean) & !missing(share_priv)

gen pct_private = 100 * share_priv
gen pct_public  = 100 * (1 - share_priv)
gen pct_lowses  = 100 * share_lowses if !missing(share_lowses)

label variable score_mean    "Commune mean SIMCE score"
label variable score_pub     "Public-school mean SIMCE score"
label variable score_priv    "Private-school mean SIMCE score"
label variable delta_y       "Private-public score gap"
label variable pct_public    "Public enrollment share (%)"
label variable pct_private   "Private enrollment share (%)"
label variable ses_mean      "Commune SES mean (1-5)"
label variable pct_lowses    "Low-SES share (%)"
label variable ses_pub       "Public-school SES mean (1-5)"
label variable ses_priv      "Private-school SES mean (1-5)"
label variable delta_ses     "Private-public SES gap"

foreach v in score_pub score_priv delta_y ses_pub ses_priv delta_ses {
    replace `v' = . if both_sectors != 1
}

local sumvars ///
    score_mean score_pub score_priv delta_y ///
    pct_public pct_private ///
    ses_mean pct_lowses ses_pub ses_priv delta_ses

file open sumfh using `"$tab\tab_sumstats.tex"', write replace text
    file write sumfh ///
        `"                    &        Mean&          SD&         Min&         Max&           N\\ "' _n
    file write sumfh "\midrule" _n

    foreach v of local sumvars {
        quietly summarize `v'
        local lbl : variable label `v'
        local lbl = subinstr(`"`lbl'"', "%", "\%", .)
        local mean : display %9.2f r(mean)
        local sd   : display %9.2f r(sd)
        local min  : display %9.2f r(min)
        local max  : display %9.2f r(max)
        local N    : display %9.0f r(N)

        file write sumfh ///
            `"`lbl'&      `mean'&       `sd'&      `min'&      `max'&       `N'\\ "' _n
    }

    file write sumfh "\bottomrule" _n
    file close sumfh
/* ==================================================================
   TABLE ORDER 1-2: Panel FE regressions
   ================================================================== */

use "$data_int\panel_full.dta", clear
keep if !missing(score_mean) & !missing(share_subv) & !missing(share_paid)

gen str15 gy_str = string(agno) + "_" + grade_std
encode gy_str, gen(gy_fe)
drop gy_str

gen str25 gs_year_str = string(agno) + "_" + grade_std + "_" + subject
encode gs_year_str, gen(gs_year_fe)
drop gs_year_str

gen share_priv = share_subv + share_paid
egen cg_fe = group(cod_com grade_std)

/* Grade-specific long differences. H-U's test-score outcomes are
   4th-grade scores (PER 1982, SIMCE 1988/1996), so the 4B-only long
   difference is the closest replication of their design on the mature
   period. The 2M long difference is the secondary-margin analogue.
   Grade-specific construction also avoids mixing grade composition
   across endpoints (the 2005 wave contains no 2M test). */

foreach g in 4b 2m {
    local y0 = cond("`g'" == "4b", 2005, 2006)
    preserve
        keep if grade_std == "`g'"
        gen double hu_wscore = score_mean * wt_tested
        gen double hu_wshare = share_priv * wt_tested
        collapse (sum) hu_wscore hu_wshare wt_tested, by(cod_com agno)
        gen score_mean = hu_wscore / wt_tested if wt_tested > 0
        gen share_priv = hu_wshare / wt_tested if wt_tested > 0
        drop hu_wscore hu_wshare

        keep if inlist(agno, `y0', 2024)
        reshape wide score_mean share_priv wt_tested, i(cod_com) j(agno)
        keep if !missing(score_mean`y0') & !missing(score_mean2024) ///
            & !missing(share_priv`y0') & !missing(share_priv2024)

        gen score_change = score_mean2024 - score_mean`y0'
        gen share_priv = share_priv2024 - share_priv`y0'
        gen wt_ld = (wt_tested`y0' + wt_tested2024) / 2

        quietly regress score_change share_priv score_mean`y0' share_priv`y0' ///
            [aw=wt_ld], vce(cluster cod_com)
    restore
    estadd local spec   "LD `g'"
    estadd local wt     "Yes"
    estadd local basec  "Yes"
    estadd local lag4b  "No"
    estadd scalar n_clust = e(N_clust)
    if "`g'" == "4b" {
        estimates store hu1
        di "LD 4B-only: b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N)
    }
    else {
        estimates store hu2
        di "LD 2M-only: b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N)
    }
}

/* Grade-10 panel: commune FE on the 2M subsample (within a single grade,
   commune FE and commune x grade FE are the identical estimator). */
quietly reghdfe score_mean share_priv [aw=wt_tested] ///
    if grade_std == "2m", absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local spec   "Panel 2M"
estadd local wt     "Yes"
estadd local basec  "No"
estadd local lag4b  "No"
estadd scalar n_clust = e(N_clust)
estimates store hu3
di "Panel 2M-only: b = " %6.2f _b[share_priv] " (se = " %5.2f _se[share_priv] ")  N = " e(N)

di ""
di "==============================================="
di "  PAPER ORDER 1: tab_panel_full"
di "==============================================="

eststo clear

/* (1) commune FE: mixes temporal and persistent cross-grade variation */
eststo m1: reghdfe score_mean share_priv [aw=wt_tested], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local unitfe "Commune"
estadd local sampl  "Pooled"
estadd scalar n_clust = e(N_clust)

/* (2) commune x grade FE: temporal variation only (robustness column,
   shown last in the manuscript table) */
eststo m2: reghdfe score_mean share_priv [aw=wt_tested], ///
    absorb(cg_fe gs_year_fe) cluster(cod_com)
estadd local unitfe "Commune x grade"
estadd local sampl  "Pooled"
estadd scalar n_clust = e(N_clust)

/* (3)-(4) grade subsamples */
eststo m3: reghdfe score_mean share_priv [aw=wt_tested] ///
    if grade_std=="4b", absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local unitfe "Commune"
estadd local sampl  "4B only"
estadd scalar n_clust = e(N_clust)

eststo m4: reghdfe score_mean share_priv [aw=wt_tested] ///
    if grade_std=="2m", absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local unitfe "Commune"
estadd local sampl  "2M only"
estadd scalar n_clust = e(N_clust)

/* (5)-(6) subjects, commune FE (matching the main specification) */
eststo m5: reghdfe score_mean share_priv [aw=wt_tested] ///
    if subject=="lect", absorb(cod_com gy_fe) cluster(cod_com)
estadd local unitfe "Commune"
estadd local sampl  "Reading"
estadd scalar n_clust = e(N_clust)

eststo m6: reghdfe score_mean share_priv [aw=wt_tested] ///
    if subject=="mate", absorb(cod_com gy_fe) cluster(cod_com)
estadd local unitfe "Commune"
estadd local sampl  "Math"
estadd scalar n_clust = e(N_clust)

esttab m1 m3 m4 m5 m6 m2 using "$tab\tab_panel_full.csv", replace ///
    keep(share_priv) ///
    star(* 0.10 ** 0.05 *** 0.01) b(%8.2f) se(%8.2f) compress ///
    title("Panel FE: commune FE baseline, grades, subjects, CxG robustness") ///
    mtitles("Commune FE" "4B" "2M" "Reading" "Math" "CxG FE") ///
    stats(unitfe sampl N n_clust r2, ///
        fmt(0 0 %9.0f %9.0f %6.3f) ///
        labels("Unit FE" "Sample" "N" "Clusters" "R2"))

esttab m1 m3 m4 m5 m6 m2 using "$tab\tab_panel_full.tex", replace booktabs fragment ///
    keep(share_priv) ///
    star(* 0.10 ** 0.05 *** 0.01) b(%8.2f) se(%8.2f) compress ///
    title("Panel Fixed Effects: Baseline, Grades, Subjects, Robustness\label{tab:panelfull}") ///
    mtitles("Commune FE" "4B only" "2M only" "Reading" "Math" "C\$\times\$G FE") ///
    stats(N n_clust r2, ///
        fmt(%9.0f %9.0f %6.3f) ///
        labels("N" "Clusters" "R$^2$")) ///




/* ==================================================================
   TABLE ORDER 3-4: SES-gap panel regressions
   ================================================================== */

use "$data_int\panel_ses_gap.dta", clear
keep if both_sectors == 1

capture drop delta_ses_c
capture drop delta_ses_base_c
capture drop p_x_dses
capture drop p_x_dses_base

quietly sum delta_ses [aw=wt_harm]
local dses_mean = r(mean)
gen delta_ses_c = delta_ses - `dses_mean'

quietly sum delta_ses_base [aw=wt_harm] if !missing(delta_ses_base)
local dses_base_mean = r(mean)
gen delta_ses_base_c = delta_ses_base - `dses_base_mean'

gen p_x_dses = share_priv * delta_ses_c
gen p_x_dses_base = share_priv * delta_ses_base_c

di ""
di "==============================================="
di "  PAPER ORDER 3: tab_ses_gap_gap"
di "==============================================="

eststo clear

eststo g1: reghdfe delta_y delta_ses [aw=wt_harm], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"
estadd local wt     "Harmonic"
eststo g2: reghdfe delta_y delta_ses share_priv [aw=wt_harm], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"
estadd local wt     "Harmonic"
eststo g3: reghdfe delta_y delta_ses share_priv [aw=wt_harm], ///
    absorb(gs_year_fe) cluster(cod_com)
estadd local comfe  "No"
estadd local gsyfe  "Yes"
estadd local wt     "Harmonic"
esttab g1 g2 g3 using "$tab\tab_ses_gap_gap.csv", replace ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(delta_ses share_priv) ///
    order(delta_ses share_priv) ///
    stats(comfe gsyfe wt N r2, ///
        labels("Commune FE" "GradexSubjxYear FE" "Weight" "N" "R2") ///
        fmt(0 0 0 0 3)) ///
    title("Table 1: Private-Public Score Gap on SES Gap") ///
    mtitles("DeltaY on DeltaS" "+ Priv Share" "No Commune FE")

esttab g1 g2 g3 using "$tab\tab_ses_gap_gap.tex", replace ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(delta_ses share_priv) ///
    order(delta_ses share_priv) ///
    stats(comfe gsyfe wt N r2, ///
        labels("Commune FE" "GxSxT FE" "Weight" "N" "R2") ///
        fmt(0 0 0 0 3)) ///
    title("Private-Public Score Gap on SES Gap\label{tab:sesgapgap}") ///
    mtitles("$\Delta Y$ on $\Delta S$" "+ Priv Share" "No Commune FE") ///
    booktabs

di ""
di "==============================================="
di "  PAPER ORDER 4: tab_ses_gap_pop"
di "==============================================="

eststo clear

eststo p1: reghdfe score_mean share_priv [aw=wt_tested], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"
estadd scalar n_clust = e(N_clust)

eststo p2: reghdfe score_mean share_priv delta_ses [aw=wt_tested], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"
estadd scalar n_clust = e(N_clust)

eststo p3: reghdfe score_mean share_priv delta_ses_c p_x_dses [aw=wt_tested], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"
estadd scalar n_clust = e(N_clust)

eststo p4: reghdfe score_mean share_priv delta_ses_base_c p_x_dses_base ///
    [aw=wt_tested] if !missing(delta_ses_base_c), ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"
estadd scalar n_clust = e(N_clust)
label variable share_priv        "Private Share"
label variable delta_ses         "SES Gap"
label variable delta_ses_c       "SES Gap (Centered)"
label variable p_x_dses          "Share \$\times\$ SES Gap"
esttab p1 p2 p3 using "$tab\tab_ses_gap_pop.csv", replace ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(share_priv delta_ses delta_ses_c p_x_dses) ///
    order(share_priv delta_ses delta_ses_c p_x_dses) ///
    label ///
    stats(comfe gsyfe N n_clust r2, ///
        labels("Commune FE" "GradexSubjxYear FE" "N" "Clusters" "R2") ///
        fmt(0 0 0 0 3)) ///
    title("Table 2: Population Scores, Private Share, and SES Gap Interaction") ///
    mtitles("Baseline" "+ DeltaS" "Interaction")

esttab p1 p2 p3 using "$tab\tab_ses_gap_pop.tex", replace fragment ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(share_priv delta_ses delta_ses_c p_x_dses) ///
    order(share_priv delta_ses delta_ses_c p_x_dses) ///
    label ///
    stats(comfe gsyfe N n_clust r2, ///
        labels("Commune FE" "GxSxT FE" "N" "Clusters" "R2") ///
        fmt(0 0 0 0 3)) ///
    title("Population Scores, Private Share, and SES Gap Interaction\label{tab:sesgappop}") ///
    mtitles("Baseline" "+ $\Delta S$" "Interaction") ///
    booktabs


/* ==================================================================
   TABLE ORDER 5: Cohort value-added
   ================================================================== */

use "$data_int\cohort_va.dta", clear

di ""
di "==============================================="
di "  PAPER ORDER 5: tab_cohort_va"
di "==============================================="

eststo clear

gen share_priv = share_priv_2m

quietly reghdfe score_2m share_priv score_4b [aw=wt_2m], ///
    absorb(subj_cohort_fe) cluster(cod_com)
estadd local spec   "Subj x Coh"
estadd local wt     "Yes"
estadd local basec  "Yes"
estadd local lag4b  "Yes"
estadd scalar n_clust = e(N_clust)
estimates store hu4

esttab hu1 hu2 hu3 hu4 using "$tab\tab_hu_benchmark.csv", replace ///
    keep(share_priv) ///
    star(* 0.10 ** 0.05 *** 0.01) b(%8.2f) se(%8.2f) compress ///
    title("Revisiting Hsieh-Urquiola on the Later SIMCE Panel") ///
    mtitles("LD 4B (H-U margin)" "LD 2M" "Panel 2M" "Cohort VA") ///
    stats(basec lag4b N n_clust r2, ///
        fmt(0 0 %9.0f %9.0f %6.3f) ///
        labels("Baseline controls" "Lag 4B score" "N" "Clusters" "R2"))

esttab hu1 hu2 hu3 hu4 using "$tab\tab_hu_benchmark.tex", replace booktabs fragment ///
    keep(share_priv) ///
    star(* 0.10 ** 0.05 *** 0.01) b(%8.2f) se(%8.2f) compress ///
    title("Revisiting Hsieh-Urquiola on the Later SIMCE Panel\label{tab:hubenchmark}") ///
    mtitles("LD 4B (H--U margin)" "LD 2M" "Panel 2M" "Cohort VA") ///
    stats(basec lag4b N n_clust r2, ///
        fmt(0 0 %9.0f %9.0f %6.3f) ///
        labels("Baseline controls" "Lag 4B score" "N" "Clusters" "R2")) ///


eststo v1: reghdfe score_2m share_priv_2m score_4b [aw=wt_2m], ///
    absorb(subj_cohort_fe) cluster(cod_com)
estadd local comfe  "No"
estadd local fe2    "Subject x cohort"
estadd scalar n_clust = e(N_clust)

eststo v2: reghdfe score_2m share_priv_2m share_priv_4b score_4b [aw=wt_2m], ///
    absorb(subj_cohort_fe) cluster(cod_com)
estadd local comfe  "No"
estadd local fe2    "Subject x cohort"
estadd scalar n_clust = e(N_clust)

/* Gain-score (unit persistence) variant: dropped from the table
   2026-07-13 (author decision) but kept here because the main text and
   appendix cite the estimate (~13.4) as the lambda = 1 special case of
   the baseline-adjustment sensitivity analysis. */
eststo v3: reghdfe score_gain share_priv_2m [aw=wt_2m], ///
    absorb(subj_cohort_fe) cluster(cod_com)
estadd local comfe  "No"
estadd local fe2    "Subject x cohort"
estadd scalar n_clust = e(N_clust)
di "V3 gain-score (not tabulated): b = " %6.2f _b[share_priv_2m] " (se = " %5.2f _se[share_priv_2m] ")"

eststo v4: reghdfe score_2m share_priv_2m score_4b [aw=wt_2m], ///
    absorb(commune_fe subj_cohort_fe) cluster(cod_com)

eststo v5: reghdfe score_2m share_priv_2m [aw=wt_2m], ///
    absorb(commune_fe subj_cohort_fe) cluster(cod_com)

eststo v6: reghdfe score_2m share_priv_2m score_4b [aw=wt_2m] ///
    if subject == "lect", ///
    absorb(cohort_fe) cluster(cod_com)
estadd local comfe  "No"
estadd local fe2    "Cohort"
estadd scalar n_clust = e(N_clust)

eststo v7: reghdfe score_2m share_priv_2m score_4b [aw=wt_2m] ///
    if subject == "mate", ///
    absorb(cohort_fe) cluster(cod_com)
estadd local comfe  "No"
estadd local fe2    "Cohort"
estadd scalar n_clust = e(N_clust)

label variable share_priv_2m  "Private Share (2M)"
label variable score_4b       "Baseline Score (4B)"
label variable share_priv_4b  "Private Share (4B)"
esttab v1 v2 v6 v7 using "$tab\tab_cohort_va.csv", replace ///
    keep(share_priv_2m score_4b share_priv_4b) ///
    order(share_priv_2m score_4b share_priv_4b) ///
    se star(* 0.10 ** 0.05 *** 0.01) ///
    stats(comfe fe2 N n_clust r2, labels("Commune FE" "Other FE" "Observations" "Clusters" "R2") fmt(0 0 %8.0fc %8.0fc %8.3f)) ///
    mtitles("VA" "VA+4Bshr" "Reading" "Math") ///
    label b(%8.3f) se(%8.3f) ///
    title("Cohort Value-Added: 2M Score on Private Share, Controlling for 4B Baseline")

esttab v1 v2 v6 v7 using "$tab\tab_cohort_va.tex", replace fragment ///
    keep(share_priv_2m score_4b share_priv_4b) ///
    order(share_priv_2m score_4b share_priv_4b) ///
    se star(* 0.10 ** 0.05 *** 0.01) ///
    stats(comfe fe2 N n_clust r2, labels("Commune FE" "Other FE" "Observations" "Clusters" "R2") fmt(0 0 %8.0fc %8.0fc %8.3f)) ///
    mtitles("VA" "VA+4Bshr" "Reading" "Math") ///



/* ==================================================================
   TABLE ORDER 6: Cohort value-added with SES interactions
   ================================================================== */

use "$data_int\cohort_va.dta", clear

gen grade_std = "2m"
rename agno_2m agno
merge m:1 cod_com grade_std agno using "$data_int\ses_sector_vars.dta", ///
    keep(master match) nogen keepusing(delta_ses ses_pub ses_priv ///
    delta_sh_ses1-delta_sh_ses5)
rename agno agno_2m
rename (delta_ses ses_pub ses_priv) (delta_ses_2m ses_pub_2m ses_priv_2m)

drop grade_std
gen grade_std = "4b"
rename agno_4b agno
merge m:1 cod_com grade_std agno using "$data_int\ses_sector_vars.dta", ///
    keep(master match) nogen keepusing(delta_ses ses_pub ses_priv)
rename agno agno_4b
rename (delta_ses ses_pub ses_priv) (delta_ses_4b ses_pub_4b ses_priv_4b)
drop grade_std

keep if !missing(delta_ses_2m) & !missing(score_2m) & !missing(score_4b) ///
    & !missing(share_priv_2m)

quietly sum delta_ses_2m [aw=wt_2m]
local dses_2m_mean = r(mean)
gen delta_ses_2m_c = delta_ses_2m - `dses_2m_mean'

quietly sum delta_ses_4b [aw=wt_2m] if !missing(delta_ses_4b)
local dses_4b_mean = r(mean)
gen delta_ses_4b_c = delta_ses_4b - `dses_4b_mean'

gen p_x_dses_2m = share_priv_2m * delta_ses_2m_c
gen p_x_dses_4b = share_priv_2m * delta_ses_4b_c

di ""
di "==============================================="
di "  PAPER ORDER 6: tab_ses_gap_va"
di "==============================================="

eststo clear

eststo c1: reghdfe score_2m share_priv_2m score_4b [aw=wt_2m], ///
    absorb(subj_cohort_fe) cluster(cod_com)
estadd local cohfe  "Yes"
estadd scalar n_clust = e(N_clust)

eststo c2: reghdfe score_2m share_priv_2m score_4b delta_ses_2m_c p_x_dses_2m ///
    [aw=wt_2m], absorb(subj_cohort_fe) cluster(cod_com)
estadd local cohfe  "Yes"
estadd scalar n_clust = e(N_clust)

label variable share_priv_2m  "Private Share (10th Grade)"
label variable score_4b       "Baseline Score (4th Grade)"
label variable delta_ses_2m_c "SES Gap (Centered)"
label variable p_x_dses_2m    "Private Share x SES Gap"

esttab c1 c2 using "$tab\tab_ses_gap_va.csv", replace ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(share_priv_2m score_4b delta_ses_2m_c p_x_dses_2m) ///
    order(share_priv_2m score_4b delta_ses_2m_c p_x_dses_2m) ///
    label ///
    stats(cohfe N n_clust r2, ///
        labels("Subject x Cohort FE" "N" "Clusters" "R2") ///
        fmt(0 0 0 3)) ///
    title("Table 3: Cohort Value-Added with SES Gap Interaction") ///
    mtitles("Baseline VA" "SES Interaction")

esttab c1 c2 using "$tab\tab_ses_gap_va.tex", replace fragment ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(share_priv_2m score_4b delta_ses_2m_c p_x_dses_2m) ///
    order(share_priv_2m score_4b delta_ses_2m_c p_x_dses_2m) ///
    label ///
    stats(cohfe N n_clust r2, ///
        labels("Subject x Cohort FE" "N" "Clusters" "R2") ///
        fmt(0 0 0 3)) ///
    title("Cohort Value-Added with SES Gap Interaction\label{tab:sesgapva}") ///
    mtitles("Baseline VA" "SES Interaction") ///
    booktabs


/* ==================================================================
   TABLE ORDER 7-8: Sector outcomes and robustness
   ================================================================== */

use "$data_int\panel_ses_gap.dta", clear
keep if both_sectors == 1

quietly sum delta_ses [aw=wt_tested]
local dses_mean_s = r(mean)
gen delta_ses_c = delta_ses - `dses_mean_s'

capture drop p_x_dses
gen p_x_dses = share_priv * delta_ses_c

capture drop gs_year_fe
gen str25 gs_year_str = string(agno) + "_" + grade_std + "_" + subject
encode gs_year_str, gen(gs_year_fe)
drop gs_year_str

di ""
di "==============================================="
di "  PAPER ORDER 7: tab_ses_gap_sector"
di "==============================================="

eststo clear

eststo s1: reghdfe score_pub share_priv delta_ses_c [aw=n_pub], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"
estadd local sector "Public"

eststo s2: reghdfe score_pub share_priv delta_ses_c p_x_dses [aw=n_pub], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"
estadd local sector "Public"

eststo s3: reghdfe score_priv share_priv delta_ses_c [aw=n_priv], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"
estadd local sector "Private"

eststo s4: reghdfe score_priv share_priv delta_ses_c p_x_dses [aw=n_priv], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"
estadd local sector "Private"

esttab s1 s2 s3 s4 using "$tab\tab_ses_gap_sector.csv", replace ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(share_priv delta_ses_c p_x_dses) ///
    order(share_priv delta_ses_c p_x_dses) ///
    stats(comfe gsyfe sector N r2, ///
        labels("Commune FE" "GradexSubjxYear FE" "DV Sector" "N" "R2") ///
        fmt(0 0 0 0 3)) ///
    title("Table 4: Sector-Specific Outcomes with SES Gap Interaction") ///
    mtitles("Pub: Base" "Pub: Intxn" "Priv: Base" "Priv: Intxn")

esttab s1 s2 s3 s4 using "$tab\tab_ses_gap_sector.tex", replace ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(share_priv delta_ses_c p_x_dses) ///
    order(share_priv delta_ses_c p_x_dses) ///
    stats(comfe gsyfe sector N r2, ///
        labels("Commune FE" "GxSxT FE" ///
               "DV Sector" "N" "R2") ///
        fmt(0 0 0 0 3)) ///
    title("Sector-Specific Outcomes with SES Gap Interaction\label{tab:sesgapsector}") ///
    mtitles("Pub: Base" "Pub: Intxn" "Priv: Base" "Priv: Intxn") ///
    booktabs

di ""
di "==============================================="
di "  PAPER ORDER 8: tab_ses_gap_robust"
di "==============================================="

forval k = 1/4 {
    capture drop p_x_dsh`k'
    gen p_x_dsh`k' = share_priv * delta_sh_ses`k'
}

eststo clear

eststo r1: reghdfe score_mean share_priv ///
    delta_sh_ses1 delta_sh_ses2 delta_sh_ses3 delta_sh_ses4 ///
    [aw=wt_tested], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"

eststo r2: reghdfe score_mean share_priv ///
    delta_sh_ses1 delta_sh_ses2 delta_sh_ses3 delta_sh_ses4 ///
    p_x_dsh1 p_x_dsh2 p_x_dsh3 p_x_dsh4 ///
    [aw=wt_tested], ///
    absorb(cod_com gs_year_fe) cluster(cod_com)
estadd local comfe  "Yes"
estadd local gsyfe  "Yes"

esttab r1 r2 using "$tab\tab_ses_gap_robust.csv", replace ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(share_priv delta_sh_ses1 delta_sh_ses2 delta_sh_ses3 delta_sh_ses4 ///
         p_x_dsh1 p_x_dsh2 p_x_dsh3 p_x_dsh4) ///
    stats(comfe gsyfe N n_clust r2, ///
        labels("Commune FE" "GradexSubjxYear FE" "N" "Clusters" "R2") ///
        fmt(0 0 0 0 3)) ///
    title("Table 5: Robustness - Categorical SES Composition Gaps") ///
    mtitles("Cat Controls" "Cat Interactions")

esttab r1 r2 using "$tab\tab_ses_gap_robust.tex", replace ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    keep(share_priv delta_sh_ses1 delta_sh_ses2 delta_sh_ses3 delta_sh_ses4 ///
         p_x_dsh1 p_x_dsh2 p_x_dsh3 p_x_dsh4) ///
    stats(comfe gsyfe N r2, ///
        labels("Commune FE" "GxSxT FE" "N" "R2") ///
        fmt(0 0 0 3)) ///
    title("Robustness: Categorical SES Composition Gaps\label{tab:sesgaprobust}") ///
    mtitles("Cat Controls" "Cat Interactions") ///
    booktabs

di ""
di "=== 16_paper_regressions_ordered.do COMPLETE ==="
log close
exit, clear



























