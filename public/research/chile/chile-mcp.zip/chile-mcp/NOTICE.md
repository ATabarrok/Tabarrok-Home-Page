Built using Paper2Agent by Jiacheng Miao and collaborators, MIT licensed, commit c5ce59cc726eddebd6623cc70ad2a80ae55c224e. https://github.com/jmiao24/Paper2Agent

Research manuscript and source analysis: Alex Tabarrok, Private School Competition and Student Achievement in Chile. Bundled data are derived commune-level aggregates, not student microdata.

Scientific computation uses PyFixest; dependency licenses remain with their installed distributions.
