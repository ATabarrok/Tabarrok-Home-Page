"""Compare the regenerated table bodies with those of the paper.

expected_tables/ holds the table bodies as they are typeset in the paper. This script compares
each with the file of the same name under <output>/tables, ignoring line endings and trailing
blanks, and lists every line that differs.

Usage:  python 90_compare_tables.py
"""

import sys

import config as cfg


def lines(path):
    return [l.rstrip() for l in path.read_text(encoding="utf-8").replace("\r\n", "\n").rstrip("\n").split("\n")]


def main():
    expected = sorted((cfg.ROOT / "expected_tables").glob("*.tex"))
    same, different, missing = [], [], []
    for e in expected:
        got = cfg.TABLES / e.name
        if not got.exists():
            missing.append(e.name)
            continue
        a, b = lines(e), lines(got)
        if a == b:
            same.append(e.name)
            continue
        different.append(e.name)
        print(f"\n{e.name}: differs")
        for i in range(max(len(a), len(b))):
            x, y = (a[i] if i < len(a) else "<no line>"), (b[i] if i < len(b) else "<no line>")
            if x != y:
                print(f"  line {i + 1}\n    paper:       {x}\n    regenerated: {y}")
    print(f"\n{len(same)} of {len(expected)} table bodies identical to the paper's.")
    if missing:
        print(f"{len(missing)} not regenerated: " + ", ".join(missing))
    if different:
        print(f"{len(different)} differ: " + ", ".join(different))
    sys.exit(1 if different else 0)


if __name__ == "__main__":
    main()
