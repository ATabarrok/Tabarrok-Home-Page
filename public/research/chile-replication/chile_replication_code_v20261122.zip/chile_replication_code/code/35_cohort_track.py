"""Appendix Table D6: the main coefficient with the secondary track held fixed and by track.

Chilean secondary schools are academic (cientifico-humanista, enrolment code 310) or
technical-vocational. The table re-estimates the main specification on cohort members in public
or subsidized private schools at grade 10, adding the cohort's academic-track share, then the
pupil's own track, and separately for the pupils of each track. Standard errors clustered by
market. The table reports coefficients per ten percentage points of share.

Output: tab_pupil_track.tex.
Usage:  python 35_cohort_track.py
"""

import warnings

import config as cfg
import pupils as P

warnings.filterwarnings("ignore")


def main():
    cfg.make_dirs()
    a = P.track_frame()
    on = a[a.depe10.isin(P.PUBLIC_PS)].copy()
    on["hc"] = (on.ense10 == 310).astype(float)
    E = {}
    f = "score~share10+lnn0+score4+" + "+".join(P.PAR)
    for key, name in P.SUBJECTS:
        v = on.assign(score=on[key], score4=on[f"{key}4"]).dropna(subset=["score", "score4"] + P.PAR)
        E[name] = [P.fit(f + "|rc", v, "share10"), P.fit(f + "+hc_share|rc", v, "share10"), P.fit(f + "+hc|rc", v, "share10"),
                   P.fit(f + "|rc", v[v.hc == 1], "share10"), P.fit(f + "|rc", v[v.hc == 0], "share10")]
    T = [r" & Mathematics & Reading & Pupils \\ \midrule"]
    for i, lab in enumerate(("Main specification, pupils in public or subsidized private schools at grade 10",
                             "Adding the cohort's academic-track share", "Adding the pupil's own track",
                             "Pupils in the academic track", "Pupils in the vocational track")):
        m, r = E["Mathematics"][i], E["Reading"][i]
        T += [f"{lab} & {P.num(m['b'] / 10, 3)}{P.stars_t(m['b'], m['se'])} & {P.num(r['b'] / 10, 3)}{P.stars_t(r['b'], r['se'])} & {m['N']:,} \\\\",
              f" & ({m['se'] / 10:.3f}) & ({r['se'] / 10:.3f}) & \\\\"]
        if i == 2:
            T.append(r"\addlinespace")
    P.write_table("tab_pupil_track", T + [r"\bottomrule"])


if __name__ == "__main__":
    main()
