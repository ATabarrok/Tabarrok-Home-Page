"""Read the pupil-level SIMCE score files and keep one row per pupil. RESTRICTED INPUT.

Input:  the pupil files of the Agencia de Calidad de la Educacion, in the folder structure in
        which the Agencia delivers them (see data/restricted/README.md). Files are delimited
        text, latin-1; the delimiter is "|" to 2022 and ";" from 2023. Two files (grade 8 in
        2019, grade 10 in 2022) have a header written as one quoted string, and the second has
        two unnamed empty fields.
Output: <work>/pupil/scores_<grade>_<year>.pkl for grades 4, 6, 8 and 10 (4b, 6b, 8b, 2m),
        2005-2024, with year, grade, the masked pupil identifier (mrun), school (rbd), class
        (cod_curso) and the reading and mathematics scores. These files are restricted.

Repeated identifiers. About 4 percent of rows share an mrun with another row of the same file.
Nearly all are pupils listed at two schools in the year, one row marked withdrawn and without a
score. Identifiers with more than four rows are placeholders carried by many pupils and are
dropped; otherwise one row is kept per mrun, the row with the most scores. Rows with no mrun
are dropped.

Usage:  python 21_pupil_scores.py
"""

import re

import numpy as np
import pandas as pd

import config as cfg

MAX_LISTINGS = 4


def read_scores(path):
    with open(path, encoding="latin-1") as fh:
        head = fh.readline()
    sep = max("|;,\t", key=head.count)
    names = [c.strip().strip('"').lower() for c in head.strip().split(sep)]
    d = pd.read_csv(path, sep=sep, encoding="latin-1", low_memory=False, header=None, skiprows=1)
    extra = [f"unnamed_{i}" for i in range(d.shape[1] - len(names))]
    assert d.shape[1] >= len(names), path
    cols = names + extra
    if extra and d.iloc[:, len(names) - 2:len(names)].isna().all().all():
        # the empty fields sit before the last two named columns
        cols = names[:-2] + extra + names[-2:]
    d.columns = cols
    return d


def number(s):
    if s.dtype == object:
        s = s.astype(str).str.replace(",", ".", regex=False)
    return pd.to_numeric(s, errors="coerce")


def main():
    cfg.make_dirs()
    files = [f for f in sorted(cfg.RESTRICTED.glob("*/*/simce*_alu*")) if f.suffix.lower() in (".csv", ".txt")]
    if not files:
        raise SystemExit(f"No pupil score files under {cfg.RESTRICTED}. See data/restricted/README.md.")
    for f in files:
        m = re.match(r"simce(4b|6b|8b|2m)(\d{4})_", f.name)
        if not m or not 2005 <= int(m.group(2)) <= 2024:
            continue
        g, y = m.group(1), int(m.group(2))
        d = read_scores(f)
        k = pd.DataFrame({
            "agno": y, "grade": g,
            "mrun": number(d["mrun"]), "rbd": number(d["rbd"]),
            "cod_curso": number(d["cod_curso"]) if "cod_curso" in d else np.nan,
            "lect": number(d[f"ptje_lect{g}_alu"]), "mate": number(d[f"ptje_mate{g}_alu"]),
        })
        k = k[k.mrun.notna()].copy()
        k["mrun"] = k.mrun.astype("int64")
        k["listings"] = k.groupby("mrun").mrun.transform("size")
        k = k[k.listings <= MAX_LISTINGS].copy()
        k["nscore"] = k.lect.notna().astype(int) + k.mate.notna().astype(int)
        k["has"] = (k.nscore > 0).astype(int)
        k["multi_scored"] = k.groupby("mrun").has.transform("sum") > 1
        k = k.sort_values(["mrun", "nscore"], ascending=[True, False]).drop_duplicates("mrun")
        k = k.drop(columns=["nscore", "has"])
        k["rbd"] = k.rbd.astype("int64")
        k.to_pickle(cfg.PUPIL / f"scores_{g}_{y}.pkl")
        print(g, y, f"pupils {len(k):,}", flush=True)


if __name__ == "__main__":
    main()
