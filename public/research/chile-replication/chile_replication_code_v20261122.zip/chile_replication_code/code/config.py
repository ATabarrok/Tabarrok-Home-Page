"""Folders used by every script of the package.

The defaults keep everything inside the package. Three environment variables move a folder
elsewhere, which is useful when the restricted files may not sit beside the public ones:

    CHILE_RESTRICTED_DATA   the Agencia de Calidad pupil files (default data/restricted)
    CHILE_WORK_DIR          intermediate files (default work)
    CHILE_OUTPUT_DIR        tables and figures (default output)

Files under WORK / "pupil" are built from the restricted pupil records and are themselves
restricted. Everything under OUTPUT is aggregate.
"""

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CODE = ROOT / "code"
PUBLIC = ROOT / "data" / "public"
RESTRICTED = Path(os.environ.get("CHILE_RESTRICTED_DATA", ROOT / "data" / "restricted"))
WORK = Path(os.environ.get("CHILE_WORK_DIR", ROOT / "work"))
OUTPUT = Path(os.environ.get("CHILE_OUTPUT_DIR", ROOT / "output"))

# public inputs
SIMCE_SCHOOLS = PUBLIC / "simce_schools"          # school-level SIMCE results, one folder per year
ENROLLMENT = PUBLIC / "enrollment"                # enrolment by school, one folder per year
REGISTER_RAW = PUBLIC / "enrollment_register"     # enrolment by pupil, one archive per year
ADMISSIONS = PUBLIC / "admissions"                # School Admission System, one folder per process
OECD_FUA = PUBLIC / "oecd" / "oecd_municipalities.csv"

# intermediate files
DERIVED = WORK / "derived"                        # school and commune files built from public data
REGISTER = WORK / "register"                      # the enrolment register reduced to seven variables
PUPIL = WORK / "pupil"                            # RESTRICTED: built from the pupil score files
ESTIMATES = WORK / "estimates"

TABLES = OUTPUT / "tables"
FIGURES = OUTPUT / "figures"

CROSSWALK = DERIVED / "market_crosswalk.csv"
HIGH_PP = DERIVED / "high_pp_communes.csv"


def make_dirs():
    for d in (DERIVED, REGISTER, PUPIL, ESTIMATES, TABLES, FIGURES):
        d.mkdir(parents=True, exist_ok=True)
