"""Reduce the enrolment register to the variables used to follow pupils.

Input:  data/public/enrollment_register/Matricula-por-estudiante-<year>.rar, 2005-2024, the
        per-pupil enrolment files of the Ministerio de Educacion
        (https://datosabiertos.mineduc.cl/matricula-por-estudiante-2/). Each archive holds one
        delimited text file of about 500 MB with one row per pupil.
Output: <work>/register/m<year>.pkl, one file per year with mrun (the masked pupil identifier),
        rbd (school), cod_com_rbd (commune of the school), cod_com_alu (commune of residence),
        cod_depe (sector), cod_ense (type of education) and cod_grado (grade), stored as integers
        with -1 for a missing value; register_log.csv with row counts per year.

Commune codes are brought to the current coding: Nuble (8401-8421 to region 16, years to
2017), Marga Marga (5106, 5108, 5505, 5507 to 5801-5804, years to 2010), and the regions
created in 2007 (Arica y Parinacota, Los Rios and El Tamarugal). The script stops if a school
commune is not in the market crosswalk afterwards.

The archives are RAR5. The script tries the Python package unrar-cffi, then `tar -xf` (bsdtar,
shipped with Windows 10 and later), then `7z x`. bsdtar exits with status 1 on these archives
because a documentation PDF inside each uses a filter it cannot read; the data file extracts in
full, so the extraction is accepted when exactly one data file comes out. If no reader is
available, extract the archives by hand into one folder and pass --extracted <folder>.

Usage:  python 20_register.py [--force] [--extracted <folder>] [years]
"""

import csv
import io
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import pandas as pd

import config as cfg

YEARS = list(range(2005, 2025))
WANT = ["mrun", "rbd", "cod_com_rbd", "cod_com_alu", "cod_depe", "cod_ense", "cod_grado"]
DTYPES = {"mrun": "int32", "rbd": "int32", "cod_com_rbd": "int32", "cod_com_alu": "int32",
          "cod_depe": "int8", "cod_ense": "int16", "cod_grado": "int8"}
RECODE = {
    1102: 1402, 1103: 1403, 1104: 1404, 1105: 1405, 1106: 1401,           # El Tamarugal
    1201: 15101, 1202: 15102, 1301: 15201, 1302: 15202,                   # Arica y Parinacota
    10501: 14101, 10502: 14102, 10503: 14202, 10504: 14201, 10505: 14203, 10506: 14103,
    10507: 14104, 10508: 14105, 10509: 14106, 10510: 14107, 10511: 14108, 10512: 14204,  # Los Rios
    5106: 5801, 5108: 5804, 5505: 5802, 5507: 5803,                       # Marga Marga
    8401: 16101, 8402: 16102, 8403: 16202, 8404: 16203, 8405: 16302, 8406: 16103,
    8407: 16104, 8408: 16204, 8409: 16303, 8410: 16105, 8411: 16106, 8412: 16205,
    8413: 16107, 8414: 16201, 8415: 16206, 8416: 16301, 8417: 16304, 8418: 16108,
    8419: 16305, 8420: 16207, 8421: 16109,                                # Nuble
}


def is_data_file(name):
    return name.lower().endswith((".csv", ".txt"))


def read_member_bytes(archive):
    """Return (member name, bytes) for the single data file inside a RAR archive."""
    try:
        from unrar.cffi import rarfile  # type: ignore

        rf = rarfile.RarFile(str(archive))
        names = [i.filename for i in rf.infolist() if is_data_file(i.filename)]
        if len(names) != 1:
            raise RuntimeError(f"{archive.name}: expected one data file, found {names}")
        return names[0], rf.read(names[0])
    except ImportError:
        pass
    for cmd in (["tar", "-xf", str(archive), "-C"], ["7z", "x", "-y", str(archive), "-o"]):
        if shutil.which(cmd[0]) is None:
            continue
        with tempfile.TemporaryDirectory() as tmp:
            args = cmd[:-1] + ([cmd[-1], tmp] if cmd[0] == "tar" else [cmd[-1] + tmp])
            done = subprocess.run(args, capture_output=True)
            files = [p for p in Path(tmp).rglob("*") if p.is_file() and is_data_file(p.name)]
            if len(files) == 1:
                if done.returncode != 0:
                    print(f"  {cmd[0]} exit {done.returncode} on {archive.name}; the data file was extracted")
                return files[0].name, files[0].read_bytes()
    raise RuntimeError(f"Could not read {archive.name}. Install unrar-cffi, or extract by hand and use --extracted.")


def reduce_year(year, extracted=None):
    if extracted is not None:
        files = [p for p in Path(extracted).rglob("*") if is_data_file(p.name) and f"_{year}_" in p.name]
        if len(files) != 1:
            raise RuntimeError(f"{year}: expected one extracted file, found {files}")
        name, raw = files[0].name, files[0].read_bytes()
    else:
        archive = cfg.REGISTER_RAW / f"Matricula-por-estudiante-{year}.rar"
        with open(archive, "rb") as fh:
            if fh.read(4) != b"Rar!":
                raise RuntimeError(f"{archive.name} is not a RAR archive")
        name, raw = read_member_bytes(archive)
    header = raw[:2000].decode("latin-1").split("\n")[0]
    sep = ";" if header.count(";") > header.count(",") else ","
    clean = lambda c: c.strip().lower().replace("﻿", "").replace("ï»¿", "")
    d = pd.read_csv(io.BytesIO(raw), sep=sep, encoding="latin-1", low_memory=False, usecols=lambda c: clean(c) in WANT)
    del raw
    d.columns = [clean(c) for c in d.columns]
    missing = [c for c in WANT if c not in d.columns]
    if missing:
        raise RuntimeError(f"{year}: missing columns {missing}")
    for c in d.columns:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    for c in ("cod_com_rbd", "cod_com_alu"):
        d[c] = d[c].replace(RECODE)
    known = set(pd.read_csv(cfg.CROSSWALK).cod_com)
    unknown = sorted(set(d.cod_com_rbd.dropna().astype(int)) - known)
    if unknown:
        raise RuntimeError(f"{year}: school commune codes not in the market crosswalk: {unknown}")
    d = d[WANT].fillna(-1).astype(DTYPES)
    d.to_pickle(cfg.REGISTER / f"m{year}.pkl")
    grade4 = int(((d.cod_ense == 110) & (d.cod_grado == 4)).sum())
    return dict(year=year, member=name, rows=len(d), mrun_missing=int((d.mrun < 0).sum()),
                mrun_duplicated=int(d.mrun[d.mrun >= 0].duplicated().sum()), grade4_basic=grade4)


def main(argv):
    cfg.make_dirs()
    force = "--force" in argv
    extracted = argv[argv.index("--extracted") + 1] if "--extracted" in argv else None
    years = [int(a) for a in argv if a.isdigit()] or YEARS
    log_path = cfg.REGISTER / "register_log.csv"
    log = {}
    if log_path.exists():
        with open(log_path, newline="", encoding="utf-8") as fh:
            log = {int(r["year"]): r for r in csv.DictReader(fh)}
    for year in years:
        if (cfg.REGISTER / f"m{year}.pkl").exists() and not force:
            print(year, "already reduced")
            continue
        row = reduce_year(year, extracted)
        log[year] = row
        print(row, flush=True)
        with open(log_path, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(row.keys()))
            w.writeheader()
            for y in sorted(log):
                w.writerow(log[y])


if __name__ == "__main__":
    main(sys.argv[1:])
