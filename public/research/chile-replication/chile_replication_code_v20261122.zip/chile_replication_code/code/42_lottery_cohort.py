"""Table 7 (the lottery effect beside the cohort coefficient) and Appendix Tables E3 (lottery
effects by kind of pupil and of school) and E4 (cohorts admitted before and by lottery).

The lottery estimate concerns a pupil whose sector depends on the draw; the cohort coefficient
concerns the mean of a whole cohort. For the starting cohorts of 2016 to 2018 the script sets
the two side by side: the cohort gain implied if a larger private share affects nobody but the
pupils whose sector differs, and the observed cohort coefficient less that figure.

  One effect:      every pupil moved gains the lottery effect.
  Pupils differ:   the lottery effect is estimated for four kinds of pupil (public or private
                   school in grade 8, grade-4 score below or above the median) and weighted by
                   each kind's part of the pupils whose sector differs across markets.
  Schools differ:  lottery effects are estimated for four kinds of school (private or public,
                   held a grade-9 lottery that year or not) and weighted by the places of each
                   kind associated with a higher private share.

Lottery estimates are clustered by the school of the lottery and cohort estimates by market; a
difference treats the two as independent. Cohort coefficients are reported per ten percentage
points of share; lottery effects and sector advantages in points per pupil.

Output: tab_lottery_cohort.tex, tab_lottery_kinds.tex, tab_lottery_eras.tex.
Usage:  python -I 42_lottery_cohort.py
"""

import sys
import warnings
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pyfixest as pf

import config as cfg
import lotteries as Z
import pupils as P

warnings.filterwarnings("ignore")
END, MID = r" \\", r" \\ \midrule"
S = ("Mathematics", "Reading")
ERAS = ("2006--2012", "2016--2018")


def ols(formula, data, term):
    r = P.fit(formula, data, term)
    return r["b"], r["se"]


def main():
    cfg.make_dirs()
    f = Z.prepare(Z.build())
    held = set(zip(f.year.astype(int), f.rbd_l.astype(int)))   # schools that held a grade-9 lottery, by process year

    def in_held(years, schools):
        return np.array([(int(y), int(r)) in held if r == r else False for y, r in zip(years, schools)])

    # the lottery sample: kind of lottery school, of fallback, and of school attended at grade 10
    f["ftype"] = np.select([f.fb != "known", (f.priv_f == 1) & in_held(f.year, f.rbd_f), f.priv_f == 1, in_held(f.year, f.rbd_f)],
                           ["none", "Po", "Pf", "Mo"], "Mf")
    f["g10"] = np.where(f.priv_l == 1, "Po", "Mo") + "_" + f.ftype
    at = in_held(f.year, f.rbd10)
    f["T_Po"] = ((f.depe10 == 3) & at).astype(float)
    f["T_Pf"] = (f.depe10.isin([3, 4]) & ~at).astype(float)
    f["T_Mo"] = (f.depe10.isin([1, 2, 5, 6]) & at).astype(float)
    t = Z.with_controls(f.dropna(subset=["mate", "lect"]))
    groups = sorted(t.g10.unique())
    for g in groups:
        t["w_" + g] = t.win * (t.g10 == g)
    t["rsg"] = t.groupby(["rs", "g10"]).ngroup()
    two = t[t.grp.isin(["priv_pub", "pub_priv"])].copy()
    two["w_in"], two["w_out"] = two.win * (two.grp == "priv_pub"), two.win * (two.grp == "pub_priv")
    two["rs2"] = two.groupby(["rs", "grp"]).ngroup()

    # the cohort frame
    w = P.wide_frame().copy()
    w["lot"] = w.cohort.isin(P.LOTTERY_COHORTS)
    a = w[w.lot].copy()
    a["lot10"] = in_held(a.cohort + 4, a.rbd10)
    a["priv8"] = np.where(a.depe8.notna(), (a.depe8 == 3).astype(float), np.nan)

    A, B, kinds, schools, era = {}, {}, {}, {}, {}
    for key, name in P.SUBJECTS:
        ctrl = "+".join(["score4"] + P.PAR)
        # the two periods
        e = w.assign(score=w[key], score4=w[f"{key}4"]).dropna(subset=["score", "score4", "ps10"] + P.PAR)
        for per, k in zip(ERAS, (e[~e.lot], e[e.lot])):
            era[name, per] = dict(coef=ols(f"score~share10+lnn0+{ctrl}|rc", k, "share10"),
                                  adv=ols(f"score~ps10+{ctrl}|mc", k, "ps10"),
                                  within=ols(f"score~share10+ps10+lnn0+{ctrl}|rc", k, "share10"))

        d = a.assign(score=a[key], score4=a[f"{key}4"]).dropna(subset=["score", "score4", "ps10"] + P.PAR).copy()
        d["Po"], d["Pf"] = ((d.ps10 == 1) & d.lot10).astype(float), ((d.ps10 == 1) & ~d.lot10).astype(float)
        d["Mo"], d["Mf"] = ((d.ps10 == 0) & d.lot10).astype(float), ((d.ps10 == 0) & ~d.lot10).astype(float)
        beta, se_beta = ols(f"score~share10+lnn0+{ctrl}|rc", d, "share10")
        adv = ols(f"score~ps10+{ctrl}|mc", d, "ps10")
        within = ols(f"score~share10+ps10+lnn0+{ctrl}|rc", d, "share10")
        b, V = Z.tsls(two, key, ["ps10"], ["w_in", "w_out"], Z.CTRL, "rs2")
        tau, se_tau = b[0], np.sqrt(V[0, 0])
        A[name] = dict(coef=(beta, se_beta), tau=(tau, se_tau), adv=adv, within=within)
        B[name, "one"] = ((tau, se_tau), (beta - tau, np.sqrt(se_beta ** 2 + se_tau ** 2)))

        # pupils differ
        med = d.groupby("cohort").score4.median()
        k = two.assign(cohort=two.year - 4)
        k["low4"] = np.where(k[f"{key}4"].notna(), (k[f"{key}4"] < k.cohort.map(med)).astype(float), np.nan)
        k = k.dropna(subset=["low4"])
        d["low4"] = (d.score4 < d.cohort.map(med)).astype(float)
        cells = []
        for p8, l4, lab in ((0, 1, "Public school in grade 8, grade-4 score below the median"), (0, 0, "Public school in grade 8, above the median"),
                            (1, 1, "Private school in grade 8, below the median"), (1, 0, "Private school in grade 8, above the median")):
            kk = k[(k.priv8 == p8) & (k.low4 == l4)]
            dd = d[(d.priv8 == p8) & (d.low4 == l4)]
            bb, VV = Z.tsls(kk, key, ["ps10"], ["w_in", "w_out"], Z.CTRL, "rs2")
            fs, _ = ols(f"ps10~share10+lnn0+{ctrl}|rc", dd, "share10")
            cells.append((bb[0], np.sqrt(VV[0, 0]), len(dd), fs * len(dd), lab))
        n_all, n_mv = sum(c[2] for c in cells), sum(c[3] for c in cells)
        for bb, ss, n, mv, lab in cells:
            kinds[name, lab] = dict(b=bb, se=ss, share=n / n_all, per_unit=mv / n_mv)
        wts = [c[3] / n_mv for c in cells]
        p = sum(wi * c[0] for wi, c in zip(wts, cells))
        s = np.sqrt(sum((wi * c[1]) ** 2 for wi, c in zip(wts, cells)))
        B[name, "pupils"] = ((p, s), (beta - p, np.sqrt(se_beta ** 2 + s ** 2)))

        # schools differ
        b3, V3 = Z.tsls(t, key, ["T_Po", "T_Pf", "T_Mo"], ["w_" + g for g in groups], Z.CTRL, "rsg")
        se3 = np.sqrt(np.diag(V3))
        marg = {x: ols(f"{x}~share10+lnn0+{ctrl}|rc", d, "share10") for x in ("Po", "Pf", "Mo", "Mf")}
        gm = np.array([marg["Po"][0], marg["Pf"][0], marg["Mo"][0]])
        pred, se_pred = gm @ b3, np.sqrt(gm @ V3 @ gm)
        for i, (x, lab) in enumerate((("Po", "Private, held a grade-9 lottery"), ("Pf", "Private, held none"), ("Mo", "Public, held a grade-9 lottery"))):
            schools[name, lab] = dict(b=b3[i], se=se3[i], share=d[x].mean(), per_unit=marg[x][0], per_unit_se=marg[x][1])
        schools[name, "Public, held none"] = dict(b=None, share=d["Mf"].mean(), per_unit=marg["Mf"][0], per_unit_se=marg["Mf"][1])
        B[name, "schools"] = ((pred, se_pred), (beta - pred, np.sqrt(se_beta ** 2 + se_pred ** 2)))
        print(name, "done", flush=True)

    star = lambda b, se, d=2: f"{P.num(b, d)}{P.stars_t(b, se)}"

    # Table 7. Cohort figures per ten percentage points of share.
    def pair(lab, key, scale):
        top, bot = [lab], [""]
        for s in S:
            b, se = A[s][key]
            top += [star(b * scale, se * scale), ""]
            bot += [f"({se * scale:.2f})", ""]
        return [" & ".join(top) + END, " & ".join(bot) + END]

    def implied(lab, key):
        cells = []
        for s in S:
            (i, si), (g, sg) = B[s, key]
            cells += [f"{P.num(i / 10)} ({si / 10:.2f})", f"{P.num(g / 10)}{P.stars_t(g, sg)} ({sg / 10:.2f})"]
        return " & ".join([lab] + cells) + END

    T = [r" & \multicolumn{2}{c}{Mathematics} & \multicolumn{2}{c}{Reading} \\ \cmidrule(lr){2-3}\cmidrule(lr){4-5}",
         " & Estimate & Cohort less & Estimate & Cohort less" + END, " & & implied & & implied" + MID,
         r"\multicolumn{5}{l}{\textit{A. The two estimates}} \\"]
    T += pair("Observed cohort difference (10 pp)", "coef", 0.1)
    T += pair("Lottery gain per switcher", "tau", 1.0)
    T += [r"\addlinespace", r"\multicolumn{5}{l}{\textit{B. Cohort gain implied by switchers and remaining difference (10 pp)}} \\",
          implied("Switchers gain the lottery estimate", "one"), implied("Pupils differ", "pupils"), implied("Schools differ", "schools"),
          r"\addlinespace", r"\multicolumn{5}{l}{\textit{C. The two parts of the cohort coefficient in the cohort data}} \\"]
    T += pair("Private advantage inside a market", "adv", 1.0)
    T += pair("Share slope (10 pp), own sector fixed", "within", 0.1)
    P.write_table("tab_lottery_cohort", T + [r"\bottomrule"])

    # Appendix Table E3
    one = lambda r: f"{star(r['b'], r['se'])} ({r['se']:.2f})"
    T = [r" & \multicolumn{2}{c}{Lottery effect} & Share of & Per unit \\ \cmidrule(lr){2-3}", " & Mathematics & Reading & pupils & of share" + MID,
         r"\multicolumn{5}{l}{\textit{A. Kinds of pupil: effect of the private sector}} \\"]
    for lab in dict.fromkeys(k[1] for k in kinds):
        m, r = kinds["Mathematics", lab], kinds["Reading", lab]
        T.append(" & ".join([lab, one(m), one(r), f"{m['share']:.3f}", f"{m['per_unit']:.3f}"]) + END)
    T += [r"\addlinespace", r"\multicolumn{5}{l}{\textit{B. Kinds of school: effect against a public school that held no grade-9 lottery}} \\"]
    for lab in dict.fromkeys(k[1] for k in schools):
        m, r = schools["Mathematics", lab], schools["Reading", lab]
        eff = ["reference", "reference"] if m["b"] is None else [one(m), one(r)]
        T.append(" & ".join([lab] + eff + [f"{m['share']:.3f}", f"{P.num(m['per_unit'], 3)} ({m['per_unit_se']:.3f})"]) + END)
    P.write_table("tab_lottery_kinds", T + [r"\bottomrule"])

    # Appendix Table E4
    def row(lab, fn):
        return " & ".join([lab] + [fn(s, per) for s in S for per in ERAS]) + END

    def less(s, per, key, scale, d):
        b, se = era[s, per][key]
        tau, se_tau = A[s]["tau"]
        return f"{P.num((b - tau) * scale, d)} ({np.sqrt(se ** 2 + se_tau ** 2) * scale:.{d}f})"

    T = [r" & \multicolumn{2}{c}{Mathematics} & \multicolumn{2}{c}{Reading} \\ \cmidrule(lr){2-3}\cmidrule(lr){4-5}",
         " & 2006--2012 & 2016--2018 & 2006--2012 & 2016--2018" + MID,
         row("Cohort coefficient", lambda s, per: f"{P.num(era[s, per]['coef'][0] / 10, 3)} ({era[s, per]['coef'][1] / 10:.3f})"),
         row("Private advantage inside a market", lambda s, per: f"{P.num(era[s, per]['adv'][0])} ({era[s, per]['adv'][1]:.2f})"),
         row(r"\quad of which school effect (lotteries)", lambda s, per: f"{P.num(A[s]['tau'][0])} ({A[s]['tau'][1]:.2f})"),
         row(r"\quad of which sorting", lambda s, per: less(s, per, "adv", 1.0, 2)),
         row("Cohort gain less implied switcher gain", lambda s, per: less(s, per, "coef", 0.1, 3)),
         row("Slope on the share, own sector fixed", lambda s, per: f"{P.num(era[s, per]['within'][0] / 10, 3)} ({era[s, per]['within'][1] / 10:.3f})"),
         r"\bottomrule"]
    P.write_table("tab_lottery_eras", T)


if __name__ == "__main__":
    main()
