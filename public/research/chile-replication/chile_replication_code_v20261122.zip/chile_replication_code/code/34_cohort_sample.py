"""Appendix Table D2 (who is in the main sample; estimates on fuller samples) and Appendix Table D5 (the
sensitivity of the coefficient to pupils without a grade-10 score).

Panel A of Appendix Table D2. Cumulative shares of the starting cohorts reaching each step into the main
mathematics sample, and pupil-level regressions of membership on the grade-4 private share.

Panel B of Appendix Table D2. The main coefficient when (i) a missing grade-4 answer on a parent's
schooling takes the same parent's earliest later answer and household income enters as its
percentile among the parents answering the same questionnaire, and (ii) pupils who reach grade
10 a year late are added with the score of that year's test (eight cohorts have a test a year
later; none exists for the 2012 and 2018 cohorts).

Appendix Table D5. Eight cohorts, parent answers filled. Each pupil without a grade-10 score is
given the score expected of an on-time pupil with the same controls, with a residual drawn from
the on-time pupils, less k times the measured deficit of pupils tested a year late. The draws use
a fixed seed.

Tables report share coefficients per ten percentage points of share.

Output: tab_pupil_sample.tex, tab_pupil_fuller.tex, tab_pupil_bound.tex.
Usage:  python 34_cohort_sample.py
"""

import warnings

import numpy as np
import pandas as pd
import pyfixest as pf

import config as cfg
import pupils as P

warnings.filterwarnings("ignore")
SEED = 20261119
X = ["score4", "fedu", "medu", "pct", "lnn0"]
KS = [0, 0.5, 1, 1.5, 2, 3, 4]


def sample_table():
    k = P.coverage_frame()
    k["mc"] = k.groupby(["market", "cohort"]).ngroup()
    k["ins"] = k.insample.astype(float)
    k["region"] = k.market.map(P.regions())
    k["lnn0"] = np.log(k.groupby(["market", "cohort"]).ins.transform("size"))
    k = k.dropna(subset=["region"]).copy()
    k["rc"] = k.groupby(["region", "cohort"]).ngroup()
    k["ont"] = k.ontime.astype(float)
    e1 = P.fit("ins~share4+lnn0|rc", k, "share4")
    e2 = P.fit("ont~share4+lnn0|rc", k, "share4")
    kk = k[k.mate4.notna()].copy()
    kk["x"] = kk.ins * kk.share4
    e3 = P.fit("mate4~ins+x|mc", kk, "x")
    e4 = P.fit("mate4~ins|mc", kk, "ins")
    P.write_table("tab_pupil_sample", [
        r" & Share of starting cohort \\ \midrule",
        f"Pupils in the starting cohorts & {len(k):,} \\\\",
        f"In grade 10 six years later & {k.ontime.mean():.3f} \\\\",
        f"Tested in mathematics at grade 10 & {k.tested.mean():.3f} \\\\",
        f"With a grade-4 mathematics score & {k.with4.mean():.3f} \\\\",
        f"With parents' schooling and income (main sample) & {k.insample.mean():.3f} \\\\",
        r"\addlinespace",
        # membership and progression: percentage points per ten percentage points of share
        f"In the main sample, on the grade-4 share & {P.num(e1['b'] * 10)} ({e1['se'] * 10:.2f}) \\\\",
        f"In grade 10 on time, on the grade-4 share & {P.num(e2['b'] * 10)} ({e2['se'] * 10:.2f}) \\\\",
        f"Grade-4 score gap, sample against other pupils & {P.num(e4['b'])} ({e4['se']:.2f}) \\\\",
        f"Gap $\\times$ grade-4 share & {P.num(e3['b'] / 10, 3)} ({e3['se'] / 10:.3f}) \\\\",
        r"\bottomrule"])


def fuller_table(a):
    E = {}
    for key, name in P.SUBJECTS:
        d = a.assign(score4=a[f"{key}4"]).dropna(subset=["score4"])
        on = d[d.on_time].dropna(subset=[f"{key}_on"]).assign(score=lambda x: x[f"{key}_on"])
        l1 = d[d.late1 & d.test1].dropna(subset=[f"{key}_l1"]).assign(score=lambda x: x[f"{key}_l1"])
        log_inc = "score~share10+lnn0+score4+fedu+medu+linc|csub"
        pct_inc = "score~share10+lnn0+score4+fedu+medu+pct|csub"
        E[name] = [
            P.fit(log_inc, on[on.complete0], "share10"),
            P.fit(pct_inc, on[on.complete1], "share10"),
            P.fit(log_inc, on[on.test1 & on.complete0], "share10"),
            P.fit(log_inc, pd.concat([on[on.test1 & on.complete0], l1[l1.complete0]], ignore_index=True), "share10"),
            P.fit(pct_inc, pd.concat([on[on.test1 & on.complete1], l1[l1.complete1]], ignore_index=True), "share10"),
        ]
    row = lambda i: " & ".join(f"{P.num(E[s][i]['b'] / 10, 3)} ({E[s][i]['se'] / 10:.3f})" for s in ("Mathematics", "Reading"))
    P.write_table("tab_pupil_fuller", [
        r" & Mathematics & Reading \\ \midrule",
        r"\multicolumn{3}{l}{\textit{Ten cohorts, on-time pupils}} \\",
        r"Grade-4 parent answers (Table~\ref{tab:pupilmain}) & " + row(0) + r" \\",
        r"Parent answers filled from later questionnaires & " + row(1) + r" \\",
        r"\addlinespace",
        r"\multicolumn{3}{l}{\textit{Eight cohorts with a grade-10 test one year later}} \\",
        r"On-time pupils, grade-4 parent answers & " + row(2) + r" \\",
        r"Adding pupils one year late & " + row(3) + r" \\",
        r"Adding pupils one year late, parent answers filled & " + row(4) + r" \\",
        r"\bottomrule"])


def bound_table(a):
    a = a[a.test1].copy()
    rng = np.random.default_rng(SEED)
    rhs = "share10+" + "+".join(X)
    B = {}
    for key, name in P.SUBJECTS:
        d = a.assign(score4=a[f"{key}4"]).dropna(subset=X).copy()
        on = d.on_time & d[f"{key}_on"].notna()
        l1 = d.late1 & d[f"{key}_l1"].notna()
        d["score"] = d[f"{key}_on"].where(on, d[f"{key}_l1"].where(l1))
        d["absent"] = d.on_time & ~on
        d["never"] = ~on & ~l1 & ~d.absent
        d["unobs"] = (d.absent | d.never).astype(float)
        obs = d[on | l1].assign(late=lambda x: l1[x.index].astype(float))
        r = dict(observed=P.fit(f"score~{rhs}|csub", obs, "share10")["b"],
                 deficit=-P.fit(f"score~late+{rhs}|csub", obs, "late")["b"],
                 unobserved=P.fit(f"unobs~{rhs}|csub", d, "share10")["b"], pupils=len(d))
        # the score expected of an on-time pupil, with a residual drawn from the on-time pupils
        co = pf.feols(f"score~{rhs}|csub", d[on], vcov=P.VC).coef()
        xb = sum(co[v] * d[v] for v in ["share10"] + X)
        res_on = d.loc[on, "score"] - xb[on]
        fe = res_on.groupby(d.loc[on, "csub"]).mean()
        resid = (res_on - d.loc[on, "csub"].map(fe)).to_numpy()
        pred = xb + d.csub.map(fe) + rng.choice(resid, size=len(d))
        for block, who in (("all", d.unobs.astype(bool)), ("never", d.never)):
            bs = {}
            for k in KS:
                y = d.score.where(on | l1, pred - np.where(who, k * r["deficit"], 0.0))
                bs[k] = pf.feols(f"y~{rhs}|csub", d.assign(y=y), vcov=P.VC).coef()["share10"]
            slope = bs[0] - bs[1]
            r[block] = bs
            r[block + "_zero"] = bs[0] / slope if slope > 0 else float("inf")
        B[name] = r
    S = ("Mathematics", "Reading")
    zero = lambda blk, s: "none" if B[s][blk + "_zero"] == float("inf") else f"{B[s][blk + '_zero']:.0f}"
    T = [r" & \multicolumn{2}{c}{Every unobserved pupil} & \multicolumn{2}{c}{Only pupils not reaching grade 10} \\ \cmidrule(lr){2-3}\cmidrule(lr){4-5}",
         r"$k$ & Mathematics & Reading & Mathematics & Reading \\ \midrule"]
    for k in (0, 1, 2, 4):
        T.append(f"{k} & " + " & ".join(P.num(B[s][blk][k] / 10, 3) for blk in ("all", "never") for s in S) + r" \\")
    T += [r"\addlinespace",
          "$k$ at which the coefficient is zero & " + " & ".join(zero(blk, s) for blk in ("all", "never") for s in S) + r" \\",
          r"\midrule",
          "Observed pupils only & " + " & ".join(P.num(B[s]["observed"] / 10, 3) for s in S) + r" & & \\",
          "Deficit of a late pupil, points & " + " & ".join(f"{B[s]['deficit']:.2f}" for s in S) + r" & & \\",
          "Being unobserved (percentage points) & " + " & ".join(P.num(B[s]["unobserved"] * 10) for s in S) + r" & & \\",
          "Pupils & " + " & ".join(f"{B[s]['pupils']:,}" for s in S) + r" & & \\", r"\bottomrule"]
    P.write_table("tab_pupil_bound", T)


def main():
    cfg.make_dirs()
    sample_table()
    a = P.filled_late_frame()
    fuller_table(a)
    bound_table(a)


if __name__ == "__main__":
    main()
