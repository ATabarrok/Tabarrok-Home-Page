/*===========================================================================
  05_commune_ses.do
  Socioeconomic composition of each commune from the SIMCE classification of schools
  (cod_grupo, 1 low to 5 high), merged into the commune panel.

  Input:   <work>/derived/simce_rbd_all.dta, panel_full.dta
  Output:  <work>/derived/panel_full_ses.dta
===========================================================================*/

version 18
clear all
set more off
set linesize 120

local _code : environment CHILE_CODE_DIR
if "`_code'" == "" local _code = c(pwd)
do "`_code'/00_setup.do"

log using "$logs/05_commune_ses.log", replace text
di "=== 05_commune_ses.do START ==="


/* ==================================================================
   PART A: Diagnostics — cod_grupo coverage and distribution

   cod_grupo = school socioeconomic group (1=Bajo .. 5=Alto).
   Already destringed in 03_ingest_simce.do.  Confirm coverage.
   ================================================================== */

use agno grade_std rbd cod_com_rbd cod_grupo sector n_lect n_mate ///
    score_lect score_mate ///
    using "$data_int/simce_rbd_all.dta", clear

/* --- Apply sector filter (toggle in 00_setup.do) --- */
if $drop_pp {
    drop if sector == 3
    di "PP schools dropped from SES universe (drop_pp = $drop_pp)"
}

di ""
di "=== cod_grupo raw values ==="
tab cod_grupo, missing

/* Force numeric if any string remnants survived ingestion */
capture confirm numeric variable cod_grupo
if _rc != 0 {
    di "cod_grupo is string — recoding to numeric"
    gen byte ses_num = .
    replace ses_num = 1 if cod_grupo == "Bajo"
    replace ses_num = 2 if cod_grupo == "Medio bajo"
    replace ses_num = 3 if cod_grupo == "Medio"
    replace ses_num = 4 if cod_grupo == "Medio alto"
    replace ses_num = 5 if cod_grupo == "Alto"
    drop cod_grupo
    rename ses_num cod_grupo
}

/* Validate range */
replace cod_grupo = . if cod_grupo < 1 | cod_grupo > 5

di ""
di "=== cod_grupo coverage by year ==="
tab agno cod_grupo, missing row

di ""
di "=== cod_grupo coverage by grade ==="
tab grade_std cod_grupo, missing row

di ""
di "=== cod_grupo by sector (1=Public, 2=PS, 3=PP) ==="
tab sector cod_grupo if !missing(sector) & !missing(cod_grupo), row nofreq

di ""
di "=== Missingness rate by year ==="
gen byte cg_miss = missing(cod_grupo)
tab agno cg_miss, row
drop cg_miss

di ""
di "=== Summary: cod_grupo ==="
sum cod_grupo, detail


/* ==================================================================
   PART B: Commune-level SES aggregates

   For each commune × grade × year, compute:
     ses_mean:      tested-student-weighted mean of cod_grupo (1-5)
     share_lowses:  share of tested students in cod_grupo <= 2 schools
     ses_modal:     tested-student-weighted modal cod_grupo (for stratification)

   Restrict to 4B and 2M (matching 13_panel_full.do).
   ================================================================== */

keep if inlist(grade_std, "4b", "2m")
drop if missing(cod_com_rbd)

/* Use tested-student counts as weights; exclude rows with no tested students */
gen double wt = n_lect
replace wt = n_mate if missing(wt) | wt == 0
drop if missing(wt) | wt <= 0

/* Only obs with non-missing cod_grupo contribute to SES aggregates */
preserve
    keep if !missing(cod_grupo)

    /* Weighted score for mean computation */
    gen double wt_ses = wt * cod_grupo
    gen double wt_low = wt * (cod_grupo <= 2)

    /* Collapse to commune × grade × year */
    collapse (sum) wt_ses wt_low wt_total=wt, by(cod_com_rbd grade_std agno)

    gen ses_mean    = wt_ses / wt_total if wt_total > 0
    gen share_lowses = wt_low / wt_total if wt_total > 0
    drop wt_ses wt_low

    /* Binary commune classification */
    gen byte lowses_commune = (ses_mean < 3) if !missing(ses_mean)

    rename wt_total ses_n_students
    rename cod_com_rbd cod_com

    di ""
    di "=== Commune-level SES summary ==="
    sum ses_mean share_lowses lowses_commune, detail
    tab lowses_commune

    tempfile ses_commune
    save `ses_commune'
restore

/* Also compute modal cod_grupo per commune × grade × year */
preserve
    keep if !missing(cod_grupo)

    /* Total weight per cod_grupo within each commune-grade-year */
    collapse (sum) wt, by(cod_com_rbd grade_std agno cod_grupo)

    /* Keep the cod_grupo with highest total weight */
    bysort cod_com_rbd grade_std agno (wt): keep if _n == _N
    rename cod_grupo ses_modal
    rename cod_com_rbd cod_com
    keep cod_com grade_std agno ses_modal

    tempfile ses_modal
    save `ses_modal'
restore


/* ==================================================================
   PART C: Merge SES into panel_full.dta
   ================================================================== */

use "$data_int/panel_full.dta", clear

merge m:1 cod_com grade_std agno using `ses_commune', keep(master match) nogen
merge m:1 cod_com grade_std agno using `ses_modal',   keep(master match) nogen

di ""
di "=== panel_full_ses merge diagnostics ==="
di "Total rows: " _N
quietly count if !missing(ses_mean)
di "Rows with ses_mean: " r(N)
quietly count if missing(ses_mean)
di "Rows missing ses_mean: " r(N)

tab agno if !missing(ses_mean), sort

save "$data_int/panel_full_ses.dta", replace
di "Saved: $data_int/panel_full_ses.dta"

log close
exit, clear
