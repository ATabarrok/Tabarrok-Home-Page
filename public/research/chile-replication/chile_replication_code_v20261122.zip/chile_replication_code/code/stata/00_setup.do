/*===========================================================================
  00_setup.do
  Folders and constants used by the Stata scripts. Every script runs this file first.

  The scripts are run by run_all.py, which sets CHILE_CODE_DIR to the folder holding
  this file. To run a script by hand, start Stata in code/stata.

  CHILE_WORK_DIR and CHILE_OUTPUT_DIR move the intermediate files and the tables and
  figures out of the package folder; the defaults are <package>/work and <package>/output.
===========================================================================*/

version 17
clear all
set more off
set linesize 120

local here : environment CHILE_CODE_DIR
if "`here'" == "" local here = c(pwd)
local here = subinstr("`here'", "\", "/", .)
global root = regexr("`here'", "/code/stata/?$", "")

local work : environment CHILE_WORK_DIR
if "`work'" == "" local work "$root/work"
local work = subinstr("`work'", "\", "/", .)
local out : environment CHILE_OUTPUT_DIR
if "`out'" == "" local out "$root/output"
local out = subinstr("`out'", "\", "/", .)

global simce_raw  "$root/data/public/simce_schools"
global enroll_raw "$root/data/public/enrollment"
global data_int   "`work'/derived"
global logs       "`work'/logs"
global tab        "`out'/tables"
global fig        "`out'/figures"

foreach d in "`work'" "$data_int" "$logs" "`out'" "$tab" "$fig" {
    capture mkdir `"`d'"'
}

/* Paid private schools are outside the analysis: they receive no voucher and are
   concentrated in a few wealthy communes. */
global drop_pp 1

/* Communes where paid private schools hold at least this share of enrolment in any
   grade-4 or grade-10 year are excluded. */
global drop_high_pp 1
global pp_exclude_thresh 0.50

di "Root: $root"
di "Work: `work'"
