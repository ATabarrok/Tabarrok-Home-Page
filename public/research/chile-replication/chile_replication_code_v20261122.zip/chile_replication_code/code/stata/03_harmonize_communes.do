/*===========================================================================
  03_harmonize_communes.do
  Bring commune codes to the current coding in both intermediate files.

  (1) Nuble. The 21 communes of the Nuble region carry Region 8 codes (8401-8421) in SIMCE
      files up to 2017 and in enrolment files up to 2018, and Region 16 codes afterwards.
      The mapping was derived from schools observed in both 2017 and 2018 and agrees with the
      official correspondence.
  (2) Marga Marga. Enrolment files carry the old codes of Quilpue (5106), Villa Alemana (5108),
      Limache (5505) and Olmue (5507) through 2010 and the Marga Marga codes (5801-5804) from
      2011. SIMCE carries the new codes in all years.
  (3) The enrolment files of 2004-2007 use the regional coding in force before 2007. For those
      years the commune of a school is taken from the 2008 enrolment file, the first on the
      current coding, and from the SIMCE files for schools closed before 2008.
  (4) A school with no commune in the SIMCE files of 2015 or 2017 takes its commune from the
      enrolment file of the same year when the commune names in the two sources agree.

  Run after 01 and 02. Modifies in place:
      <work>/derived/simce_rbd_all.dta
      <work>/derived/enrollment_all.dta
===========================================================================*/

version 18
clear all
set more off
set linesize 120

local _code : environment CHILE_CODE_DIR
if "`_code'" == "" local _code = c(pwd)
do "`_code'/00_setup.do"

log using "$logs/03_harmonize_communes.log", replace text
di "=== 03_harmonize_communes.do START ==="

/* ------------------------------------------------------------------
   Commune recode program:
   - Nuble: old Region 8 codes (8401-8421) -> Region 16. Verified via
     rbd overlap across the 2017/2018 SIMCE boundary; matches official
     SUBDERE correspondence.
   - Marga Marga: old Valparaiso codes -> 5801-5804. Verified via rbd
     overlap across the 2010/2011 enrollment boundary.
   ------------------------------------------------------------------ */
capture program drop apply_recode
program define apply_recode
    args var
    recode `var' ///
        (1106 = 1401)  /* Pozo Almonte: residual pre-2007 codes */ ///
        (1201 = 15101) /* Arica          */ ///
        (10501 = 14101) /* Valdivia      */ ///
        (10503 = 14202) /* Futrono       */ ///
        (10504 = 14201) /* La Union      */ ///
        (10505 = 14203) /* Lago Ranco    */ ///
        (10506 = 14103) /* Lanco         */ ///
        (10507 = 14104) /* Los Lagos     */ ///
        (10509 = 14106) /* Mariquina     */ ///
        (10510 = 14107) /* Paillaco      */ ///
        (10511 = 14108) /* Panguipulli   */ ///
        (10512 = 14204) /* Rio Bueno     */ ///
        (5106 = 5801)  /* Quilpue        */ ///
        (5108 = 5804)  /* Villa Alemana  */ ///
        (5505 = 5802)  /* Limache        */ ///
        (5507 = 5803)  /* Olmue          */ ///
        (8401 = 16101) /* Chillan        */ ///
        (8402 = 16102) /* Bulnes         */ ///
        (8403 = 16202) /* Cobquecura     */ ///
        (8404 = 16203) /* Coelemu        */ ///
        (8405 = 16302) /* Coihueco       */ ///
        (8406 = 16103) /* Chillan Viejo  */ ///
        (8407 = 16104) /* El Carmen      */ ///
        (8408 = 16204) /* Ninhue         */ ///
        (8409 = 16303) /* Niquen         */ ///
        (8410 = 16105) /* Pemuco         */ ///
        (8411 = 16106) /* Pinto          */ ///
        (8412 = 16205) /* Portezuelo     */ ///
        (8413 = 16107) /* Quillon        */ ///
        (8414 = 16201) /* Quirihue       */ ///
        (8415 = 16206) /* Ranquil        */ ///
        (8416 = 16301) /* San Carlos     */ ///
        (8417 = 16304) /* San Fabian     */ ///
        (8418 = 16108) /* San Ignacio    */ ///
        (8419 = 16305) /* San Nicolas    */ ///
        (8420 = 16207) /* Treguaco       */ ///
        (8421 = 16109) /* Yungay         */
end


/* ==================================================================
   PART 1: SIMCE RBD intermediate -- Nuble recode
   ================================================================== */

use "$data_int/simce_rbd_all.dta", clear

quietly count if (inrange(cod_com_rbd, 8401, 8421) | inlist(cod_com_rbd, 5106, 5108, 5505, 5507))
di ""
di "=== SIMCE: rows with old Nuble/Marga Marga codes before fix: " r(N)

apply_recode cod_com_rbd

quietly count if (inrange(cod_com_rbd, 8401, 8421) | inlist(cod_com_rbd, 5106, 5108, 5505, 5507))
di "=== SIMCE: rows with old Nuble/Marga Marga codes after fix:  " r(N)
assert r(N) == 0

save "$data_int/simce_rbd_all.dta", replace
di "Saved: simce_rbd_all.dta (Nuble harmonized)"


/* ==================================================================
   PART 2: Build rbd -> commune crosswalks for early enrollment years

   Primary:  2008 enrollment (first year natively on the new standard;
             most complete school universe).
   Fallback: SIMCE codes (cod_com_rbd_2013 standard, all years pooled,
             modal commune per rbd) for schools closed before 2008.
   Both crosswalks are built AFTER the Nuble recode so they carry 16xxx.
   ================================================================== */

/* --- Primary crosswalk: enrollment 2008 --- */
use agno rbd cod_com_rbd using "$data_int/enrollment_all.dta", clear
keep if agno == 2008 & !missing(rbd) & !missing(cod_com_rbd)
apply_recode cod_com_rbd
keep rbd cod_com_rbd
duplicates drop
/* A school should map to exactly one commune; report and resolve any
   rbd with conflicting communes by keeping the first (none expected). */
quietly bysort rbd: gen byte _dupflag = _N > 1
quietly count if _dupflag
di "=== Crosswalk e08: rbd with conflicting communes: " r(N)
bysort rbd (cod_com_rbd): keep if _n == 1
drop _dupflag
rename cod_com_rbd cod_com_e08
tempfile xwalk_e08
save `xwalk_e08'
di "Crosswalk e08 rows: " _N

/* --- Fallback crosswalk: SIMCE (harmonized), modal commune per rbd --- */
use rbd cod_com_rbd using "$data_int/simce_rbd_all.dta", clear
keep if !missing(rbd) & !missing(cod_com_rbd)
bysort rbd cod_com_rbd: gen long _n_pair = _N
bysort rbd (_n_pair cod_com_rbd): keep if _n == _N   /* modal commune */
keep rbd cod_com_rbd
rename cod_com_rbd cod_com_simce
tempfile xwalk_simce
save `xwalk_simce'
di "Crosswalk simce rows: " _N


/* ==================================================================
   PART 3: Enrollment intermediate -- crosswalk 2004-2007, Nuble recode

   For 2004-2007 rows, replace cod_com_rbd wholesale with the e08
   crosswalk value (these files are on the pre-2007 standard; even
   numerically-identical codes are only coincidentally right).
   Fall back to the SIMCE crosswalk, then keep the original value
   (flagged and counted) for schools in neither.
   ================================================================== */

use "$data_int/enrollment_all.dta", clear

quietly count if (inrange(cod_com_rbd, 8401, 8421) | inlist(cod_com_rbd, 5106, 5108, 5505, 5507))
di ""
di "=== ENROLLMENT: rows with old Nuble/Marga Marga codes before fix: " r(N)

merge m:1 rbd using `xwalk_e08',   keep(master match) nogen
merge m:1 rbd using `xwalk_simce', keep(master match) nogen

gen byte early = agno <= 2007
gen byte fixed_e08   = early & !missing(cod_com_e08)
gen byte fixed_simce = early &  missing(cod_com_e08) & !missing(cod_com_simce)
gen byte unfixed     = early &  missing(cod_com_e08) &  missing(cod_com_simce)

di ""
di "=== 2004-2007 enrollment crosswalk coverage (rows) ==="
tab agno fixed_e08   if early
tab agno fixed_simce if early
tab agno unfixed     if early

replace cod_com_rbd = cod_com_e08   if fixed_e08
replace cod_com_rbd = cod_com_simce if fixed_simce

di ""
di "=== Unfixed early rows by year (schools absent from 2008 enrollment"
di "    and all SIMCE files; original code retained) ==="
tab agno if unfixed

drop cod_com_e08 cod_com_simce early fixed_e08 fixed_simce unfixed

/* Recode across all years (covers Nuble 2008-2018, Marga Marga 2008-2010, and residual early rows) */
apply_recode cod_com_rbd

quietly count if (inrange(cod_com_rbd, 8401, 8421) | inlist(cod_com_rbd, 5106, 5108, 5505, 5507))
di "=== ENROLLMENT: rows with old Nuble/Marga Marga codes after fix: " r(N)
assert r(N) == 0

save "$data_int/enrollment_all.dta", replace
di "Saved: enrollment_all.dta (harmonized)"


/* ==================================================================
   PART 4: Validation

   (a) No old Nuble/Marga Marga codes anywhere (asserted above).
   (b) Distinct commune counts per file.
   (c) Every commune code should appear in the 2024 enrollment
       universe (complete, current-standard list of communes).
       Codes failing this are listed with row counts by year.
   ================================================================== */

/* Recover missing SIMCE locations using contemporaneous enrollment ONLY
   when both source commune names agree. Preserve existing valid locations.
   Enrollment has already received the historical code harmonization above.
   Compact expanded-grade inputs omit names and inherit these canonical fixes. */
use "$data_int/enrollment_all.dta", clear
capture confirm variable nom_com_rbd
if _rc == 0 {
    keep agno rbd cod_com_rbd nom_com_rbd
    gen str100 _en_name = ustrregexra(ustrnormalize(ustrlower(nom_com_rbd), "nfd"), "\p{Mark}", "")
    replace _en_name = ustrregexra(_en_name, "[^a-z0-9]", "")
    bysort agno rbd: assert cod_com_rbd == cod_com_rbd[1]
    bysort agno rbd: assert _en_name == _en_name[1]
    duplicates drop agno rbd, force
    rename cod_com_rbd _en_com
    keep agno rbd _en_com _en_name
    tempfile current_locations
    save `current_locations'
    use "$data_int/simce_rbd_all.dta", clear
    gen str100 _sim_name = ustrregexra(ustrnormalize(ustrlower(nom_com_rbd), "nfd"), "\p{Mark}", "")
    replace _sim_name = ustrregexra(_sim_name, "[^a-z0-9]", "")
    merge m:1 agno rbd using `current_locations', keep(master match) nogen
    capture drop location_recovered
    gen byte location_recovered = inlist(agno, 2015, 2017) & missing(cod_com_rbd) & !missing(_en_com) & _en_name == _sim_name & _sim_name != ""
    preserve
        keep if location_recovered
        keep agno grade_std rbd nom_com_rbd _en_com score_lect score_mate n_lect n_mate
        export delimited using "$logs/03_recovered_locations.csv", replace
    restore
    replace cod_com_rbd = _en_com if location_recovered
    drop _en_com _en_name _sim_name
    save "$data_int/simce_rbd_all.dta", replace
}

/* Official universe: communes in 2024 enrollment */
use agno cod_com_rbd using "$data_int/enrollment_all.dta", clear
keep if agno == 2024 & !missing(cod_com_rbd)
duplicates drop cod_com_rbd, force
keep cod_com_rbd
gen byte in_2024_universe = 1
quietly count
di ""
di "=== Commune codes in 2024 enrollment universe: " r(N)
tempfile universe
save `universe'

/* Enrollment check */
use agno cod_com_rbd using "$data_int/enrollment_all.dta", clear
keep if !missing(cod_com_rbd)
merge m:1 cod_com_rbd using `universe', keep(master match) nogen
quietly levelsof cod_com_rbd, local(all_codes)
di "=== ENROLLMENT: distinct commune codes (all years): " `: word count `all_codes''
quietly count if missing(in_2024_universe) & !inlist(cod_com_rbd, 12103, 12202)
di "=== ENROLLMENT: rows with codes outside 2024 universe: " r(N)
if r(N) > 0 {
    di "    (by year and code:)"
    tab agno cod_com_rbd if missing(in_2024_universe)
}
assert !missing(in_2024_universe) | inlist(cod_com_rbd, 12103, 12202)

/* SIMCE check */
use agno cod_com_rbd using "$data_int/simce_rbd_all.dta", clear
keep if !missing(cod_com_rbd)
merge m:1 cod_com_rbd using `universe', keep(master match) nogen
quietly levelsof cod_com_rbd, local(all_codes)
di "=== SIMCE: distinct commune codes (all years): " `: word count `all_codes''
quietly count if missing(in_2024_universe) & !inlist(cod_com_rbd, 12103, 12202)
di "=== SIMCE: rows with codes outside 2024 universe: " r(N)
if r(N) > 0 {
    di "    (by year and code:)"
    tab agno cod_com_rbd if missing(in_2024_universe)
}
assert !missing(in_2024_universe) | inlist(cod_com_rbd, 12103, 12202)

di ""
di "=== 03_harmonize_communes.do COMPLETE ==="
log close
exit, clear
