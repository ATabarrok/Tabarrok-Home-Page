/*===========================================================================
  06_market_dynamics.do
  Appendix C: how the private share changed inside communes between 2005 and 2024, grade 4.

  Input:   <work>/derived/panel_full_ses.dta
  Output:  <output>/tables/tab_market_dynamics_summary.tex      (Appendix Table C1)
           <output>/tables/tab_market_dynamics_correlates.tex   (Appendix Table C2)
           <output>/figures/fig_market_dynamics_hist.png        (Appendix Figure C1)
===========================================================================*/

version 18
clear all
set more off
set linesize 120

local _code : environment CHILE_CODE_DIR
if "`_code'" == "" local _code = c(pwd)
do "`_code'/00_setup.do"

capture log close
log using "$logs/06_market_dynamics.log", replace text
di "=== 06_market_dynamics.do START ==="

use "$data_int/panel_full_ses.dta", clear
keep if subject == "lect" & grade_std == "4b"

gen double share_priv = share_subv + share_paid
gen double priv_enroll = share_priv * enroll_total if !missing(share_priv, enroll_total)
gen double pub_enroll  = (1 - share_priv) * enroll_total if !missing(share_priv, enroll_total)

sort cod_com agno
by cod_com: gen double d_wave_pp = 100 * (share_priv - share_priv[_n-1]) if _n > 1

quietly summarize d_wave_pp, detail
local wave_mean : display %9.2f r(mean)
local wave_p25  : display %9.2f r(p25)
local wave_p50  : display %9.2f r(p50)
local wave_p75  : display %9.2f r(p75)
local wave_min  : display %9.2f r(min)
local wave_max  : display %9.2f r(max)
local wave_n    : display %9.0fc r(N)

preserve
    collapse (sum) priv_enroll enroll_total, by(agno)
    gen double nat_share = 100 * priv_enroll / enroll_total if enroll_total > 0
    quietly summarize nat_share if agno == 2005
    local nat_share_2005 : display %4.1f r(mean)
    quietly summarize nat_share if agno == 2024
    local nat_share_2024 : display %4.1f r(mean)
restore

keep cod_com agno share_priv priv_enroll pub_enroll enroll_total ses_mean share_lowses
keep if inlist(agno, 2005, 2024)

reshape wide share_priv priv_enroll pub_enroll enroll_total ses_mean share_lowses, ///
    i(cod_com) j(agno)

keep if !missing(share_priv2005) & !missing(share_priv2024)

gen double d_share = share_priv2024 - share_priv2005
gen double d_pp    = 100 * d_share
gen double d_total = enroll_total2024 - enroll_total2005
gen double d_priv  = priv_enroll2024 - priv_enroll2005
gen double d_pub   = pub_enroll2024 - pub_enroll2005

gen double pct_total = 100 * d_total / enroll_total2005 if enroll_total2005 > 0
gen double pct_priv  = 100 * d_priv  / priv_enroll2005  if priv_enroll2005  > 0
gen double pct_pub   = 100 * d_pub   / pub_enroll2005   if pub_enroll2005   > 0

count if d_pp > 0
local n_up : display %9.0fc r(N)
count if d_pp < 0
local n_down : display %9.0fc r(N)
count if d_pp == 0
local n_flat : display %9.0fc r(N)
count
local n_communes : display %9.0fc r(N)

quietly summarize d_pp, detail
local dpp_mean : display %9.2f r(mean)
local dpp_p25  : display %9.2f r(p25)
local dpp_p50  : display %9.2f r(p50)
local dpp_p75  : display %9.2f r(p75)
local dpp_min  : display %9.2f r(min)
local dpp_max  : display %9.2f r(max)
local dpp_n    : display %9.0fc r(N)

quietly summarize pct_total, detail
local total_mean : display %9.2f r(mean)
local total_p25  : display %9.2f r(p25)
local total_p50  : display %9.2f r(p50)
local total_p75  : display %9.2f r(p75)
local total_min  : display %9.2f r(min)
local total_max  : display %9.2f r(max)
local total_n    : display %9.0fc r(N)

quietly summarize pct_pub, detail
local pub_mean : display %9.2f r(mean)
local pub_p25  : display %9.2f r(p25)
local pub_p50  : display %9.2f r(p50)
local pub_p75  : display %9.2f r(p75)
local pub_min  : display %9.2f r(min)
local pub_max  : display %9.2f r(max)
local pub_n    : display %9.0fc r(N)

quietly summarize pct_priv, detail
local priv_mean : display %9.2f r(mean)
local priv_p25  : display %9.2f r(p25)
local priv_p50  : display %9.2f r(p50)
local priv_p75  : display %9.2f r(p75)
local priv_min  : display %9.2f r(min)
local priv_max  : display %9.2f r(max)
local priv_n    : display %9.0fc r(N)

tempname C

quietly corr d_pp share_priv2005 if !missing(d_pp, share_priv2005)
matrix `C' = r(C)
local rho_share0 : display %6.3f el(`C', 1, 2)
count if !missing(d_pp, share_priv2005)
local n_share0 : display %9.0fc r(N)

quietly corr d_pp ses_mean2005 if !missing(d_pp, ses_mean2005)
matrix `C' = r(C)
local rho_ses0 : display %6.3f el(`C', 1, 2)
count if !missing(d_pp, ses_mean2005)
local n_ses0 : display %9.0fc r(N)

quietly corr d_pp share_lowses2005 if !missing(d_pp, share_lowses2005)
matrix `C' = r(C)
local rho_low0 : display %6.3f el(`C', 1, 2)
count if !missing(d_pp, share_lowses2005)
local n_low0 : display %9.0fc r(N)

quietly corr d_pp pct_total if !missing(d_pp, pct_total)
matrix `C' = r(C)
local rho_total : display %5.2f el(`C', 1, 2)
local rho_total_table : display %6.3f el(`C', 1, 2)
count if !missing(d_pp, pct_total)
local n_total_corr : display %9.0fc r(N)

quietly corr d_pp pct_priv if !missing(d_pp, pct_priv)
matrix `C' = r(C)
local rho_priv : display %6.3f el(`C', 1, 2)
count if !missing(d_pp, pct_priv)
local n_priv_corr : display %9.0fc r(N)

quietly corr d_pp pct_pub if !missing(d_pp, pct_pub)
matrix `C' = r(C)
local rho_pub : display %5.2f el(`C', 1, 2)
local rho_pub_table : display %6.3f el(`C', 1, 2)
count if !missing(d_pp, pct_pub)
local n_pub_corr : display %9.0fc r(N)

* Negative numbers in mathematics mode, so they print with a minus sign and not a hyphen.
foreach L in wave_mean wave_p25 wave_p50 wave_p75 wave_min wave_max dpp_mean dpp_p25 dpp_p50 dpp_p75 dpp_min dpp_max ///
    total_mean total_p25 total_p50 total_p75 total_min total_max pub_mean pub_p25 pub_p50 pub_p75 pub_min pub_max ///
    priv_mean priv_p25 priv_p50 priv_p75 priv_min priv_max rho_share0 rho_ses0 rho_low0 rho_total_table rho_priv rho_pub_table {
    local t = strtrim("``L''")
    if substr("`t'", 1, 1) == "-" local `L' = "\$-" + substr("`t'", 2, .) + "\$"
    else local `L' "`t'"
}

file open sumfh using `"$tab/tab_market_dynamics_summary.tex"', write replace text
file write sumfh "\begin{table}[htbp]\centering" _n
file write sumfh "\scriptsize" _n
file write sumfh "\setlength{\tabcolsep}{3pt}" _n
file write sumfh "\caption{Commune-Level Market Dynamics in the Balanced Grade-4 Sample\label{tab:marketdynsum}}" _n
file write sumfh "\begin{threeparttable}" _n
file write sumfh "\begin{tabular}{p{0.42\textwidth}rrrrrrr}" _n
file write sumfh "\toprule" _n
file write sumfh `"& Mean & P25 & P50 & P75 & Min & Max & N\\ "' _n
file write sumfh "\midrule" _n
file write sumfh ///
    `"Change in private share between observed SIMCE waves (pp)&      `wave_mean'&      `wave_p25'&      `wave_p50'&      `wave_p75'&      `wave_min'&      `wave_max'&      `wave_n'\\ "' _n
file write sumfh ///
    `"Change in private share, 2005--2024 (pp)&      `dpp_mean'&      `dpp_p25'&      `dpp_p50'&      `dpp_p75'&      `dpp_min'&      `dpp_max'&      `dpp_n'\\ "' _n
file write sumfh ///
    `"Total enrollment change, 2005--2024 (\%)&      `total_mean'&      `total_p25'&      `total_p50'&      `total_p75'&      `total_min'&      `total_max'&      `total_n'\\ "' _n
file write sumfh ///
    `"Public enrollment change, 2005--2024 (\%)&      `pub_mean'&      `pub_p25'&      `pub_p50'&      `pub_p75'&      `pub_min'&      `pub_max'&      `pub_n'\\ "' _n
file write sumfh ///
    `"Private enrollment change, 2005--2024 (\%)&      `priv_mean'&      `priv_p25'&      `priv_p50'&      `priv_p75'&      `priv_min'&      `priv_max'&      `priv_n'\\ "' _n
file write sumfh "\bottomrule" _n
file write sumfh "\end{tabular}" _n
file write sumfh "\begin{tablenotes}[flushleft]" _n
file write sumfh "\footnotesize" _n
file write sumfh "\item Source: Author's calculations from the balanced grade-4 commune panel. The first row reports changes between successive observed SIMCE waves; the remaining rows compare commune endpoints in 2005 and 2024. The private-enrollment row excludes communes with zero private enrollment in 2005." _n
file write sumfh "\end{tablenotes}" _n
file write sumfh "\end{threeparttable}" _n
file write sumfh "\end{table}" _n
file close sumfh

file open corrfh using `"$tab/tab_market_dynamics_correlates.tex"', write replace text
file write corrfh "\begin{table}[htbp]\centering" _n
file write corrfh "\caption{Correlates of Commune-Level Private-Share Change\label{tab:marketdyncorr}}" _n
file write corrfh "\begin{threeparttable}" _n
file write corrfh "\begin{tabular}{p{0.42\textwidth}cc}" _n
file write corrfh "\toprule" _n
file write corrfh `"Variable & Correlation with $\Delta$ private share & N\\ "' _n
file write corrfh "\midrule" _n
file write corrfh ///
    `"Baseline private share (2005)&      `rho_share0'&      `n_share0'\\ "' _n
file write corrfh ///
    `"Baseline SES mean (2005)&      `rho_ses0'&      `n_ses0'\\ "' _n
file write corrfh ///
    `"Baseline low-SES share (2005)&      `rho_low0'&      `n_low0'\\ "' _n
file write corrfh ///
    `"Total enrollment change, 2005--2024 (\%)&      `rho_total_table'&      `n_total_corr'\\ "' _n
file write corrfh ///
    `"Private enrollment change, 2005--2024 (\%)&      `rho_priv'&      `n_priv_corr'\\ "' _n
file write corrfh ///
    `"Public enrollment change, 2005--2024 (\%)&      `rho_pub_table'&      `n_pub_corr'\\ "' _n
file write corrfh "\bottomrule" _n
file write corrfh "\end{tabular}" _n
file write corrfh "\begin{tablenotes}[flushleft]" _n
file write corrfh "\footnotesize" _n
file write corrfh "\item Source: Author's calculations from the balanced grade-4 commune panel. Correlations are unweighted across communes with both endpoints observed. Positive values indicate that communes with larger values experienced larger increases in private share over 2005--2024." _n
file write corrfh "\end{tablenotes}" _n
file write corrfh "\end{threeparttable}" _n
file write corrfh "\end{table}" _n
file close corrfh

histogram d_pp, frequency ///
    width(5) start(-30) ///
    color(navy*0.65) fcolor(navy*0.65) lcolor(white) ///
    xline(0, lcolor(maroon) lpattern(dash)) ///
    xtitle("Change in private share, 2005 to 2024 (percentage points)") ///
    ytitle("Number of communes") ///
    title("Commune-level changes in private share") ///
    subtitle("Grade 4, communes observed in both years") ///
    note("Increase: `n_up' communes; decline: `n_down'; no change: `n_flat'.") ///
    name(g_market_hist, replace)
graph export "$fig/fig_market_dynamics_hist.png", replace width(1800)

di "=== 06_market_dynamics.do END ==="
log close
exit, clear
