/*===========================================================================
  02_ingest_enrollment.do
  Read the Ministry of Education's enrolment summaries by school (Resumen de matricula por
  unidad educativa), 2004-2024, and stack them.

  Input:   data/public/enrollment/<year>/...
           <work>/derived/simce_rbd_all.dta  (commune codes for schools in 2006-2007)
  Output:  <work>/derived/enrollment_all.dta, one row per school, type of education and year,
           with enrolment by grade (mat_gra_1 ... mat_gra_8) and the sector of the school.
===========================================================================*/

version 18
clear all
set more off
set linesize 120

local _code : environment CHILE_CODE_DIR
if "`_code'" == "" local _code = c(pwd)
do "`_code'/00_setup.do"

log using "$logs/02_ingest_enrollment.log", replace text

di "=== 02_ingest_enrollment.do START ==="

local eb `"$enroll_raw"'


/* ── Accumulator ──────────────────────────────────────────────────────── */
tempfile enroll_all
clear
save `enroll_all', replace emptyok

local n_files 0


/* ══════════════════════════════════════════════════════════════════════════
   MAIN LOOP: Ingest each year's enrollment CSV
   ══════════════════════════════════════════════════════════════════════════ */

/* ─── 2004-2021: Standard naming pattern, semicolon delimiter ─────── */
foreach yr in 2004 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 {

    di ""
    di "=== Ingesting enrollment: `yr' ==="

    local fp `"`eb'/`yr'/Resumen-matricula-UE-`yr'/Resumen_matricula_UE_`yr'.csv"'

    /* All 21 source files pass strict UTF-8 decoding. */
    local enc "utf-8"

    capture confirm file `"`fp'"'
    if _rc != 0 {
        di as error "WARNING: File not found for `yr', skipping."
        di as error `"Path: `fp'"'
        continue
    }

    import delimited using `"`fp'"', delimiter(";") encoding("`enc'") ///
        varnames(1) clear

    di "Imported: " _N " rows, " c(k) " variables"

    /* Lowercase all variable names (handles 2018+ UPPERCASE) */
    capture rename *, lower

    /* Ensure year variable */
    capture confirm variable agno
    if _rc != 0 {
        gen int agno = `yr'
    }
    capture destring agno, replace force

    /* Destring key variables */
    foreach v in rbd cod_reg_rbd cod_pro_rbd cod_com_rbd cod_depe cod_depe2 ///
                 rural_rbd estado_estab cod_ense cod_ense2 ///
                 mat_gra_1 mat_gra_2 mat_gra_3 mat_gra_4 ///
                 mat_gra_5 mat_gra_6 mat_gra_7 mat_gra_8 ///
                 mat_total {
        capture destring `v', replace force
    }

    di "  Enrollment `yr' OK: " _N " rows, " c(k) " vars"

    append using `enroll_all', force
    save `enroll_all', replace
    local n_files = `n_files' + 1
}


/* ─── 2022 (non-standard filename) ────────────────────────────────── */
di ""
di "=== Ingesting enrollment: 2022 ==="
local fp `"`eb'/2022/Resumen-matricula-UE-2022/20221014_Resumen_matrícula_UE_2022_20220430_WEB.csv"'
capture confirm file `"`fp'"'
if _rc != 0 {
    di as error "WARNING: File not found for 2022, skipping."
}
else {
    import delimited using `"`fp'"', delimiter(";") encoding("utf-8") ///
        varnames(1) clear
    di "Imported: " _N " rows, " c(k) " variables"
    capture rename *, lower
    capture destring agno rbd cod_reg_rbd cod_pro_rbd cod_com_rbd ///
        cod_depe cod_depe2 rural_rbd estado_estab cod_ense cod_ense2 ///
        mat_gra_1 mat_gra_2 mat_gra_3 mat_gra_4 mat_gra_5 mat_gra_6 ///
        mat_gra_7 mat_gra_8 mat_total, replace force
    di "  Enrollment 2022 OK: " _N " rows"
    append using `enroll_all', force
    save `enroll_all', replace
    local n_files = `n_files' + 1
}


/* ─── 2023 (non-standard filename, capitalized folder) ────────────── */
di ""
di "=== Ingesting enrollment: 2023 ==="
local fp `"`eb'/2023/Resumen-Matricula-UE-2023/20230928_Resumen_matrícula_UE_2023_20230430_WEB.csv"'
capture confirm file `"`fp'"'
if _rc != 0 {
    di as error "WARNING: File not found for 2023, skipping."
}
else {
    import delimited using `"`fp'"', delimiter(";") encoding("utf-8") ///
        varnames(1) clear
    di "Imported: " _N " rows, " c(k) " variables"
    capture rename *, lower
    capture destring agno rbd cod_reg_rbd cod_pro_rbd cod_com_rbd ///
        cod_depe cod_depe2 rural_rbd estado_estab cod_ense cod_ense2 ///
        mat_gra_1 mat_gra_2 mat_gra_3 mat_gra_4 mat_gra_5 mat_gra_6 ///
        mat_gra_7 mat_gra_8 mat_total, replace force
    di "  Enrollment 2023 OK: " _N " rows"
    append using `enroll_all', force
    save `enroll_all', replace
    local n_files = `n_files' + 1
}


/* ─── 2024 (non-standard filename) ────────────────────────────────── */
di ""
di "=== Ingesting enrollment: 2024 ==="
local fp `"`eb'/2024/Resumen-Matricula-UE-2024/20241002_Resumen_matrícula_UE_2024_20240430_PUBL.csv"'
capture confirm file `"`fp'"'
if _rc != 0 {
    di as error "WARNING: File not found for 2024, skipping."
}
else {
    import delimited using `"`fp'"', delimiter(";") encoding("utf-8") ///
        varnames(1) clear
    di "Imported: " _N " rows, " c(k) " variables"
    capture rename *, lower
    capture destring agno rbd cod_reg_rbd cod_pro_rbd cod_com_rbd ///
        cod_depe cod_depe2 rural_rbd estado_estab cod_ense cod_ense2 ///
        mat_gra_1 mat_gra_2 mat_gra_3 mat_gra_4 mat_gra_5 mat_gra_6 ///
        mat_gra_7 mat_gra_8 mat_total, replace force
    di "  Enrollment 2024 OK: " _N " rows"
    append using `enroll_all', force
    save `enroll_all', replace
    local n_files = `n_files' + 1
}


/* ══════════════════════════════════════════════════════════════════════════
   FINAL CLEANING
   ══════════════════════════════════════════════════════════════════════════ */

use `enroll_all', clear

di ""
di "=== Final combined enrollment dataset ==="
di "Total rows: " _N
di "Files ingested: `n_files'"


/* ══════════════════════════════════════════════════════════════════════════
   FIX 1: Commune codes for 2006-2007
   These years have old 4-digit codes for ~60% of rows (regions 1-9).
   Build crosswalk from SIMCE rbd → cod_com_rbd_2013, merge on rbd.
   ══════════════════════════════════════════════════════════════════════════ */
di ""
di "=== Fixing 2006-2007 commune codes via SIMCE crosswalk ==="

/* Build crosswalk from the already-cleaned SIMCE RBD file */
capture confirm file `"$data_int/simce_rbd_all.dta"'
if _rc == 0 {
    tempfile com_xwalk
    preserve
        use rbd agno cod_com_rbd using `"$data_int/simce_rbd_all.dta"', clear
        /* Use 2006 SIMCE data (already has cod_com_rbd_2013 applied) */
        keep if agno == 2006 & !missing(cod_com_rbd) & !missing(rbd)
        keep rbd cod_com_rbd
        rename cod_com_rbd cod_com_xwalk
        duplicates drop rbd, force
        save `com_xwalk'
    restore

    /* Apply to 2006 enrollment */
    preserve
        keep if agno == 2006
        local n06 = _N
        local old_com cod_com_rbd
        merge m:1 rbd using `com_xwalk', keep(master match)
        quietly count if _merge == 3
        local matched = r(N)
        replace cod_com_rbd = cod_com_xwalk if _merge == 3
        drop cod_com_xwalk _merge
        di "2006 enrollment: `n06' rows, `matched' matched to SIMCE crosswalk"
        tempfile fix06
        save `fix06'
    restore
    drop if agno == 2006
    append using `fix06', force

    /* Apply to 2007 enrollment (use same 2006 crosswalk) */
    preserve
        keep if agno == 2007
        local n07 = _N
        merge m:1 rbd using `com_xwalk', keep(master match)
        quietly count if _merge == 3
        local matched = r(N)
        replace cod_com_rbd = cod_com_xwalk if _merge == 3
        drop cod_com_xwalk _merge
        di "2007 enrollment: `n07' rows, `matched' matched to SIMCE crosswalk"
        tempfile fix07
        save `fix07'
    restore
    drop if agno == 2007
    append using `fix07', force

    di "Commune code crosswalk applied to 2006 and 2007."
}
else {
    di as error "WARNING: simce_rbd_all.dta not found. Run 03_ingest_simce.do first."
    di as error "Skipping 2006-2007 commune code fix."
}


/* ══════════════════════════════════════════════════════════════════════════
   FIX 2: Unified sector variable
   Pre-2010 files use cod_depe:   1=Mun, 2=Corp, 3=PS, 4=PP, 5=Corp deleg.
   2010+ files use cod_depe2:     1=Mun, 2=PS, 3=PP, 4=Corp deleg., 5=SLEP
   Create unified sector: 1=Public, 2=PS, 3=PP
   ══════════════════════════════════════════════════════════════════════════ */
di ""
di "=== Creating unified sector variable ==="

gen byte sector = .

/* 2004-2009 (or whenever cod_depe2 is missing): use cod_depe */
replace sector = 1 if missing(cod_depe2) & inlist(cod_depe, 1, 2, 5)
replace sector = 2 if missing(cod_depe2) & cod_depe == 3
replace sector = 3 if missing(cod_depe2) & cod_depe == 4

/* 2010+ (cod_depe2 available): use cod_depe2 */
replace sector = 1 if !missing(cod_depe2) & inlist(cod_depe2, 1, 4, 5)
replace sector = 2 if !missing(cod_depe2) & cod_depe2 == 2
replace sector = 3 if !missing(cod_depe2) & cod_depe2 == 3

label define sector_lbl 1 "Public" 2 "PS" 3 "PP"
label values sector sector_lbl
label variable sector "Sector (1=Public, 2=PS, 3=PP)"

tab sector agno, missing


/* Variable labels */
capture label variable agno         "Year"
capture label variable rbd          "School identifier (RBD)"
capture label variable cod_reg_rbd  "Region code"
capture label variable cod_pro_rbd  "Province code"
capture label variable cod_com_rbd  "Commune code"
capture label variable cod_depe     "Dependency type (pre-2010: 1=Mun,2=Corp,3=PS,4=PP,5=Deleg)"
capture label variable cod_depe2    "Dependency type 2 (2010+: 1=Mun,2=PS,3=PP,4=Deleg,5=SLEP)"
capture label variable rural_rbd    "Rural flag (0=urban, 1=rural)"
capture label variable estado_estab "School status (1=active, 2018+)"
capture label variable cod_ense     "Education level code"
capture label variable cod_ense2    "Education level grouped (2018+)"
capture label variable mat_gra_1    "Enrollment grade 1"
capture label variable mat_gra_2    "Enrollment grade 2"
capture label variable mat_gra_3    "Enrollment grade 3"
capture label variable mat_gra_4    "Enrollment grade 4"
capture label variable mat_gra_5    "Enrollment grade 5"
capture label variable mat_gra_6    "Enrollment grade 6"
capture label variable mat_gra_7    "Enrollment grade 7"
capture label variable mat_gra_8    "Enrollment grade 8"
capture label variable mat_total    "Total enrollment (school x ense)"
capture label variable nom_rbd      "School name"
capture label variable nombre_slep  "SLEP name (2024+)"

/* Sort and check uniqueness on year x rbd x cod_ense */
sort agno rbd cod_ense
quietly duplicates report agno rbd cod_ense
di ""
di "=== Uniqueness check: year x RBD x cod_ense ==="
if r(unique_value) == _N {
    di "PASS: year x RBD x cod_ense is unique (N=" _N ")"
}
else {
    di as error "NOTE: " _N - r(unique_value) " duplicate rows at year x RBD x cod_ense level"
    di "Listing first 20:"
    duplicates list agno rbd cod_ense in 1/20
}

/* Year coverage */
di ""
di "=== Year coverage ==="
tab agno

/* Dependency distribution in most recent year */
di ""
di "=== Dependency distribution (most recent year) ==="
quietly sum agno
local maxyr = r(max)
tab cod_depe if agno == `maxyr'

save `"$data_int/enrollment_all.dta"', replace
di ""
di "Saved: $data_int/enrollment_all.dta (" _N " rows)"

di ""
di "=== 02_ingest_enrollment.do COMPLETE ==="
di "Files ingested: `n_files' (expected 21)"
log close
exit, clear
