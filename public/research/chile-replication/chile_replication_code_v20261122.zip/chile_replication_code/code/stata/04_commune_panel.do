/*===========================================================================
  04_commune_panel.do
  The communes excluded from the analysis, and the commune panel for grades 4 and 10.

  A commune is excluded if paid private schools hold at least half of enrolment in any grade-4
  or grade-10 year, counting every sector.

  The panel has one row per commune, grade, subject and year: the mean score of the commune's
  public and subsidized private schools weighted by pupils tested, and the subsidized private
  share of enrolment in the grade.

  Input:   <work>/derived/simce_rbd_all.dta, enrollment_all.dta
  Output:  <work>/derived/high_pp_communes.dta
           <work>/derived/panel_full.dta
===========================================================================*/

version 18
clear all
set more off
set linesize 120

local _code : environment CHILE_CODE_DIR
if "`_code'" == "" local _code = c(pwd)
do "`_code'/00_setup.do"

/* ==================================================================
   Build commune exclusion for PP-heavy full-market communes

   Screen communes using the full enrollment market before PP schools are
   dropped. A commune is excluded if its PP share is ever at least
   $pp_exclude_thresh in the relevant 4B or 2M commune-grade-year cell.
   ================================================================== */

tempfile pp_4b high_pp_communes
    use agno cod_com_rbd cod_ense mat_gra_4 mat_gra_2 sector using "$data_int/enrollment_all.dta", clear
    keep if !missing(cod_com_rbd)
    rename cod_com_rbd cod_com

    preserve
        keep if cod_ense == 110
        replace mat_gra_4 = 0 if missing(mat_gra_4)
        gen double enroll_total_all = mat_gra_4
        gen double enroll_pp = mat_gra_4 * (sector == 3)
        collapse (sum) enroll_total_all enroll_pp, by(cod_com agno)
        gen str2 grade_std = "4b"
        save `pp_4b'
    restore

    keep if inlist(cod_ense, 310, 410, 510, 610, 710, 810, 910)
    replace mat_gra_2 = 0 if missing(mat_gra_2)
    gen double enroll_total_all = mat_gra_2
    gen double enroll_pp = mat_gra_2 * (sector == 3)
    collapse (sum) enroll_total_all enroll_pp, by(cod_com agno)
    gen str2 grade_std = "2m"
    append using `pp_4b'

    gen double pp_share_all = enroll_pp / enroll_total_all if enroll_total_all > 0
    keep if !missing(pp_share_all)
    collapse (max) max_pp_share=pp_share_all (mean) mean_pp_share=pp_share_all ///
        (count) n_cells=pp_share_all, by(cod_com)
    gen byte high_pp_commune = max_pp_share >= $pp_exclude_thresh
    gen cod_com_rbd = cod_com
    save `high_pp_communes'
    save "$data_int/high_pp_communes.dta", replace
log using "$logs/04_commune_panel.log", replace text
di "=== 04_commune_panel.do START ==="


/* ==================================================================
   PART A: SIMCE RBD ??? commune ?? grade ?? year weighted scores

   Goal: convert school-level (RBD) SIMCE scores into commune-level
   means, weighted by the number of tested students at each school.

   Steps:
   1. Load school-level SIMCE data (score + N tested per school).
   2. Keep only 4B and 2M (6B excluded ??? too few years for panel).
   3. Compute weighted scores: ws = score ?? N_tested per school.
   4. Collapse (sum) across schools within each commune ?? grade ?? year.
   5. Recover the weighted mean: score = sum(ws) / sum(N_tested).

   Result: one row per commune ?? grade ?? year, with enrollment-weighted
   mean lectura and matem??ticas scores.
   ================================================================== */

use agno grade_std rbd cod_com_rbd sector n_lect n_mate score_lect score_mate ///
    using "$data_int/simce_rbd_all.dta", clear

keep if inlist(grade_std, "4b", "2m")

/* --- Apply sector filter (toggle in 00_setup.do) --- */
if $drop_pp {
    drop if sector == 3
    di "PP schools dropped from SIMCE universe (drop_pp = $drop_pp)"
}
drop sector

/* Zero out N for schools with missing scores so they don't enter the weighted mean */
replace n_lect = 0 if missing(score_lect)
replace n_mate = 0 if missing(score_mate)

/* Weighted score components: score ?? N_tested */
gen double ws_l = score_lect * n_lect
gen double ws_m = score_mate * n_mate
replace ws_l = 0 if missing(ws_l)
replace ws_m = 0 if missing(ws_m)

drop if missing(cod_com_rbd)
rename cod_com_rbd cod_com
merge m:1 cod_com using `high_pp_communes', keep(master match) nogen keepusing(high_pp_commune)
replace high_pp_commune = 0 if missing(high_pp_commune)
if $drop_high_pp {
    drop if high_pp_commune == 1
    di "High-PP communes dropped from enrollment universe (drop_high_pp = $drop_high_pp, threshold = $pp_exclude_thresh)"
}
drop high_pp_commune

/* Sum across all schools in each commune ?? grade ?? year */
collapse (sum) ws_l ws_m nalu_lect=n_lect nalu_mate=n_mate, by(cod_com grade_std agno)

/* Recover weighted mean scores */
gen score_lect = ws_l / nalu_lect if nalu_lect > 0
gen score_mate = ws_m / nalu_mate if nalu_mate > 0
drop ws_l ws_m

di ""
di "=== SIMCE commune panel ==="
di "Rows: " _N
tab agno grade_std

tempfile simce_stack
save `simce_stack'


/* ==================================================================
   PART B: Enrollment ??? commune ?? grade ?? year sector shares

   Goal: compute the private-school enrollment share in each commune
   ?? grade ?? year.  This is the key independent variable.

   Uses the unified sector variable (1=Public, 2=PS, 3=PP)
   created in 04_ingest_enrollment.do.

   cod_ense identifies the education level of each enrollment record:
     110 = Educaci??n B??sica (maps to grade 4B)
     310 = Ed. Media Human??stico-Cient??fica  }  (map to grade 2M)
     410 = commercial vocational; 510/610/710/810 = other vocational
     910 = artistic (all map to grade 2M via mat_gra_2)

   For each commune ?? year:
     share_subv = PS enrollment / total enrollment
     share_paid = PP enrollment / total enrollment
   ================================================================== */

use agno rbd cod_com_rbd cod_ense mat_gra_4 mat_gra_2 sector ///
    using "$data_int/enrollment_all.dta", clear

drop if missing(cod_com_rbd)
rename cod_com_rbd cod_com
merge m:1 cod_com using `high_pp_communes', keep(master match) nogen keepusing(high_pp_commune)
replace high_pp_commune = 0 if missing(high_pp_commune)
if $drop_high_pp {
    drop if high_pp_commune == 1
    di "High-PP communes dropped from SIMCE universe (drop_high_pp = $drop_high_pp, threshold = $pp_exclude_thresh)"
}
drop high_pp_commune

/* --- Apply sector filter (toggle in 00_setup.do) --- */
if $drop_pp {
    drop if sector == 3
    di "PP schools dropped from enrollment universe (drop_pp = $drop_pp)"
}

/* ?????? 4B: b??sica (cod_ense == 110) ?????? */
/* mat_gra_4 = enrollment in 4th grade at this school */
preserve
    keep if cod_ense == 110
    replace mat_gra_4 = 0 if missing(mat_gra_4)
    /* Flag PS and PP enrollment; public (sector==1) is the residual */
    gen double es = mat_gra_4 * (sector == 2)
    gen double ep = mat_gra_4 * (sector == 3)
    collapse (sum) enroll_total=mat_gra_4 enroll_subv=es enroll_paid=ep, by(cod_com agno)
    gen share_subv = enroll_subv / enroll_total if enroll_total > 0
    gen share_paid = enroll_paid / enroll_total if enroll_total > 0
    drop enroll_subv enroll_paid
    gen str grade_std = "4b"
    tempfile enroll_4b
    save `enroll_4b'
restore

/* ?????? 2M: media (all regular academic, vocational and artistic codes) ?????? */
/* mat_gra_2 = enrollment in 2nd year media at this school */
keep if inlist(cod_ense, 310, 410, 510, 610, 710, 810, 910)
replace mat_gra_2 = 0 if missing(mat_gra_2)
gen double es = mat_gra_2 * (sector == 2)
gen double ep = mat_gra_2 * (sector == 3)
collapse (sum) enroll_total=mat_gra_2 enroll_subv=es enroll_paid=ep, by(cod_com agno)
gen share_subv = enroll_subv / enroll_total if enroll_total > 0
gen share_paid = enroll_paid / enroll_total if enroll_total > 0
drop enroll_subv enroll_paid
gen str grade_std = "2m"

append using `enroll_4b'

di ""
di "=== Enrollment commune panel ==="
di "Rows: " _N
tab agno grade_std

tempfile enroll_stack
save `enroll_stack'


/* ==================================================================
   PART C: Merge SIMCE + enrollment; reshape to subject-long

   1. Merge the commune SIMCE scores (Part A) with the enrollment
      shares (Part B) on commune ?? grade ?? year.
   2. Reshape from wide (score_lect, score_mate as separate columns)
      to long (one row per subject, with a single score_mean column).
      This doubles the row count but lets us stack both subjects into
      the same regression with grade??subject??year FE.

   Result: panel_full.dta ??? one row per commune ?? grade ?? subject ?? year.
   ================================================================== */

use `simce_stack', clear
merge 1:1 cod_com grade_std agno using `enroll_stack', keep(master match) nogen
di "After SIMCE-enrollment merge: " _N " rows"

/* Reshape wide ??? long on subject (lectura / matem??ticas) */
preserve
    gen subject    = "lect"
    gen score_mean = score_lect
    gen wt_tested  = nalu_lect
    keep cod_com grade_std agno subject score_mean wt_tested enroll_total share_subv share_paid
    tempfile panel_lect
    save `panel_lect'
restore
gen subject    = "mate"
gen score_mean = score_mate
gen wt_tested  = nalu_mate
keep cod_com grade_std agno subject score_mean wt_tested enroll_total share_subv share_paid
append using `panel_lect'
sort cod_com grade_std agno subject

di ""
di "=== Full panel ==="
di "Total rows: " _N
tab agno grade_std
quietly count if !missing(score_mean) & !missing(share_subv)
di "Complete obs (score + share non-missing): " r(N)
foreach v in share_subv share_paid score_mean {
    quietly sum `v'
    di "  `v': mean=" %6.3f r(mean) "  sd=" %6.3f r(sd) ///
       "  min=" %5.1f r(min) "  max=" %5.1f r(max)
}

save "$data_int/panel_full.dta", replace
di "Saved: $data_int/panel_full.dta"

log close
exit, clear
