/*===========================================================================
  01_ingest_simce.do
  Read the public school-level and commune-level SIMCE files, 2005-2024, for grades 4, 6 and
  10 (4b, 6b, 2m), standardize variable names and stack them.

  Input:   data/public/simce_schools/<year>/...   (DTA to 2022, semicolon-delimited CSV after)
  Output:  <work>/derived/simce_rbd_all.dta        school level
           <work>/derived/simce_com_all.dta        commune level
           <work>/logs/01_schema_summary.csv       variables found in each file

  Terms:   rbd          school identifier
           agno         year of the test
           cod_com_rbd  commune of the school
           sector       1 public (municipal, SLEP, delegated administration),
                        2 subsidized private, 3 paid private
           score_lect, score_mate   mean reading and mathematics score of the school
           n_lect, n_mate           pupils tested
           grade_std    4b, 6b or 2m
  Years:   grade 4 2005-2018 and 2022-2024; grade 6 2013-2016, 2018 and 2024;
           grade 10 2006, 2008, 2010, 2012-2018 and 2022-2024.
===========================================================================*/

version 18
clear all
set more off
set linesize 120

local _code : environment CHILE_CODE_DIR
if "`_code'" == "" local _code = c(pwd)
do "`_code'/00_setup.do"

log using "$logs/01_ingest_simce.log", replace text

di "=== 01_ingest_simce.do START ==="

/* ── Convenience: base path ──────────────────────────────────────────── */
local sb `"$simce_raw"'


/* ══════════════════════════════════════════════════════════════════════════
   PROGRAM: process_rbd
   Load one RBD-level SIMCE file (DTA or CSV), standardize variable names.
   File path is passed via global macro $simce_fpath.
   ══════════════════════════════════════════════════════════════════════════ */
capture program drop process_rbd
program define process_rbd
    args grade fmt delim yr

    di ""
    di "=== Ingesting RBD: grade `grade', year `yr', format `fmt' ==="
    di `"Path: $simce_fpath"'

    /* ── Load data ────────────────────────────────────────────────────── */
    if "`fmt'" == "dta" {
        use `"$simce_fpath"', clear
    }
    else {
        import delimited using `"$simce_fpath"', delimiter("`delim'") ///
            encoding("latin1") varnames(1) clear
    }

    di "Imported: " _N " rows, " c(k) " variables"

    /* ── Lowercase all variable names ─────────────────────────────────── */
    capture rename *, lower

    /* Legacy pre-Unicode DTA strings retain Latin-1 bytes. Decode only
       invalid UTF-8 strings, leaving already-Unicode source text intact. */
    ds, has(type string)
    foreach v of varlist `r(varlist)' {
        replace `v' = ustrfrom(`v', "latin1", 1) if ustrinvalidcnt(`v') > 0
        assert ustrinvalidcnt(`v') == 0
    }

    /* ── Strip grade stub from variable names ─────────────────────────── */
    local g "`grade'"

    /* Tested-student counts */
    capture rename nalu_lect`g'_rbd   n_lect
    capture rename nalu_mate`g'_rbd   n_mate
    capture rename nalu_`g'_rbd       n_total

    /* Mean scores */
    capture rename prom_lect`g'_rbd   score_lect
    capture rename prom_mate`g'_rbd   score_mate

    /* Score differences and significance */
    capture rename dif_lect`g'_rbd      dif_lect
    capture rename dif_mate`g'_rbd      dif_mate
    capture rename difgru_lect`g'_rbd   difgru_lect
    capture rename difgru_mate`g'_rbd   difgru_mate
    capture rename sigdif_lect`g'_rbd   sigdif_lect
    capture rename sigdif_mate`g'_rbd   sigdif_mate
    capture rename siggru_lect`g'_rbd   siggru_lect
    capture rename siggru_mate`g'_rbd   siggru_mate
    capture rename marca_lect`g'_rbd    marca_lect
    capture rename marca_mate`g'_rbd    marca_mate
    capture rename marcadif_lect`g'_rbd marcadif_lect
    capture rename marcadif_mate`g'_rbd marcadif_mate

    /* Learning-standard distributions (not in all years) */
    capture rename palu_eda_ins_lect`g'_rbd pct_ins_lect
    capture rename palu_eda_ele_lect`g'_rbd pct_ele_lect
    capture rename palu_eda_ade_lect`g'_rbd pct_ade_lect
    capture rename palu_eda_ins_mate`g'_rbd pct_ins_mate
    capture rename palu_eda_ele_mate`g'_rbd pct_ele_mate
    capture rename palu_eda_ade_mate`g'_rbd pct_ade_mate

    /* ── Ensure year variable ─────────────────────────────────────────── */
    capture confirm variable agno
    if _rc != 0 {
        gen int agno = `yr'
    }
    capture destring agno, replace force

    /* ── Add grade identifiers ────────────────────────────────────────── */
    gen str4 grade_std = "`grade'"
    gen int  grade_num = .
    replace  grade_num = 4  if "`grade'" == "4b"
    replace  grade_num = 6  if "`grade'" == "6b"
    replace  grade_num = 10 if "`grade'" == "2m"

    /* ── Commune code harmonization ────────────────────────────────────
       2006-2013 DTA files have cod_com_rbd_2013 (post-reform 5-digit).
       Always prefer it over cod_com_rbd (pre-reform codes).
       ────────────────────────────────────────────────────────────────── */
    capture confirm variable cod_com_rbd_2013
    if _rc == 0 {
        di "  Replacing cod_com_rbd with cod_com_rbd_2013 for `yr'"
        capture destring cod_com_rbd_2013, replace force
        replace cod_com_rbd = cod_com_rbd_2013
        drop cod_com_rbd_2013
    }

    /* ── Ensure key variables are numeric ─────────────────────────────── */
    foreach v in rbd cod_reg_rbd cod_pro_rbd cod_com_rbd cod_deprov_rbd ///
                 cod_depe1 cod_depe2 cod_grupo cod_rural_rbd noaplica {
        capture destring `v', replace force
    }
    foreach v in n_lect n_mate n_total score_lect score_mate ///
                 dif_lect dif_mate ///
                 pct_ins_lect pct_ele_lect pct_ade_lect ///
                 pct_ins_mate pct_ele_mate pct_ade_mate {
        capture destring `v', replace force
    }

    /* ── Diagnostic ───────────────────────────────────────────────────── */
    capture confirm variable n_lect
    if _rc == 0 {
        quietly sum n_lect
        di "  n_lect: mean=" %6.1f r(mean) ", max=" r(max) ", N=" r(N)
    }
    else {
        di "  NOTE: no n_lect variable for `grade' `yr'"
    }

    di "  RBD `grade' `yr' OK: " _N " rows, " c(k) " vars"
end


/* ══════════════════════════════════════════════════════════════════════════
   PROGRAM: process_com
   Load one commune-level SIMCE file, standardize variable names.
   File path is passed via global macro $simce_fpath.
   ══════════════════════════════════════════════════════════════════════════ */
capture program drop process_com
program define process_com
    args grade fmt delim yr

    di ""
    di "=== Ingesting COMMUNE: grade `grade', year `yr', format `fmt' ==="

    if "`fmt'" == "dta" {
        use `"$simce_fpath"', clear
    }
    else {
        import delimited using `"$simce_fpath"', delimiter("`delim'") ///
            encoding("latin1") varnames(1) clear
    }

    di "Imported: " _N " rows, " c(k) " variables"

    capture rename *, lower

    local g "`grade'"

    /* Commune key */
    capture rename cod_com cod_com_off

    /* Score variables */
    capture rename prom_lect`g'_com   score_lect_com
    capture rename prom_mate`g'_com   score_mate_com
    capture rename dif_lect`g'_com    dif_lect_com
    capture rename dif_mate`g'_com    dif_mate_com
    capture rename sigdif_lect`g'_com sigdif_lect_com
    capture rename sigdif_mate`g'_com sigdif_mate_com

    /* Year */
    capture confirm variable agno
    if _rc != 0 {
        gen int agno = `yr'
    }
    capture destring agno, replace force

    /* Grade identifiers */
    gen str4 grade_std = "`grade'"
    gen int  grade_num = .
    replace  grade_num = 4  if "`grade'" == "4b"
    replace  grade_num = 6  if "`grade'" == "6b"
    replace  grade_num = 10 if "`grade'" == "2m"

    /* Ensure numeric */
    foreach v in cod_reg cod_pro cod_com_off cod_deprov ///
                 score_lect_com score_mate_com ///
                 dif_lect_com dif_mate_com {
        capture destring `v', replace force
    }

    /* Handle cod_com variant */
    capture confirm variable cod_com
    if _rc == 0 {
        capture rename cod_com cod_com_off
        capture destring cod_com_off, replace force
    }

    di "  COMMUNE `grade' `yr' OK: " _N " rows"
end


/* ══════════════════════════════════════════════════════════════════════════
   ACCUMULATORS — disk-based so crashes don't lose progress
   ══════════════════════════════════════════════════════════════════════════ */
global rbd_accum_path "`c(tmpdir)'/rbd_accum_tmp.dta"
global com_accum_path "`c(tmpdir)'/com_accum_tmp.dta"
di "Accumulators in: `c(tmpdir)'"
clear
save `"$rbd_accum_path"', replace emptyok
save `"$com_accum_path"', replace emptyok

local rbd_count 0
local com_count 0
local rbd_fail  0
local com_fail  0

/* ── Helper: safe ingest with error handling ──────────────────────────
   Wraps process_rbd / process_com in capture so one bad file
   doesn't abort the entire run.  Sets _safe_ok in caller's scope.
   ──────────────────────────────────────────────────────────────────── */
capture program drop safe_ingest
program define safe_ingest
    args proc grade fmt delim yr accum_type
    capture noisily `proc' "`grade'" "`fmt'" "`delim'" `yr'
    local rc = _rc
    if `rc' != 0 {
        di as error "  >>> FAILED: `grade' `yr' (rc=`rc'). Skipping."
        clear
        c_local _safe_ok 0
    }
    else {
        if "`accum_type'" == "rbd" {
            append using `"$rbd_accum_path"', force
            save `"$rbd_accum_path"', replace
        }
        else {
            append using `"$com_accum_path"', force
            save `"$com_accum_path"', replace
        }
        c_local _safe_ok 1
    }
end


/* ══════════════════════════════════════════════════════════════════════════
   RBD FILES: INGEST ALL GRADES x YEARS  (36 files total)
   ══════════════════════════════════════════════════════════════════════════ */

di ""
di "=================================================================="
di "  PHASE 1: RBD (school-level) files"
di "=================================================================="

/* ─── 4B RBD: 2005-2017 (standard DTA pattern) ────────────────────── */
foreach yr in 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 {
    local d = uchar(176)
    global simce_fpath `"$simce_raw/`yr'/Simce+4`d'+Basico+`yr'/Simce 4`d' Basico `yr'/Archivos DTA (Stata)/simce4b`yr'_rbd_publica_final.dta"'
    safe_ingest process_rbd "4b" "dta" ";" `yr' "rbd"
    if `_safe_ok' local rbd_count = `rbd_count' + 1
    else local rbd_fail = `rbd_fail' + 1
}

/* 4B RBD 2018 (DTA, non-standard folder) */
global simce_fpath `"`sb'/2018/Simce+4°+basico+2018/Simce4b2018_publicas_web/Archivos DTA (Stata)/simce4b2018_rbd_publica_final.dta"'
safe_ingest process_rbd "4b" "dta" "" 2018 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

/* 4B RBD 2022 (DTA, accented folder) */
global simce_fpath `"`sb'/2022/Simce+4°+básico+2022/Simce 4° básico 2022/Archivos DTA (Stata)/Simce4b2022_rbd_final.dta"'
safe_ingest process_rbd "4b" "dta" "" 2022 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

/* 4B RBD 2023 (CSV, semicolon) */
global simce_fpath `"`sb'/2023/4b/Archivos CSV (Planos)/simce4b2023_rbd_público_final.csv"'
safe_ingest process_rbd "4b" "csv" ";" 2023 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

/* 4B RBD 2024 (CSV, semicolon) */
global simce_fpath `"`sb'/2024/Simce+4to+basico+2024/4B/Archivos CSV (Planos)/simce4b2024_rbd_preliminar.csv"'
safe_ingest process_rbd "4b" "csv" ";" 2024 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

di ""
di ">>> 4B RBD complete: `rbd_count' files ingested so far"


/* ─── 6B RBD: 2013-2016, 2018, 2024 ──────────────────────────────── */

/* 6B RBD 2013 (DTA, accented folder, _lect_ in filename) */
global simce_fpath `"`sb'/2013/Simce+6°+básico+2013/Simce 6° Básico 2013/Archivos DTA (Stata)/simce6b2013_rbd_lect_publica_final.dta"'
safe_ingest process_rbd "6b" "dta" "" 2013 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

/* 6B RBD 2014-2016 (standard DTA) */
foreach yr in 2014 2015 2016 {
    local d = uchar(176)
    global simce_fpath `"$simce_raw/`yr'/Simce+6`d'+Basico+`yr'/Simce 6`d' Basico `yr'/Archivos DTA (Stata)/simce6b`yr'_rbd_publica_final.dta"'
    safe_ingest process_rbd "6b" "dta" ";" `yr' "rbd"
    if `_safe_ok' local rbd_count = `rbd_count' + 1
    else local rbd_fail = `rbd_fail' + 1
}

/* 6B RBD 2018 (DTA, non-standard folder) */
global simce_fpath `"`sb'/2018/Simce+6°+basico+2018/Simce6b2018_publicas_web/Archivos DTA (Stata)/simce6b2018_rbd_publica_final.dta"'
safe_ingest process_rbd "6b" "dta" "" 2018 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

/* 6B RBD 2024 (CSV, semicolon) */
global simce_fpath `"`sb'/2024/Simce+6to+basico+2024/6B/Archivos CSV (Planos)/simce6b2024_rbd_preliminar.csv"'
safe_ingest process_rbd "6b" "csv" ";" 2024 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

di ""
di ">>> 6B RBD complete: `rbd_count' files ingested so far"


/* ─── 2M RBD: 2006-2017 (gaps), 2018, 2022-2024 ─────────────────── */

/* 2M RBD 2006-2017 (standard DTA; only years with 2M SIMCE) */
foreach yr in 2006 2008 2010 2012 2013 2014 2015 2016 2017 {
    local d = uchar(176)
    global simce_fpath `"$simce_raw/`yr'/Simce+2`d'+medio+`yr'/Simce 2`d' Medio `yr'/Archivos DTA (Stata)/simce2m`yr'_rbd_publica_final.dta"'
    safe_ingest process_rbd "2m" "dta" ";" `yr' "rbd"
    if `_safe_ok' local rbd_count = `rbd_count' + 1
    else local rbd_fail = `rbd_fail' + 1
}

/* 2M RBD 2018 (DTA, non-standard folder) */
global simce_fpath `"`sb'/2018/Simce+2°+medio+2018/Simce2m2018_publicas_web/Archivos DTA (Stata)/simce2m2018_rbd_publica_final.dta"'
safe_ingest process_rbd "2m" "dta" "" 2018 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

/* 2M RBD 2022 (DTA) */
global simce_fpath `"`sb'/2022/Simce+2°+medio+2022/Simce 2° medio 2022/Archivos DTA (Stata)/Simce2m2022_rbd_final.dta"'
safe_ingest process_rbd "2m" "dta" "" 2022 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

/* 2M RBD 2023 (CSV, semicolon) */
global simce_fpath `"`sb'/2023/2m/Archivos CSV (Planos)/simce2m2023_rbd_público_final.csv"'
safe_ingest process_rbd "2m" "csv" ";" 2023 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

/* 2M RBD 2024 (CSV, semicolon) */
global simce_fpath `"`sb'/2024/Simce+2do+medio+2024/2M/Archivos CSV (Planos)/simce2m2024_rbd_preliminar.csv"'
safe_ingest process_rbd "2m" "csv" ";" 2024 "rbd"
if `_safe_ok' local rbd_count = `rbd_count' + 1
else local rbd_fail = `rbd_fail' + 1

di ""
di ">>> ALL RBD complete: `rbd_count' files ingested, `rbd_fail' failed (expected 36)"
if `rbd_fail' > 0 {
    di as error "WARNING: `rbd_fail' RBD file(s) could not be ingested. Check paths above."
}


/* ══════════════════════════════════════════════════════════════════════════
   COMMUNE FILES: INGEST ALL GRADES x YEARS  (36 files total)
   ══════════════════════════════════════════════════════════════════════════ */

di ""
di "=================================================================="
di "  PHASE 2: Commune-level files"
di "=================================================================="

/* ─── 4B COMMUNE: 2005-2018, 2022-2024 ────────────────────────────── */
foreach yr in 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 {
    local d = uchar(176)
    global simce_fpath `"$simce_raw/`yr'/Simce+4`d'+Basico+`yr'/Simce 4`d' Basico `yr'/Archivos DTA (Stata)/simce4b`yr'_comuna_publica_final.dta"'
    safe_ingest process_com "4b" "dta" ";" `yr' "com"
    if `_safe_ok' local com_count = `com_count' + 1
    else local com_fail = `com_fail' + 1
}

/* 4B COMMUNE 2018 (DTA, non-standard folder) */
global simce_fpath `"`sb'/2018/Simce+4°+basico+2018/Simce4b2018_publicas_web/Archivos DTA (Stata)/simce4b2018_comuna_publica_final.dta"'
safe_ingest process_com "4b" "dta" "" 2018 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

/* 4B COMMUNE 2022 (DTA, accented folder) */
global simce_fpath `"`sb'/2022/Simce+4°+básico+2022/Simce 4° básico 2022/Archivos DTA (Stata)/simce4b2022_comuna_final.dta"'
safe_ingest process_com "4b" "dta" "" 2022 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

/* 4B COMMUNE 2023 (CSV, semicolon) */
global simce_fpath `"`sb'/2023/4b/Archivos CSV (Planos)/simce4b2023_comuna_público_final.csv"'
safe_ingest process_com "4b" "csv" ";" 2023 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

/* 4B COMMUNE 2024 (CSV, semicolon) */
global simce_fpath `"`sb'/2024/Simce+4to+basico+2024/4B/Archivos CSV (Planos)/simce4b2024_comuna_preliminar.csv"'
safe_ingest process_com "4b" "csv" ";" 2024 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

di ""
di ">>> 4B COMMUNE complete: `com_count' files ingested so far"


/* ─── 6B COMMUNE: 2013-2016, 2018, 2024 ──────────────────────────── */

/* 6B COMMUNE 2013 (DTA, accented folder, _lect_ in filename) */
global simce_fpath `"`sb'/2013/Simce+6°+básico+2013/Simce 6° Básico 2013/Archivos DTA (Stata)/simce6b2013_comuna_lect_publica_final.dta"'
safe_ingest process_com "6b" "dta" "" 2013 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

/* 6B COMMUNE 2014-2016 (standard DTA) */
foreach yr in 2014 2015 2016 {
    local d = uchar(176)
    global simce_fpath `"$simce_raw/`yr'/Simce+6`d'+Basico+`yr'/Simce 6`d' Basico `yr'/Archivos DTA (Stata)/simce6b`yr'_comuna_publica_final.dta"'
    safe_ingest process_com "6b" "dta" ";" `yr' "com"
    if `_safe_ok' local com_count = `com_count' + 1
    else local com_fail = `com_fail' + 1
}

/* 6B COMMUNE 2018 (DTA, non-standard folder) */
global simce_fpath `"`sb'/2018/Simce+6°+basico+2018/Simce6b2018_publicas_web/Archivos DTA (Stata)/simce6b2018_comuna_publica_final.dta"'
safe_ingest process_com "6b" "dta" "" 2018 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

/* 6B COMMUNE 2024 (CSV, semicolon) */
global simce_fpath `"`sb'/2024/Simce+6to+basico+2024/6B/Archivos CSV (Planos)/simce6b2024_comuna_preliminar.csv"'
safe_ingest process_com "6b" "csv" ";" 2024 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

di ""
di ">>> 6B COMMUNE complete: `com_count' files ingested so far"


/* ─── 2M COMMUNE: 2006-2018, 2022-2024 ──────────────────────────── */
foreach yr in 2006 2008 2010 2012 2013 2014 2015 2016 2017 {
    local d = uchar(176)
    global simce_fpath `"$simce_raw/`yr'/Simce+2`d'+medio+`yr'/Simce 2`d' Medio `yr'/Archivos DTA (Stata)/simce2m`yr'_comuna_publica_final.dta"'
    safe_ingest process_com "2m" "dta" ";" `yr' "com"
    if `_safe_ok' local com_count = `com_count' + 1
    else local com_fail = `com_fail' + 1
}

/* 2M COMMUNE 2018 (DTA, non-standard folder) */
global simce_fpath `"`sb'/2018/Simce+2°+medio+2018/Simce2m2018_publicas_web/Archivos DTA (Stata)/simce2m2018_comuna_publica_final.dta"'
safe_ingest process_com "2m" "dta" "" 2018 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

/* 2M COMMUNE 2022 (DTA) */
global simce_fpath `"`sb'/2022/Simce+2°+medio+2022/Simce 2° medio 2022/Archivos DTA (Stata)/simce2m2022_comuna_final.dta"'
safe_ingest process_com "2m" "dta" "" 2022 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

/* 2M COMMUNE 2023 (CSV, semicolon) */
global simce_fpath `"`sb'/2023/2m/Archivos CSV (Planos)/simce2m2023_comuna_público_final.csv"'
safe_ingest process_com "2m" "csv" ";" 2023 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

/* 2M COMMUNE 2024 (CSV, semicolon) */
global simce_fpath `"`sb'/2024/Simce+2do+medio+2024/2M/Archivos CSV (Planos)/simce2m2024_comuna_preliminar.csv"'
safe_ingest process_com "2m" "csv" ";" 2024 "com"
if `_safe_ok' local com_count = `com_count' + 1
else local com_fail = `com_fail' + 1

di ""
di ">>> ALL COMMUNE complete: `com_count' files ingested, `com_fail' failed (expected 36)"
if `com_fail' > 0 {
    di as error "WARNING: `com_fail' COMMUNE file(s) could not be ingested. Check paths above."
}


/* ══════════════════════════════════════════════════════════════════════════
   FINAL CLEANING: RBD DATASET
   ══════════════════════════════════════════════════════════════════════════ */

di ""
di "=================================================================="
di "  PHASE 3: Final cleaning and output"
di "=================================================================="

use `"$rbd_accum_path"', clear

/* Ensure rbd is numeric */
capture destring rbd, replace force

/* ── Fix 2015/2017 broken commune codes via 2016 crosswalk ─────────
   In these years cod_com_rbd contains sequential integers (1-54, 1-32)
   instead of real commune codes. Build xwalk from 2016 data.
   ──────────────────────────────────────────────────────────────────── */
tempfile xwalk16
preserve
    keep if agno == 2016 & !missing(cod_com_rbd) & !missing(rbd)
    keep rbd cod_com_rbd
    rename cod_com_rbd cod_com_xwalk
    duplicates drop rbd, force
    save `xwalk16'
restore

/* Apply crosswalk to 2015 */
preserve
    keep if agno == 2015
    local n15 = _N
    drop cod_com_rbd
    merge m:1 rbd using `xwalk16', keep(master match) nogen
    rename cod_com_xwalk cod_com_rbd
    quietly count if missing(cod_com_rbd)
    di "2015 commune fix: `n15' rows, " r(N) " still missing cod_com_rbd"
    tempfile fix15
    save `fix15'
restore
drop if agno == 2015
append using `fix15', force

/* Apply crosswalk to 2017 */
preserve
    keep if agno == 2017
    local n17 = _N
    drop cod_com_rbd
    merge m:1 rbd using `xwalk16', keep(master match) nogen
    rename cod_com_xwalk cod_com_rbd
    quietly count if missing(cod_com_rbd)
    di "2017 commune fix: `n17' rows, " r(N) " still missing cod_com_rbd"
    tempfile fix17
    save `fix17'
restore
drop if agno == 2017
append using `fix17', force

di ""
di "=== Commune code fixes applied (2015/2017 via 2016 crosswalk) ==="

/* Source-specific sector mapping, independently verified across all years.
   SIMCE cod_depe2 is NOT enrollment cod_depe2. Use detailed cod_depe1:
   1/2 municipal, 3 subsidized private, 4 fee-paying private, 5 delegated,
   6 SLEP. Retain the project's convention grouping delegated with public.
   In 2013 delegated schools are already coded 1, also correctly public. */
assert inlist(cod_depe1, 1, 2, 3, 4, 5, 6)
gen byte sector = .
replace sector = 1 if inlist(cod_depe1, 1, 2, 5, 6)
replace sector = 2 if cod_depe1 == 3
replace sector = 3 if cod_depe1 == 4
assert !missing(sector)
label define sector_lbl 1 "Public" 2 "PS" 3 "PP"
label values sector sector_lbl
label variable sector "Sector (1=Public, 2=PS, 3=PP)"

di ""
di "=== Sector variable created from detailed SIMCE cod_depe1 ==="
tab sector agno, missing

/* Variable labels (capture in case var missing in some year subsets) */
capture label variable rbd          "School identifier (RBD)"
capture label variable agno         "Year"
capture label variable cod_com_rbd  "Commune code"
capture label variable cod_depe1    "Dependency type 1"
capture label variable cod_depe2    "Dependency type 2 (SLEP-aware)"
capture label variable n_lect       "N tested students: lectura"
capture label variable n_mate       "N tested students: matematicas"
capture label variable n_total      "N tested students: total"
capture label variable score_lect   "Mean lectura score"
capture label variable score_mate   "Mean matematicas score"
capture label variable grade_std    "Grade (4b/6b/2m)"
capture label variable grade_num    "Grade (numeric: 4=4B, 6=6B, 10=IIM)"
capture label variable noaplica     "Suppression flag (1=suppressed)"
capture label variable pct_ade_lect "% at Adecuado level: lectura"
capture label variable pct_ade_mate "% at Adecuado level: matematicas"
capture label variable pct_ins_lect "% at Insuficiente level: lectura"
capture label variable pct_ins_mate "% at Insuficiente level: matematicas"
capture label variable pct_ele_lect "% at Elemental level: lectura"
capture label variable pct_ele_mate "% at Elemental level: matematicas"

/* Recode suppressed scores (0 or <100) as missing — these are not real SIMCE scores */
foreach v in score_lect score_mate {
    capture confirm variable `v'
    if _rc == 0 {
        quietly count if !missing(`v') & `v' < 100
        di "Recoding `v': " r(N) " values below 100 set to missing"
        replace `v' = . if `v' < 100
    }
}

/* All-zero triples denote unavailable distributions, not zero achievement.
   Preserve an individual zero share when the complete distribution is valid. */
foreach subject in lect mate {
    tempvar unavailable
    gen byte `unavailable' = pct_ins_`subject' == 0 & pct_ele_`subject' == 0 & pct_ade_`subject' == 0
    quietly count if `unavailable'
    di "Unavailable all-zero proficiency distributions (`subject'): " r(N)
    foreach level in ins ele ade {
        replace pct_`level'_`subject' = . if `unavailable'
    }
    assert abs(pct_ins_`subject' + pct_ele_`subject' + pct_ade_`subject' - 100) <= 2 if !missing(pct_ins_`subject', pct_ele_`subject', pct_ade_`subject')
    drop `unavailable'
}

/* Sort and verify uniqueness on year x grade x RBD */
sort agno grade_std rbd
quietly duplicates report agno grade_std rbd
di ""
di "=== Uniqueness check: year x grade x RBD ==="
if r(unique_value) == _N {
    di "PASS: year x grade x RBD is unique (N=" _N ")"
}
else {
    di as error "FAIL: Duplicate rows. N=" _N ", unique=" r(unique_value)
    di "First 20 duplicates:"
    duplicates list agno grade_std rbd in 1/20
}

/* Year x grade coverage */
di ""
di "=== Year x Grade coverage (RBD) ==="
tab agno grade_std

save `"$data_int/simce_rbd_all.dta"', replace
di ""
di "Saved: $data_int/simce_rbd_all.dta (" _N " rows)"


/* ══════════════════════════════════════════════════════════════════════════
   FINAL CLEANING: COMMUNE DATASET
   ══════════════════════════════════════════════════════════════════════════ */
use `"$com_accum_path"', clear

/* Standardize commune key variable name */
capture confirm variable cod_com_off
if _rc == 0 {
    rename cod_com_off cod_com
}
capture destring cod_com, replace force
capture destring agno, replace force

/* Variable labels */
capture label variable grade_std      "Grade (4b/6b/2m)"
capture label variable grade_num      "Grade (numeric: 4=4B, 6=6B, 10=IIM)"
capture label variable agno           "Year"
capture label variable cod_com        "Commune code"
capture label variable score_lect_com "Mean lectura score (commune)"
capture label variable score_mate_com "Mean matematicas score (commune)"

/* Recode suppressed commune scores (<100) as missing */
foreach v in score_lect_com score_mate_com {
    capture confirm variable `v'
    if _rc == 0 {
        quietly count if !missing(`v') & `v' < 100
        di "Recoding `v': " r(N) " values below 100 set to missing"
        replace `v' = . if `v' < 100
    }
}

sort agno grade_std cod_com
quietly duplicates report agno grade_std cod_com
di ""
di "=== Uniqueness check: year x grade x commune ==="
if r(unique_value) == _N {
    di "PASS: year x grade x commune is unique (N=" _N ")"
}
else {
    local n_dup = _N - r(unique_value)
    di "NOTE: `n_dup' duplicate year x grade x commune rows — dropping duplicates"
    duplicates drop agno grade_std cod_com, force
    di "After dedup: N=" _N
}

/* Year x grade coverage */
di ""
di "=== Year x Grade coverage (COMMUNE) ==="
tab agno grade_std

save `"$data_int/simce_com_all.dta"', replace
di ""
di "Saved: $data_int/simce_com_all.dta (" _N " rows)"


/* ══════════════════════════════════════════════════════════════════════════
   SCHEMA SUMMARY
   ══════════════════════════════════════════════════════════════════════════ */

/* Build a schema summary from the final RBD dataset */
use `"$data_int/simce_rbd_all.dta"', clear

tempfile schema_tmp
preserve
    contract agno grade_std, freq(n_schools)
    gen byte has_n_lect  = 0
    gen byte has_score   = 0
    gen byte has_stdlvl  = 0
    gen byte has_depe    = 0
    save `schema_tmp', replace
restore

/* Check variable availability per year x grade */
levelsof agno, local(years)
levelsof grade_std, local(grades)
foreach y of local years {
    foreach g of local grades {
        quietly count if agno == `y' & grade_std == "`g'"
        if r(N) > 0 {
            quietly count if agno == `y' & grade_std == "`g'" & !missing(n_lect)
            local hn = (r(N) > 0)
            quietly count if agno == `y' & grade_std == "`g'" & !missing(score_lect)
            local hs = (r(N) > 0)
            quietly count if agno == `y' & grade_std == "`g'" & !missing(pct_ade_lect)
            local hsl = (r(N) > 0)
            quietly count if agno == `y' & grade_std == "`g'" & !missing(cod_depe1)
            local hd = (r(N) > 0)

            preserve
                use `schema_tmp', clear
                replace has_n_lect = `hn'  if agno == `y' & grade_std == "`g'"
                replace has_score  = `hs'  if agno == `y' & grade_std == "`g'"
                replace has_stdlvl = `hsl' if agno == `y' & grade_std == "`g'"
                replace has_depe   = `hd'  if agno == `y' & grade_std == "`g'"
                save `schema_tmp', replace
            restore
        }
    }
}

use `schema_tmp', clear
export delimited using `"$logs/01_schema_summary.csv"', replace
di ""
di "=== Schema Summary ==="
list, sep(6) noobs


/* ── Cleanup ──────────────────────────────────────────────────────────── */
capture program drop process_rbd
capture program drop process_com
capture program drop safe_ingest

/* Clean up disk-based accumulators */
capture erase `"$rbd_accum_path"'
capture erase `"$com_accum_path"'

/* Drop temporary globals */
macro drop simce_fpath rbd_accum_path com_accum_path

di ""
di "=== 01_ingest_simce.do COMPLETE ==="
di "RBD files ingested:     `rbd_count' (`rbd_fail' failed)"
di "Commune files ingested: `com_count' (`com_fail' failed)"
if `rbd_fail' + `com_fail' > 0 {
    di as error "WARNING: Some files failed. Review log above for >>> FAILED lines."
}
log close
exit, clear
