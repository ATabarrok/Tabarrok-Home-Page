"""Parents' schooling and household income from the SIMCE parent questionnaires. RESTRICTED INPUT.

Output, all restricted:
  <work>/pupil/parents_4b_<year>.pkl            grade-4 questionnaire of each starting year:
                                                mrun, fedu, medu (years of schooling), inc
                                                (monthly household income, thousands of pesos),
                                                linc (its logarithm)
  <work>/pupil/parents_later_<grade>_<year>.pkl the same pupils' later questionnaires (grades 6,
                                                8 and 10): mrun, fedu_l, medu_l and pct_l, the
                                                household's income percentile among the parents
                                                answering that questionnaire

The questionnaire file (cpad) is keyed by idalumno; the score file of the same grade and year
links idalumno to the masked pupil identifier (mrun).

Schooling. Every year lists the same ladder in the same order: no schooling, grades 1-8 of
basic education, years 1-4 of secondary, 4 or 5 years of technical secondary, incomplete and
complete technical tertiary, incomplete and complete university, master's, doctorate. Years of
schooling by position: 0, 1-8, 9-12, 12, 13, 15, 14, 17, 19, 21. "No father/mother", "does not
know", blank and double marks are missing. Codes start at a different number in different
years (the fifth entry of GRADE4 below is the code of "no schooling").

Income. Monthly household income in brackets, 13 brackets to 2008 and 15 from 2009. Bracket
midpoints; the open top bracket is its lower bound times 1.25. Pesos are nominal, so the
logarithm of income is compared only within a starting cohort, and later questionnaires enter
as percentiles.

The files of 2008-2011 store each answer as one 0/1 column per option; a pupil with exactly
one mark gets that option. The questionnaire of 2017 has two forms; both are read.

Usage:  python 22_parent_answers.py
"""

import re

import numpy as np
import pandas as pd

import config as cfg

YEARS_BY_POSITION = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 12, 13, 15, 14, 17, 19, 21]
BOUNDS = [0, 100, 200, 300, 400, 500, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000, 2200]
# grade-4 year: father, mother, income question; storage; code of "no schooling"; first income code; brackets
GRADE4 = {
    2005: ("cpad_p07", "cpad_p08", "cpad_p12", "single", 0, 0, 13),
    2006: ("cpad_p09", "cpad_p10", "cpad_p15", "single", 2, 1, 13),
    2007: ("cpad_p06", "cpad_p07", "cpad_p08", "single", 2, 1, 13),
    2008: ("cpad_p05", "cpad_p06", "cpad_p07", "dummies", 2, 1, 13),
    2009: ("cpad_p09_01", "cpad_p09_02", "cpad_p10", "dummies", 1, 1, 15),
    2010: ("cpad_p09", "cpad_p10", "cpad_p11", "dummies", 1, 1, 15),
    2011: ("cpad_p08", "cpad_p09", "cpad_p10", "dummies", 1, 1, 15),
    2012: ("cpad_p08", "cpad_p09", "cpad_p10", "single", 1, 1, 15),
    2013: ("cpad_p07", "cpad_p08", "cpad_p09", "single", 1, 1, 15),
    2014: ("cpad_p04", "cpad_p05", "cpad_p06", "single", 0, 1, 15),
    2015: ("cpad_p07", "cpad_p08", "cpad_p10", "single", 1, 1, 15),
    2016: ("cpad_p07", "cpad_p08", "cpad_p10", "single", 1, 1, 15),
    2017: ("cpad_p06", "cpad_p07", "cpad_p10", "single", 1, 1, 15),
    2018: ("cpad_p06", "cpad_p07", "cpad_p10", "single", 1, 1, 15),
    2022: ("cpad_p05", "cpad_p04", "cpad_p03", "single", 1, 1, 15),
}
# (grade, year) of a later questionnaire: father, mother, income question; storage
LATER = {
    ("6b", 2013): ("cpad_p07", "cpad_p08", "cpad_p09", "single"), ("6b", 2014): ("cpad_p04", "cpad_p05", "cpad_p06", "single"),
    ("6b", 2018): ("cpad_p06", "cpad_p07", "cpad_p10", "single"),
    ("8b", 2011): ("cpad_p08", "cpad_p09", "cpad_p10", "dummies"), ("8b", 2013): ("cpad_p07", "cpad_p08", "cpad_p09", "single"),
    ("8b", 2014): ("cpad_p04", "cpad_p05", "cpad_p06", "single"), ("8b", 2015): ("cpad_p07", "cpad_p08", "cpad_p10", "single"),
    ("2m", 2012): ("cpad_p08", "cpad_p09", "cpad_p10", "single"), ("2m", 2013): ("cpad_p07", "cpad_p08", "cpad_p09", "single"),
    ("2m", 2015): ("cpad_p07", "cpad_p08", "cpad_p10", "single"), ("2m", 2016): ("cpad_p07", "cpad_p08", "cpad_p10", "single"),
    ("2m", 2017): ("cpad_p06", "cpad_p07", "cpad_p10", "single"), ("2m", 2018): ("cpad_p06", "cpad_p07", "cpad_p10", "single"),
    ("2m", 2022): ("cpad_p05", "cpad_p04", "cpad_p03", "single"), ("2m", 2023): ("p05", "p04", "p03", "single"),
}


def read_table(path, want=None):
    with open(path, encoding="latin-1") as fh:
        head = fh.readline()
    sep = max("|;,\t", key=head.count)
    names = [c.strip().strip('"').lower() for c in head.strip().split(sep)]
    use = None
    if want is not None:
        use = [i for i, n in enumerate(names) if want(n)]
    d = pd.read_csv(path, sep=sep, encoding="latin-1", low_memory=False, header=None, skiprows=1, usecols=use)
    d.columns = [names[i] for i in use] if use is not None else names[:d.shape[1]]
    return d


def num(s):
    if s.dtype == object:
        s = s.astype(str).str.replace(",", ".", regex=False)
    return pd.to_numeric(s, errors="coerce")


def answer(d, var, mode):
    """The code of the option chosen."""
    if mode == "single":
        return num(d[var])
    cols = sorted(c for c in d.columns if re.fullmatch(re.escape(var) + r"_\d\d", c))
    m = d[cols].apply(num).fillna(0).to_numpy()
    one = (m == 1).sum(axis=1) == 1
    code = (m == 1).argmax(axis=1) + 1
    return pd.Series(np.where(one, code, np.nan), index=d.index)


def schooling(code, start):
    pos = code - start
    ok = pos.between(0, len(YEARS_BY_POSITION) - 1)
    return pos.where(ok).map(lambda p: YEARS_BY_POSITION[int(p)] if pd.notna(p) else np.nan)


def income(code, first, k):
    pos = code - first
    mid = [(BOUNDS[i] + BOUNDS[i + 1]) / 2 for i in range(k - 1)] + [BOUNDS[k - 1] * 1.25]
    mid[0] = 50
    ok = pos.between(0, k - 1)
    return pos.where(ok).map(lambda p: mid[int(p)] if pd.notna(p) else np.nan)



def grade4(y):
    fa, mo, inc, mode, start, first, k = GRADE4[y]
    folder = next(cfg.RESTRICTED.glob(f"Simce cuarto*{y}*"))
    need = lambda n: n in ("idalumno",) or any(n == v or n.startswith(v + "_") for v in (fa, mo, inc))
    q = pd.concat([read_table(f, need) for f in sorted(folder.glob(f"*/simce4b{y}_cpad*"))
                   if f.suffix.lower() in (".csv", ".txt")], ignore_index=True)
    alu = next(f for f in sorted(folder.glob(f"*/simce4b{y}_alu*")) if f.suffix.lower() in (".csv", ".txt"))
    ids = read_table(alu, lambda n: n in ("idalumno", "mrun"))
    p = pd.DataFrame({"idalumno": num(q["idalumno"]),
                      "fedu": schooling(answer(q, fa, mode), start),
                      "medu": schooling(answer(q, mo, mode), start),
                      "inc": income(answer(q, inc, mode), first, k)})
    p = p.dropna(subset=["idalumno"]).drop_duplicates("idalumno")
    ids = pd.DataFrame({"idalumno": num(ids["idalumno"]), "mrun": num(ids["mrun"])}).dropna()
    p = p.merge(ids, on="idalumno", how="inner")
    p["mrun"] = p.mrun.astype("int64")
    p["answered"] = p[["fedu", "medu", "inc"]].notna().sum(axis=1)
    p = p.sort_values(["mrun", "answered"], ascending=[True, False]).drop_duplicates("mrun")
    p["linc"] = np.log(p.inc)
    return p[["mrun", "fedu", "medu", "inc", "linc"]]


def later(tag, y):
    fa, mo, inc, mode = LATER[(tag, y)]
    need = lambda n: n == "idalumno" or any(n == v or n.startswith(v + "_") for v in (fa, mo, inc))
    q = pd.concat([read_table(f, need) for f in sorted(cfg.RESTRICTED.rglob(f"simce{tag}{y}_cpad*"))
                   if f.suffix.lower() in (".csv", ".txt")], ignore_index=True)
    alu = next(f for f in sorted(cfg.RESTRICTED.rglob(f"simce{tag}{y}_alu*")) if f.suffix.lower() in (".csv", ".txt"))
    ids = read_table(alu, lambda n: n in ("idalumno", "mrun"))
    ids = pd.DataFrame({"idalumno": num(ids["idalumno"]), "mrun": num(ids["mrun"])}).dropna()
    code = answer(q, inc, mode)
    code = code.where(code.between(1, 15))
    p = pd.DataFrame({"idalumno": num(q["idalumno"]),
                      "fedu_l": schooling(answer(q, fa, mode), 1),
                      "medu_l": schooling(answer(q, mo, mode), 1),
                      "pct_l": code.rank(pct=True, method="average")})
    p = p.dropna(subset=["idalumno"]).drop_duplicates("idalumno").merge(ids, on="idalumno", how="inner")
    p["mrun"] = p.mrun.astype("int64")
    return p[["mrun", "fedu_l", "medu_l", "pct_l"]].drop_duplicates("mrun")


def main():
    cfg.make_dirs()
    for y in GRADE4:
        grade4(y).to_pickle(cfg.PUPIL / f"parents_4b_{y}.pkl")
        print("grade 4", y, flush=True)
    for tag, y in LATER:
        later(tag, y).to_pickle(cfg.PUPIL / f"parents_later_{tag}_{y}.pkl")
        print(tag, y, flush=True)


if __name__ == "__main__":
    main()
