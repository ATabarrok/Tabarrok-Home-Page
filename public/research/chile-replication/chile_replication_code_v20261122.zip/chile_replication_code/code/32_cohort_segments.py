"""Appendix Table D1 (segments of schooling) and Appendix Table D3 (each starting cohort and end grade).

Pupil-level regressions of the score at the end grade on the cohort's own private share at that
grade, the pupil's own earlier score in the same subject, father's and mother's schooling, log
household income, log cohort size and region-by-cohort effects. Pupils are on time and tested at
both ends of the segment. Standard errors clustered by market. Tables report coefficients per
ten percentage points of share.

Panel C of Appendix Table D1 stacks the three adjacent segments (grade 4 to 6, 6 to 8, 8 to 10) with one
coefficient on the share, effects for each region, cohort and segment, and control slopes that
differ by segment. The p-value is from a Wald test that the three segment coefficients are equal.

Output: tab_pupil_segments_pooled.tex, tab_pupil_bycohort.tex.
Usage:  python 32_cohort_segments.py
"""

import warnings

import numpy as np
import pyfixest as pf
from scipy import stats

import config as cfg
import pupils as P

warnings.filterwarnings("ignore")
PAR = "+".join(P.PAR)
SEGMENTS = ((4, 6), (6, 8), (8, 10), (6, 10), (4, 8), (4, 10))
ADJACENT = ((4, 6), (6, 8), (8, 10))
CTRL = ["prev", "fedu", "medu", "linc", "lnn0"]


def fit(data, formula):
    if data.market.nunique() < 30:
        return None
    r = P.fit(formula, data, "share")
    r["cohorts"] = data.cohort.nunique()
    return r


def stacked(d):
    """Common share coefficient over the adjacent segments, and the Wald test of equality."""
    d = d.dropna(subset=["market"]).copy()
    d["seg"] = d.g0.astype(str) + d.g1.astype(str)
    d["cs"] = d.groupby(["region", "cohort", "seg"]).ngroup()
    names = sorted(d.seg.unique())
    inter = []
    for k in names:
        for v in CTRL:
            d[f"{v}_{k}"] = d[v] * (d.seg == k)
            inter.append(f"{v}_{k}")
        d[f"share_{k}"] = d.share * (d.seg == k)
    rhs = "+".join(inter)
    common = pf.feols(f"score~share+{rhs}|cs", d, vcov=P.VC).tidy().loc["share"]
    sep = pf.feols("score~" + "+".join(f"share_{k}" for k in names) + f"+{rhs}|cs", d, vcov=P.VC)
    cn = list(sep._coefnames)
    idx = [cn.index(f"share_{k}") for k in names]
    b = np.asarray(sep.coef())[idx]
    V = np.asarray(sep._vcov)[np.ix_(idx, idx)]
    R = np.array([[1, -1, 0], [0, 1, -1]], float)
    w = float((R @ b) @ np.linalg.solve(R @ V @ R.T, R @ b))
    return dict(b=common["Estimate"], se=common["Std. Error"], p=common["Pr(>|t|)"], p_equal=float(stats.chi2.sf(w, 2)),
                pupils=d.mrun.nunique(), cohorts=d.cohort.nunique())


def main():
    cfg.make_dirs()
    d = P.segment_frame()
    f0 = f"score~share+lnn0+prev+{PAR}"
    f1 = f"score~share+lnn0+prev:C(cohort)+{PAR}|rc"
    by_cohort, pooled, segment, latest, common = {}, {}, {}, {}, {}
    for sub, name in P.SUBJECTS:
        s = d[d.subject == sub]
        for c in sorted(d.cohort.unique()):
            for g1 in (6, 8, 10):
                k = s[(s.cohort == c) & (s.g0 == 4) & (s.g1 == g1)]
                by_cohort[name, c, g1] = fit(k, f0 + "|region") if len(k) else None
        for g1 in (6, 8, 10):
            pooled[name, g1] = fit(s[(s.g0 == 4) & (s.g1 == g1)], f0 + "|rc")
        for g0, g1 in SEGMENTS:
            segment[name, g0, g1] = fit(s[(s.g0 == g0) & (s.g1 == g1)], f0 + "|rc")
        k = s[s.g1 == 10]
        later = k[k.latest & (k.g0 > 4)].cohort.unique()
        latest[name, "all"] = fit(k[k.latest], f1)
        latest[name, "later"] = fit(k[k.latest & (k.g0 > 4)], f1)
        latest[name, "same"] = fit(k[(k.g0 == 4) & k.cohort.isin(later)], f1)
        adj = s[[(a, b) in ADJACENT for a, b in zip(s.g0, s.g1)]]
        common[name] = stacked(adj)
        print(name, "done", flush=True)

    M, R = "Mathematics", "Reading"
    cell = lambda r: f"{P.num(r['b'] / 10, 3)}{P.stars(r['p'])}"
    se = lambda r: f"({r['se'] / 10:.3f})"

    T = [r" & Cohorts & Mathematics & Reading & Pupils \\ \midrule",
         r"\multicolumn{5}{l}{\textit{A. Control: own score at the start of the segment}} \\"]
    for i, (g0, g1) in enumerate(SEGMENTS):
        if i == 0:
            T += [r"\multicolumn{5}{l}{Two-year segments} \\"]
        if i == len(ADJACENT):
            T += [r"\addlinespace", r"\multicolumn{5}{l}{Longer spans} \\"]
        a, b = segment[M, g0, g1], segment[R, g0, g1]
        T += [f"\\quad Grade {g0} to grade {g1} & {a['cohorts']} & {cell(a)} & {cell(b)} & {a['N']:,} \\\\", f" & & {se(a)} & {se(b)} & \\\\"]
    T += [r"\addlinespace", r"\multicolumn{5}{l}{\textit{B. Grade 10, control: most recent earlier score}} \\"]
    for key, lab in (("all", "All cohorts"), ("later", "Cohorts with a grade-6 or grade-8 test"), ("same", "Same cohorts, grade-4 score")):
        a, b = latest[M, key], latest[R, key]
        T += [f"{lab} & {a['cohorts']} & {cell(a)} & {cell(b)} & {a['N']:,} \\\\", f" & & {se(a)} & {se(b)} & \\\\"]
    a, b = common[M], common[R]
    T += [r"\addlinespace", r"\multicolumn{5}{l}{\textit{C. One effect per two-year segment, the three adjacent segments together}} \\",
          f"Common effect & {a['cohorts']} & {cell(a)} & {cell(b)} & {a['pupils']:,} \\\\", f" & & {se(a)} & {se(b)} & \\\\",
          f"Equality of the three segments, $p$-value & & {a['p_equal']:.3f} & {b['p_equal']:.3f} & \\\\", r"\bottomrule"]
    P.write_table("tab_pupil_segments_pooled", T)

    T = [r" & \multicolumn{3}{c}{Mathematics} & \multicolumn{3}{c}{Reading} \\ \cmidrule(lr){2-4}\cmidrule(lr){5-7}",
         r"Starting cohort & Grade 6 & Grade 8 & Grade 10 & Grade 6 & Grade 8 & Grade 10 \\ \midrule"]
    for c in sorted(d.cohort.unique()):
        rows = [by_cohort[name, c, g1] for name in (M, R) for g1 in (6, 8, 10)]
        if not any(rows):
            continue
        T += [" & ".join([str(c)] + [cell(r) if r else "" for r in rows]) + r" \\", " & ".join([""] + [se(r) if r else "" for r in rows]) + r" \\"]
    rows = [pooled[name, g1] for name in (M, R) for g1 in (6, 8, 10)]
    T += [" & ".join(["\\midrule\nPooled"] + [cell(r) for r in rows]) + r" \\", " & ".join([""] + [se(r) for r in rows]) + r" \\", r"\bottomrule"]
    P.write_table("tab_pupil_bycohort", T)


if __name__ == "__main__":
    main()
