"""Commune and market panels from the public school files, and the tables estimated on them:
Appendix Table B4 (summary statistics), Table 2 (long differences in the manner of Hsieh and Urquiola),
Appendix Table C3 (all pairs of waves), C4 (panel), C5 (policy eras) and C6 (OECD markets).

Inputs, built by the Stata scripts 01 to 04 from public files:
    <work>/derived/simce_rbd_all.dta      school mean scores, grades 4, 6 and 10
    <work>/derived/enrollment_all.dta     enrolment by school and grade
    <work>/derived/high_pp_communes.dta   the excluded communes
and read here:
    data/public/simce_schools/**/simce8b<year>_rbd*.dta    school mean scores, grade 8
    data/public/oecd/oecd_municipalities.csv               OECD functional urban areas

Also written, for the pupil-level scripts:
    <work>/derived/market_crosswalk.csv   commune -> market (an OECD functional urban area, or the
                                          commune itself outside those areas)
    <work>/derived/high_pp_communes.csv

Panels. One row per commune (or market), grade, subject and year: the mean score of public and
subsidized private schools weighted by pupils tested, and the subsidized private share of
enrolment in the grade. Paid private schools and the nine excluded communes are left out.

Estimation. Weighted least squares with absorbed effects and standard errors clustered by
commune or market; groups with a single observation are dropped. Tables report coefficients per
ten percentage points of share.

Usage:  python 10_commune_tables.py
"""

import re
import warnings

import numpy as np
import pandas as pd
import pyfixest as pf
from scipy import stats

import config as cfg
import pupils as P

warnings.filterwarnings("ignore")
SECONDARY = [310, 410, 510, 610, 710, 810, 910]
GRADES = [("4b", [110], "mat_gra_4"), ("6b", [110], "mat_gra_6"), ("8b", [110], "mat_gra_8"), ("2m", SECONDARY, "mat_gra_2")]
RECODE = {1106: 1401, 1201: 15101, 10501: 14101, 10503: 14202, 10504: 14201, 10505: 14203, 10506: 14103, 10507: 14104,
          10509: 14106, 10510: 14107, 10511: 14108, 10512: 14204, 5106: 5801, 5108: 5804, 5505: 5802, 5507: 5803,
          8401: 16101, 8402: 16102, 8403: 16202, 8404: 16203, 8405: 16302, 8406: 16103, 8407: 16104, 8408: 16204,
          8409: 16303, 8410: 16105, 8411: 16106, 8412: 16205, 8413: 16107, 8414: 16201, 8415: 16206, 8416: 16301,
          8417: 16304, 8418: 16108, 8419: 16305, 8420: 16207, 8421: 16109}
SANTIAGO = 900011


def read(path, **kw):
    return pd.read_stata(path, convert_categoricals=False, **kw)


# ---------------------------------------------------------------------------- data
def school_files():
    """School scores for grades 4, 6, 8 and 10, and enrolment by school."""
    cols = ["agno", "grade_std", "rbd", "cod_com_rbd", "sector", "n_lect", "n_mate", "score_lect", "score_mate"]
    s = read(cfg.DERIVED / "simce_rbd_all.dta", columns=cols)
    e = read(cfg.DERIVED / "enrollment_all.dta", columns=["agno", "rbd", "cod_com_rbd", "sector", "cod_ense"] + [f"mat_gra_{g}" for g in (2, 4, 6, 8)])
    # the commune of a school in the enrolment file of the same year stands in for an invalid code
    location = e.dropna(subset=["cod_com_rbd"]).groupby(["agno", "rbd"]).cod_com_rbd.first()
    adds = []
    for p in sorted(cfg.SIMCE_SCHOOLS.rglob("*.dta")):
        if not re.match(r"simce8b\d{4}_rbd", p.name, re.I):
            continue
        z = read(p)
        z.columns = z.columns.str.lower()
        yr = int(z.agno.iloc[0])
        if yr < 2005:
            continue
        code = "cod_com_rbd_2014" if "cod_com_rbd_2014" in z else "cod_com_rbd_2013" if "cod_com_rbd_2013" in z else "cod_com_rbd"
        q = z[["agno", "rbd", code, "cod_depe1", "nalu_lect8b_rbd", "nalu_mate8b_rbd", "prom_lect8b_rbd", "prom_mate8b_rbd"]].copy()
        q.columns = ["agno", "rbd", "cod_com_rbd", "sector", "n_lect", "n_mate", "score_lect", "score_mate"]
        for c in q:
            q[c] = pd.to_numeric(q[c], errors="coerce")
        assert q.sector.isin([1, 2, 3, 4, 5, 6]).all()
        q["sector"] = q.sector.map({1: 1, 2: 1, 3: 2, 4: 3, 5: 1, 6: 1})
        q["grade_std"] = "8b"
        for sub in ("lect", "mate"):
            q.loc[q[f"score_{sub}"].lt(100), f"score_{sub}"] = np.nan      # suppressed scores
        q["cod_com_rbd"] = q.cod_com_rbd.astype(float)
        invalid = q.cod_com_rbd.lt(1000) | q.cod_com_rbd.isna()
        fallback = pd.Series([location.get((a, r), np.nan) for a, r in zip(q.agno, q.rbd)], index=q.index)
        q.loc[invalid, "cod_com_rbd"] = fallback[invalid]
        q["cod_com_rbd"] = q.cod_com_rbd.replace(RECODE)
        adds.append(q[cols])
    s = pd.concat([s, *adds], ignore_index=True)
    assert not s.duplicated(["agno", "grade_std", "rbd"]).any()
    return s, e


def crosswalk(s, e):
    """Commune -> market. Every commune with a public or subsidized private school."""
    codes = set(s.loc[(s.sector != 3) & s.grade_std.isin(["4b", "2m"]), "cod_com_rbd"].dropna())
    codes |= set(e.loc[(e.sector != 3) & e.cod_ense.isin([110] + SECONDARY), "cod_com_rbd"].dropna())
    src = pd.read_csv(cfg.OECD_FUA, dtype=str).fillna("")
    src = src[src["ISO3 code"] == "CHL"]
    fua = {int(r["Municipality ID"]): 900000 + int(r["FUA ID"][2:5]) for _, r in src.iterrows() if r["FUA ID"]}
    cw = pd.DataFrame({"cod_com": sorted(int(c) for c in codes)})
    cw["oecd_fua"] = cw.cod_com.map(fua).fillna(cw.cod_com).astype(int)
    cw.to_csv(cfg.CROSSWALK, index=False)
    return cw


def panel(s, e, cw=None):
    """Commune panel, or market panel when a crosswalk is given."""
    s, e = s.copy(), e.copy()
    if cw is not None:
        for d in (s, e):
            d["cod_com_rbd"] = d.cod_com_rbd.map(dict(zip(cw.cod_com, cw.oecd_fua)))
        s, e = s.dropna(subset=["cod_com_rbd"]), e.dropna(subset=["cod_com_rbd"])
    rows = []
    for grade, codes, col in GRADES:
        z = e[e.cod_ense.isin(codes)].copy()
        z["total"] = z[col].fillna(0)
        z["private"] = z.total * z.sector.eq(2)
        shares = z.groupby(["cod_com_rbd", "agno"])[["total", "private"]].sum().reset_index()
        shares["share_subv"] = shares.private / shares.total
        for sub in ("lect", "mate"):
            z = s[s.grade_std.eq(grade)].copy()
            z["wt_tested"] = z["n_" + sub].fillna(0).where(z["score_" + sub].notna(), 0)
            z["num"] = (z["score_" + sub] * z.wt_tested).fillna(0)
            z = z.groupby(["cod_com_rbd", "agno"])[["num", "wt_tested"]].sum().reset_index().merge(shares, on=["cod_com_rbd", "agno"], how="left", validate="one_to_one")
            z["score_mean"], z["subject"], z["grade_std"] = z.num / z.wt_tested, sub, grade
            rows.append(z[z.score_mean.notna() & z.share_subv.notna() & z.wt_tested.gt(0)])
    p = pd.concat(rows, ignore_index=True).rename(columns={"cod_com_rbd": "cod_com"}).drop(columns=["num", "total", "private"])
    p["cod_com"], p["agno"] = p.cod_com.astype(int), p.agno.astype(int)
    p["cell"] = p.groupby(["agno", "grade_std", "subject"]).ngroup()
    p["mg"] = p.groupby(["cod_com", "grade_std"]).ngroup()
    return p


def long_difference(s, e, grade, codes, col, year):
    """Change in a commune's mean score (reading and mathematics pooled) and in its private share
    between the first year and 2024."""
    z = s[s.grade_std.eq(grade)].copy()
    for sub in ("lect", "mate"):
        z["n_" + sub] = z["n_" + sub].where(z["score_" + sub].notna() & (z["n_" + sub] > 0), 0).fillna(0)
        z["ws_" + sub] = (z["score_" + sub] * z["n_" + sub]).fillna(0)
    t = z.groupby(["cod_com_rbd", "agno"])[["n_lect", "n_mate", "ws_lect", "ws_mate"]].sum()
    x = e[e.cod_ense.isin(codes)].copy()
    x["total"] = x[col].fillna(0)
    x["private"] = x.total * (x.sector == 2)
    t = t.join(x.groupby(["cod_com_rbd", "agno"])[["private", "total"]].sum(), how="outer").reset_index()
    t["score"] = (t.ws_lect + t.ws_mate) / (t.n_lect + t.n_mate)
    t["wt"] = t.n_lect + t.n_mate
    t["share"] = t.private / t.total.where(t.total > 0)
    a = t[t.agno == year][["cod_com_rbd", "score", "wt", "share"]].rename(columns={"score": "score_base", "wt": "wt_base", "share": "share_base"})
    a = a.merge(t[t.agno == 2024][["cod_com_rbd", "score", "wt", "share"]], on="cod_com_rbd", validate="one_to_one")
    a["gain"], a["dshare"], a["weight"] = a.score - a.score_base, a.share - a.share_base, (a.wt + a.wt_base) / 2
    return a.dropna(subset=["gain", "dshare", "score_base", "share_base", "weight"]).rename(columns={"cod_com_rbd": "cod_com"})


# ---------------------------------------------------------------------------- estimation
def fit(formula, data, weights, term, cluster="cod_com"):
    data = data.assign(one=1.0)
    m = pf.feols(formula, data, weights=weights, vcov={"CRV1": cluster}, fixef_rm="singleton")
    t = m.tidy()
    terms = [term] if isinstance(term, str) else term
    r = dict(N=int(m._N), clusters=int(m._data[cluster].nunique()), r2=float(m._r2), model=m)   # counts are of the estimation sample
    for k in terms:
        r[k] = dict(b=t.loc[k, "Estimate"], se=t.loc[k, "Std. Error"], p=t.loc[k, "Pr(>|t|)"])
    return r


def cell(r, d=3, stars=True):
    return P.num(r['b'] / 10, d) + (P.stars(r['p']) if stars else '')


def se(r, d=3):
    return f"({r['se'] / 10:.{d}f})"


def main():
    cfg.make_dirs()
    s, e = school_files()
    hp = read(cfg.DERIVED / "high_pp_communes.dta")[["cod_com", "high_pp_commune"]]
    hp.to_csv(cfg.HIGH_PP, index=False)
    excluded = set(hp.loc[hp.high_pp_commune.eq(1), "cod_com"])
    cw = crosswalk(s, e)
    s = s[s.sector.isin([1, 2]) & ~s.cod_com_rbd.isin(excluded) & s.cod_com_rbd.notna()].copy()
    e = e[e.sector.isin([1, 2]) & ~e.cod_com_rbd.isin(excluded) & e.cod_com_rbd.notna()].copy()
    cp, op = panel(s, e), panel(s, e, cw)

    # Appendix Table B4
    rows = [("Commune mean SIMCE score", cp.score_mean), ("Reading mean SIMCE score", cp.loc[cp.subject.eq("lect"), "score_mean"]),
            ("Mathematics mean SIMCE score", cp.loc[cp.subject.eq("mate"), "score_mean"]), (r"Public enrollment share (\%)", 100 * (1 - cp.share_subv)),
            (r"Private enrollment share (\%)", 100 * cp.share_subv), ("Tested pupils per subject cell", cp.wt_tested)]
    T = [r" & Mean & SD & Min & Max & N \\ \midrule"]
    T += [lab + " & " + " & ".join([f"{v.mean():,.2f}", f"{v.std():,.2f}", f"{v.min():,.2f}", f"{v.max():,.2f}", f"{v.count():,}"]) + r" \\" for lab, v in rows]
    P.write_table("tab_sumstats_allgrades", T + [r"\bottomrule"])

    # Appendix Table C4
    w = "wt_tested"
    f0 = "score_mean~share_subv|cod_com+cell"
    C1 = [fit(f0, cp, w, "share_subv"), fit(f0, cp[cp.subject == "lect"], w, "share_subv"), fit(f0, cp[cp.subject == "mate"], w, "share_subv"),
          fit("score_mean~share_subv|mg+cell", cp, w, "share_subv"), fit(f0, op, w, "share_subv")]
    T = [" & " + " & ".join(f"({i})" for i in range(1, 6)) + r" \\", r" & Commune FE & Reading & Math & C$\times$G FE & Full OECD \\ \midrule",
         "Private share & " + " & ".join(cell(r["share_subv"]) for r in C1) + r" \\", " & " + " & ".join(se(r["share_subv"]) for r in C1) + r" \\", r"\midrule",
         "Observations & " + " & ".join(f"{r['N']:,}" for r in C1) + r" \\", "Clusters & " + " & ".join(f"{r['clusters']:,}" for r in C1) + r" \\",
         "R$^2$ & " + " & ".join(f"{r['r2']:.3f}" for r in C1) + r" \\"]
    P.write_table("tab_panel_allgrades", T)

    # Table 2
    L4 = long_difference(s, e, "4b", [110], "mat_gra_4", 2005)
    L10 = long_difference(s, e, "2m", SECONDARY, "mat_gra_2", 2006)
    H = [fit("gain~dshare+score_base+share_base", L4, "weight", "dshare"), fit("gain~dshare+score_base+share_base", L10, "weight", "dshare"),
         fit(f0, cp[cp.grade_std == "2m"], w, "share_subv")]
    T = [r" & (1) & (2) & (3) \\", r" & LD grade 4 & LD grade 10 & Panel grade 10 \\ \midrule",
         f"Change in private share & {cell(H[0]['dshare'])} & {cell(H[1]['dshare'])} &  \\\\", f" & {se(H[0]['dshare'])} & {se(H[1]['dshare'])} &  \\\\",
         f"Private share & & & {cell(H[2]['share_subv'])} \\\\", f" & & & {se(H[2]['share_subv'])} \\\\", r"\midrule",
         "Observations & " + " & ".join(f"{r['N']:,}" for r in H) + r" \\", "Communes & " + " & ".join(f"{r['clusters']:,}" for r in H) + r" \\",
         "R$^2$ & " + " & ".join(f"{r['r2']:.3f}" for r in H) + r" \\"]
    P.write_table("tab_hu_benchmark_commune", T)

    # Appendix Table C5
    era = cp.copy()
    era["era"] = np.select([era.agno.between(2005, 2009), era.agno.between(2010, 2014), era.agno.between(2015, 2019), era.agno.between(2022, 2024)], [1, 2, 3, 4], 0)
    for k in range(1, 5):
        era[f"x{k}"] = era.share_subv * (era.era == k)
    sep = [fit(f0, era[era.era == k], w, "share_subv") for k in range(1, 5)]
    xs = [f"x{k}" for k in range(1, 5)]
    pooled = fit("score_mean~x1+x2+x3+x4|cod_com+cell", era, w, xs)
    m = pooled["model"]
    names = list(m._coefnames)
    idx = [names.index(x) for x in xs]
    b, V = np.asarray(m.coef())[idx], np.asarray(m._vcov)[np.ix_(idx, idx)]
    R = np.array([[1, -1, 0, 0], [1, 0, -1, 0], [1, 0, 0, -1]], float)
    F = float((R @ b) @ np.linalg.solve(R @ V @ R.T, R @ b)) / 3
    p_equal = float(stats.f.sf(F, 3, pooled["clusters"] - 1))
    T = [r"\begin{table}[htbp]\centering\small", r"\caption{Panel Estimates by Policy Era: Commune Benchmark\label{tab:panelera}}",
         r"\begin{threeparttable}\begin{tabular}{lrrr}\toprule", r"Era & Separate regressions & Pooled, common FE & N (separate) \\ \midrule"]
    for k, lab in enumerate(("2005--2009", "2010--2014", "2015--2019", "2022--2024"), 1):
        a, c = sep[k - 1]["share_subv"], pooled[f"x{k}"]
        T.append(f"{lab} & {cell(a)} {se(a)} & {cell(c)} {se(c)} & {sep[k - 1]['N']:,} \\\\")
    T += [r"\bottomrule\end{tabular}\begin{tablenotes}[flushleft]\footnotesize\item Score differences are per ten-percentage-point higher private share. "
          r"Grades 4, 6, 8 and 10. Separate regressions use era-specific commune effects; pooled interactions use common commune effects. "
          r"Both include grade $\times$ subject $\times$ year effects, tested-count weights and commune-clustered standard errors. "
          f"Equality of pooled slopes: $p={p_equal:.3f}$. " + r"$^{*}p<0.10$, $^{**}p<0.05$, $^{***}p<0.01$.",
          r"\end{tablenotes}\end{threeparttable}\end{table}"]
    P.write_table("tab_panel_era_allgrades", T)

    # Appendix Table C6
    rows = [("Baseline OECD", C1[4]),
            ("Excluding Santiago", fit(f0, op[op.cod_com != SANTIAGO], w, "share_subv")),
            ("Equal cell weights", fit(f0, op, "one", "share_subv"))]
    T = [r"\begin{table}[htbp]\centering\small", r"\caption{Additional OECD Market Robustness\label{tab:robustmarket}}",
         r"\begin{threeparttable}\begin{tabular}{lr}\toprule", r"Specification & All-grade panel \\ \midrule"]
    T += [f"{lab} & {cell(a['share_subv'])} {se(a['share_subv'])} \\\\" for lab, a in rows]
    T += [r"\bottomrule\end{tabular}\begin{tablenotes}[flushleft]\footnotesize\item Score differences are per ten-percentage-point higher private share. "
          r"All definitions retain the public/PS universe and the original commune exclusions. The panel has market and grade-by-subject-by-year effects. "
          r"Standard errors are clustered by market. "
          r"Equal-cell estimates assign each observation weight one.", r"\end{tablenotes}\end{threeparttable}\end{table}"]
    P.write_table("tab_robust_oecd", T)

    # Appendix Table C3: every pair of assessment waves within a commune
    B = {}
    for grade in ("4b", "2m"):
        q = cp[cp.grade_std == grade][["cod_com", "agno", "subject", "score_mean", "share_subv", "wt_tested"]].copy()
        waves = sorted(q.agno.unique())
        before = {wv: (waves[i - 1] if i > 0 else None) for i, wv in enumerate(waves)}
        m = q.merge(q, on=["cod_com", "subject"], suffixes=("0", "1"))
        m = m[m.agno1 > m.agno0].copy()
        m["h"], m["dy"], m["ds"] = m.agno1 - m.agno0, m.score_mean1 - m.score_mean0, m.share_subv1 - m.share_subv0
        m["w"] = (m.wt_tested0 + m.wt_tested1) / 2
        m["pair"] = m.groupby(["agno0", "agno1", "subject"]).ngroup()
        m["agnoL"] = m.agno0.map(before)
        lag = q.rename(columns={"agno": "agnoL", "score_mean": "yL", "share_subv": "sL"})[["cod_com", "subject", "agnoL", "yL", "sL"]]
        m = m.merge(lag, on=["cod_com", "subject", "agnoL"], how="left", validate="many_to_one")
        m["dy_pre"] = m.score_mean0 - m.yL
        lagged = m.dropna(subset=["yL", "sL"])
        hu = "dy~ds+score_mean0+share_subv0|pair"

        def pairs_fit(formula, data):
            mod = pf.feols(formula, data, weights="w", vcov={"CRV1": "cod_com"})
            t = mod.tidy().loc["ds"]
            return dict(b=t["Estimate"], se=t["Std. Error"], p=t["Pr(>|t|)"], N=int(mod._N), communes=data.cod_com.nunique())

        B[grade] = {"All wave pairs": pairs_fit(hu, m), "No starting controls": pairs_fit("dy~ds|pair", m),
                    "Starting score instrumented": pairs_fit("dy~ds+share_subv0|pair|score_mean0~yL", lagged),
                    "Intervals of 1--5 years": pairs_fit(hu, m[m.h <= 5]), "Intervals of 6--12 years": pairs_fit(hu, m[(m.h >= 6) & (m.h <= 12)]),
                    "Intervals of 13 or more years": pairs_fit(hu, m[m.h >= 13]), "Pre-period test": pairs_fit("dy_pre~ds+yL+sL|pair", lagged)}
    T = [r" & (1) & (2) \\", r" & Grade 4 & Grade 10 \\ \midrule"]
    for lab in B["4b"]:
        a, c = B["4b"][lab], B["2m"][lab]
        T += [f"{lab} & {cell(a)} & {cell(c)} \\\\", f" & {se(a)} & {se(c)} \\\\"]
        if lab in ("Starting score instrumented", "Intervals of 13 or more years"):
            T.append(r"\addlinespace")
    a, c = B["4b"]["All wave pairs"], B["2m"]["All wave pairs"]
    T += [r"\midrule", f"Commune-pair observations & {a['N']:,} & {c['N']:,} \\\\", f"Communes & {a['communes']:,} & {c['communes']:,} \\\\"]
    P.write_table("tab_hu_horizons_commune", T)


if __name__ == "__main__":
    main()
