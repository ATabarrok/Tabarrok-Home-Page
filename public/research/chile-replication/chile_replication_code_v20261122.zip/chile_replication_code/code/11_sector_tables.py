"""Appendix Table B1 (enrolment by school sector, 2024) and B3 (socioeconomic composition by sector).

Table B1. Shares of total enrolment in 2024, every type of education, by the administrative
dependency of the school in the enrolment file: municipal, Local Public Education Service
(SLEP), delegated administration, subsidized private and paid private.

Table B3. The SIMCE classification of each school's socioeconomic group (cod_grupo, 1 low to
5 high), pooling grades 4 and 10 over 2005-2024, before any commune is excluded. A school is
weighted by its pupils tested in reading, or in mathematics when the reading count is missing.

Both tables are typed into the text of the paper; the rows are written here in the same form.

Input:  <work>/derived/enrollment_all.dta, simce_rbd_all.dta (Stata scripts 01 to 03)
Output: tab_sector_enrollment.tex, tab_sector_ses.tex
Usage:  python 11_sector_tables.py
"""

import pandas as pd

import config as cfg
import pupils as P


def main():
    cfg.make_dirs()
    e = pd.read_stata(cfg.DERIVED / "enrollment_all.dta", convert_categoricals=False, columns=["agno", "cod_depe", "cod_depe2", "mat_total"])
    e = e[e.agno == 2024].copy()
    e["dep"] = e.cod_depe2.fillna(e.cod_depe)   # 1 municipal, 2 subsidized private, 3 paid private, 4 delegated, 5 SLEP
    n = e.groupby("dep").mat_total.sum()
    pct = lambda codes: f"{100 * n[codes].sum() / n[[1, 2, 3, 4, 5]].sum():.1f}" + r"\%"
    P.write_table("tab_sector_enrollment", [
        f"Municipal & {pct([1])} \\\\", f"SLEP & {pct([5])} \\\\", f"Corp.\\ adm.\\ delegada & {pct([4])} \\\\",
        f"\\textbf{{Total Public}} & \\textbf{{{pct([1, 5, 4])}}} \\\\", r"\addlinespace",
        f"Particular subvencionado (PS) & {pct([2])} \\\\", f"Particular pagado (PP) & {pct([3])} \\\\",
        f"\\textbf{{Total Private}} & \\textbf{{{pct([2, 3])}}} \\\\"])

    s = pd.read_stata(cfg.DERIVED / "simce_rbd_all.dta", convert_categoricals=False, columns=["grade_std", "sector", "cod_grupo", "n_lect", "n_mate"])
    s = s[s.grade_std.isin(["4b", "2m"])].copy()
    s["w"] = s.n_lect.where(s.n_lect.gt(0), s.n_mate)
    a = s[s.cod_grupo.between(1, 5) & s.w.gt(0)].groupby(["sector", "cod_grupo"]).w.sum().unstack(fill_value=0)
    comp = a.div(a.sum(axis=1), axis=0) * 100
    P.write_table("tab_sector_ses", [lab + " & " + " & ".join(f"{comp.loc[code, g]:.1f}" + r"\%" for g in range(1, 6)) + r" \\"
                                     for code, lab in ((1, "Public"), (2, "PS"), (3, "PP"))])


if __name__ == "__main__":
    main()
