"""Table 1: the fixed-cohort and lottery samples.

Columns. (1) Every member of the ten starting cohorts: pupils in grade 4 in a public or
subsidized private school of a market, outside the nine high-PP communes. (2) The main
mathematics sample of Table 3: members in grade 10 six years later, tested in mathematics, with
a grade-4 mathematics score and the three parent answers. (3) Applicants to grade 9 in the
admission processes of 2020 to 2022 with a first lottery. (4) The applicants of the main lottery
estimate (private lottery and public fallback, or public lottery and private fallback) tested
with both grade-10 scores two years later, the sample of Table 6, Panel B.

Rows are means, with standard deviations in parentheses for scores, schooling, income and the
share. Scores are SIMCE points. Schooling is in years. Household income is the midpoint of the
bracket reported at grade 4, in thousands of pesos of the year of the questionnaire (not
reported for the lottery columns, which the lottery tables do not use). Sectors
at grade 10 are among pupils in grade 10 on time in a public or subsidized private school.

Run isolated, because it reads the admission files: python -I 43_sample_descriptives.py
Output: tab_sample_descriptives.tex
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

import config as cfg  # noqa: E402
import lotteries as L  # noqa: E402
import pupils as P  # noqa: E402


def starting_frame():
    """Every member of the starting cohorts, as counted in Appendix Table D2, Panel A (no member is dropped
    for a missing region or grade-10 share)."""
    out = []
    for c in P.COHORTS:
        a = P.grade4(c)[["mrun", "market", "cod_depe"]].rename(columns={"cod_depe": "depe4"})
        a = a.merge(P.parents(c, ("mrun", "fedu", "medu", "linc", "inc")).drop_duplicates("mrun"), on="mrun", how="left")
        a = a.merge(P.scores(4, c, "4"), on="mrun", how="left")
        a = a.merge(P.on_time(c + 6, 10, {"cod_depe": "depe10"}), on="mrun", how="left").merge(P.scores(10, c + 6), on="mrun", how="left")
        a["share10"] = P.own_share(a, "depe10")
        a["cohort"] = c
        out.append(a)
    a = pd.concat(out, ignore_index=True)
    a["ontime"] = a.depe10.notna()
    return a


def cohort_columns():
    w = P.wide_frame()
    w["ontime"] = w.depe10.notna()
    main = w[w.ontime & w.mate.notna() & w.mate4.notna() & w[P.PAR].notna().all(axis=1)].copy()
    inc = pd.concat([P.parents(c, ("mrun", "inc")).drop_duplicates("mrun").assign(cohort=c) for c in P.COHORTS])
    main = main.merge(inc, on=["mrun", "cohort"], how="left")
    start = starting_frame()
    for lo, hi in ((2006, 2012), (2016, 2018)):
        k = start[start.cohort.between(lo, hi)]
        print(f"grade-10 means, starting cohorts {lo}-{hi}: mathematics {k.mate.mean():.1f}, reading {k.lect.mean():.1f}")
    return start, main


def lottery_columns():
    f = L.prepare(L.build())
    tested = f[f.grp.isin(["priv_pub", "pub_priv"]) & f.mate.notna() & f.lect.notna()]
    off = tested[tested.rbd10.isna()]
    print("tested but not in grade 10 of secondary on time:", len(off))
    for y in L.YEARS:
        r = L.register(y + 2)
        r = r[r.mrun.isin(off.loc[off.year == y, "mrun"])]
        print(y + 2, "register rows:", len(r), r.groupby(["cod_ense", "cod_grado"]).size().head(8).to_dict())
    return f, tested


def m(s, d=1, sd=False):
    s = pd.Series(s, dtype=float).dropna()
    if len(s) == 0:
        return "", ""
    return f"{s.mean():.{d}f}", (f"({s.std():.{d}f})" if sd else "")


def pct(s):
    s = pd.Series(s, dtype=float).dropna()
    return f"{100 * s.mean():.1f}" if len(s) else ""


def main():
    w, main_s = cohort_columns()
    f, lt = lottery_columns()
    cols = [w, main_s, f, lt]
    is_l = [False, False, True, True]

    def row(label, get, d=1, sd=False, share=False):
        vals, sds = [], []
        for d_, lot in zip(cols, is_l):
            x = get(d_, lot)
            if x is None:
                vals.append(""); sds.append(""); continue
            if share:
                vals.append(pct(x)); sds.append("")
            else:
                a, b = m(x, d, sd); vals.append(a); sds.append(b)
        out = [label + " & " + " & ".join(vals) + r" \\"]
        if sd:
            out.append(" & " + " & ".join(sds) + r" \\")
        return out

    def g(col):
        return lambda d_, lot: d_[col] if col in d_ else None

    lines = [r" & \multicolumn{2}{c}{Fixed cohorts} & \multicolumn{2}{c}{Admission lotteries} \\ \cmidrule(lr){2-3}\cmidrule(lr){4-5}",
             r" & Starting & Main & First & Main \\",
             r" & cohorts & sample & lottery & estimate \\",
             r" & (1) & (2) & (3) & (4) \\ \midrule"]
    n = [len(w), len(main_s), len(f), len(lt)]
    lines.append("Pupils & " + " & ".join(f"{v:,}" for v in n) + r" \\")
    lines.append("Markets (1, 2) or lottery schools (3, 4) & " + " & ".join(
        f"{v:,}" for v in (w.market.nunique(), main_s.market.nunique(), f.rbd_l.nunique(), lt.rbd_l.nunique())) + r" \\ \addlinespace")
    lines.append(r"\multicolumn{5}{l}{\textit{Grade 4 and family}} \\")
    lines += row("Mathematics score", g("mate4"), sd=True)
    lines += row("Reading score", g("lect4"), sd=True)
    lines += row("Mother's schooling (years)", g("medu"), sd=True)
    lines += row("Father's schooling (years)", g("fedu"), sd=True)
    lines += row("Household income (thousand pesos)", lambda d_, lot: None if lot else d_.inc, d=0, sd=True)
    lines += row("All three parent answers (\\%)", lambda d_, lot: None if lot else d_[P.PAR].notna().all(axis=1), share=True)
    lines += row("In a subsidized private school at grade 4 (\\%)", lambda d_, lot: None if lot else d_.depe4 == 3, share=True)
    lines += row("In a subsidized private school at grade 8 (\\%)", lambda d_, lot: (d_.depe8 == 3).where(d_.depe8.notna()) if lot else None, share=True)
    lines.append(r"\addlinespace")
    lines.append(r"\multicolumn{5}{l}{\textit{Grade 10}} \\")
    lines += row("In grade 10 on time (\\%)", lambda d_, lot: d_.rbd10.notna() if lot else d_.ontime, share=True)
    lines += row("In a subsidized private school (\\%)",
                 lambda d_, lot: (d_.depe10 == 3).where(d_.depe10.isin(P.PUBLIC_PS)), share=True)
    lines += row("Mathematics score", g("mate"), sd=True)
    lines += row("Reading score", g("lect"), sd=True)
    lines += row("Cohort's own private share at grade 10", lambda d_, lot: None if lot else d_.share10, d=3, sd=True)
    lines.append(r"\addlinespace")
    lines.append(r"\multicolumn{5}{l}{\textit{The lottery}} \\")
    lines += row("Lottery at a subsidized private school (\\%)", lambda d_, lot: d_.priv_l if lot else None, share=True)
    lines += row("Lottery at the first preference (\\%)", lambda d_, lot: d_.pref_l == 1 if lot else None, share=True)
    lines += row("Won the lottery (\\%)", lambda d_, lot: d_.win if lot else None, share=True)
    lines.append(r"\bottomrule")
    P.write_table("tab_sample_descriptives", lines)
    print("main sample", len(main_s), "markets", main_s.market.nunique(), "market-cohorts", main_s.groupby(["market", "cohort"]).ngroups)


if __name__ == "__main__":
    main()
