"""The admission lotteries of the School Admission System (SAE): each applicant's first lottery
and fallback, and the estimators used by the lottery tables.

Input: data/public/admissions/SAE_<year>/, the public files of the processes of 2020, 2021 and
2022 (entry in 2021 to 2023), applications to grade 9. File A1 lists the courses and their
places, B1 the applicants, C1 the applications with the priority and the random number of each,
D1 the assignment, F1 pairs of relatives applying together.

The mechanism. Families rank courses (a school and a program). Each course orders its
applicants by priority class: already enrolled, sibling enrolled, child of staff, former pupil,
all others. Inside a priority class the order is the random number of the application, lowest
first, and priority pupils (prioritario) have places reserved. Inside a cell (course, priority
class, prioritario) an applicant is admitted if the number is at or below the cutoff of the cell.

Applicants set aside: those with a relative in the same process, and those ordered by the school
in a special procedure (special educational needs, or a test at a few selective schools).

The first lottery of an applicant is the highest-ranked course on the list at which the
applicant's cell has both admitted and rejected applicants. The fallback is the first
lower-ranked course at which the applicant's own number clears the cutoff, found for winners and
losers alike. Where a winner's lower-ranked cell cannot be read off the data a fixed rule
settles it: between the last admitted and the first rejected number, not admitted; a cell where
everyone who asked got in, admitted; a cell where nobody got in, not admitted; an empty cell,
admitted unless somebody at the course was rejected.

The frame is cached in <work>/pupil/lottery_frame.pkl. It holds pupil records and is restricted.
"""

import numpy as np
import pandas as pd
import pyfixest as pf

import config as cfg
import pupils as P

YEARS = [2020, 2021, 2022]
VC = {"CRV1": "school"}
GROUPS = [("priv_pub", "private lottery, public fallback"), ("pub_priv", "public lottery, private fallback"),
          ("priv_priv", "private lottery, private fallback"), ("pub_pub", "public lottery, public fallback"),
          ("priv_none", "private lottery, no fallback"), ("pub_none", "public lottery, no fallback")]
CTRL = ["zmate4", "zlect4", "medu", "zmate4_m", "zlect4_m", "medu_m", "es_mujer", "alto_rendimiento"]


def read(year, stem):
    hits = [q for q in (cfg.ADMISSIONS / f"SAE_{year}").rglob(f"{stem}_*.csv") if "__MACOSX" not in q.parts]
    return pd.read_csv(hits[0], sep=";", decimal=",", encoding="utf-8-sig", na_values=[" ", ""], low_memory=False)


def register(year):
    m = pd.read_pickle(cfg.REGISTER / f"m{year}.pkl")
    return m[m.mrun >= 0]


def lotteries(year, level=9):
    """Each applicant's first lottery and fallback in one process."""
    a, b, c, d, f1 = (read(year, s) for s in ("A1", "B1", "C1", "D1", "F1"))
    related = set(f1.mrun_1) | set(f1.mrun_2)
    a = a[a.cod_nivel == level]
    b = b[b.cod_nivel == level]
    d = d[d.cod_nivel == level]
    c = c[c.cod_nivel == level].merge(b[["mrun", "prioritario"]], on="mrun").merge(
        d[["mrun", "rbd_admitido", "cod_curso_admitido"]], on="mrun")
    c = c.rename(columns={"preferencia_postulante": "pref", "loteria_original": "lot"})
    c["adm"] = (c.rbd_admitido == c.rbd) & (c.cod_curso_admitido == c.cod_curso)
    c["cls"] = np.select([c.prioridad_matriculado == 1, c.prioridad_hermano == 1, c.prioridad_hijo_funcionario == 1,
                          c.prioridad_exalumno == 1], [1, 2, 3, 4], 5)
    special = c.orden_alta_exigencia_transicion.notna() | c.orden_pie.notna() | (c.es_pie == 1)
    c["clean"] = ~c.mrun.isin(related) & ~special.groupby(c.mrun).transform("max")
    c["admrank"] = c.mrun.map(c[c.adm].drop_duplicates("mrun").set_index("mrun").pref)
    c["live"] = c.admrank.isna() | (c.pref <= c.admrank)
    key = ["rbd", "cod_curso", "cls", "prioritario"]
    course = ["rbd", "cod_curso"]

    # cutoffs from clean, live applications
    cl = c[c.clean & c.live].copy()
    cl["lw"], cl["ll"] = cl.lot.where(cl.adm), cl.lot.where(~cl.adm)
    cell = cl.groupby(key).agg(nW=("adm", "sum"), n=("adm", "size"), maxwin=("lw", "max"), minlose=("ll", "min")).reset_index()
    cell["nL"] = cell.n - cell.nW
    cell["lottery"] = (cell.nW > 0) & (cell.nL > 0)
    co = cl.groupby(course).agg(low_adm=("cls", lambda s: s[cl.loc[s.index, "adm"]].max()),
                                rej_any=("cls", lambda s: s[~cl.loc[s.index, "adm"]].min()),
                                rej_pri=("cls", lambda s: s[~cl.loc[s.index, "adm"] & (cl.loc[s.index, "prioritario"] == 1)].min())).reset_index()
    tot = c.groupby(course).adm.sum().rename("admitted").reset_index().merge(a[course + ["vacantes"]], on=course, how="left")
    tot["unfilled"] = tot.admitted < tot.vacantes

    # every application of a clean applicant: would the applicant be admitted there if they asked?
    k = c[c.clean].merge(cell[key + ["nW", "nL", "maxwin", "minlose", "lottery"]], on=key, how="left").merge(co, on=course, how="left").merge(
        tot[course + ["unfilled"]], on=course, how="left")
    k[["nW", "nL"]] = k[["nW", "nL"]].fillna(0)
    k["lottery"] = k.lottery.fillna(False).astype(bool)
    sure_win = (k.cls == 1) | (k.unfilled == True) | (k.low_adm > k.cls)  # noqa: E712
    sure_loss = np.where(k.prioritario == 1, k.rej_pri < k.cls, k.rej_any < k.cls)
    clears = np.full(len(k), np.nan)
    clears[(k.nW > 0) & (k.lot <= k.maxwin)] = 1
    clears[(k.nL > 0) & (k.lot >= k.minlose)] = 0
    clears[np.isnan(clears) & sure_win.to_numpy()] = 1
    clears[np.isnan(clears) & sure_loss] = 0
    amb = np.isnan(clears)
    rule = np.where((k.nW > 0) & (k.nL > 0), 0, np.where(k.nW > 0, 1, np.where(k.nL > 0, 0, np.where(k.rej_any.notna(), 0, 1))))
    clears[amb] = rule[amb]
    k["clears"], k["amb"] = clears, amb

    # the first lottery
    lot = k[k.live & k.lottery].sort_values(["mrun", "pref"]).drop_duplicates("mrun")
    lot = lot[["mrun", "rbd", "cod_curso", "cls", "prioritario", "pref", "lot", "adm", "maxwin", "minlose", "nW", "nL"]].rename(
        columns={"rbd": "rbd_l", "cod_curso": "curso_l", "pref": "pref_l", "adm": "win", "lot": "lot_l"})
    # the fallback: the first lower-ranked course that is not a certain rejection
    below = k.merge(lot[["mrun", "pref_l"]], on="mrun")
    below = below[below.pref > below.pref_l].sort_values(["mrun", "pref"])
    below["amb_before"] = below.groupby("mrun").amb.cumsum() > 0
    hit = below[below.clears == 1].drop_duplicates("mrun")
    lot = lot.merge(hit[["mrun", "rbd", "cod_curso", "pref", "amb_before"]].rename(
        columns={"rbd": "rbd_f", "cod_curso": "curso_f", "pref": "pref_f", "amb_before": "fb_rule"}), on="mrun", how="left")
    lot["fb"] = np.where(lot.rbd_f.isna(), "none", "known")
    lot["fb_rule"] = np.where(lot.rbd_f.isna(), lot.mrun.map(below.groupby("mrun").amb.max()).fillna(False), lot.fb_rule).astype(bool)
    lot = lot.merge(d[["mrun", "rbd_admitido", "cod_curso_admitido", "respuesta_postulante", "rbd_admitido_post_resp"]], on="mrun")
    lot = lot.merge(b[["mrun", "es_mujer", "alto_rendimiento"]], on="mrun")
    lot["nlist"] = lot.mrun.map(c[c.agregada_por_continuidad == 0].groupby("mrun").size())
    return lot


def build_year(year):
    """The lotteries of one process with sectors, later enrolment and scores."""
    lot = lotteries(year)
    m1, m2, m0 = register(year + 1), register(year + 2), register(year)
    sector = m1.groupby("rbd").cod_depe.agg(lambda s: s.mode().iloc[0])
    lot["depe_l"], lot["depe_f"] = lot.rbd_l.map(sector), lot.rbd_f.map(sector)
    g8 = m0.sort_values("cod_ense").drop_duplicates("mrun")
    g8 = g8.loc[(g8.cod_ense == 110) & (g8.cod_grado == 8), ["mrun", "rbd", "cod_depe", "cod_com_rbd"]].rename(
        columns={"rbd": "rbd8", "cod_depe": "depe8", "cod_com_rbd": "com8"})
    g9 = m1.sort_values("cod_ense").drop_duplicates("mrun")
    g9 = g9.loc[g9.cod_ense.isin(P.SECONDARY) & (g9.cod_grado == 1), ["mrun", "rbd", "cod_depe"]].rename(columns={"rbd": "rbd9", "cod_depe": "depe9"})
    g10 = m2.sort_values("cod_ense").drop_duplicates("mrun")
    g10 = g10.loc[g10.cod_ense.isin(P.SECONDARY) & (g10.cod_grado == 2), ["mrun", "rbd", "cod_depe"]].rename(columns={"rbd": "rbd10", "cod_depe": "depe10"})
    lot = lot.merge(g8, on="mrun", how="left").merge(g9, on="mrun", how="left").merge(g10, on="mrun", how="left")
    lot = lot.merge(pd.read_pickle(cfg.PUPIL / f"scores_2m_{year + 2}.pkl")[["mrun", "lect", "mate"]], on="mrun", how="left")
    s4 = pd.read_pickle(cfg.PUPIL / f"scores_4b_{year - 4}.pkl")[["mrun", "lect", "mate"]].rename(columns={"lect": "lect4", "mate": "mate4"})
    lot = lot.merge(s4.drop_duplicates("mrun"), on="mrun", how="left")
    lot = lot.merge(pd.read_pickle(cfg.PUPIL / f"parents_4b_{year - 4}.pkl")[["mrun", "fedu", "medu", "linc"]].drop_duplicates("mrun"), on="mrun", how="left")
    lot["year"] = year
    return lot


def build():
    cache = cfg.PUPIL / "lottery_frame.pkl"
    if cache.exists():
        return pd.read_pickle(cache)
    f = pd.concat([build_year(y) for y in YEARS], ignore_index=True)
    f.to_pickle(cache)
    return f


def prepare(f):
    """Derived columns used by every block: the cell of the lottery (rs), groups by the sector of
    the lottery course and of the fallback, attendance, standardised scores."""
    f = f.copy()
    f["win"] = f.win.astype(float)
    f["rs"] = f.groupby(["year", "rbd_l", "curso_l", "cls", "prioritario"]).ngroup()
    f["school"] = f.rbd_l
    f["priv_l"] = (f.depe_l == 3).astype(float)
    f["priv_f"] = np.where(f.fb == "known", (f.depe_f == 3).astype(float), np.nan)
    f["grp"] = np.select([(f.fb == "known") & (f.priv_l == 1) & (f.priv_f == 0), (f.fb == "known") & (f.priv_l == 0) & (f.priv_f == 1),
                          (f.fb == "known") & (f.priv_l == 1) & (f.priv_f == 1), (f.fb == "known") & (f.priv_l == 0) & (f.priv_f == 0),
                          (f.fb == "none") & (f.priv_l == 1)], ["priv_pub", "pub_priv", "priv_priv", "pub_pub", "priv_none"], "pub_none")
    f["on9"], f["on10"] = f.rbd9.notna().astype(float), f.rbd10.notna().astype(float)
    f["at_l9"], f["at_l10"] = (f.rbd9 == f.rbd_l).astype(float), (f.rbd10 == f.rbd_l).astype(float)
    f["ps9"], f["ps10"] = (f.depe9 == 3).astype(float), (f.depe10 == 3).astype(float)
    f["tested"] = f.mate.notna().astype(float)
    f["priv8"] = (f.depe8 == 3).astype(float)
    f["has4"] = f.mate4.notna().astype(float)
    f["fbpriv"] = (f.priv_f == 1).astype(float)
    f["rm"] = (f.com8 // 1000 == 13)
    # Grade-10 scores in standard deviations of all pupils tested in the same year. Grade-4 scores,
    # used as controls and for balance, are standardised within year among applicants with a first lottery.
    nat = {}
    for y in sorted(int(v) for v in f.year.unique()):
        s = pd.read_pickle(cfg.PUPIL / f"scores_2m_{y + 2}.pkl")
        nat[y] = {c: (s[c].mean(), s[c].std()) for c in ("mate", "lect")}
    for c in ("mate", "lect"):
        f["z" + c] = [(v - nat[int(y)][c][0]) / nat[int(y)][c][1] for v, y in zip(f[c], f.year)]
    for c in ("mate4", "lect4"):
        f["z" + c] = f.groupby("year")[c].transform(lambda x: (x - x.mean()) / x.std())
    return f


def with_controls(f):
    """Missing grade-4 scores and mother's schooling set to zero, with indicators."""
    t = f.copy()
    for c in ("zmate4", "zlect4", "medu"):
        t[c + "_m"] = t[c].isna().astype(float)
        t[c] = t[c].fillna(0)
    return t


def ols(formula, data, term):
    t = pf.feols(formula, data, vcov=VC).tidy().loc[term]
    return dict(b=t["Estimate"], se=t["Std. Error"], N=len(data))


def tsls(data, y, endog, inst, ctrl, fe="rs", cluster="school"):
    """Two-stage least squares with several endogenous regressors; coefficients and their
    cluster-robust covariance."""
    rhs = "+".join(ctrl) if ctrl else "1"

    def r(v):
        return np.asarray(pf.feols(f"{v}~{rhs}|{fe}", data, fixef_rm="none").resid())

    Y = r(y)
    X = np.column_stack([r(v) for v in endog])
    Z = np.column_stack([r(v) for v in inst])
    Xh = Z @ np.linalg.lstsq(Z, X, rcond=None)[0]
    A = np.linalg.inv(Xh.T @ X)
    b = A @ Xh.T @ Y
    G = pd.DataFrame(Xh * (Y - X @ b)[:, None]).groupby(data[cluster].to_numpy()).sum().to_numpy()
    M = G.shape[0]
    return b, A @ (G.T @ G) @ A.T * M / (M - 1)


def sector_iv(data, y, treat="ps10", ctrl=CTRL, groups=("priv_pub", "pub_priv")):
    """The private sector as the treatment; instruments winning, by group; effects for cell by group."""
    k = data[data.grp.isin(groups)].copy()
    inst = []
    for g in groups:
        k["w_" + g] = k.win * (k.grp == g)
        inst.append("w_" + g)
    k["rsg"] = k.groupby(["rs", "grp"]).ngroup()
    b, V = tsls(k, y, [treat], inst, ctrl, "rsg")
    return dict(b=b[0], se=float(np.sqrt(V[0, 0])), N=len(k))


def lee_bounds(allg, k, tested, outcomes, controls):
    """Bounds on winners less losers when the two are tested at different rates (Lee 2009): trim
    the arm tested more often, from the top and from the bottom of its residual scores."""
    dlt = pf.feols(f"{tested}~win|rs", allg, vcov=VC).coef()["win"]
    arm = 1.0 if dlt > 0 else 0.0
    q = abs(dlt) / allg[tested][allg.win == arm].mean()
    out = {}
    for y in outcomes:
        res = pd.Series(np.asarray(pf.feols(f"{y}~{controls}|rs", k, fixef_rm="none").resid()), index=k.index)
        inarm = k.win == arm
        hi, lo = res[inarm].quantile(1 - q), res[inarm].quantile(q)
        b_top = pf.feols(f"{y}~win+{controls}|rs", k[~(inarm & (res > hi))], vcov=VC).coef()["win"]
        b_bot = pf.feols(f"{y}~win+{controls}|rs", k[~(inarm & (res < lo))], vcov=VC).coef()["win"]
        out[y] = (min(b_top, b_bot), max(b_top, b_bot), len(k))
    return out
