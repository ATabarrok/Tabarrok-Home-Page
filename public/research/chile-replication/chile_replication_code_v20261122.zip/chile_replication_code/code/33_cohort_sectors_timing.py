"""Table 4 (before and after grade 8), Table 5 (the selection signature), Figure 2 and Appendix Figure D1.

Sample: members of the starting cohorts in a public or subsidized private school at grade 10,
tested, with a grade-4 score and the three parent answers. Region-by-cohort effects and log
cohort size; standard errors clustered by market. Tables report coefficients per ten percentage
points of share.

Table 5. Sectors are those attended at grade 10. Slopes of the cohort mean and of each sector's
mean on the cohort's share, without pupil controls and with the grade-4 score and the parent
answers held fixed; and the slope of the grade-4 scores of the pupils who attend public schools
at grade 10.

Table 4. Four cohorts were tested at grades 4, 8 and 10 (2007, 2009, 2010, 2011). For the same
pupils (the last row of Panel A tests the difference between its first and third rows): does the cohort's share at grade 10 predict the grade-8 score given the grade-4 score,
and the grade-10 score given the grade-8 score? The same for the cohort's share at grade 8 and
its rise from grade 8 to grade 10. In points and in standard deviations of all pupils tested in
the same grade and year.

Figures. Three panels by set of controls and three series: the whole cohort, pupils in public
schools and pupils in subsidized private schools at grade 10. Scores and the share are
residualized inside each series on region-by-cohort effects, log cohort size and the panel's
controls, so the slope of each line is the coefficient of the corresponding regression. Points
are means in twenty bins holding equal numbers of pupils.

Output: tab_pupil_timing.tex, tab_pupil_selection.tex, fig_fixed_cohort_sector10_math and
fig_fixed_cohort_sector10_reading (PNG and PDF).
Usage:  python 33_cohort_sectors_timing.py
"""

import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker
import numpy as np
import pandas as pd
import pyfixest as pf

import config as cfg
import pupils as P

warnings.filterwarnings("ignore")
INK, MUTED, GRID = "#1f1f1e", "#6b6a63", "#e4e3dd"
STYLE = {"all": ("#2a78d6", "o", "Whole cohort"),
         "pub": ("#eb6834", "s", "In a public school at grade 10"),
         "priv": ("#1baf7a", "^", "In a subsidized private school at grade 10")}
PANELS = (("No controls", []), ("Controlling for own grade-4 score", ["score4"]),
          ("Own grade-4 score, parents'\nschooling and income", ["score4"] + P.PAR))


def est(y, x, ctrl, fe, data):
    return P.fit(f"{y}~{'+'.join([x] + ctrl)}|{fe}", data, x)


def national_sd():
    """Mean and standard deviation of all pupils tested, by grade, year and subject."""
    out = {}
    for g, tag in P.TAG.items():
        for f in sorted(cfg.PUPIL.glob(f"scores_{tag}_*.pkl")):
            y = int(f.stem.split("_")[-1])
            s = pd.read_pickle(f)
            for c in ("mate", "lect"):
                out[(g, y, c)] = (s[c].mean(), s[c].std())
    return out


def sectors(a):
    E = {}
    for key, name in P.SUBJECTS:
        d = a.assign(score=a[key], score4=a[f"{key}4"]).dropna(subset=["score", "score4", "ps10"] + P.PAR)
        raw, ctl = ["lnn0"], ["lnn0", "score4"] + P.PAR
        pub, priv = d[d.ps10 == 0], d[d.ps10 == 1]
        E[name, "Whole cohort"] = (est("score", "share10", raw, "rc", d), est("score", "share10", ctl, "rc", d))
        E[name, "Public-school pupils"] = (est("score", "share10", raw, "rc", pub), est("score", "share10", ctl, "rc", pub))
        E[name, "Subsidized-private-school pupils"] = (est("score", "share10", raw, "rc", priv), est("score", "share10", ctl, "rc", priv))
        E[name, "Grade-4 score of eventual public-school pupils"] = (est("score4", "share10", raw, "rc", pub), None)
    T = [r" & \multicolumn{2}{c}{Mathematics} & \multicolumn{2}{c}{Reading} \\ \cmidrule(lr){2-3}\cmidrule(lr){4-5}",
         r" & Unadjusted & Adjusted & Unadjusted & Adjusted \\ \midrule"]
    for title in ("Whole cohort", "Public-school pupils", "Subsidized-private-school pupils", "Grade-4 score of eventual public-school pupils"):
        top, bot = [title], [""]
        for name in ("Mathematics", "Reading"):
            for r in E[name, title]:
                top.append("" if r is None else P.num(r["b"] / 10) + P.stars(r["p"]))
                bot.append("" if r is None else f"({r['se'] / 10:.2f})")
        T += [" & ".join(top) + r" \\", " & ".join(bot) + r" \\"]
    P.write_table("tab_pupil_selection", T + [r"\bottomrule"])


def slope_gap(d, y8, y10, s8, base):
    """The grade 8 to 10 slope on the share less the grade 4 to 8 slope, for the same pupils.

    The two regressions of Panel A (grade-8 score given grade 4; grade-10 score given grade 8)
    are stacked, every coefficient and the region-by-cohort effects free in each, so the point
    estimates are those of the separate regressions; the covariance of the two slopes comes from
    clustering the stacked rows by market."""
    rows = []
    for eq, y in ((0, y8), (1, y10)):
        k = d[["market", "rc", "share10", s8] + base].copy()
        k["y"] = d[y].to_numpy()
        k[s8] = k[s8] * eq
        for v in ["share10"] + base:
            for e in (0, 1):
                k[f"{v}_{e}"] = k[v] * (eq == e)
        k["rce"] = k.rc.astype(str) + "_" + str(eq)
        rows.append(k)
    k = pd.concat(rows, ignore_index=True)
    rhs = [f"{v}_{e}" for v in ["share10"] + base for e in (0, 1)] + [s8]
    m = pf.feols(f"y~{'+'.join(rhs)}|rce", k, vcov=P.VC)
    names = list(m._coefnames)
    V = np.asarray(m._vcov)
    i, j = names.index("share10_1"), names.index("share10_0")
    b = m.coef()["share10_1"] - m.coef()["share10_0"]
    se = float(np.sqrt(V[i, i] + V[j, j] - 2 * V[i, j]))
    return dict(b=float(b), se=se)


def timing(a):
    nat = national_sd()
    a = a.copy()
    a["ps8"] = np.where(a.depe8.isin(P.PUBLIC_PS), (a.depe8 == 3).astype(float), np.nan)
    a["share8"] = a.groupby(["market", "cohort"]).ps8.transform("mean")
    a["jump"] = a.share10 - a.share8
    rows = ("Grade-8 score", "Grade-10 score", "Grade-10 score given the grade-8 score", "Grade-8 score: share at grade 8",
            "Grade-8 score: rise in the share", "Grade-10 score given grade 8: share at grade 8", "Grade-10 score given grade 8: rise in the share")
    E, n = {}, {}
    for key, name in P.SUBJECTS:
        d = a.assign(score=a[key], score4=a[f"{key}4"], score8=a[f"{key}8"]).dropna(
            subset=["score", "score4", "score8", "ps10", "share8"] + P.PAR).copy()
        for col, g, off in (("score", 10, 6), ("score8", 8, 4), ("score4", 4, 0)):
            mu = d.cohort.map(lambda c: nat[(g, int(c) + off, key)][0])
            sd = d.cohort.map(lambda c: nat[(g, int(c) + off, key)][1])
            d["z" + col] = (d[col] - mu) / sd
        n[name] = len(d)
        for unit, s, s8, s4 in (("points", "score", "score8", "score4"), ("SD", "zscore", "zscore8", "zscore4")):
            base = ["lnn0", s4] + P.PAR
            E[name, unit, rows[0]] = est(s8, "share10", base, "rc", d)
            E[name, unit, rows[1]] = est(s, "share10", base, "rc", d)
            E[name, unit, rows[2]] = est(s, "share10", [s8] + base, "rc", d)
            E[name, unit, rows[3]] = est(s8, "share8", ["jump"] + base, "rc", d)
            E[name, unit, rows[4]] = est(s8, "jump", ["share8"] + base, "rc", d)
            E[name, unit, rows[5]] = est(s, "share8", ["jump", s8] + base, "rc", d)
            E[name, unit, rows[6]] = est(s, "jump", ["share8", s8] + base, "rc", d)
            E[name, unit, "gap"] = slope_gap(d, s8, s, s8, base)

    def four(lab):
        cells = [(E[s, u, lab], k) for u, k in (("points", 3), ("SD", 4)) for s in ("Mathematics", "Reading")]
        return [lab + " & " + " & ".join(f"{P.num(c['b'] / 10, k)}{P.stars(c['p'])}" for c, k in cells) + r" \\",
                " & " + " & ".join(f"({c['se'] / 10:.{k}f})" for c, k in cells) + r" \\"]

    T = [r" & \multicolumn{2}{c}{Points} & \multicolumn{2}{c}{Standard deviations} \\ \cmidrule(lr){2-3}\cmidrule(lr){4-5}",
         r" & Mathematics & Reading & Mathematics & Reading \\ \midrule",
         r"\multicolumn{5}{l}{\textit{A. Coefficient on the cohort's private share at grade 10}} \\"]
    for lab in rows[:3]:
        T += four(lab)
    cells = [(E[s, u, "gap"], k) for u, k in (("points", 3), ("SD", 4)) for s in ("Mathematics", "Reading")]
    T += ["Row 3 less row 1 (grade 8 to 10 less grade 4 to 8) & " + " & ".join(f"{P.num(c['b'] / 10, k)}{P.stars_t(c['b'], c['se'])}" for c, k in cells) + r" \\",
          " & " + " & ".join(f"({c['se'] / 10:.{k}f})" for c, k in cells) + r" \\"]
    T += [r"\addlinespace", r"\multicolumn{5}{l}{\textit{B. The share at grade 8 and its rise from grade 8 to grade 10}} \\"]
    shown = {rows[3]: "Share at grade 8", rows[4]: "Rise in the share, grade 8 to grade 10",
             rows[5]: "Share at grade 8", rows[6]: "Rise in the share, grade 8 to grade 10"}
    for i, lab in enumerate(rows[3:]):
        if i == 0:
            T += [r"\multicolumn{5}{l}{Grade-8 score, given the grade-4 score (before the transition)} \\"]
        if i == 2:
            T += [r"\multicolumn{5}{l}{Grade-10 score, given the grade-8 score} \\"]
        rows_out = four(lab)
        rows_out[0] = r"\quad " + shown[lab] + rows_out[0][len(lab):]
        T += rows_out
    m, r = n["Mathematics"], n["Reading"]
    T += [r"\midrule", f"Pupils & {m:,} & {r:,} & {m:,} & {r:,} \\\\", r"\bottomrule"]
    P.write_table("tab_pupil_timing", T)


def figure(a, key, name, path):
    d = a.assign(score=a[key], score4=a[f"{key}4"]).dropna(subset=["score", "score4", "ps10"] + P.PAR).copy()
    series = {"all": d, "pub": d[d.ps10 == 0], "priv": d[d.ps10 == 1]}
    fig, axes = plt.subplots(1, 3, figsize=(13.2, 6.0), sharey=True)
    lo_x, hi_x = 1.0, 0.0
    for ax, (ptitle, pctl) in zip(axes, PANELS):
        rhs = "+".join(["lnn0"] + pctl)
        whole = pd.Series(np.asarray(pf.feols(f"score~{rhs}|rc", d, fixef_rm="none").resid()), index=d.index)
        for s in ("pub", "priv", "all"):
            k = series[s]
            color, marker, label = STYLE[s]
            ry = np.asarray(pf.feols(f"score~{rhs}|rc", k, fixef_rm="none").resid())
            rx = np.asarray(pf.feols(f"share10~{rhs}|rc", k, fixef_rm="none").resid())
            slope = float(rx @ ry / (rx @ rx))
            level, centre = float(whole[k.index].mean()), float(k.share10.mean())
            b = pd.DataFrame({"x": rx + centre, "y": ry + level, "bin": pd.qcut(rx, 20, labels=False, duplicates="drop")}).groupby("bin").agg(
                x=("x", "mean"), y=("y", "mean")).reset_index()
            big = s == "all"
            if big:
                cohort_label = f"Whole cohort: {slope / 10:+.2f} points per 10 pp"
            lo, hi = b.x.min(), b.x.max()
            lo_x, hi_x = min(lo_x, lo), max(hi_x, hi)
            ax.plot([lo, hi], [level + slope * (lo - centre), level + slope * (hi - centre)], color=color, lw=2.4 if big else 1.6,
                    zorder=3 if big else 2, solid_capstyle="round")
            ax.scatter(b.x, b.y, s=46 if big else 34, marker=marker, color=color, edgecolor="white", linewidth=1.0, zorder=4 if big else 3, label=label)
        ax.axhline(0, color=MUTED, lw=0.8, ls=(0, (4, 3)), zorder=1)
        heading = ptitle if "\n" in ptitle else ptitle + "\n"
        ax.set_title(f"{heading}\n{cohort_label}", fontsize=14, color=INK, loc="left", pad=8)
        ax.set_xlabel("Cohort's private share at grade 10\n(net of the controls above)", fontsize=13, color=MUTED)
        ax.grid(axis="y", color=GRID, lw=0.8)
        ax.set_axisbelow(True)
        for sp in ("top", "right", "left"):
            ax.spines[sp].set_visible(False)
        ax.spines["bottom"].set_color(GRID)
        ax.tick_params(colors=MUTED, labelsize=12, length=0)
        ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
    for ax in axes:
        ax.set_xlim(lo_x - 0.03, hi_x + 0.03)
    axes[0].set_ylabel("Grade-10 score, SIMCE points\n(0 = mean of the whole cohort)", fontsize=13, color=MUTED)
    handles, labs = axes[2].get_legend_handles_labels()
    order = [labs.index(STYLE[s][2]) for s in ("all", "pub", "priv")]
    fig.legend([handles[i] for i in order], [labs[i] for i in order], loc="lower center", ncol=3, frameon=False, markerscale=1.5,
               fontsize=14, labelcolor=INK, bbox_to_anchor=(0.5, -0.005), handletextpad=0.4, columnspacing=2.2)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    fig.savefig(path.with_suffix(".png"), dpi=200, facecolor="white")
    fig.savefig(path.with_suffix(".pdf"), facecolor="white")
    plt.close(fig)


def main():
    cfg.make_dirs()
    a = P.wide_frame()
    sectors(a)
    timing(a)
    figure(a, "mate", "Mathematics", cfg.FIGURES / "fig_fixed_cohort_sector10_math")
    figure(a, "lect", "Reading", cfg.FIGURES / "fig_fixed_cohort_sector10_reading")


if __name__ == "__main__":
    main()
