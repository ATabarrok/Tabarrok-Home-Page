"""Shared definitions for the pupil-level scripts: cohorts, markets, the main specification,
and the pupil frames the tables are estimated on.

A starting cohort is the pupils enrolled in grade 4 in the public and subsidized private
schools of a market in a year, outside the nine communes where paid private schools hold half
of enrolment or more. Pupils are followed by their masked identifier (mrun) through the
enrolment register, wherever they attend. A market is an OECD functional urban area or, outside
those areas, a single commune.

The main specification compares markets inside the same region and starting cohort and holds
the logarithm of the market's starting-cohort size fixed.
"""

import functools

import numpy as np
import pandas as pd
import pyfixest as pf

import config as cfg

PUBLIC_PS = [1, 2, 3, 5, 6]          # cod_depe: municipal (1, 2), subsidized private (3), delegated (5), SLEP (6)
PUBLIC = [1, 2, 5, 6]
SECONDARY = [310, 410, 510, 610, 710, 810, 910]
COHORTS = [2006, 2007, 2008, 2009, 2010, 2011, 2012, 2016, 2017, 2018]
LOTTERY_COHORTS = [2016, 2017, 2018]
TIMING_COHORTS = [2007, 2009, 2010, 2011]
TAG = {4: "4b", 6: "6b", 8: "8b", 10: "2m"}
PAR = ["fedu", "medu", "linc"]
SUBJECTS = (("mate", "Mathematics"), ("lect", "Reading"))
VC = {"CRV1": "market"}


# ---------------------------------------------------------------------------- markets
@functools.lru_cache(maxsize=1)
def markets():
    """Commune -> market, and the set of excluded communes."""
    cw = pd.read_csv(cfg.CROSSWALK)
    hp = pd.read_csv(cfg.HIGH_PP)
    return dict(zip(cw.cod_com, cw.oecd_fua)), set(hp.loc[hp.high_pp_commune.eq(1), "cod_com"])


@functools.lru_cache(maxsize=1)
def regions():
    """Market -> administrative region (the leading digits of the commune code)."""
    cw = pd.read_csv(cfg.CROSSWALK)
    cw["region"] = cw.cod_com // 1000
    return cw.groupby("oecd_fua").region.agg(lambda s: s.mode().iloc[0])


def add_spec(u, size="n0"):
    """Add the region and the log of the starting-cohort size."""
    u = u.copy()
    u["region"] = u.market.map(regions())
    u["lnn0"] = np.log(u[size])
    return u


def rc_group(u, *extra):
    """Region-by-cohort groups (by further columns when given)."""
    return u.groupby(["region", "cohort", *extra]).ngroup()


# ---------------------------------------------------------------------------- files
@functools.lru_cache(maxsize=4)
def register(year):
    d = pd.read_pickle(cfg.REGISTER / f"m{year}.pkl")
    return d[d.mrun >= 0]


def has_scores(grade, year):
    return (cfg.PUPIL / f"scores_{TAG[grade]}_{year}.pkl").exists()


def scores(grade, year, suffix=None):
    """mrun and the two scores of a grade-year; suffix renames them (lect -> lect<suffix>)."""
    e = pd.read_pickle(cfg.PUPIL / f"scores_{TAG[grade]}_{year}.pkl")[["mrun", "lect", "mate"]]
    return e if suffix is None else e.rename(columns={"lect": f"lect{suffix}", "mate": f"mate{suffix}"})


def parents(cohort, columns=("mrun", "fedu", "medu", "linc")):
    return pd.read_pickle(cfg.PUPIL / f"parents_4b_{cohort}.pkl")[list(columns)]


def grade4(cohort):
    """The starting cohort: grade-4 pupils of public and subsidized private schools."""
    market_of, excluded = markets()
    a = register(cohort)
    a = a[(a.cod_ense == 110) & (a.cod_grado == 4)].drop_duplicates("mrun")
    a = a[a.cod_depe.isin(PUBLIC_PS) & ~a.cod_com_rbd.isin(excluded)].copy()
    a["market"] = a.cod_com_rbd.map(market_of)
    return a


def on_time(year, grade, columns):
    """Pupils enrolled in a grade in a year, one row each. columns maps register names to new names."""
    b = register(year).sort_values("cod_ense").drop_duplicates("mrun")
    on = ((b.cod_ense == 110) & (b.cod_grado == grade)) if grade < 9 else (b.cod_ense.isin(SECONDARY) & (b.cod_grado == 2))
    return b.loc[on, ["mrun"] + list(columns)].rename(columns=columns)


def own_share(a, sector_column):
    """The cohort's own private share: among its members in public or subsidized private schools."""
    pool = a[a[sector_column].isin(PUBLIC_PS)]
    return a.market.map(pool.groupby("market")[sector_column].apply(lambda s: (s == 3).mean()))


# ---------------------------------------------------------------------------- frames
def main_frame():
    """One row per pupil and subject: cohort members in grade 10 on time, tested, with a grade-4
    score in the subject and the three parent answers. The sample of the main table."""
    out = []
    for c in COHORTS:
        a = grade4(c)[["mrun", "market", "cod_depe"]].rename(columns={"cod_depe": "depe4"})
        a["share"] = a.groupby("market").depe4.transform(lambda s: (s == 3).mean())
        a["n0"] = a.groupby("market").mrun.transform("size")
        a = a.merge(parents(c), on="mrun", how="left").merge(scores(4, c, "4"), on="mrun", how="left")
        m = a.merge(on_time(c + 6, 10, {"cod_depe": "depe10"}), on="mrun", how="inner").merge(scores(10, c + 6), on="mrun", how="left")
        m["share10"] = own_share(m, "depe10")
        for sub in ("lect", "mate"):
            u = m[["market", "share", "share10", "n0", "depe4", "depe10", "fedu", "medu", "linc", sub, f"{sub}4"]].rename(
                columns={sub: "score", f"{sub}4": "score4"})
            u["cohort"], u["subject"] = c, sub
            out.append(u)
    u = pd.concat(out, ignore_index=True).dropna(subset=["score", "score4", "fedu", "medu", "linc"]).copy()
    u = add_spec(u).dropna(subset=["region", "share10"]).copy()
    return u


def wide_frame():
    """One row per member of a starting cohort, with schools, sectors and scores at grades 4, 8
    and 10. Cached, because several scripts use it."""
    cache = cfg.PUPIL / "wide_frame.pkl"
    if cache.exists():
        return pd.read_pickle(cache)
    out = []
    for c in COHORTS:
        a = grade4(c)[["mrun", "market", "rbd", "cod_depe"]].rename(columns={"rbd": "rbd4", "cod_depe": "depe4"})
        a["n0"] = a.groupby("market").mrun.transform("size")
        a = a.merge(parents(c), on="mrun", how="left").merge(scores(4, c, "4"), on="mrun", how="left")
        a = a.merge(on_time(c + 4, 8, {"rbd": "rbd8", "cod_depe": "depe8"}), on="mrun", how="left")
        if has_scores(8, c + 4):
            a = a.merge(scores(8, c + 4, "8"), on="mrun", how="left")
        else:
            a["lect8"], a["mate8"] = np.nan, np.nan
        a = a.merge(on_time(c + 6, 10, {"rbd": "rbd10", "cod_depe": "depe10"}), on="mrun", how="left")
        a = a.merge(scores(10, c + 6), on="mrun", how="left")
        a["share10"] = own_share(a, "depe10")
        a["ps10"] = np.where(a.depe10.isin(PUBLIC_PS), (a.depe10 == 3).astype(float), np.nan)
        a["cohort"] = c
        out.append(a)
    a = add_spec(pd.concat(out, ignore_index=True)).dropna(subset=["region", "share10"])
    a["rc"] = rc_group(a)
    a["mc"] = a.groupby(["market", "cohort"]).ngroup()
    a.to_pickle(cache)
    return a


def late_frame():
    """One row per member of a starting cohort, with the grade-10 score on time and, where a test
    exists, one and two years late."""
    def late_scores(y, tag):
        e = pd.read_pickle(cfg.PUPIL / f"scores_2m_{y}.pkl")[["mrun", "lect", "mate"]]
        return e.rename(columns={"lect": f"lect{tag}", "mate": f"mate{tag}"})

    out = []
    for c in COHORTS:
        a = grade4(c)[["mrun", "market", "cod_depe"]].rename(columns={"cod_depe": "depe4"})
        a["share"] = a.groupby("market").depe4.transform(lambda s: (s == 3).mean())
        a["n0"] = a.groupby("market").mrun.transform("size")
        a = a.merge(parents(c), on="mrun", how="left").merge(scores(4, c, "4"), on="mrun", how="left")
        a = a.merge(on_time(c + 6, 10, {"cod_depe": "depe10"}), on="mrun", how="left").merge(late_scores(c + 6, "_on"), on="mrun", how="left")
        a["on_time"] = a.depe10.notna()
        a["share10"] = own_share(a, "depe10")
        for lag in (1, 2):
            y = c + 6 + lag
            a[f"test{lag}"] = has_scores(10, y)
            if has_scores(10, y):
                a = a.merge(on_time(y, 10, {"cod_depe": f"depe_l{lag}"}), on="mrun", how="left").merge(late_scores(y, f"_l{lag}"), on="mrun", how="left")
            else:
                a[f"depe_l{lag}"], a[f"lect_l{lag}"], a[f"mate_l{lag}"] = pd.NA, float("nan"), float("nan")
        a["late1"] = ~a.on_time & a.depe_l1.notna()
        a["late2"] = ~a.on_time & ~a.late1 & a.depe_l2.notna()
        a["cohort"] = c
        out.append(a)
    return pd.concat(out, ignore_index=True).dropna(subset=["market", "share10"]).copy()


def filled_late_frame():
    """The late frame with parent answers filled from later questionnaires. A missing grade-4
    answer on father's or mother's schooling takes the same parent's earliest later answer (grade
    6, 8 or 10). Household income is its percentile among the parents answering the same
    questionnaire, grade 4 where it exists and the earliest later one otherwise (pct)."""
    a = late_frame()
    a["complete0"] = a[["fedu", "medu", "linc"]].notna().all(axis=1)
    a["pct"], a["pct4"] = float("nan"), float("nan")
    lag = {"6b": 2, "8b": 4, "2m": 6}
    for c in sorted(a.cohort.unique()):
        m = a.cohort == c
        g4 = parents(c, ("mrun", "inc"))
        g4["pct4"] = g4.inc.rank(pct=True, method="average")
        a.loc[m, "pct"] = a.loc[m, ["mrun"]].merge(g4[["mrun", "pct4"]], on="mrun", how="left").pct4.to_numpy()
        a.loc[m, "pct4"] = a.loc[m, "pct"]
        for tag in ("6b", "8b", "2m"):
            f = cfg.PUPIL / f"parents_later_{tag}_{c + lag[tag]}.pkl"
            if not f.exists():
                continue
            d = a.loc[m, ["mrun"]].merge(pd.read_pickle(f), on="mrun", how="left")
            d.index = a.index[m]
            for v, w in (("pct", "pct_l"), ("fedu", "fedu_l"), ("medu", "medu_l")):
                a.loc[m, v] = a.loc[m, v].fillna(d[w])
    a = add_spec(a).dropna(subset=["region"])
    a["csub"] = rc_group(a)
    a["complete1"] = a[["fedu", "medu", "pct"]].notna().all(axis=1)
    return a


def segment_frame():
    """One row per pupil, subject and pair of grades tested (the earlier grade g0, the later g1):
    cohort members on time and tested at both, with the parent answers. The share is the cohort's
    own private share at the later grade."""
    seg = []
    cohorts = [int(p.stem.split("_")[-1]) for p in sorted(cfg.PUPIL.glob("parents_4b_*.pkl"))]
    for c in cohorts:
        if not (has_scores(4, c) and (cfg.REGISTER / f"m{c}.pkl").exists()):
            continue
        a = grade4(c)
        a["n0"] = a.groupby("market").mrun.transform("size")
        a = a[["mrun", "market", "n0"]].merge(parents(c), on="mrun", how="left").merge(scores(4, c, "4"), on="mrun", how="left")
        a["on4"] = True
        grades = [4]
        for g in (6, 8, 10):
            y = c + g - 4
            if not (has_scores(g, y) and (cfg.REGISTER / f"m{y}.pkl").exists()):
                continue
            a = a.merge(on_time(y, g, {"cod_depe": f"depe{g}"}), on="mrun", how="left")
            a[f"share{g}"] = own_share(a, f"depe{g}")
            a = a.merge(scores(g, y, str(g)), on="mrun", how="left")
            a[f"on{g}"] = a[f"depe{g}"].notna()
            grades.append(g)
        par_ok = a[PAR].notna().all(axis=1)
        for g1 in grades[1:]:
            earlier = [g for g in grades if g < g1]
            for g0 in earlier:
                for sub, _ in SUBJECTS:
                    ok = par_ok & a[f"on{g1}"] & a[f"on{g0}"] & a[f"{sub}{g1}"].notna() & a[f"{sub}{g0}"].notna() & a[f"share{g1}"].notna()
                    u = a.loc[ok, ["mrun", "market", "n0"] + PAR].copy()
                    u["score"], u["prev"], u["share"] = a.loc[ok, f"{sub}{g1}"], a.loc[ok, f"{sub}{g0}"], a.loc[ok, f"share{g1}"]
                    u["cohort"], u["g0"], u["g1"], u["subject"] = c, g0, g1, sub
                    u["latest"] = g0 == max(earlier)
                    seg.append(u)
    d = add_spec(pd.concat(seg, ignore_index=True)).dropna(subset=["region"])
    d["rc"] = rc_group(d)
    return d


def track_frame():
    """One row per member of a starting cohort with the secondary track at grade 10 (enrolment
    code 310 is the academic track) and the cohort's academic-track share."""
    out = []
    for c in COHORTS:
        a = grade4(c)[["mrun", "market", "cod_depe"]].rename(columns={"cod_depe": "depe4"})
        a["n0"] = a.groupby("market").mrun.transform("size")
        a = a.merge(parents(c), on="mrun", how="left").merge(scores(4, c, "4"), on="mrun", how="left")
        a = a.merge(on_time(c + 6, 10, {"cod_depe": "depe10", "cod_ense": "ense10"}), on="mrun", how="left")
        a = a.merge(scores(10, c + 6), on="mrun", how="left")
        pool = a[a.depe10.isin(PUBLIC_PS)]
        a["share10"] = own_share(a, "depe10")
        a["hc_share"] = a.market.map(pool.groupby("market").ense10.apply(lambda s: (s == 310).mean()))
        a["cohort"] = c
        out.append(a)
    a = add_spec(pd.concat(out, ignore_index=True)).dropna(subset=["region", "share10"])
    a["rc"] = rc_group(a)
    return a


def coverage_frame():
    """Every member of the starting cohorts, with the steps into the main mathematics sample."""
    out = []
    for c in COHORTS:
        a = grade4(c)
        a["share4"] = a.groupby("market").cod_depe.transform(lambda s: (s == 3).mean())
        a = a[["mrun", "market", "share4"]].merge(parents(c), on="mrun", how="left")
        a = a.merge(scores(4, c, "4")[["mrun", "mate4"]], on="mrun", how="left")
        b = on_time(c + 6, 10, {})
        b["ontime"] = True
        a = a.merge(b, on="mrun", how="left")
        a["ontime"] = a.ontime.fillna(False).astype(bool)
        a = a.merge(scores(10, c + 6)[["mrun", "mate"]], on="mrun", how="left")
        a["tested"] = a.ontime & a.mate.notna()
        a["with4"] = a.tested & a.mate4.notna()
        a["insample"] = a.with4 & a[PAR].notna().all(axis=1)
        a["cohort"] = c
        out.append(a[["market", "cohort", "share4", "mate4", "ontime", "tested", "with4", "insample"]])
    return pd.concat(out, ignore_index=True)


# ---------------------------------------------------------------------------- estimation and tables
def fit(formula, data, term, vcov=None):
    """Coefficient, standard error, p-value and number of observations of one term."""
    m = pf.feols(formula, data, vcov=vcov or VC)
    t = m.tidy().loc[term]
    return dict(b=t["Estimate"], se=t["Std. Error"], p=t["Pr(>|t|)"], N=len(data))


def stars(p):
    return r"\sym{***}" if p < 0.01 else r"\sym{**}" if p < 0.05 else r"\sym{*}" if p < 0.10 else ""


def stars_t(b, se):
    """Stars from the ratio of a coefficient to its standard error (normal critical values)."""
    t = abs(b / se) if se and se > 0 else 0.0
    return r"\sym{***}" if t >= 2.576 else r"\sym{**}" if t >= 1.960 else r"\sym{*}" if t >= 1.645 else ""


def num(x, d=2):
    """A number with d decimals; negative numbers in mathematics mode; no negative zero."""
    s = f"{abs(x):.{d}f}"
    return f"$-{s}$" if x < 0 and float(s) != 0 else s


def write_table(name, lines):
    cfg.TABLES.mkdir(parents=True, exist_ok=True)
    (cfg.TABLES / f"{name}.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("wrote", name)
