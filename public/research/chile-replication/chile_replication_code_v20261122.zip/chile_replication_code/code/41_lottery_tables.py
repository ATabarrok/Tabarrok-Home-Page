"""Table 6 (admission lotteries) and Appendix Tables E1 (balance and attrition) and E2 (other
choices, kinds of pupil, bounds).

Applicants to grade 9 in the admission processes of 2020, 2021 and 2022 with a first lottery;
the outcome is the grade-10 SIMCE score two years later, for pupils in grade 10 on time. Every
comparison is made inside the cell of the lottery (year, course, priority class, prioritario),
where admission depends on a random number alone. Standard errors clustered by the school of
the lottery.

Controls: grade-4 mathematics and reading scores and mother's schooling, with indicators where
missing, sex, and being in the top fifth of grades in the school of origin.

Output: tab_lottery_groups.tex, tab_lottery_iv.tex, tab_lottery_balance.tex, tab_lottery_robust.tex.
Usage:  python -I 41_lottery_tables.py
"""

import sys
import warnings
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

import config as cfg
import lotteries as Z
import pupils as P

warnings.filterwarnings("ignore")
CS = "+".join(Z.CTRL)
R = {}
MID, END = r" \\ \midrule", r" \\"
SHORT = {"priv_pub": "Private, public", "pub_priv": "Public, private", "priv_priv": "Private, private", "pub_pub": "Public, public",
         "priv_none": "Private, none", "pub_none": "Public, none"}
COLS = ("all", "into private", "out of private")


def one(r, d=2):
    """Coefficient and standard error in one cell."""
    return f"{P.num(r['b'], d)}{P.stars_t(r['b'], r['se'])} ({r['se']:.{d}f})"


def pair(cells):
    """A coefficient row and the row of standard errors under it. cells: label, then (result, digits) or a string."""
    top, bot = [cells[0]], [""]
    for c in cells[1:]:
        if isinstance(c, str):
            top.append(c)
            bot.append("")
        else:
            r, d = c
            top.append(f"{P.num(r['b'], d)}{P.stars_t(r['b'], r['se'])}")
            bot.append(f"({r['se']:.{d}f})")
    return [" & ".join(top) + END, " & ".join(bot) + END]


def both(block, label, data, **kw):
    R[block, label + ", mathematics"] = Z.sector_iv(data, "mate", **kw)
    R[block, label + ", reading"] = Z.sector_iv(data, "lect", **kw)


def estimate(f):
    """f: the prepared frame, every applicant with a first lottery."""
    t = Z.with_controls(f.dropna(subset=["mate", "lect"]))
    cols = (("all", f), ("into private", f[f.grp == "priv_pub"]), ("out of private", f[f.grp == "pub_priv"]))

    # balance and attrition: winners less losers inside the cell
    for lab, v in (("grade-4 mathematics (SD)", "zmate4"), ("grade-4 reading (SD)", "zlect4"), ("mother's schooling (years)", "medu"),
                   ("log income", "linc"), ("has a grade-4 score", "has4"), ("girl", "es_mujer"), ("top 20% of grades", "alto_rendimiento"),
                   ("private school in grade 8", "priv8"), ("length of the list", "nlist"), ("fallback is private", "fbpriv")):
        for s, k in cols:
            R["C", f"{lab}, {s}"] = Z.ols(f"{v}~win|rs", k.dropna(subset=[v]), "win")
    for lab, v in (("in grade 9 the next year", "on9"), ("on time in grade 10", "on10"), ("tested in mathematics", "tested")):
        for s, k in cols:
            R["D", f"{lab}, {s}"] = Z.ols(f"{v}~win|rs", k, "win")
    for lab, v in (("grade-4 mathematics (SD)", "zmate4"), ("grade-4 reading (SD)", "zlect4"), ("mother's schooling (years)", "medu"),
                   ("top 20% of grades", "alto_rendimiento")):
        for s, k in cols:
            R["D tested", f"{lab}, {s}"] = Z.ols(f"{v}~win|rs", k[k.tested == 1].dropna(subset=[v]), "win")

    # winners less losers by group, pupils tested at grade 10
    for g, _ in Z.GROUPS:
        k = t[t.grp == g]
        for v in ("at_l10", "ps10", "mate", "lect"):
            R["E " + g, v] = Z.ols(f"{v}~win+{CS}|rs", k, "win")

    # the effect of being in a subsidized private school at grade 10
    both("F", "private lottery, public fallback", t, groups=("priv_pub",))
    both("F", "public lottery, private fallback", t, groups=("pub_priv",))
    both("F", "the two sector-changing groups together", t)
    both("F", "all six groups", t, groups=tuple(g for g, _ in Z.GROUPS))
    R["F SD", "mathematics"] = Z.sector_iv(t, "zmate")
    R["F SD", "reading"] = Z.sector_iv(t, "zlect")
    for g, lab in Z.GROUPS[:2]:
        R["F bounds", lab] = Z.lee_bounds(f[f.grp == g], t[t.grp == g].copy(), "tested", ("mate", "lect"), CS)

    both("G", "no controls", t, ctrl=[])
    both("G", "lotteries at the first preference only", t[t.pref_l == 1])
    both("G", "fallback not settled by the rule", t[~t.fb_rule])
    both("G", "treatment: private sector in grade 9", t, treat="ps9")
    both("G", "pupils with a grade-4 score", t[t.has4 == 1])
    for y in Z.YEARS:
        both("G", f"process {y}", t[t.year == y])
    both("H", "prioritario", t[t.prioritario == 1])
    both("H", "not prioritario", t[t.prioritario == 0])
    both("H", "girls", t[t.es_mujer == 1])
    both("H", "boys", t[t.es_mujer == 0])
    both("H", "public school in grade 8", t[t.priv8 == 0])
    both("H", "private school in grade 8", t[t.priv8 == 1])
    both("H", "Santiago region", t[t.rm])
    both("H", "other regions", t[~t.rm])
    both("H", "grade-4 mathematics below the average", t[(t.has4 == 1) & (t.zmate4 < 0)])
    both("H", "grade-4 mathematics above the average", t[(t.has4 == 1) & (t.zmate4 >= 0)])

    # the same pupils without the lottery
    two = t[t.grp.isin(["priv_pub", "pub_priv"])].copy()
    two["rsg"] = two.groupby(["rs", "grp"]).ngroup()
    R["I", "mathematics"] = Z.ols(f"mate~ps10+{CS}|rsg", two, "ps10")
    R["I", "reading"] = Z.ols(f"lect~ps10+{CS}|rsg", two, "ps10")

    # three treatments at once: the lottery school when private, when public, and the private sector
    four = t[t.grp.isin(["priv_pub", "pub_priv", "priv_priv", "pub_pub"])].copy()
    inst = []
    for g in ("priv_pub", "pub_priv", "priv_priv", "pub_pub"):
        four["w_" + g] = four.win * (four.grp == g)
        inst.append("w_" + g)
    four["rsg"] = four.groupby(["rs", "grp"]).ngroup()
    four["at_priv"] = four.at_l10 * four.priv_l
    four["at_pub"] = four.at_l10 * (1 - four.priv_l)
    for y, lab in (("mate", "mathematics"), ("lect", "reading")):
        b, V = Z.tsls(four, y, ["at_priv", "at_pub", "ps10"], inst, Z.CTRL, "rsg")
        for i, v in enumerate(("at_priv", "at_pub", "ps10")):
            R["three", f"{lab}: {v}"] = dict(b=b[i], se=float(np.sqrt(V[i, i])), N=len(four))


def estimate_late(full):
    """Processes of 2020 and 2021: pupils who reach grade 10 a year late sit that year's test."""
    full = Z.with_controls(full)
    late = []
    for y in (2020, 2021):
        m3 = Z.register(y + 3).sort_values("cod_ense").drop_duplicates("mrun")
        g = m3.loc[m3.cod_ense.isin(P.SECONDARY) & (m3.cod_grado == 2), ["mrun", "rbd", "cod_depe"]].rename(columns={"rbd": "rbd10L", "cod_depe": "depe10L"})
        s = pd.read_pickle(cfg.PUPIL / f"scores_2m_{y + 3}.pkl")
        g = g.merge(s[["mrun", "mate", "lect"]].rename(columns={"mate": "mateL", "lect": "lectL"}), on="mrun", how="left")
        g["year"] = y
        late.append(g)
    f = full[full.year <= 2021].merge(pd.concat(late), on=["mrun", "year"], how="left")
    f["lateg10"] = ((f.on10 == 0) & f.rbd10L.notna()).astype(float)
    f["reach"] = ((f.on10 == 1) | (f.lateg10 == 1)).astype(float)
    isl = f.lateg10 == 1
    f["mate_all"] = np.where(f.on10 == 1, f.mate, np.where(isl, f.mateL, np.nan))
    f["lect_all"] = np.where(f.on10 == 1, f.lect, np.where(isl, f.lectL, np.nan))
    f["ps_all"] = np.where(f.on10 == 1, f.ps10, np.where(isl, (f.depe10L == 3).astype(float), np.nan))
    f["tested_all"] = f.mate_all.notna().astype(float)
    groups = (("all", f), ("into private", f[f.grp == "priv_pub"]), ("out of private", f[f.grp == "pub_priv"]))
    for lab, v in (("in grade 10 on time", "on10"), ("in grade 10 a year late", "lateg10"), ("in grade 10 on time or a year late", "reach"),
                   ("tested on time or a year late", "tested_all")):
        for s, k in groups:
            R["late attrition", f"{lab}, {s}"] = Z.ols(f"{v}~win|rs", k, "win")
    for lab, sub, tr in (("pupils on time", ["mate", "lect"], "ps10"), ("with pupils a year late", ["mate_all", "lect_all"], "ps_all")):
        k = f.dropna(subset=sub)
        R["late effect", lab + ", mathematics"] = Z.sector_iv(k, sub[0], treat=tr)
        R["late effect", lab + ", reading"] = Z.sector_iv(k, sub[1], treat=tr)
    t_all = f.dropna(subset=["mate_all", "lect_all"])
    for g, lab in Z.GROUPS[:2]:
        R["late bounds", lab] = Z.lee_bounds(f[f.grp == g], t_all[t_all.grp == g].copy(), "tested_all", ("mate_all", "lect_all"), CS)


def groups_table():
    T = [r" & & \multicolumn{2}{c}{Fraction at grade 10 in the} & \multicolumn{2}{c}{Grade-10 score} \\ \cmidrule(lr){3-4}\cmidrule(lr){5-6}",
         "Lottery course, fallback & Pupils & lottery school & private sector & Mathematics & Reading" + MID,
         r"\multicolumn{6}{l}{\textit{A. Winners less losers, by the sector of the lottery course and of the fallback}} \\"]
    for g, _ in Z.GROUPS:
        r = {v: R["E " + g, v] for v in ("at_l10", "ps10", "mate", "lect")}
        T += pair([SHORT[g], f"{r['mate']['N']:,}", (r["at_l10"], 3), (r["ps10"], 3), (r["mate"], 2), (r["lect"], 2)])
    return T + [r"\bottomrule"]


def iv_table():
    T = [" & Mathematics & Reading & Pupils" + MID,
         r"\multicolumn{4}{l}{\textit{B. Effect of being in a subsidized private school at grade 10}} \\"]
    for key, lab in (("private lottery, public fallback", "Private lottery, public fallback"),
                     ("public lottery, private fallback", "Public lottery, private fallback"),
                     ("the two sector-changing groups together", "The two groups together")):
        m, r = R["F", key + ", mathematics"], R["F", key + ", reading"]
        T += pair([lab, (m, 2), (r, 2), f"{m['N']:,}"])
    m, r = R["F SD", "mathematics"], R["F SD", "reading"]
    T += pair(["The same in national standard deviations", (m, 3), (r, 3), f"{m['N']:,}"])
    T += [r"\addlinespace", r"\multicolumn{4}{l}{\textit{C. Three treatments at once, the four groups with a fallback}} \\"]
    for v, lab in (("at_priv", "In the lottery school, a private school"), ("at_pub", "In the lottery school, a public school"),
                   ("ps10", "In a subsidized private school at grade 10")):
        m, r = R["three", "mathematics: " + v], R["three", "reading: " + v]
        T += pair([lab, (m, 2), (r, 2), f"{m['N']:,}"])
    m, r = R["I", "mathematics"], R["I", "reading"]
    T += [r"\addlinespace", r"\multicolumn{4}{l}{\textit{D. The same pupils without the lottery}} \\"]
    T += pair(["Private against public at grade 10, least squares", (m, 2), (r, 2), f"{m['N']:,}"])
    return T + [r"\bottomrule"]


def balance_table():
    T = [" & All & Private lottery, & Public lottery," + END, " & applicants & public fallback & private fallback" + MID]

    def block(title, blk, items, skip=()):
        out = [r"\multicolumn{4}{l}{\textit{" + title + r"}} \\"]
        for key, lab in items:
            cells = ["" if (key in skip and s != "all") else one(R[blk, f"{key}, {s}"], 3) for s in COLS]
            out.append(" & ".join([lab] + cells) + END)
        return out

    T += block("A. Fixed before the lottery", "C",
               [("grade-4 mathematics (SD)", "Grade-4 mathematics, SD"), ("grade-4 reading (SD)", "Grade-4 reading, SD"),
                ("mother's schooling (years)", "Mother's schooling, years"), ("log income", "Log household income"),
                ("has a grade-4 score", "Has a grade-4 score"), ("girl", "Girl"), ("top 20% of grades", "Top fifth of grades in own school"),
                ("private school in grade 8", "In a private school in grade 8"), ("length of the list", "Courses on the list"),
                ("fallback is private", "Fallback is a private school")], skip=("fallback is private",))
    T.append(r"\addlinespace")
    T += block("B. After the lottery", "D", [("in grade 9 the next year", "In grade 9 the next year"), ("on time in grade 10", "In grade 10 on time"),
                                              ("tested in mathematics", "Tested in mathematics at grade 10")])
    T.append(r"\addlinespace")
    T += block("C. Fixed before the lottery, among pupils tested at grade 10", "D tested",
               [("grade-4 mathematics (SD)", "Grade-4 mathematics, SD"), ("grade-4 reading (SD)", "Grade-4 reading, SD"),
                ("mother's schooling (years)", "Mother's schooling, years"), ("top 20% of grades", "Top fifth of grades in own school")])
    T.append(r"\addlinespace")
    T += block("D. After the lottery, processes of 2020 and 2021", "late attrition",
               [("in grade 10 on time", "In grade 10 on time"), ("in grade 10 a year late", "In grade 10 a year late"),
                ("in grade 10 on time or a year late", "In grade 10 on time or a year late"),
                ("tested on time or a year late", "Tested, on time or a year late")])
    return T + [r"\bottomrule"]


def robust_table():
    def row(blk, key, lab):
        m, r = R[blk, key + ", mathematics"], R[blk, key + ", reading"]
        return " & ".join([lab, one(m), one(r), f"{m['N']:,}"]) + END

    def bounds(blk, lab, title, ys):
        b = R[blk, lab]
        return " & ".join([title, f"{P.num(b[ys[0]][0])} to {P.num(b[ys[0]][1])}", f"{P.num(b[ys[1]][0])} to {P.num(b[ys[1]][1])}", f"{b[ys[0]][2]:,}"]) + END

    T = [" & Mathematics & Reading & Pupils" + MID, row("F", "the two sector-changing groups together", "Estimate of Table~\\ref{tab:lottery}"),
         r"\addlinespace", r"\multicolumn{4}{l}{\textit{A. Other choices}} \\", row("F", "all six groups", "All six groups of applicants")]
    for key, lab in (("no controls", "No controls"), ("lotteries at the first preference only", "Lotteries at the first preference only"),
                     ("fallback not settled by the rule", "Fallback read directly from the cutoffs"),
                     ("treatment: private sector in grade 9", "Private sector measured in grade 9"),
                     ("pupils with a grade-4 score", "Pupils with a grade-4 score"),
                     ("process 2020", "Process of 2020, grade 10 in 2022"), ("process 2021", "Process of 2021, grade 10 in 2023"),
                     ("process 2022", "Process of 2022, grade 10 in 2024")):
        T.append(row("G", key, lab))
    T += [r"\addlinespace", r"\multicolumn{4}{l}{\textit{B. By kind of pupil}} \\"]
    for key, lab in (("prioritario", "Priority pupils"), ("not prioritario", "Other pupils"), ("girls", "Girls"), ("boys", "Boys"),
                     ("public school in grade 8", "In a public school in grade 8"), ("private school in grade 8", "In a private school in grade 8"),
                     ("Santiago region", "Santiago region"), ("other regions", "Other regions"),
                     ("grade-4 mathematics below the average", "Grade-4 mathematics below the average"),
                     ("grade-4 mathematics above the average", "Grade-4 mathematics above the average")):
        T.append(row("H", key, lab))
    T += [r"\addlinespace", r"\multicolumn{4}{l}{\textit{C. Bounds on winners less losers for unequal testing}} \\"]
    for _, lab in Z.GROUPS[:2]:
        T.append(bounds("F bounds", lab, lab.capitalize(), ("mate", "lect")))
    T += [r"\addlinespace", r"\multicolumn{4}{l}{\textit{D. Processes of 2020 and 2021, with pupils who reach grade 10 a year late}} \\",
          row("late effect", "pupils on time", "Estimate, pupils on time"),
          row("late effect", "with pupils a year late", "Estimate, adding pupils a year late")]
    for _, lab in Z.GROUPS[:2]:
        T.append(bounds("late bounds", lab, "Bounds, " + lab, ("mate_all", "lect_all")))
    return T + [r"\bottomrule"]


def main():
    cfg.make_dirs()
    f = Z.prepare(Z.build())
    estimate(f)
    estimate_late(f)
    P.write_table("tab_lottery_groups", groups_table())
    P.write_table("tab_lottery_iv", iv_table())
    P.write_table("tab_lottery_balance", balance_table())
    P.write_table("tab_lottery_robust", robust_table())


if __name__ == "__main__":
    main()
