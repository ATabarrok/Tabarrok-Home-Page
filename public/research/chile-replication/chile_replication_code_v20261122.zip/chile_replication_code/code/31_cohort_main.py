"""Table 3 (the main cohort table) and Appendix Table D4 (other comparisons of markets).

Pupil-level regressions of the grade-10 score on the starting cohort's own private share at
grade 10. The share is, among the members of the starting cohort who are in grade 10 six years
later in a public or subsidized private school anywhere in the country, the share in
subsidized private schools. Region-by-cohort effects and log cohort size; standard errors
clustered by market. Tables report coefficients per ten percentage points of share.

Oster's (2019) calculation is made on market-cohort means, weighted by pupils. Both regressions
keep region-by-cohort effects and log cohort size; the longer one adds the cohort means of the
grade-4 score and of the three parent variables. R-squared values are net of the effects and of
size. The maximum R-squared is 1.3 times and twice that of the longer regression, and one.

Appendix Table D4, Panel E, defines the cohort by the commune of the grade-4 school in place of
the market.

Output: tab_cohort_pupil_main.tex, tab_pupil_spec.tex.
Usage:  python 31_cohort_main.py
"""

import warnings

import numpy as np
import pandas as pd
import pyfixest as pf
from scipy.optimize import brentq

import config as cfg
import pupils as P

warnings.filterwarnings("ignore")
PAR = "+".join(P.PAR)


# ---------------------------------------------------------------------------- Oster (2019), as in psacalc
def within(d, cols, fe, w):
    """Weighted demeaning within the fixed effect."""
    out = {}
    g = d[fe]
    sw = d[w].groupby(g).transform("sum")
    for c in cols:
        m = (d[c] * d[w]).groupby(g).transform("sum") / sw
        out[c] = d[c] - m
    return pd.DataFrame(out, index=d.index)


def delta_for(beta, b0, r0, b1, r1, rmax, syy, sxx, tx):
    """Oster's delta for a hypothesised true coefficient beta."""
    bt = b1 - beta
    d01 = b0 - b1
    a = (r1 - r0) * syy
    m = (rmax - r1) * syy
    num = bt * a * tx + bt * sxx * tx * d01 ** 2 + 2 * bt ** 2 * (tx * d01 * sxx) + bt ** 3 * (tx * sxx - tx ** 2)
    den = m * d01 * sxx + bt * m * (sxx - tx) + bt ** 2 * (tx * d01 * sxx) + bt ** 3 * (tx * sxx - tx ** 2)
    return num / den


def beta_star(b0, r0, b1, r1, rmax, syy, sxx, tx):
    """The coefficient at delta = 1: the root nearest the long estimate."""
    f = lambda b: delta_for(b, b0, r0, b1, r1, rmax, syy, sxx, tx) - 1
    span = max(abs(b0 - b1), 1.0)
    grid = np.linspace(b1 - 6 * span, b1 + 6 * span, 4001)
    vals = np.array([f(b) for b in grid])
    roots = []
    for i in range(len(grid) - 1):
        if np.isfinite(vals[i]) and np.isfinite(vals[i + 1]) and vals[i] * vals[i + 1] < 0 and abs(vals[i] - vals[i + 1]) < 50:
            roots.append(brentq(f, grid[i], grid[i + 1]))
    return min(roots, key=lambda b: abs(b - b1)) if roots else np.nan


def cell_oster(v):
    cell = v.groupby(["market", "cohort"]).agg(score=("score", "mean"), share10=("share10", "first"), lnn0=("lnn0", "first"),
                                               csub=("csub", "first"), m4=("score4", "mean"), fedu=("fedu", "mean"),
                                               medu=("medu", "mean"), linc=("linc", "mean"), w=("score", "size")).reset_index()
    cell["w"] = cell.w.astype(float)
    add = ["m4", "fedu", "medu", "linc"]
    r = within(cell, ["score", "share10", "lnn0"] + add, "csub", "w")
    W = cell.w.to_numpy()
    sq = np.sqrt(W)
    B = r[["lnn0"]].to_numpy()
    for c in ["score", "share10"] + add:
        g_ = np.linalg.lstsq(B * sq[:, None], r[c].to_numpy() * sq, rcond=None)[0]
        r[c] = r[c].to_numpy() - B @ g_
    wm = lambda x: np.average(x, weights=W)
    y, X, Z = r["score"].to_numpy(), r["share10"].to_numpy(), r[add].to_numpy()
    syy, sxx = wm(y ** 2), wm(X ** 2)
    b0 = wm(X * y) / sxx
    r0 = 1 - wm((y - b0 * X) ** 2) / syy
    full = np.column_stack([X, Z])
    coef = np.linalg.lstsq(full * sq[:, None], y * sq, rcond=None)[0]
    b1 = coef[0]
    r1 = 1 - wm((y - full @ coef) ** 2) / syy
    gz = np.linalg.lstsq(Z * sq[:, None], X * sq, rcond=None)[0]
    tx = wm((X - Z @ gz) ** 2)
    res = {}
    for tag, rm in (("13", min(1.0, 1.3 * r1)), ("20", min(1.0, 2 * r1)), ("one", 1.0)):
        res[f"delta_{tag}"] = delta_for(0.0, b0, r0, b1, r1, rm, syy, sxx, tx)
        res[f"beta_star_{tag}"] = beta_star(b0, r0, b1, r1, rm, syy, sxx, tx)
    return res


# ---------------------------------------------------------------------------- cohorts defined by commune
def commune_row():
    """All communes: the cohort is the grade-4 pupils of a commune; its own share at grade 10
    follows its members wherever they attend; size is the log of the commune's starting cohort."""
    a = P.wide_frame().copy()
    a["com4"] = np.nan
    for c in sorted(int(v) for v in a.cohort.unique()):
        k = a.cohort == c
        a.loc[k, "com4"] = a.loc[k, "rbd4"].map(P.register(c).groupby("rbd").cod_com_rbd.first())
    a = a.dropna(subset=["com4"]).copy()
    g = a.groupby(["com4", "cohort"])
    a["lnnc"] = np.log(g.mrun.transform("size"))
    a["share_c"] = g.ps10.transform("mean")
    a = a.dropna(subset=["share_c"])
    out = {}
    for key, name in P.SUBJECTS:
        d = a.assign(score=a[key], score4=a[f"{key}4"]).dropna(subset=["score", "score4", "rbd10"] + P.PAR)
        out[name] = P.fit(f"score~share_c+lnnc+score4+{PAR}|rc", d, "share_c")
        out[name]["communes"] = d.com4.nunique()
    return out


def main():
    cfg.make_dirs()
    u = P.main_frame()
    main, oster, spec, info = {}, {}, {}, {}
    for key, name in P.SUBJECTS:
        v = u[u.subject == key].copy()
        v["csub"] = P.rc_group(v)
        v["co"] = v.groupby("cohort").ngroup()
        g = v.groupby(["market", "cohort"])
        for c in ("fedu", "medu", "linc", "score4"):
            v[c + "_bar"] = g[c].transform("mean")
        info[name] = dict(pupils=len(v), markets=v.market.nunique())
        main[name] = {
            "No controls": P.fit("score~share10+lnn0|csub", v, "share10"),
            "Own grade-4 score": P.fit("score~share10+lnn0+score4|csub", v, "share10"),
            "Adding parents' schooling and income": P.fit(f"score~share10+lnn0+score4+{PAR}|csub", v, "share10"),
            "Adding classmates' average background": P.fit(f"score~share10+lnn0+score4+{PAR}+fedu_bar+medu_bar+linc_bar+score4_bar|csub", v, "share10"),
            "Grade-4 share in place of grade-10 share": P.fit(f"score~share+lnn0+score4+{PAR}|csub", v, "share"),
            "Starting-cohort effects only, no region effects or market size": P.fit(f"score~share10+score4+{PAR}|co", v, "share10"),
        }
        oster[name] = cell_oster(v)

        # other comparisons of markets, with the pupil controls of the third row
        v["fua"] = (v.market >= 900000).astype(int)   # OECD functional urban areas; the other markets are single communes
        v["dec"] = v.groupby("cohort").lnn0.transform(lambda x: pd.qcut(x, 10, labels=False, duplicates="drop"))
        v["rcd"] = v.groupby(["csub", "dec"]).ngroup()
        v["lnn0_2"], v["lnn0_3"] = v.lnn0 ** 2, v.lnn0 ** 3
        C = f"score4+{PAR}"
        santiago = v.groupby("market").size().idxmax()
        spec[name] = {
            "main": P.fit(f"score~share10+lnn0+{C}|csub", v, "share10"),
            "no size": P.fit(f"score~share10+{C}|csub", v, "share10"),
            "cohort effects and size": P.fit(f"score~share10+lnn0+{C}|co", v, "share10"),
            "cohort effects only": P.fit(f"score~share10+{C}|co", v, "share10"),
            "market and region-by-cohort effects": P.fit(f"score~share10+lnn0+{C}|market+csub", v, "share10"),
            "market and cohort effects": P.fit(f"score~share10+lnn0+{C}|market+co", v, "share10"),
            "cubic": P.fit(f"score~share10+lnn0+lnn0_2+lnn0_3+{C}|csub", v, "share10"),
            "bins": P.fit(f"score~share10+{C}|csub+dec", v, "share10"),
            "deciles": P.fit(f"score~share10+{C}|rcd", v, "share10"),
            "urban indicator": P.fit(f"score~share10+fua+{C}|csub", v, "share10"),
            "without Santiago": P.fit(f"score~share10+lnn0+{C}|csub", v[v.market != santiago], "share10"),
            "single communes": P.fit(f"score~share10+lnn0+{C}|csub", v[v.fua == 0], "share10"),
        }
        print(name, "done", flush=True)
    com = commune_row()

    # Table 7
    M, R = "Mathematics", "Reading"
    T = [r" & (1) & (2) \\", r" & Mathematics & Reading \\ \midrule"]
    for lab in main[M]:
        a, b = main[M][lab], main[R][lab]
        T += [f"{lab} & {a['b'] / 10:.3f}{P.stars(a['p'])} & {b['b'] / 10:.3f}{P.stars(b['p'])} \\\\",
              f" & ({a['se'] / 10:.3f}) & ({b['se'] / 10:.3f}) \\\\"]
        if lab == "Adding classmates' average background":
            T.append(r"\addlinespace")
    T.append(r"\addlinespace")
    for tag, rmax in (("13", r"$R_{\max} = 1.3\tilde{R}^2$"), ("one", r"$R_{\max} = 1$")):   # 2 x R2 is reported in the text
        T += [f"Oster $\\delta$, {rmax} & {P.num(oster[M]['delta_' + tag])} & {P.num(oster[R]['delta_' + tag])} \\\\",
              f"Coefficient at $\\delta = 1$, {rmax} & {P.num(oster[M]['beta_star_' + tag] / 10, 3)} & {P.num(oster[R]['beta_star_' + tag] / 10, 3)} \\\\"]
    T += [r"\midrule", f"Pupils & {info[M]['pupils']:,} & {info[R]['pupils']:,} \\\\",
          f"Markets & {info[M]['markets']:,} & {info[R]['markets']:,} \\\\", r"\bottomrule"]
    P.write_table("tab_cohort_pupil_main", T)

    # Appendix Table D4
    def two(key, lab):
        m, r = spec[M][key], spec[R][key]
        return [f"{lab} & {P.num(m['b'] / 10, 3)}{P.stars_t(m['b'], m['se'])} & {P.num(r['b'] / 10, 3)}{P.stars_t(r['b'], r['se'])} & {m['N']:,} \\\\",
                f" & ({m['se'] / 10:.3f}) & ({r['se'] / 10:.3f}) & \\\\"]

    T = [r" & Mathematics & Reading & Pupils \\ \midrule", r"\multicolumn{4}{l}{\textit{A. Region effects and market size}} \\"]
    T += two("main", "Region-by-cohort effects and log cohort size (main)")
    T += two("no size", "Region-by-cohort effects, no market size")
    T += two("cohort effects and size", "Starting-cohort effects and log cohort size")
    T += two("cohort effects only", "Starting-cohort effects only")
    T += [r"\addlinespace", r"\multicolumn{4}{l}{\textit{B. An effect for every market, with log cohort size}} \\"]
    T += two("market and region-by-cohort effects", "Market and region-by-cohort effects")
    T += two("market and cohort effects", "Market and starting-cohort effects")
    T += [r"\addlinespace", r"\multicolumn{4}{l}{\textit{C. Other forms of market size, with region-by-cohort effects}} \\"]
    T += two("cubic", "Cubic in log cohort size")
    T += two("bins", "Ten bins of cohort size")
    T += two("deciles", "Region-by-cohort-by-size-decile effects")
    T += two("urban indicator", "Urban-area indicator in place of size")
    T += [r"\addlinespace", r"\multicolumn{4}{l}{\textit{D. Main specification on parts of the sample}} \\"]
    T += two("without Santiago", "Without the Santiago market")
    T += two("single communes", "Single-commune markets")
    m, r = com[M], com[R]
    T += [r"\addlinespace", r"\multicolumn{4}{l}{\textit{E. Cohorts defined by the commune of the grade-4 school}} \\",
          f"All {m['communes']} communes, region-by-cohort effects and log cohort size & {P.num(m['b'] / 10, 3)}{P.stars_t(m['b'], m['se'])} & "
          f"{P.num(r['b'] / 10, 3)}{P.stars_t(r['b'], r['se'])} & {m['N']:,} \\\\",
          f" & ({m['se'] / 10:.3f}) & ({r['se'] / 10:.3f}) & \\\\", r"\bottomrule"]
    P.write_table("tab_pupil_spec", T)


if __name__ == "__main__":
    main()
