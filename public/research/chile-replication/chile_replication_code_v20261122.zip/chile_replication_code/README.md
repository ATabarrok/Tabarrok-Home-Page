# Replication package

**Private School Competition and Student Achievement in Chile**
Alex Tabarrok

> **This is the code-only archive.** It holds the code, the table bodies of the paper and a
> manifest of the public data, but not the data files, which come to about 2 GB (1.2 GB
> compressed). `data/public/MANIFEST.tsv` lists every public file the scripts read: its path
> under `data/public/`, its size in bytes and its SHA-256. Download the files from the sources
> named under "Data" below and place them at the paths in the manifest. Where this README says
> the public data are included, it describes the full package.

This package rebuilds every table of the paper, and the three figures drawn from data, starting
from the raw files. It holds the code, all the public data, and the table bodies as they are
typeset in the paper, against which the regenerated ones are compared.

## What is here

| Folder | Contents |
|---|---|
| `code/` | Python scripts, and Stata scripts in `code/stata/` |
| `data/public/` | Every public input (about 2 GB) |
| `data/restricted/` | Empty. The pupil files of the Agencia de Calidad de la Educación go here |
| `expected_tables/` | The table bodies of the paper |
| `run_all.py` | Runs every step in order |

Running the package creates `work/` (intermediate files) and `output/` (tables and figures).

## Data

### Public, included

| Folder | Source | Used for |
|---|---|---|
| `data/public/simce_schools/` | Agencia de Calidad de la Educación, SIMCE results by school and by commune, 2004–2024 (`informacionestadistica.agenciaeducacion.cl`) | Commune and market panels |
| `data/public/enrollment/` | Ministerio de Educación, Centro de Estudios, *Resumen de matrícula por unidad educativa*, 2004–2024 (`datosabiertos.mineduc.cl`) | Private shares of enrolment |
| `data/public/enrollment_register/` | Ministerio de Educación, *Matrícula por estudiante*, 2005–2024, with a masked pupil identifier (`datosabiertos.mineduc.cl/matricula-por-estudiante-2/`) | Following pupils from grade 4 to grade 10 |
| `data/public/admissions/` | Ministerio de Educación, *Sistema de Admisión Escolar*, processes of 2020, 2021 and 2022 (`datosabiertos.mineduc.cl/sistema-de-admision-escolar-sae/`) | Admission lotteries |
| `data/public/oecd/` | OECD, list of municipalities in functional urban areas (`oecd.org`, *OECD definition of cities and functional urban areas*) | School markets |

The files are as downloaded, in the folder structure of the source, with one exception. The two
folders of the 2023 SIMCE results have names so long that a file inside them exceeds the
260-character path limit of Windows once the package sits in an ordinary folder. They are
`data/public/simce_schools/2023/4b` and `2023/2m` here, with their contents unchanged. On
Windows, keep the package in a folder whose own path is shorter than about 100 characters.

The register archives are RAR files of about 35 MB each; the scripts read them without
unpacking them by hand.

### Restricted, not included

The pupil-level SIMCE results and the parent questionnaires are released by the Agencia de
Calidad de la Educación to researchers on request. They carry the same masked pupil identifier
as the public enrolment register. `data/restricted/README.md` says which files are needed and
how to place them. No file in this package contains pupil-level SIMCE data.

Without the restricted files the package rebuilds Table 2 and Appendix Tables B1, B3, B4 and C1 to C6,
and Appendix Figure C1:

    python run_all.py --public-only

## Software

- **Stata** 17 or later, for steps 01 to 06. No user-written commands are needed.
- **Python** 3.10 or later with the packages of `requirements.txt`:

      python -m pip install -r requirements.txt

- A program that reads RAR5 archives, for step 20: the Python package `unrar-cffi`, or `tar`
  (bsdtar, shipped with Windows 10 and later and with macOS), or `7z`.

The results in `expected_tables/` were produced with StataNow 19 MP, Python 3.12, pandas 3.0,
numpy 2.4, scipy 1.18, pyfixest 0.70 and matplotlib 3.10 on Windows.

## Running

    python run_all.py

Stata is found from the environment variable `STATA_EXE`, from the PATH, or in the usual
installation folders. A step that has already run is skipped; `--force` runs everything
again, `--from 31` starts at a step, `--only 31 32` runs the steps named, `--list` lists them.
Logs are written to `work/logs/`.

Three environment variables move folders out of the package, which is the way to keep the
restricted files and everything built from them elsewhere:

| Variable | Folder | Default |
|---|---|---|
| `CHILE_RESTRICTED_DATA` | the Agencia pupil files | `data/restricted` |
| `CHILE_WORK_DIR` | intermediate files | `work` |
| `CHILE_OUTPUT_DIR` | tables and figures | `output` |

`work/pupil/` holds files built from the restricted pupil records. They are themselves
restricted and must not be shared. Everything under `output/` is aggregate.

## Steps

| Step | Script | Produces | Needs |
|---|---|---|---|
| 01 | `stata/01_ingest_simce.do` | School and commune SIMCE files stacked | public |
| 02 | `stata/02_ingest_enrollment.do` | Enrolment by school stacked | public |
| 03 | `stata/03_harmonize_communes.do` | Commune codes on the current coding | public |
| 04 | `stata/04_commune_panel.do` | Excluded communes; commune panel, grades 4 and 10 | public |
| 05 | `stata/05_commune_ses.do` | Socioeconomic composition of communes | public |
| 06 | `stata/06_market_dynamics.do` | **Appendix Tables C1, C2; Appendix Figure C1** | public |
| 10 | `10_commune_tables.py` | **Table 2; Appendix Tables B4, C3, C4, C5, C6**; the market crosswalk | public |
| 11 | `11_sector_tables.py` | **Appendix Tables B1, B3** | public |
| 20 | `20_register.py` | The enrolment register reduced to seven variables | public |
| 21 | `21_pupil_scores.py` | Pupil scores, one row per pupil | restricted |
| 22 | `22_parent_answers.py` | Parents' schooling and household income | restricted |
| 31 | `31_cohort_main.py` | **Table 3; Appendix Table D4** | restricted |
| 32 | `32_cohort_segments.py` | **Appendix Tables D1, D3** | restricted |
| 33 | `33_cohort_sectors_timing.py` | **Tables 4, 5; Figure 2; Appendix Figure D1** | restricted |
| 34 | `34_cohort_sample.py` | **Appendix Tables D2, D5** | restricted |
| 35 | `35_cohort_track.py` | **Appendix Table D6** | restricted |
| 41 | `41_lottery_tables.py` | **Table 6; Appendix Tables E1, E2** | restricted |
| 42 | `42_lottery_cohort.py` | **Table 7; Appendix Tables E3, E4** | restricted |
| 43 | `43_sample_descriptives.py` | **Table 1** | restricted |
| 90 | `90_compare_tables.py` | Comparison with `expected_tables/` | |

Appendix Table B2 lists reforms and Figure 1 is a drawing of the model; neither uses data.

`config.py` names the folders. `pupils.py` defines the starting cohorts, the markets, the main
specification and the pupil frames. `lotteries.py` reconstructs each applicant's first lottery
and fallback and holds the estimators of the lottery tables.

## Tables and files

| Table | File under `output/tables/` |
|---|---|
| 1 | `tab_sample_descriptives.tex` |
| 2 | `tab_hu_benchmark_commune.tex` |
| 3 | `tab_cohort_pupil_main.tex` |
| 4 | `tab_pupil_timing.tex` |
| 5 | `tab_pupil_selection.tex` |
| 6 | `tab_lottery_groups.tex` (Panel A), `tab_lottery_iv.tex` (Panels B to D) |
| 7 | `tab_lottery_cohort.tex` |
| B1, B3, B4 | `tab_sector_enrollment.tex`, `tab_sector_ses.tex`, `tab_sumstats_allgrades.tex` |
| C1, C2, C3 | `tab_market_dynamics_summary.tex`, `tab_market_dynamics_correlates.tex`, `tab_hu_horizons_commune.tex` |
| C4, C5, C6 | `tab_panel_allgrades.tex`, `tab_panel_era_allgrades.tex`, `tab_robust_oecd.tex` |
| D1, D2, D3, D4, D5, D6 | `tab_pupil_segments_pooled.tex`, `tab_pupil_sample.tex` (Panel A) and `tab_pupil_fuller.tex` (Panel B), `tab_pupil_bycohort.tex`, `tab_pupil_spec.tex`, `tab_pupil_bound.tex`, `tab_pupil_track.tex` |
| E1, E2, E3, E4 | `tab_lottery_balance.tex`, `tab_lottery_robust.tex`, `tab_lottery_kinds.tex`, `tab_lottery_eras.tex` |

Figure 2 is `output/figures/fig_fixed_cohort_sector10_math.png` and Appendix Figure D1
`fig_fixed_cohort_sector10_reading.png`; Appendix Figure C1 is `fig_market_dynamics_hist.png`.

## Units

Every coefficient of a score on a private share is reported per ten percentage points of
share. Lottery effects, differences between sectors and counts are in points per pupil.

## Checking the result

Step 90 compares each regenerated table body with the one in `expected_tables/`, ignoring line
endings, and prints every line that differs. On the computer on which the package was
assembled all 28 bodies were identical. Small differences in the last digit can arise with other
versions of the numerical libraries.

Appendix Table D5 draws residuals at random with a fixed seed (`34_cohort_sample.py`).

The figures are redrawn with the same points, lines and labels. The image files are not
identical byte for byte across computers, because fonts differ.

## Running times

The whole run took about 35 minutes on the desktop computer on which the package was
assembled, and needs about 5 GB of free disk space for intermediate files.

| Steps | Minutes |
|---|---|
| 01 to 06, Stata: ingestion, commune panel, Appendix C | 4 |
| 10, 11: commune and sector tables | 1 to 4 |
| 20: enrolment register | 9 |
| 21, 22: pupil scores and parent answers | 6 |
| 31 to 35: cohort tables and figures | 10 |
| 41, 42, 43: lottery tables and Table 1 | 3 |
