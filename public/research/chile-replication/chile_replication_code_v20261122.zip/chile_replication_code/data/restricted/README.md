# Restricted data: pupil-level SIMCE files

This folder is empty in the package. Steps 21 onward of `run_all.py` read the pupil-level files
of the Agencia de Calidad de la Educación, which the Agencia releases to researchers on request
(`informacionestadistica.agenciaeducacion.cl`, *bases de datos para investigación*). The request
must ask for the version that carries the masked pupil identifier `mrun`, which is the
identifier of the public enrolment register.

## Files needed

For each grade and year below, the folder as delivered by the Agencia:

| Grade | Years |
|---|---|
| 4 (`4b`) | 2005–2018, 2022–2024 |
| 6 (`6b`) | 2013–2016, 2018, 2024 |
| 8 (`8b`) | 2007, 2009, 2011, 2013–2015, 2017, 2019 |
| 10 (`2m`) | 2006, 2008, 2010, 2012–2018, 2022–2024 |

Two files of each folder are read:

- the pupil results, `simce<grade><year>_alu_...`, with `mrun`, `idalumno`, `rbd`, `cod_curso`
  and the scores `ptje_lect<grade>_alu` and `ptje_mate<grade>_alu`;
- the parent questionnaire, `simce<grade><year>_cpad_...`, keyed by `idalumno`. The grade-4
  questionnaires of 2005–2018 and 2022 are needed, and the later questionnaires listed in
  `code/22_parent_answers.py`.

## Layout

Place the delivered folders here unchanged, one per grade and year, each with its subfolder of
delimited text files:

    data/restricted/
      Simce cuarto básico 2005 - Versión privada/
        <subfolder>/
          simce4b2005_alu_....csv
          simce4b2005_cpad_....csv
      Simce segundo medio 2006 - Versión privada/
        ...

The scripts find the files by name (`simce4b2005_alu*`), two levels below this folder, so the
names of the folders themselves do not matter except for the grade-4 folders, which must begin
with `Simce cuarto` and contain the year.

To keep the files elsewhere, set the environment variable `CHILE_RESTRICTED_DATA` to the folder
that holds them, and `CHILE_WORK_DIR` to a folder for the intermediate files built from them.

## Confidentiality

The files hold records of individual pupils. They and every file under `work/pupil/` must stay
out of any shared folder or public repository. The tables and figures under `output/` are
aggregates.
