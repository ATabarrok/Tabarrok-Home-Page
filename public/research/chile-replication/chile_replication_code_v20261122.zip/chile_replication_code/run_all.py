"""Run the replication from the raw files to the tables and figures of the paper.

Usage
    python run_all.py                  run every step that has not been run
    python run_all.py --force          run every step again
    python run_all.py --from 31        start at a given step
    python run_all.py --only 31 32     run the steps named
    python run_all.py --public-only    stop before the steps that need the restricted pupil files
    python run_all.py --list           list the steps

Steps 01 to 06 need Stata. The executable is taken from the environment variable STATA_EXE,
or found on the PATH, or in the usual installation folders. Steps 20 onward need the restricted
pupil files of the Agencia de Calidad de la Educacion (see data/restricted/README.md).

A step is skipped when its marker file exists. Logs are written to <work>/logs. See README.md
for the table produced by each step and for running times.
"""

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CODE = ROOT / "code"
sys.path.insert(0, str(CODE))
import config as cfg  # noqa: E402

LOGS = cfg.WORK / "logs"
D, T, PU = cfg.DERIVED, cfg.TABLES, cfg.PUPIL
# (step, script, marker that shows the step has run, needs restricted files, isolated)
STEPS = [
    ("01", "stata/01_ingest_simce.do", LOGS / "01.done", False, False),
    ("02", "stata/02_ingest_enrollment.do", LOGS / "02.done", False, False),
    ("03", "stata/03_harmonize_communes.do", LOGS / "03.done", False, False),
    ("04", "stata/04_commune_panel.do", D / "panel_full.dta", False, False),
    ("05", "stata/05_commune_ses.do", D / "panel_full_ses.dta", False, False),
    ("06", "stata/06_market_dynamics.do", T / "tab_market_dynamics_correlates.tex", False, False),
    ("10", "10_commune_tables.py", T / "tab_robust_oecd.tex", False, False),
    ("11", "11_sector_tables.py", T / "tab_sector_ses.tex", False, False),
    ("20", "20_register.py", cfg.REGISTER / "m2024.pkl", False, False),
    ("21", "21_pupil_scores.py", PU / "scores_2m_2024.pkl", True, False),
    ("22", "22_parent_answers.py", PU / "parents_later_2m_2023.pkl", True, False),
    ("31", "31_cohort_main.py", T / "tab_pupil_spec.tex", True, False),
    ("32", "32_cohort_segments.py", T / "tab_pupil_bycohort.tex", True, False),
    ("33", "33_cohort_sectors_timing.py", cfg.FIGURES / "fig_fixed_cohort_sector10_reading.png", True, False),
    ("34", "34_cohort_sample.py", T / "tab_pupil_bound.tex", True, False),
    ("35", "35_cohort_track.py", T / "tab_pupil_track.tex", True, False),
    ("41", "41_lottery_tables.py", T / "tab_lottery_robust.tex", True, True),
    ("42", "42_lottery_cohort.py", T / "tab_lottery_eras.tex", True, True),
    ("43", "43_sample_descriptives.py", T / "tab_sample_descriptives.tex", True, True),
    ("90", "90_compare_tables.py", None, False, False),
]


def stata_exe():
    exe = os.environ.get("STATA_EXE")
    if exe:
        return exe
    for name in ("stata-mp", "stata-se", "stata", "StataMP-64", "StataSE-64", "StataBE-64"):
        if shutil.which(name):
            return shutil.which(name)
    for base in (Path("C:/Program Files"), Path("/usr/local"), Path("/Applications")):
        for hit in sorted(base.glob("Stata*/Stata*-64.exe")) + sorted(base.glob("stata*/stata-*")) + sorted(base.glob("Stata*/Stata*.app/Contents/MacOS/stata-*")):
            return str(hit)
    raise SystemExit("Stata not found. Set the environment variable STATA_EXE to the Stata executable.")


def run_stata(script, log):
    """Batch mode writes <script>.log into the working folder, so Stata is started in a folder of its own."""
    env = dict(os.environ, CHILE_CODE_DIR=str(CODE / "stata"), CHILE_WORK_DIR=str(cfg.WORK), CHILE_OUTPUT_DIR=str(cfg.OUTPUT))
    exe = stata_exe()
    flag = "/e" if exe.lower().endswith(".exe") else "-b"
    batch = LOGS / "stata_batch"
    batch.mkdir(parents=True, exist_ok=True)
    r = subprocess.run([exe, flag, "do", str(script)], cwd=batch, env=env)
    log = batch / log.name
    text = log.read_text(encoding="utf-8", errors="replace") if log.exists() else ""
    last = text.strip().splitlines()[-1] if text.strip() else ""
    failed = r.returncode != 0 or last.startswith("r(") or not text
    return 1 if failed else 0


def main(argv):
    if "--list" in argv:
        for num, script, _, restricted, _ in STEPS:
            print(f"{num}  {script}{'   (restricted pupil files)' if restricted else ''}")
        return
    force = "--force" in argv
    start = argv[argv.index("--from") + 1] if "--from" in argv else None
    only = argv[argv.index("--only") + 1:] if "--only" in argv else None
    cfg.make_dirs()
    LOGS.mkdir(parents=True, exist_ok=True)
    started = start is None
    for num, script, marker, restricted, isolated in STEPS:
        if only is not None and num not in only:
            continue
        if not started:
            started = num == start
            if not started:
                continue
        if restricted and "--public-only" in argv:
            print(f"{num}  skipped (needs the restricted pupil files)")
            continue
        if marker is not None and marker.exists() and not force and start is None and only is None:
            print(f"{num}  skipped (already run)")
            continue
        print(f"{num}  running {script} ...", flush=True)
        t0 = time.time()
        path = CODE / script
        if script.endswith(".do"):
            code = run_stata(path, LOGS / (path.stem + ".log"))
            if code == 0 and marker is not None and marker.suffix == ".done":
                marker.write_text("done\n")
        else:
            with open(LOGS / (path.stem + ".log"), "w", encoding="utf-8") as fh:
                cmd = [sys.executable] + (["-I"] if isolated else []) + [str(path)]
                code = subprocess.run(cmd, cwd=CODE, stdout=fh, stderr=subprocess.STDOUT).returncode
        if code != 0:
            raise SystemExit(f"    FAILED after {time.time() - t0:.0f}s. See {LOGS / (path.stem + '.log')}")
        print(f"    done in {time.time() - t0:.0f}s", flush=True)
    print("Finished.")


if __name__ == "__main__":
    main(sys.argv[1:])
